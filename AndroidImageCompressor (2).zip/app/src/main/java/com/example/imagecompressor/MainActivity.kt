package com.example.imagecompressor

import android.content.Intent
import android.app.Activity
import android.view.WindowManager
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.expandIn
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.shrinkOut
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.filled.MenuOpen
import androidx.compose.material.icons.outlined.ViewSidebar
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.unit.IntSize
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.EnhancedEncryption
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Password
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.EnhancedEncryption
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.FolderZip
import androidx.compose.material.icons.outlined.LockOpen
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Transform
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.VerticalDivider
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Colorize
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material3.Typography
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.PointerEventPass
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sign
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.sp
import kotlin.math.hypot
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.core.util.Consumer
import androidx.documentfile.provider.DocumentFile
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.size.Precision
import kotlinx.coroutines.delay
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * FlClash 物理果冻弹簧常量 + Apple Liquid Glass 液态玻璃二级展开动效参数
 */
private const val JELLY_DAMPING = 0.44f
private const val PAGE_SPRING_DAMPING = 0.58f
private const val JELLY_STIFFNESS = 350f

/**
 * Apple 液态玻璃二级弹出菜单枚举：
 * 点击任意一级按钮后，以果冻弹簧展开对应的第二层液态玻璃面板；点击任意空白区域自动缩回按钮本身
 */
private enum class LiquidGlassLayer2Menu {
    NONE,
    FORMAT_PICKER,           // 输出格式二级面板
    QUALITY_SLIDER,          // 画质百分比二级面板
    PRIVACY_AND_RENAME,      // EXIF 隐私抹除与批量重命名二级面板
    DIRECT_ARCHIVE_PACK,     // 直接压入压缩包与加密密码二级面板
    OBFUSCATION_KEY,         // 加密/还原文字口令二级面板
    BLOCK_GRID_PICKER,       // 色块粒度与文件名标记二级面板
    ARCHIVE_SUBMODE,         // 归档打包/解压模式二级面板
    ARCHIVE_FORMAT_LEVEL,    // 归档格式与压缩等级二级面板
    ARCHIVE_PASSWORD_NAMING, // 归档加密密码与包名二级面板
    FAB_QUICK_HUB,           // 右下角液态玻璃快捷菜单（选图/导入包/打开阅读器/分享/清空）
    READER_CONTROL_PANEL     // 阅读器液态玻璃二级控制面板（条漫/翻页、密码解锁、口令实时还原）
}

/**
 * Open Claude UI (https://github.com/Caho1/open-claude-ui) — Claude Design System (CDS) 核心色彩令牌
 * 遵循 Editorial Warmth（暖白纸感 / 暖炭墨色）4 级表面阶梯与 #D97757 陶土橙主色规范
 */
/**
 * 1:1 复刻 FlClash-0.9.1 全局主题状态上下文 (lib/models/config.dart -> ThemeProps)
 */
val LocalFlClashThemeProps = compositionLocalOf { FlClashThemeProps() }

@Composable
private fun isFlClashDarkTheme(): Boolean {
    val themeMode = LocalFlClashThemeProps.current.themeMode
    val sysDark = isSystemInDarkTheme()
    return when (themeMode) {
        FlClashThemeMode.SYSTEM -> sysDark
        FlClashThemeMode.LIGHT -> false
        FlClashThemeMode.DARK -> true
    }
}

/**
 * 1:1 复刻 FlClash-0.9.1 物理阻尼常量 (lib/ui/navigation_dock.dart lines 20-106):
 * - _pressGrowth = 1/8 (0.125f), _maxPressGrowth = 16dp
 * - _pullLimit = 7/32 (0.21875f), _pullStretch = 0.5f
 * - _lensGrowth = 8dp, _lensMagnify = 0.16f
 * - _jellySpeed = 3f, _jellyStretch = 0.20f, _jellyBrake = 25f, _jellySquash = 0.15f, _jellyAspect = 1.4f
 * - _pressSpring: stiffness = 311f, ratio = 0.593f
 * - _followSpring: stiffness = 1024f, ratio = 0.90f
 * - _jellySpring: stiffness = 100f, ratio = 0.40f
 */
private const val FLCLASH_PRESS_STIFFNESS = 311f
private const val FLCLASH_PRESS_DAMPING = 0.593f
private const val FLCLASH_FOLLOW_STIFFNESS = 1024f
private const val FLCLASH_FOLLOW_DAMPING = 0.90f
private const val FLCLASH_TRAVEL_STIFFNESS = 380f
private const val FLCLASH_TRAVEL_DAMPING = 0.72f
private const val FLCLASH_JELLY_STIFFNESS = 100f
private const val FLCLASH_JELLY_DAMPING = 0.40f
private const val FLCLASH_PULL_LIMIT = 7f / 32f
private const val FLCLASH_PULL_STRETCH = 0.50f
private const val FLCLASH_OVERDRAG = 0.35f
private const val FLCLASH_LENS_MAGNIFY = 0.16f
private const val FLCLASH_JELLY_STRETCH = 0.20f
private const val FLCLASH_JELLY_SQUASH = 0.15f
private const val FLCLASH_JELLY_ASPECT = 1.40f

/**
 * FlClash-0.9.1 lib/ui/navigation_dock.dart line 100: _rubberBand(overshoot, limit)
 */
private fun flClashRubberBand(overshoot: Float, limit: Float): Float {
    if (limit <= 0.001f || overshoot == 0f) return 0f
    val pull = 1f - 1f / (abs(overshoot) * 0.55f / limit + 1f)
    return limit * pull * sign(overshoot)
}

/**
 * FlClash-0.9.1 lib/ui/navigation_dock.dart line 105: _saturate(value)
 */
private fun flClashSaturate(value: Float): Float {
    val clamped = value.coerceIn(-10f, 10f)
    return 1f - 2f / (exp(2f * clamped) + 1f)
}

/**
 * 1:1 复刻 FlClash-0.9.1 lib/ui/surface.dart & .agents/surfaces.md 四级表面阶梯:
 * - page:  Light = surfaceContainer (Tone 94), Dark = surface (Tone 6 / PureBlack 0)
 * - card:  Light = surfaceBright (Tone 98),    Dark = surfaceContainer (Tone 12)
 * - block: Light = surfaceContainer (Tone 94), Dark = surfaceContainerHigh (Tone 17)
 * - inset: Light = surfaceContainerHighest,    Dark = surfaceContainerHighest (Tone 22)
 */
enum class FlClashSurfaceLevel {
    PAGE,
    CARD,
    BLOCK,
    INSET;

    fun colorOf(colorScheme: androidx.compose.material3.ColorScheme, isDark: Boolean): Color {
        return when (this) {
            PAGE -> if (isDark) colorScheme.background else colorScheme.surfaceContainer
            CARD -> if (isDark) colorScheme.surfaceContainerLow else colorScheme.surfaceContainerHigh
            BLOCK -> if (isDark) colorScheme.surfaceContainerHigh else colorScheme.surfaceContainer
            INSET -> colorScheme.surfaceContainerHighest
        }
    }
}

/**
 * 1:1 复刻 FlClash-0.9.1 lib/ui/color.dart: seededColorScheme + toPureBlack
 * 支持 Vivid（鲜艳）、Tinted（浸染）、Soft（柔和）、Monochrome（单色）4种色彩风格及纯黑模式
 */
private fun buildFlClashSeededColorScheme(
    seedColor: Color,
    darkTheme: Boolean,
    style: FlClashColorStyle,
    pureBlack: Boolean
): androidx.compose.material3.ColorScheme {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(seedColor.toArgb(), hsv)
    val seedHue = hsv[0]
    val seedSat = hsv[1]
    val seedVal = hsv[2]

    // 计算主色 (_accent in lib/ui/color.dart lines 155-175)
    val primaryColor: Color
    val onPrimaryColor: Color
    val primaryContainerColor: Color
    val onPrimaryContainerColor: Color

    when (style) {
        FlClashColorStyle.MONOCHROME -> {
            primaryColor = if (darkTheme) Color(0xFFF2F2F6) else Color(0xFF161618)
            onPrimaryColor = if (darkTheme) Color(0xFF141416) else Color.White
            primaryContainerColor = if (darkTheme) Color(0xFF2C2C30) else Color(0xFFE4E4E8)
            onPrimaryContainerColor = if (darkTheme) Color(0xFFF0F0F4) else Color(0xFF1C1C20)
        }
        FlClashColorStyle.SOFT -> {
            val softSat = (seedSat * 0.55f).coerceIn(0.18f, 0.55f)
            val softVal = if (darkTheme) 0.86f else 0.68f
            primaryColor = Color.hsv(seedHue, softSat, softVal)
            onPrimaryColor = if (darkTheme) Color.hsv(seedHue, softSat * 0.8f, 0.14f) else Color.White
            primaryContainerColor = if (darkTheme) {
                Color.hsv(seedHue, (softSat * 0.65f).coerceAtMost(0.48f), 0.30f)
            } else {
                Color.hsv(seedHue, (softSat * 0.35f).coerceAtMost(0.28f), 0.94f)
            }
            onPrimaryContainerColor = if (darkTheme) {
                Color.hsv(seedHue, 0.20f, 0.94f)
            } else {
                Color.hsv(seedHue, 0.75f, 0.26f)
            }
        }
        FlClashColorStyle.VIVID, FlClashColorStyle.TINTED -> {
            // Light holds seed tone between 35 and 60; Dark lifts +3 tones within 50..75
            val vividSat = seedSat.coerceIn(0.45f, 0.92f)
            val vividVal = if (darkTheme) {
                (seedVal + 0.08f).coerceIn(0.72f, 0.96f)
            } else {
                seedVal.coerceIn(0.55f, 0.88f)
            }
            primaryColor = if (!darkTheme && seedVal in 0.50f..0.95f) {
                seedColor
            } else {
                Color.hsv(seedHue, vividSat, vividVal)
            }
            val luma = 0.2126f * primaryColor.red + 0.7152f * primaryColor.green + 0.0722f * primaryColor.blue
            onPrimaryColor = if (luma > 0.62f) Color(0xFF101216) else Color.White
            primaryContainerColor = if (darkTheme) {
                Color.hsv(seedHue, (seedSat * 0.68f).coerceAtMost(0.58f), 0.30f)
            } else {
                Color.hsv(seedHue, (seedSat * 0.22f).coerceAtMost(0.24f), 0.94f)
            }
            onPrimaryContainerColor = if (darkTheme) {
                Color.hsv(seedHue, (seedSat * 0.24f).coerceAtMost(0.26f), 0.94f)
            } else {
                Color.hsv(seedHue, (seedSat * 0.82f).coerceAtMost(0.85f), 0.28f)
            }
        }
    }

    // 计算表面色 (Surfaces stay near gray unless Tinted; toPureBlack shifts dark surfaces)
    val surfaceSat = when (style) {
        FlClashColorStyle.TINTED -> (seedSat * 0.16f).coerceAtMost(0.14f)
        FlClashColorStyle.MONOCHROME -> 0f
        else -> (seedSat * 0.025f).coerceAtMost(0.025f)
    }

    fun surfaceTone(lightV: Float, darkV: Float): Color {
        val v = if (darkTheme) darkV else lightV
        return Color.hsv(seedHue, surfaceSat, v.coerceIn(0f, 1f))
    }

    // FlClash-0.9.1 Fixed Success (Green) & Warning (Orange) & Destructive (iOS 27 SystemRed)
    val successColor = if (darkTheme) Color(0xFF4ADE80) else Color(0xFF1E8E3E)
    val successContainer = if (darkTheme) Color(0xFF13311E) else Color(0xFFDFF5E5)
    val onSuccessContainer = if (darkTheme) Color(0xFFB8F3C8) else Color(0xFF0D461D)
    val destructiveColor = if (darkTheme) Color(0xFFFF4245) else Color(0xFFFF383C)

    return if (darkTheme) {
        val pageBg = if (pureBlack) Color.Black else surfaceTone(0.95f, 0.07f)          // Tone 6: page
        val cardBg = if (pureBlack) surfaceTone(0.98f, 0.08f) else surfaceTone(0.98f, 0.125f) // Tone 12: card
        val blockBg = if (pureBlack) surfaceTone(0.94f, 0.13f) else surfaceTone(0.94f, 0.175f) // Tone 17: block
        val insetBg = if (pureBlack) surfaceTone(0.90f, 0.18f) else surfaceTone(0.90f, 0.23f)  // Tone 22: inset
        darkColorScheme(
            primary = primaryColor,
            onPrimary = onPrimaryColor,
            primaryContainer = primaryContainerColor,
            onPrimaryContainer = onPrimaryContainerColor,
            secondary = Color.hsv(seedHue, (seedSat * 0.35f).coerceAtMost(0.35f), 0.78f),
            onSecondary = Color(0xFF141519),
            secondaryContainer = blockBg,
            onSecondaryContainer = Color(0xFFECECF0),
            tertiary = successColor,
            onTertiary = Color(0xFF082912),
            tertiaryContainer = successContainer,
            onTertiaryContainer = onSuccessContainer,
            error = destructiveColor,
            errorContainer = Color(0xFF3B1416),
            onErrorContainer = Color(0xFFFFB3B4),
            background = pageBg,
            onBackground = Color(0xFFF2F2F6),
            surface = pageBg,
            onSurface = Color(0xFFF2F2F6),
            surfaceVariant = blockBg,
            onSurfaceVariant = Color(0xFF9E9FA8),
            surfaceContainerLowest = if (pureBlack) Color.Black else surfaceTone(1f, 0.045f),
            surfaceContainerLow = cardBg,
            surfaceContainer = blockBg,
            surfaceContainerHigh = blockBg,
            surfaceContainerHighest = insetBg,
            outline = Color(0xFF686972),
            outlineVariant = Color(0xFFF2F2F6).copy(alpha = 0.14f)
        )
    } else {
        // Light mode: page = Tone 94 (#F0F1F5), card = Tone 98 (#FAF9FC), block = Tone 94, inset = Tone 90 (#E4E5EA)
        val pageBg = surfaceTone(0.945f, 0.07f)
        val cardBg = Color.hsv(seedHue, surfaceSat * 0.5f, 0.988f)
        val blockBg = surfaceTone(0.942f, 0.17f)
        val insetBg = surfaceTone(0.900f, 0.22f)
        lightColorScheme(
            primary = primaryColor,
            onPrimary = onPrimaryColor,
            primaryContainer = primaryContainerColor,
            onPrimaryContainer = onPrimaryContainerColor,
            secondary = Color.hsv(seedHue, (seedSat * 0.35f).coerceAtMost(0.35f), 0.42f),
            onSecondary = Color.White,
            secondaryContainer = blockBg,
            onSecondaryContainer = Color(0xFF18191E),
            tertiary = successColor,
            onTertiary = Color.White,
            tertiaryContainer = successContainer,
            onTertiaryContainer = onSuccessContainer,
            error = destructiveColor,
            errorContainer = Color(0xFFFFE5E6),
            onErrorContainer = Color(0xFF690005),
            background = pageBg,
            onBackground = Color(0xFF15161A),
            surface = pageBg,
            onSurface = Color(0xFF15161A),
            surfaceVariant = blockBg,
            onSurfaceVariant = Color(0xFF5E6068),
            surfaceContainerLowest = Color.White,
            surfaceContainerLow = cardBg,
            surfaceContainer = pageBg,
            surfaceContainerHigh = cardBg,
            surfaceContainerHighest = insetBg,
            outline = Color(0xFF8E8E93),
            outlineVariant = Color(0xFF15161A).copy(alpha = 0.14f)
        )
    }
}

@Composable
fun FlClashM3Theme(
    themeProps: FlClashThemeProps = FlClashThemeProps(),
    useDynamicColor: Boolean = themeProps.primaryColor == null,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val systemDark = isSystemInDarkTheme()
    val darkTheme = when (themeProps.themeMode) {
        FlClashThemeMode.SYSTEM -> systemDark
        FlClashThemeMode.LIGHT -> false
        FlClashThemeMode.DARK -> true
    }

    val effectiveSeedColor = when {
        themeProps.primaryColor != null -> Color(themeProps.primaryColor)
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (darkTheme) dynamicDarkColorScheme(context).primary else dynamicLightColorScheme(context).primary
        }
        else -> Color(FlClashThemeProps.DEFAULT_PRIMARY_COLOR)
    }

    val colorScheme = remember(effectiveSeedColor, darkTheme, themeProps.colorStyle, themeProps.pureBlack) {
        buildFlClashSeededColorScheme(
            seedColor = effectiveSeedColor,
            darkTheme = darkTheme,
            style = themeProps.colorStyle,
            pureBlack = themeProps.pureBlack
        )
    }

    val flClashTypography = remember(darkTheme) {
        val titleWeight = FontWeight.SemiBold
        val bodyWeight = FontWeight.Medium
        Typography(
            headlineSmall = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp,
                lineHeight = 28.sp,
                letterSpacing = (-0.4).sp
            ),
            titleLarge = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Bold,
                fontSize = 19.sp,
                lineHeight = 24.sp,
                letterSpacing = (-0.3).sp
            ),
            titleMedium = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontWeight = titleWeight,
                fontSize = 16.sp,
                lineHeight = 22.sp,
                letterSpacing = (-0.2).sp
            ),
            titleSmall = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontWeight = titleWeight,
                fontSize = 14.sp,
                lineHeight = 19.sp
            ),
            bodyMedium = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontWeight = bodyWeight,
                fontSize = 14.sp,
                lineHeight = 20.sp
            ),
            bodySmall = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Normal,
                fontSize = 12.sp,
                lineHeight = 16.sp
            ),
            labelLarge = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontWeight = titleWeight,
                fontSize = 13.sp,
                lineHeight = 18.sp
            ),
            labelMedium = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontWeight = bodyWeight,
                fontSize = 12.sp,
                lineHeight = 16.sp
            ),
            labelSmall = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontWeight = bodyWeight,
                fontSize = 11.sp,
                lineHeight = 14.5.sp
            )
        )
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val activityWindow = (view.context as? Activity)?.window ?: return@SideEffect
            activityWindow.statusBarColor = android.graphics.Color.TRANSPARENT
            activityWindow.navigationBarColor = android.graphics.Color.TRANSPARENT
            val insetsController = WindowCompat.getInsetsController(activityWindow, view)
            insetsController.isAppearanceLightStatusBars = !darkTheme
            insetsController.isAppearanceLightNavigationBars = !darkTheme
        }
    }

    CompositionLocalProvider(LocalFlClashThemeProps provides themeProps) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = flClashTypography,
            content = content
        )
    }
}

/**
 * 7 控制点非线性滚动渐隐遮罩 (冷启动 0 离屏帧缓冲分配优化)
 */
private val CDS_SEVEN_STOP_FADE = arrayOf(
    0.00f to Color.Transparent,
    0.15f to Color.Black.copy(alpha = 0.05f),
    0.30f to Color.Black.copy(alpha = 0.15f),
    0.50f to Color.Black.copy(alpha = 0.35f),
    0.70f to Color.Black.copy(alpha = 0.65f),
    0.85f to Color.Black.copy(alpha = 0.85f),
    1.00f to Color.Black
)

private val CDS_SEVEN_STOP_FADE_REVERSED = arrayOf(
    0.00f to Color.Black,
    0.15f to Color.Black.copy(alpha = 0.85f),
    0.30f to Color.Black.copy(alpha = 0.65f),
    0.50f to Color.Black.copy(alpha = 0.35f),
    0.70f to Color.Black.copy(alpha = 0.15f),
    0.85f to Color.Black.copy(alpha = 0.05f),
    1.00f to Color.Transparent
)

private fun Modifier.cdsSevenStopScrollFadeMask(
    topFadeHeight: Dp = 22.dp,
    bottomFadeHeight: Dp = 30.dp,
    showTopFade: Boolean = true,
    showBottomFade: Boolean = true
): Modifier = if (!showTopFade && !showBottomFade) {
    this
} else {
    this
        .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
        .drawWithContent {
            drawContent()
            val topPx = topFadeHeight.toPx().coerceAtMost(size.height * 0.25f)
            val bottomPx = bottomFadeHeight.toPx().coerceAtMost(size.height * 0.25f)
            if (showTopFade && topPx > 1f) {
                drawRect(
                    brush = Brush.verticalGradient(
                        colorStops = CDS_SEVEN_STOP_FADE,
                        startY = 0f,
                        endY = topPx
                    ),
                    topLeft = Offset.Zero,
                    size = Size(size.width, topPx),
                    blendMode = BlendMode.DstIn
                )
            }
            if (showBottomFade && bottomPx > 1f) {
                val startY = (size.height - bottomPx).coerceAtLeast(0f)
                drawRect(
                    brush = Brush.verticalGradient(
                        colorStops = CDS_SEVEN_STOP_FADE_REVERSED,
                        startY = startY,
                        endY = size.height
                    ),
                    topLeft = Offset(0f, startY),
                    size = Size(size.width, bottomPx),
                    blendMode = BlendMode.DstIn
                )
            }
        }
}

/**
 * 状态指示圆点（冷启动空闲时静态渲染，激活/运行中脉冲）
 */
@Composable
private fun CdsStatusBreathingDot(
    isActive: Boolean,
    isBusy: Boolean = false,
    modifier: Modifier = Modifier
) {
    val dotColor = when {
        isBusy -> MaterialTheme.colorScheme.primary
        isActive -> MaterialTheme.colorScheme.tertiary
        else -> MaterialTheme.colorScheme.outline
    }
    if (!isActive && !isBusy) {
        Box(
            modifier = modifier
                .size(8.dp)
                .graphicsLayer { alpha = 0.55f }
                .clip(CircleShape)
                .background(dotColor)
        )
        return
    }
    val infiniteTransition = rememberInfiniteTransition(label = "AppStatusDot")
    val durationMs = if (isBusy) 1000 else 2200
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.42f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = durationMs, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "AppPulseAlpha"
    )
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = if (isBusy) 1.24f else 1.10f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = durationMs, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "AppPulseScale"
    )
    Box(
        modifier = modifier
            .size(8.dp)
            .graphicsLayer {
                scaleX = pulseScale
                scaleY = pulseScale
                alpha = pulseAlpha
            }
            .clip(CircleShape)
            .background(dotColor)
    )
}

/**
 * 1:1 复刻 FlClash-0.9.1 ElasticPress + _RenderPressTransform + LiquidGlassGlow (lib/ui/navigation_dock.dart lines 423-747):
 * - 按下时膨胀抬升 (_lift: stiffness = 311, ratio = 0.593, swell = 1 + lift * min(0.25, 16dp / longestSide))
 * - 按住拖动时沿手指方向发生橡皮筋拉伸与位移形变 (_pullX, _pullY: _rubberBand(pull, shortestSide * 7/32),
 *   scaleX = swell * (1 + |pull.dx| / width * 0.5), scaleY = swell * (1 + |pull.dy| / height * 0.5))
 * - 快速点击若未升至顶峰则先升满再回落 (_liftSnap = 0.975)
 * - 按压处投射 LiquidGlassGlow 指尖径向高光与边缘折射高光
 */
private fun Modifier.flClashJellyClick(
    enabled: Boolean = true,
    pressScale: Float = 1.0f,
    shape: Shape = RoundedCornerShape(18.dp),
    onClick: () -> Unit
): Modifier = composed {
    val coroutineScope = rememberCoroutineScope()
    var boxWidthPx by remember { mutableIntStateOf(0) }
    var boxHeightPx by remember { mutableIntStateOf(0) }
    var isHolding by remember { mutableStateOf(false) }
    var rawPullX by remember { mutableFloatStateOf(0f) }
    var rawPullY by remember { mutableFloatStateOf(0f) }
    var touchCenter by remember { mutableStateOf(Offset.Zero) }

    // FlClash _pressSpring (stiffness = 311f, ratio = 0.593f)
    val animatedLift by animateFloatAsState(
        targetValue = if (enabled && isHolding) 1f else 0f,
        animationSpec = spring(
            dampingRatio = FLCLASH_PRESS_DAMPING,
            stiffness = FLCLASH_PRESS_STIFFNESS
        ),
        label = "AppElasticLift"
    )

    // FlClash _trackSpring while dragging (120ms), _pressSpring on release
    val animatedPullX by animateFloatAsState(
        targetValue = if (enabled && isHolding) rawPullX else 0f,
        animationSpec = spring(
            dampingRatio = if (isHolding) 0.85f else FLCLASH_PRESS_DAMPING,
            stiffness = if (isHolding) 850f else FLCLASH_PRESS_STIFFNESS
        ),
        label = "AppElasticPullX"
    )
    val animatedPullY by animateFloatAsState(
        targetValue = if (enabled && isHolding) rawPullY else 0f,
        animationSpec = spring(
            dampingRatio = if (isHolding) 0.85f else FLCLASH_PRESS_DAMPING,
            stiffness = if (isHolding) 850f else FLCLASH_PRESS_STIFFNESS
        ),
        label = "AppElasticPullY"
    )

    val maxGrowthPx = with(LocalDensity.current) { 16.dp.toPx() }
    val glowReachPx = with(LocalDensity.current) { 64.dp.toPx() }

    this
        .onSizeChanged {
            boxWidthPx = it.width
            boxHeightPx = it.height
        }
        .graphicsLayer {
            if (animatedLift > 0.001f || abs(animatedPullX) > 0.05f || abs(animatedPullY) > 0.05f) {
                val w = size.width.coerceAtLeast(1f)
                val h = size.height.coerceAtLeast(1f)
                val longest = max(w, h)
                // FlClash _RenderPressTransform._transform (navigation_dock.dart lines 720-729):
                val swell = 1f + animatedLift * min(0.22f, maxGrowthPx / longest)
                val sx = swell * (1f + (abs(animatedPullX) / w) * FLCLASH_PULL_STRETCH)
                val sy = swell * (1f + (abs(animatedPullY) / h) * FLCLASH_PULL_STRETCH)
                scaleX = sx
                scaleY = sy
                translationX = animatedPullX
                translationY = animatedPullY
            }
        }
        .clip(shape)
        .drawWithContent {
            drawContent()
            // FlClash LiquidGlassGlow: 按住或拖动时在指尖投射柔和径向高光与边缘折射
            if (animatedLift > 0.01f) {
                val center = if (touchCenter == Offset.Zero) {
                    Offset(size.width / 2f, size.height / 2f)
                } else {
                    Offset(
                        touchCenter.x + animatedPullX * 0.5f,
                        touchCenter.y + animatedPullY * 0.5f
                    )
                }
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.22f * animatedLift),
                            Color.White.copy(alpha = 0.06f * animatedLift),
                            Color.Transparent
                        ),
                        center = center,
                        radius = glowReachPx.coerceAtLeast(size.maxDimension * 0.65f)
                    )
                )
            }
        }
        .pointerInput(enabled, boxWidthPx, boxHeightPx) {
            if (!enabled) return@pointerInput
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                val origin = down.position
                touchCenter = origin
                rawPullX = 0f
                rawPullY = 0f
                isHolding = true
                val shortestSide = min(boxWidthPx, boxHeightPx).toFloat().coerceAtLeast(48f)
                val pullLimitPx = shortestSide * FLCLASH_PULL_LIMIT

                do {
                    val event = awaitPointerEvent(pass = PointerEventPass.Initial)
                    val change = event.changes.firstOrNull { it.id == down.id } ?: event.changes.firstOrNull() ?: break
                    if (change.pressed) {
                        touchCenter = change.position
                        val dx = change.position.x - origin.x
                        val dy = change.position.y - origin.y
                        rawPullX = flClashRubberBand(dx, pullLimitPx)
                        rawPullY = flClashRubberBand(dy, pullLimitPx)
                    }
                } while (event.changes.any { it.pressed })

                rawPullX = 0f
                rawPullY = 0f
                // FlClash _settle: 快速点击松手时保持短暂膨胀脉冲再回弹，手感饱满不生硬
                coroutineScope.launch {
                    delay(85L)
                    isHolding = false
                }
            }
        }
        .clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null,
            enabled = enabled,
            onClick = onClick
        )
}

/**
 * 1:1 复刻 FlClash-0.9.1 CommonCard / DashboardCard + LiquidGlassStyle.regular / tinted:
 * - 未选中时遵循 .agents/surfaces.md：纯色阶提升（SurfaceLevel.CARD），无杂乱重边框，配有细腻液态玻璃顶底镜面高光弧 (shineAround)
 * - 选中/高亮时遵循 LiquidGlassStyle.tinted：投射主色光晕 + 1.2dp 液态玻璃镜面边缘高光 + 顶部柔光折射
 */
@Composable
private fun LiquidGlassSurfaceCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 22.dp,
    isHighlighted: Boolean = false,
    containerColor: Color = if (isHighlighted) {
        MaterialTheme.colorScheme.surfaceContainerHigh
    } else {
        MaterialTheme.colorScheme.surfaceContainerLow
    },
    content: @Composable () -> Unit
) {
    val themeProps = LocalFlClashThemeProps.current
    val glassEnabled = themeProps.liquidGlass != FlClashLiquidGlassMode.NONE
    val primaryColor = MaterialTheme.colorScheme.primary
    val onSurfaceColor = MaterialTheme.colorScheme.onSurface
    val isDark = isFlClashDarkTheme()

    val borderStroke = remember(isHighlighted, glassEnabled, primaryColor, onSurfaceColor, isDark) {
        when {
            isHighlighted -> BorderStroke(
                width = 1.3.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = if (isDark) 0.55f else 0.85f),
                        primaryColor.copy(alpha = 0.72f),
                        primaryColor.copy(alpha = 0.45f),
                        Color.White.copy(alpha = if (isDark) 0.35f else 0.65f)
                    )
                )
            )
            glassEnabled -> BorderStroke(
                width = 0.67.dp, // kLine = 0.67 in shaders/liquid_glass.frag
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = if (isDark) 0.22f else 0.65f),
                        onSurfaceColor.copy(alpha = 0.08f),
                        Color.White.copy(alpha = if (isDark) 0.14f else 0.42f)
                    )
                )
            )
            else -> BorderStroke(0.dp, Color.Transparent)
        }
    }

    OutlinedCard(
        shape = RoundedCornerShape(cornerRadius),
        colors = CardDefaults.outlinedCardColors(containerColor = containerColor),
        border = borderStroke,
        elevation = CardDefaults.outlinedCardElevation(
            defaultElevation = if (isHighlighted) 4.dp else 0.dp
        ),
        modifier = modifier.drawWithContent {
            drawContent()
            // 选中或开启液态玻璃时，在卡片顶部边缘绘制 FlClash shaders/liquid_glass.frag 的顶面镜面高光带 (facing = rise2)
            if (isHighlighted) {
                drawRoundRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = if (isDark) 0.16f else 0.34f),
                            primaryColor.copy(alpha = 0.08f),
                            Color.Transparent
                        ),
                        startY = 0f,
                        endY = size.height * 0.48f
                    ),
                    cornerRadius = CornerRadius(cornerRadius.toPx(), cornerRadius.toPx())
                )
            }
        }
    ) {
        content()
    }
}

/**
 * 1:1 复刻 FlClash-0.9.1 一级控制砖块 (DashboardBlock + LiquidGlassStyle.tinted 选中高光 + ElasticPress 按住拖动形变):
 * - 选中激活时：呈现鲜明的主色高光胶囊 / Tinted 液态玻璃折射高光 + 顶部镜面弧光
 * - 按住并拖动时：随手指发生橡皮筋拉伸与位移形变，松手Q弹归位
 */
@Composable
private fun LiquidGlassTriggerTile(
    icon: ImageVector,
    title: String,
    valueText: String,
    isActive: Boolean,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val bgColor by animateColorAsState(
        targetValue = if (isActive) {
            MaterialTheme.colorScheme.primary
        } else {
            MaterialTheme.colorScheme.surfaceContainerLow
        },
        animationSpec = spring(dampingRatio = FLCLASH_TRAVEL_DAMPING, stiffness = FLCLASH_TRAVEL_STIFFNESS),
        label = "TriggerTileBgColor"
    )

    val titleColor = if (isActive) {
        MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.82f)
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant
    }

    val valueColor = if (isActive) {
        MaterialTheme.colorScheme.onPrimary
    } else {
        MaterialTheme.colorScheme.onSurface
    }

    LiquidGlassSurfaceCard(
        cornerRadius = 20.dp, // DashboardCorner.block = 20.0 in lib/views/dashboard/style.dart
        isHighlighted = isActive,
        containerColor = bgColor,
        modifier = modifier
            .then(
                if (isActive) {
                    Modifier.shadow(
                        elevation = 8.dp,
                        shape = RoundedCornerShape(20.dp),
                        ambientColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.38f),
                        spotColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)
                    )
                } else {
                    Modifier
                }
            )
            .flClashJellyClick(
                enabled = enabled,
                shape = RoundedCornerShape(20.dp),
                onClick = onClick
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 13.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = if (isActive) {
                    MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.22f)
                } else {
                    MaterialTheme.colorScheme.surfaceContainerHighest
                },
                modifier = Modifier.size(36.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = if (isActive) {
                            MaterialTheme.colorScheme.onPrimary
                        } else {
                            MaterialTheme.colorScheme.primary
                        },
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodySmall,
                    color = titleColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = valueText,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = valueColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Icon(
                imageVector = if (isActive) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                contentDescription = null,
                tint = if (isActive) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(17.dp)
            )
        }
    }
}

class MainActivity : ComponentActivity() {

    private var incomingExternalIntent by mutableStateOf<Intent?>(null)
    private var interceptVolumeKeysForReader by mutableStateOf(false)
    private var volumePageStepSignal by mutableIntStateOf(0)
    private var volumePageDirection by mutableIntStateOf(0)

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (interceptVolumeKeysForReader &&
            (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || event.keyCode == KeyEvent.KEYCODE_VOLUME_UP)
        ) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                volumePageDirection = if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) 1 else -1
                volumePageStepSignal++
            }
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 开启沉浸式全屏 Edge-to-Edge 渲染，消除系统状态栏与导航栏突兀色块
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isStatusBarContrastEnforced = false
            window.isNavigationBarContrastEnforced = false
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        if (savedInstanceState == null && intent != null) {
            incomingExternalIntent = intent
        }

        addOnNewIntentListener(Consumer { newIntent ->
            incomingExternalIntent = newIntent
        })

        setContent {
            val context = LocalContext.current
            var themeProps by remember { mutableStateOf(FlClashThemeProps()) }
            LaunchedEffect(Unit) {
                val loaded = withContext(Dispatchers.IO) {
                    ImageCompressor.loadFlClashThemeProps(context)
                }
                themeProps = loaded
            }
            FlClashM3Theme(themeProps = themeProps) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    FlClashAdaptiveDashboardApp(
                        externalIntent = incomingExternalIntent,
                        onExternalIntentConsumed = { incomingExternalIntent = null },
                        useDynamicColor = themeProps.primaryColor == null,
                        onToggleDynamicColor = {
                            val updated = themeProps.copy(
                                primaryColor = if (themeProps.primaryColor == null) {
                                    FlClashThemeProps.DEFAULT_PRIMARY_COLOR
                                } else {
                                    null
                                }
                            )
                            themeProps = updated
                            ImageCompressor.saveFlClashThemeProps(context, updated)
                        },
                        themeProps = themeProps,
                        onUpdateThemeProps = { updated ->
                            themeProps = updated
                            ImageCompressor.saveFlClashThemeProps(context, updated)
                        },
                        volumePageStepSignal = volumePageStepSignal,
                        volumePageDirection = volumePageDirection,
                        onUpdateVolumeKeyIntercept = { interceptVolumeKeysForReader = it }
                    )
                }
            }
        }
    }
}

private fun extractUrisFromIntent(intent: Intent): List<Uri> {
    val uris = LinkedHashSet<Uri>()
    when (intent.action) {
        Intent.ACTION_VIEW -> {
            intent.data?.let { uris.add(it) }
        }
        Intent.ACTION_SEND -> {
            val streamUri: Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            }
            streamUri?.let { uris.add(it) }
            intent.data?.let { uris.add(it) }
        }
        Intent.ACTION_SEND_MULTIPLE -> {
            val streamList: java.util.ArrayList<Uri>? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
            }
            streamList?.forEach { uris.add(it) }
        }
    }
    intent.clipData?.let { clip ->
        for (i in 0 until clip.itemCount) {
            clip.getItemAt(i)?.uri?.let { uris.add(it) }
        }
    }
    return uris.toList()
}

@OptIn(
    ExperimentalMaterial3Api::class,
    ExperimentalLayoutApi::class,
    ExperimentalFoundationApi::class,
    ExperimentalAnimationApi::class
)
@Composable
fun FlClashAdaptiveDashboardApp(
    externalIntent: Intent?,
    onExternalIntentConsumed: () -> Unit,
    useDynamicColor: Boolean,
    onToggleDynamicColor: () -> Unit,
    themeProps: FlClashThemeProps = FlClashThemeProps(),
    onUpdateThemeProps: (FlClashThemeProps) -> Unit = {},
    volumePageStepSignal: Int = 0,
    volumePageDirection: Int = 0,
    onUpdateVolumeKeyIntercept: (Boolean) -> Unit = {}
) {
    var showFlClashThemeModal by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val coroutineScope = rememberCoroutineScope()

    // 五大工作空间左右滑页 Pager（压缩 · 混淆 · 还原 · 归档 · 阅读）
    val pagerState = rememberPagerState(
        initialPage = 0,
        pageCount = { ProcessMode.entries.size }
    )
    var pagerScrollJob by remember { mutableStateOf<Job?>(null) }
    val currentMode = ProcessMode.entries[pagerState.currentPage]

    // 当前展开的第二层 Apple 液态玻璃弹出面板（点击空白区域即置为 NONE 缩回按钮）
    var activeLayer2Menu by remember { mutableStateOf(LiquidGlassLayer2Menu.NONE) }

    var archiveSubMode by remember { mutableStateOf(ArchiveSubMode.PACK_TO_ARCHIVE) }

    // 图片队列与处理结果映射
    var selectedImages by remember { mutableStateOf<List<SelectedImageItem>>(emptyList()) }
    val compressionResults = remember { mutableStateMapOf<Uri, CompressionResult>() }
    var lastBatchReport by remember { mutableStateOf<BatchExecutionReport?>(null) }
    var lastImportedArchiveBanner by remember { mutableStateOf<String?>(null) }

    // 详情弹窗状态（支持 Before/After 拉帘对比）
    var inspectedItem by remember { mutableStateOf<SelectedImageItem?>(null) }

    // 1. 压缩与转码参数
    var selectedFormat by remember { mutableStateOf(OutputFormat.JPEG) }
    var qualitySliderValue by remember { mutableFloatStateOf(80f) }
    var selectedResolution by remember { mutableStateOf(ResolutionOption.ORIGINAL) }

    // 2. EXIF 隐私抹除与批量重命名参数
    var stripExifMetadata by remember { mutableStateOf(true) }
    var selectedRenameTemplate by remember { mutableStateOf(RenameTemplate.KEEP_ORIGINAL) }
    var customRenamePrefix by remember { mutableStateOf("IMG") }

    // 3. 文字加密混淆与无损还原参数（含自动粒度标记与识别）
    var obfuscationKeyText by remember { mutableStateOf("") }
    var selectedBlockGrid by remember { mutableStateOf(BlockGridSize.BLOCK_16) }
    var autoTagBlockSizeInName by remember { mutableStateOf(true) }

    // 4. 直接压入压缩包与 AES-256 密码配置
    var packResultIntoArchive by remember { mutableStateOf(false) }
    var selectedArchiveFormat by remember { mutableStateOf(ArchiveOutputFormat.ZIP) }
    var selectedArchiveLevel by remember { mutableStateOf(ArchiveCompressionLevel.STANDARD) }
    var archivePassword by remember { mutableStateOf("") }
    var customArchiveName by remember { mutableStateOf("") }

    // 5. 加密压缩包导入密码解锁弹窗状态
    var pendingPasswordArchiveUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var pendingPasswordArchiveNames by remember { mutableStateOf("") }
    var unlockPasswordInput by remember { mutableStateOf("") }
    var unlockPasswordError by remember { mutableStateOf<String?>(null) }
    var jumpToReaderAfterUnlock by remember { mutableStateOf(false) }

    // 6. 归档阅读器、点击屏幕左右侧翻页、音量键翻页、历史密码本与队列排序筛选状态
    var readerLayoutMode by remember { mutableStateOf(ReaderLayoutMode.VERTICAL_STRIP) }
    var isImmersiveReader by remember { mutableStateOf(false) }
    var readerLiveDecryptEnabled by remember { mutableStateOf(false) }
    var readerVolumeKeyPaging by remember { mutableStateOf(true) }
    var readerTapEdgePaging by remember { mutableStateOf(true) }
    val readerDecryptedUriCache = remember { mutableStateMapOf<Uri, Uri>() }
    var isExtractingArchive by remember { mutableStateOf(false) }
    var extractDoneCount by remember { mutableIntStateOf(0) }
    var extractTotalCount by remember { mutableIntStateOf(0) }
    var extractCurrentFile by remember { mutableStateOf("") }

    // 冷启动流畅度优化：首帧仅组合当前可见页（beyondBoundsPageCount = 0），待窗口过渡动画完成后再后台预热相邻页；
    // 同时将 SharedPreferences 磁盘读取移至 Dispatchers.IO 异步加载，彻底消除刚打开应用时的首帧卡顿
    var isColdStartSettled by remember { mutableStateOf(false) }
    var savedObfuscationKeys by remember { mutableStateOf<List<String>>(emptyList()) }
    var savedArchivePasswords by remember { mutableStateOf<List<String>>(emptyList()) }

    LaunchedEffect(Unit) {
        val loadedKeys = withContext(Dispatchers.IO) {
            ImageCompressor.getSavedObfuscationKeys(context)
        }
        val loadedPwds = withContext(Dispatchers.IO) {
            ImageCompressor.getSavedArchivePasswords(context)
        }
        savedObfuscationKeys = loadedKeys
        savedArchivePasswords = loadedPwds
        delay(220L)
        isColdStartSettled = true
    }

    // 队列图片排序与「仅看未处理」筛选
    var queueSortOrder by remember { mutableStateOf(QueueSortOrder.NAME_ASC) }
    var showOnlyUnprocessed by remember { mutableStateOf(false) }

    val displayedQueueImages = remember(
        selectedImages,
        queueSortOrder,
        showOnlyUnprocessed,
        compressionResults.size
    ) {
        val sorted = ImageCompressor.sortImageQueue(selectedImages, queueSortOrder)
        if (showOnlyUnprocessed && compressionResults.isNotEmpty()) {
            sorted.filter { compressionResults[it.uri]?.isSuccess != true }
        } else {
            sorted
        }
    }

    // 仅当处于「阅读」页、已有图片且未打开二级弹窗时，启用音量上下键翻页拦截
    LaunchedEffect(
        currentMode,
        readerVolumeKeyPaging,
        selectedImages.isNotEmpty(),
        activeLayer2Menu,
        pendingPasswordArchiveUris.isEmpty()
    ) {
        val shouldIntercept = currentMode == ProcessMode.ARCHIVE_READER &&
            readerVolumeKeyPaging &&
            selectedImages.isNotEmpty() &&
            activeLayer2Menu == LiquidGlassLayer2Menu.NONE &&
            pendingPasswordArchiveUris.isEmpty()
        onUpdateVolumeKeyIntercept(shouldIntercept)
    }

    // 自定义存储目录状态
    var customTreeUri by remember { mutableStateOf<Uri?>(null) }
    var customDirName by remember { mutableStateOf<String?>(null) }

    // 批量执行进度与可取消任务句柄（允许随时中断批处理或解压任务，且后台运行时不锁死浏览与切页）
    var isProcessing by remember { mutableStateOf(false) }
    var completedCount by remember { mutableIntStateOf(0) }
    var totalTaskCount by remember { mutableIntStateOf(0) }
    var activeTaskJob by remember { mutableStateOf<Job?>(null) }

    val cancelRunningTask: () -> Unit = {
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        activeTaskJob?.cancel()
        activeTaskJob = null
        isProcessing = false
        isExtractingArchive = false
        Toast.makeText(context, "已取消当前任务（已完成结果已保留）", Toast.LENGTH_SHORT).show()
    }

    // 当载入新图片时，若文件名带有 OBF_B8/B16/B32/B64 标记，自动同步还原粒度
    val applyAutoDetectedGrid: (List<SelectedImageItem>) -> Unit = { items ->
        ImageCompressor.detectBlockGridFromItems(items)?.let { detected ->
            selectedBlockGrid = detected
        }
    }

    // 动画跳转工作台（任务后台执行时仍允许自由切换页面与查看阅读器，不再锁死界面）
    val animateToMode: (ProcessMode) -> Unit = { targetMode ->
        activeLayer2Menu = LiquidGlassLayer2Menu.NONE
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        if (targetMode == ProcessMode.DEOBFUSCATE_RESTORE) {
            selectedFormat = OutputFormat.PNG
            applyAutoDetectedGrid(selectedImages)
        }
        pagerScrollJob?.cancel()
        pagerScrollJob = coroutineScope.launch {
            pagerState.animateScrollToPage(
                page = targetMode.ordinal,
                animationSpec = spring(
                    dampingRatio = PAGE_SPRING_DAMPING,
                    stiffness = JELLY_STIFFNESS
                )
            )
        }
    }

    // 统一处理压缩包导入（含加密检测、主线程节流实时解压进度条、随时取消与密码弹窗）
    val handleArchiveImport: (List<Uri>, String, Boolean) -> Unit = { uris, pwd, openInReader ->
        activeTaskJob?.cancel()
        activeTaskJob = coroutineScope.launch {
            if (openInReader && currentMode != ProcessMode.ARCHIVE_READER) {
                animateToMode(ProcessMode.ARCHIVE_READER)
            }
            isExtractingArchive = true
            extractDoneCount = 0
            extractTotalCount = 0
            extractCurrentFile = ""
            try {
                val summary = ImageCompressor.extractImagesFromArchiveUris(
                    context = context,
                    archiveUris = uris,
                    password = pwd,
                    onProgressiveBatch = { partialImages ->
                        coroutineScope.launch(Dispatchers.Main.immediate) {
                            if (partialImages.isNotEmpty()) {
                                selectedImages = partialImages
                                applyAutoDetectedGrid(partialImages)
                            }
                        }
                    }
                ) { done, total, currentName ->
                    coroutineScope.launch(Dispatchers.Main.immediate) {
                        extractDoneCount = done
                        extractTotalCount = total
                        extractCurrentFile = currentName
                    }
                }
                isExtractingArchive = false

                if (summary.needsPassword) {
                    pendingPasswordArchiveUris = summary.pendingUris
                    pendingPasswordArchiveNames = summary.archiveNames.joinToString(", ")
                    unlockPasswordError = if (summary.wrongPassword) "密码不正确，请重新输入" else null
                    jumpToReaderAfterUnlock = openInReader
                } else if (summary.extractedImages.isNotEmpty()) {
                    if (pwd.isNotBlank()) {
                        savedArchivePasswords = ImageCompressor.saveArchivePasswordToHistory(context, pwd)
                    }
                    pendingPasswordArchiveUris = emptyList()
                    unlockPasswordError = null
                    selectedImages = summary.extractedImages
                    applyAutoDetectedGrid(summary.extractedImages)
                    lastImportedArchiveBanner = "${summary.archiveNames.joinToString(", ")} · ${summary.extractedImages.size} 张"
                    compressionResults.clear()
                    readerDecryptedUriCache.clear()
                    lastBatchReport = null
                    completedCount = 0
                    totalTaskCount = summary.extractedImages.size
                    if (openInReader) {
                        animateToMode(ProcessMode.ARCHIVE_READER)
                    }
                    Toast.makeText(context, "已载入 ${summary.extractedImages.size} 张图片", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(
                        context,
                        summary.errorNote ?: "压缩包内未找到支持的图片",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (_: CancellationException) {
                isExtractingArchive = false
            } finally {
                isExtractingArchive = false
            }
        }
    }

    // 响应外部应用「打开方式 / 分享」传入的压缩包或图片
    LaunchedEffect(externalIntent) {
        val intentToHandle = externalIntent ?: return@LaunchedEffect
        val incomingUris = extractUrisFromIntent(intentToHandle)
        onExternalIntentConsumed()

        if (incomingUris.isNotEmpty()) {
            val archiveUris = incomingUris.filter { ImageCompressor.isArchiveUri(context, it) }
            val imageUris = incomingUris.filterNot { ImageCompressor.isArchiveUri(context, it) }

            if (archiveUris.isNotEmpty() && imageUris.isEmpty()) {
                // 外部传入压缩包时直接提取并进入「阅读」页，支持带密码压缩包解锁
                handleArchiveImport(archiveUris, archivePassword, true)
            } else {
                val mergedList = mutableListOf<SelectedImageItem>()
                if (archiveUris.isNotEmpty()) {
                    isExtractingArchive = true
                    extractDoneCount = 0
                    extractTotalCount = 0
                    extractCurrentFile = ""
                    val summary = ImageCompressor.extractImagesFromArchiveUris(
                        context = context,
                        archiveUris = archiveUris,
                        password = archivePassword
                    ) { done, total, currentName ->
                        extractDoneCount = done
                        extractTotalCount = total
                        extractCurrentFile = currentName
                    }
                    isExtractingArchive = false
                    if (summary.needsPassword) {
                        pendingPasswordArchiveUris = summary.pendingUris
                        pendingPasswordArchiveNames = summary.archiveNames.joinToString(", ")
                        jumpToReaderAfterUnlock = true
                    }
                    mergedList.addAll(summary.extractedImages)
                }
                if (imageUris.isNotEmpty()) {
                    mergedList.addAll(ImageCompressor.inspectImages(context, imageUris))
                }
                if (mergedList.isNotEmpty()) {
                    selectedImages = mergedList
                    applyAutoDetectedGrid(mergedList)
                    compressionResults.clear()
                    readerDecryptedUriCache.clear()
                    lastBatchReport = null
                    completedCount = 0
                    totalTaskCount = mergedList.size
                }
            }
        }
    }

    // 阅读器开启「口令实时还原预览」时，后台自动解混淆当前队列图片
    LaunchedEffect(readerLiveDecryptEnabled, obfuscationKeyText, selectedImages, selectedBlockGrid) {
        if (readerLiveDecryptEnabled && obfuscationKeyText.isNotBlank()) {
            for (item in selectedImages) {
                if (!readerDecryptedUriCache.containsKey(item.uri)) {
                    val decUri = ImageCompressor.decryptImageForReaderPreview(
                        context = context,
                        item = item,
                        secretKey = obfuscationKeyText,
                        fallbackGridSize = selectedBlockGrid
                    )
                    if (decUri != null) {
                        readerDecryptedUriCache[item.uri] = decUri
                    }
                }
            }
        }
    }

    // 1. 相册选图启动器
    val pickMultipleImagesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 50)
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            coroutineScope.launch {
                val inspected = ImageCompressor.inspectImages(context, uris)
                selectedImages = inspected
                applyAutoDetectedGrid(inspected)
                lastImportedArchiveBanner = null
                compressionResults.clear()
                readerDecryptedUriCache.clear()
                lastBatchReport = null
                completedCount = 0
                totalTaskCount = inspected.size
            }
        }
    }

    // 2. 压缩包导入启动器（工作台通用）
    var openArchiveInReaderFlag by remember { mutableStateOf(false) }
    val pickArchiveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            handleArchiveImport(uris, archivePassword, openArchiveInReaderFlag)
        }
    }

    // 3. SAF 目录选择器
    val pickOutputDirectoryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        if (treeUri != null) {
            runCatching {
                val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(treeUri, takeFlags)
            }
            customTreeUri = treeUri
            val docDir = DocumentFile.fromTreeUri(context, treeUri)
            customDirName = docDir?.name ?: treeUri.lastPathSegment ?: "自定义目录"
            Toast.makeText(context, "保存目录：$customDirName", Toast.LENGTH_SHORT).show()
        }
    }

    // 批量执行入口
    val triggerBatchExecution: () -> Unit = {
        activeLayer2Menu = LiquidGlassLayer2Menu.NONE
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        isProcessing = true
        completedCount = 0
        totalTaskCount = selectedImages.size
        compressionResults.clear()
        lastBatchReport = null

        if (obfuscationKeyText.isNotBlank()) {
            savedObfuscationKeys = ImageCompressor.saveObfuscationKeyToHistory(context, obfuscationKeyText)
        }
        if (archivePassword.isNotBlank()) {
            savedArchivePasswords = ImageCompressor.saveArchivePasswordToHistory(context, archivePassword)
        }

        val config = CompressionConfig(
            mode = currentMode,
            archiveSubMode = archiveSubMode,
            format = selectedFormat,
            quality = qualitySliderValue.roundToInt(),
            resolutionOption = selectedResolution,
            stripExifMetadata = stripExifMetadata,
            renameTemplate = selectedRenameTemplate,
            customRenamePrefix = customRenamePrefix,
            customTreeUri = customTreeUri,
            obfuscationKey = obfuscationKeyText,
            blockGridSize = selectedBlockGrid,
            autoTagBlockSizeInName = autoTagBlockSizeInName,
            packResultIntoArchive = packResultIntoArchive,
            archiveOutputFormat = selectedArchiveFormat,
            archiveCompressionLevel = selectedArchiveLevel,
            archivePassword = archivePassword,
            customArchiveBaseName = customArchiveName
        )

        activeTaskJob?.cancel()
        activeTaskJob = coroutineScope.launch {
            try {
                val report = ImageCompressor.processBatch(
                    context = context,
                    items = selectedImages,
                    config = config,
                    onProgress = { done, total, latest ->
                        coroutineScope.launch(Dispatchers.Main.immediate) {
                            completedCount = done
                            totalTaskCount = total
                            compressionResults[latest.source.uri] = latest
                        }
                    }
                )
                lastBatchReport = report
                isProcessing = false
                val successCount = report.itemResults.count { it.isSuccess }
                val toastMsg = if (report.archiveFileName != null) {
                    "已打包 ${report.archiveFileName} ($successCount 张)"
                } else {
                    "已完成 $successCount / ${report.itemResults.size} 张"
                }
                Toast.makeText(context, toastMsg, Toast.LENGTH_SHORT).show()
            } catch (_: CancellationException) {
                isProcessing = false
            } finally {
                isProcessing = false
                activeTaskJob = null
            }
        }
    }

    // 阅读器单页一键落盘保存到系统相册/自定义目录（支持直接保存口令实时解混淆后的高清图）
    val saveSingleReaderPage: (SelectedImageItem) -> Unit = { item ->
        val decryptedUri = if (readerLiveDecryptEnabled) readerDecryptedUriCache[item.uri] else null
        val uriToSave = decryptedUri ?: item.uri
        coroutineScope.launch {
            val saved = ImageCompressor.saveReaderPageToGallery(
                context = context,
                sourceUri = uriToSave,
                originalDisplayName = item.displayName,
                isDecryptedPreview = decryptedUri != null,
                customTreeUri = customTreeUri
            )
            if (saved != null) {
                Toast.makeText(context, "已保存至 ${saved.second}", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "保存单页失败", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // 一键分享当前处理结果
    val shareLatestOutputs: () -> Unit = {
        val archiveUri = lastBatchReport?.archiveSavedUri
        if (archiveUri != null) {
            ImageCompressor.shareOutputUris(
                context = context,
                uris = listOf(archiveUri),
                mimeType = selectedArchiveFormat.mimeType,
                chooserTitle = "分享归档压缩包"
            )
        } else {
            val outUris = selectedImages.mapNotNull { compressionResults[it.uri]?.outputUri }
            val fallbackUris = if (outUris.isNotEmpty()) outUris else selectedImages.map { it.uri }
            ImageCompressor.shareOutputUris(
                context = context,
                uris = fallbackUris,
                mimeType = "image/*",
                chooserTitle = "分享图片"
            )
        }
    }

    // 仅在全屏大图对比或密码解锁模态弹窗时启用底层景深模糊；二级菜单直接从按钮形变展开，不产生全屏遮罩或模糊跳变
    val hasModalOrLayer2 = inspectedItem != null ||
        pendingPasswordArchiveUris.isNotEmpty()

    // 沉浸式状态栏自动隐藏控制：在阅读器沉浸模式或全屏大图查看时自动隐藏系统状态栏与导航栏，滑出或退出时平滑恢复
    val shouldHideSystemBars = (currentMode == ProcessMode.ARCHIVE_READER && isImmersiveReader) ||
        inspectedItem != null
    val hostView = LocalView.current
    LaunchedEffect(shouldHideSystemBars) {
        val activityWindow = (hostView.context as? Activity)?.window ?: return@LaunchedEffect
        val controller = WindowCompat.getInsetsController(activityWindow, hostView)
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (shouldHideSystemBars) {
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    // 性能优化：移除逐帧变化的 animateDpAsState(blur)，改为静态半径触发
    val continuousPagePositionProvider: () -> Float = {
        pagerState.currentPage + pagerState.currentPageOffsetFraction
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth >= 600.dp

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .then(
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && hasModalOrLayer2) {
                            Modifier.blur(12.dp)
                        } else {
                            Modifier
                        }
                    )
            ) {
                if (isWideScreen && !isImmersiveReader) {
                    FlClashNavigationRail(
                        continuousPagePositionProvider = continuousPagePositionProvider,
                        currentMode = currentMode,
                        selectedCount = selectedImages.size,
                        isProcessing = isProcessing,
                        onSelectMode = animateToMode,
                        onOpenThemeModal = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            showFlClashThemeModal = true
                        }
                    )
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        containerColor = MaterialTheme.colorScheme.background,
                        topBar = {
                            if (!isImmersiveReader) {
                                FlClashTopBar(
                                    currentMode = currentMode,
                                    selectedCount = selectedImages.size,
                                    customTreeUri = customTreeUri,
                                    useDynamicColor = useDynamicColor,
                                    isProcessing = isProcessing,
                                    onToggleDynamicColor = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        showFlClashThemeModal = true
                                    },
                                    onPickDirectory = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        pickOutputDirectoryLauncher.launch(customTreeUri)
                                    },
                                    onClearQueue = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        selectedImages = emptyList()
                                        compressionResults.clear()
                                        readerDecryptedUriCache.clear()
                                        lastBatchReport = null
                                        lastImportedArchiveBanner = null
                                        completedCount = 0
                                        totalTaskCount = 0
                                    }
                                )
                            }
                        }
                    ) { innerPadding ->
                        HorizontalPager(
                            state = pagerState,
                            userScrollEnabled = !isImmersiveReader,
                            beyondBoundsPageCount = if (isColdStartSettled) 1 else 0,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(if (isImmersiveReader) PaddingValues(0.dp) else innerPadding)
                        ) { pageIndex ->
                            val pageMode = ProcessMode.entries[pageIndex]

                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .graphicsLayer {
                                        // 性能优化：在绘制阶段（graphicsLayer）直接读取 currentPageOffsetFraction，静止时跳过矩阵变换
                                        val pageOffset = ((pagerState.currentPage - pageIndex) + pagerState.currentPageOffsetFraction)
                                        val absOffset = abs(pageOffset).coerceIn(0f, 1f)
                                        if (absOffset > 0.001f) {
                                            if (themeProps.tabAnimation == FlClashTabAnimation.FADE) {
                                                alpha = (1f - absOffset * 0.85f).coerceIn(0f, 1f)
                                            } else {
                                                val pageScale = 1f - (absOffset * 0.06f)
                                                val pageAlpha = 1f - (absOffset * 0.24f)
                                                scaleX = pageScale
                                                scaleY = pageScale
                                                alpha = pageAlpha
                                            }
                                        }
                                    }
                            ) {
                                if (pageMode == ProcessMode.ARCHIVE_READER) {
                                    // ====== 独立压缩包图片阅读器工作空间 ======
                                    FlClashArchiveImageReaderView(
                                        images = selectedImages,
                                        decryptedUriMap = readerDecryptedUriCache,
                                        liveDecryptEnabled = readerLiveDecryptEnabled,
                                        readerLayoutMode = readerLayoutMode,
                                        isImmersive = isImmersiveReader,
                                        archiveBanner = lastImportedArchiveBanner,
                                        hasArchivePassword = archivePassword.isNotBlank(),
                                        isExtracting = isExtractingArchive,
                                        extractDoneCount = extractDoneCount,
                                        extractTotalCount = extractTotalCount,
                                        extractCurrentFile = extractCurrentFile,
                                        volumePageStepSignal = volumePageStepSignal,
                                        volumePageDirection = volumePageDirection,
                                        tapEdgePagingEnabled = readerTapEdgePaging,
                                        onCancelExtract = cancelRunningTask,
                                        onToggleImmersive = { isImmersiveReader = !isImmersiveReader },
                                        onToggleLayoutMode = {
                                            val modes = ReaderLayoutMode.entries
                                            val nextIdx = (modes.indexOf(readerLayoutMode) + 1) % modes.size
                                            readerLayoutMode = modes[nextIdx]
                                        },
                                        onOpenReaderLayer2Menu = {
                                            activeLayer2Menu = LiquidGlassLayer2Menu.READER_CONTROL_PANEL
                                        },
                                        onPickArchiveToRead = {
                                            openArchiveInReaderFlag = true
                                            pickArchiveLauncher.launch(arrayOf("*/*"))
                                        },
                                        onPickImagesToRead = {
                                            pickMultipleImagesLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        },
                                        onSaveSingleImage = saveSingleReaderPage,
                                        onShareSingleImage = { item ->
                                            val uriToShare = if (readerLiveDecryptEnabled) {
                                                readerDecryptedUriCache[item.uri] ?: item.uri
                                            } else {
                                                item.uri
                                            }
                                            ImageCompressor.shareOutputUris(
                                                context = context,
                                                uris = listOf(uriToShare),
                                                mimeType = item.mimeType,
                                                chooserTitle = item.displayName
                                            )
                                        }
                                    )
                                } else {
                                    // ====== 压缩 / 混淆 / 还原 / 归档 四大处理工作空间 ======
                                    val workbenchListState = rememberLazyListState()
                                    LazyColumn(
                                        state = workbenchListState,
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .cdsSevenStopScrollFadeMask(
                                                topFadeHeight = 18.dp,
                                                bottomFadeHeight = 32.dp,
                                                showTopFade = workbenchListState.canScrollBackward,
                                                showBottomFade = workbenchListState.canScrollForward
                                            ),
                                        contentPadding = PaddingValues(
                                            start = 16.dp,
                                            end = 16.dp,
                                            top = 12.dp,
                                            bottom = 152.dp
                                        ),
                                        verticalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        // 1. FlClash 2x2 Bento 仪表盘卡片
                                        item {
                                            FlClashBentoDashboardGrid(
                                                pageMode = pageMode,
                                                selectedImages = selectedImages,
                                                resultsMap = compressionResults,
                                                selectedFormat = selectedFormat,
                                                quality = qualitySliderValue.roundToInt(),
                                                selectedBlockGrid = selectedBlockGrid,
                                                selectedArchiveFormat = selectedArchiveFormat,
                                                customDirName = customDirName,
                                                isDirectArchiveActive = (pageMode == ProcessMode.ARCHIVE_HUB && archiveSubMode == ArchiveSubMode.PACK_TO_ARCHIVE) ||
                                                    (pageMode != ProcessMode.ARCHIVE_HUB && packResultIntoArchive),
                                                isProcessing = isProcessing,
                                                lastImportedArchiveBanner = lastImportedArchiveBanner,
                                                onPickImages = {
                                                    pickMultipleImagesLauncher.launch(
                                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                    )
                                                },
                                                onPickArchives = {
                                                    openArchiveInReaderFlag = false
                                                    pickArchiveLauncher.launch(arrayOf("*/*"))
                                                },
                                                onOpenReader = {
                                                    animateToMode(ProcessMode.ARCHIVE_READER)
                                                },
                                                onPickDirectory = {
                                                    pickOutputDirectoryLauncher.launch(customTreeUri)
                                                },
                                                onResetDirectory = {
                                                    customTreeUri = null
                                                    customDirName = null
                                                }
                                            )
                                        }

                                        // 2. 一级液态玻璃参数按钮矩阵（点击任意胶囊按钮展开第二层液态玻璃面板，整齐不堆叠）
                                        item {
                                            FlClashLiquidGlassTriggerMatrix(
                                                pageMode = pageMode,
                                                activeMenu = activeLayer2Menu,
                                                isProcessing = isProcessing,
                                                selectedFormat = selectedFormat,
                                                quality = qualitySliderValue.roundToInt(),
                                                selectedResolution = selectedResolution,
                                                stripExifMetadata = stripExifMetadata,
                                                selectedRenameTemplate = selectedRenameTemplate,
                                                obfuscationKeyText = obfuscationKeyText,
                                                selectedBlockGrid = selectedBlockGrid,
                                                autoTagBlockSizeInName = autoTagBlockSizeInName,
                                                packResultIntoArchive = packResultIntoArchive,
                                                archiveSubMode = archiveSubMode,
                                                selectedArchiveFormat = selectedArchiveFormat,
                                                selectedArchiveLevel = selectedArchiveLevel,
                                                archivePassword = archivePassword,
                                                onOpenMenu = { menu ->
                                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                    activeLayer2Menu = if (activeLayer2Menu == menu) {
                                                        LiquidGlassLayer2Menu.NONE
                                                    } else {
                                                        menu
                                                    }
                                                }
                                            )
                                        }

                                        // 3. 批处理完成统计与一键分享接力横幅
                                        if (compressionResults.isNotEmpty() || lastBatchReport?.archiveFileName != null) {
                                            item {
                                                BatchSummaryBanner(
                                                    selectedImages = selectedImages,
                                                    resultsMap = compressionResults,
                                                    batchReport = lastBatchReport,
                                                    onShareClick = shareLatestOutputs
                                                )
                                            }
                                        }

                                        // 4. 待处理图片队列
                                        if (selectedImages.isEmpty()) {
                                            item {
                                                EmptyWorkbenchCard(
                                                    currentMode = pageMode,
                                                    isExtracting = isExtractingArchive,
                                                    extractDoneCount = extractDoneCount,
                                                    extractTotalCount = extractTotalCount,
                                                    extractCurrentFile = extractCurrentFile,
                                                    onCancelExtract = cancelRunningTask,
                                                    onPickImages = {
                                                        pickMultipleImagesLauncher.launch(
                                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                        )
                                                    },
                                                    onPickArchives = {
                                                        openArchiveInReaderFlag = false
                                                        pickArchiveLauncher.launch(arrayOf("*/*"))
                                                    }
                                                )
                                            }
                                        } else {
                                            item {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 4.dp, vertical = 2.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = "队列 (${displayedQueueImages.size}/${selectedImages.size})",
                                                        style = MaterialTheme.typography.titleSmall,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                    ) {
                                                        if (compressionResults.isNotEmpty()) {
                                                            Surface(
                                                                shape = RoundedCornerShape(10.dp),
                                                                color = if (showOnlyUnprocessed) {
                                                                    MaterialTheme.colorScheme.primaryContainer
                                                                } else {
                                                                    MaterialTheme.colorScheme.surfaceContainerHigh
                                                                },
                                                                modifier = Modifier.flClashJellyClick(
                                                                    pressScale = 0.88f,
                                                                    shape = RoundedCornerShape(10.dp),
                                                                    onClick = {
                                                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                                        showOnlyUnprocessed = !showOnlyUnprocessed
                                                                    }
                                                                )
                                                            ) {
                                                                Row(
                                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                                    verticalAlignment = Alignment.CenterVertically,
                                                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                                ) {
                                                                    Icon(
                                                                        imageVector = Icons.Default.FilterAlt,
                                                                        contentDescription = null,
                                                                        tint = MaterialTheme.colorScheme.primary,
                                                                        modifier = Modifier.size(13.dp)
                                                                    )
                                                                    Text(
                                                                        text = if (showOnlyUnprocessed) "仅未处理" else "全部图片",
                                                                        style = MaterialTheme.typography.labelSmall,
                                                                        fontWeight = FontWeight.Bold,
                                                                        color = if (showOnlyUnprocessed) {
                                                                            MaterialTheme.colorScheme.onPrimaryContainer
                                                                        } else {
                                                                            MaterialTheme.colorScheme.onSurfaceVariant
                                                                        }
                                                                    )
                                                                }
                                                            }
                                                        }

                                                        Surface(
                                                            shape = RoundedCornerShape(10.dp),
                                                            color = MaterialTheme.colorScheme.secondaryContainer,
                                                            modifier = Modifier.flClashJellyClick(
                                                                pressScale = 0.88f,
                                                                shape = RoundedCornerShape(10.dp),
                                                                onClick = {
                                                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                                    val orders = QueueSortOrder.entries
                                                                    val nextOrder = orders[(orders.indexOf(queueSortOrder) + 1) % orders.size]
                                                                    queueSortOrder = nextOrder
                                                                    selectedImages = ImageCompressor.sortImageQueue(selectedImages, nextOrder)
                                                                }
                                                            )
                                                        ) {
                                                            Row(
                                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                                verticalAlignment = Alignment.CenterVertically,
                                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                            ) {
                                                                Icon(
                                                                    imageVector = Icons.Default.Sort,
                                                                    contentDescription = null,
                                                                    tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                                                    modifier = Modifier.size(13.dp)
                                                                )
                                                                Text(
                                                                    text = queueSortOrder.label,
                                                                    style = MaterialTheme.typography.labelSmall,
                                                                    fontWeight = FontWeight.Bold,
                                                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                            }

                                            items(
                                                items = displayedQueueImages,
                                                key = { it.uri.toString() }
                                            ) { item ->
                                                ImageComparisonItemCard(
                                                    item = item,
                                                    result = compressionResults[item.uri],
                                                    isProcessing = isProcessing,
                                                    modifier = Modifier.animateItemPlacement(
                                                        animationSpec = spring(
                                                            dampingRatio = JELLY_DAMPING,
                                                            stiffness = JELLY_STIFFNESS
                                                        )
                                                    ),
                                                    onCardClick = { inspectedItem = item },
                                                    onRemoveItem = {
                                                        selectedImages = selectedImages.filterNot { it.uri == item.uri }
                                                        compressionResults.remove(item.uri)
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // ====== 底部：右下角液态玻璃双层启动按钮 + 悬浮果冻胶囊导航栏 ======
                    if (!isImmersiveReader) {
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .navigationBarsPadding()
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            horizontalAlignment = Alignment.End,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (currentMode != ProcessMode.ARCHIVE_READER) {
                                FlClashLiquidGlassFloatingBarActions(
                                    currentMode = currentMode,
                                    archiveSubMode = archiveSubMode,
                                    packResultIntoArchive = packResultIntoArchive,
                                    archiveFormat = selectedArchiveFormat,
                                    selectedCount = selectedImages.size,
                                    isProcessing = isProcessing || isExtractingArchive,
                                    completedCount = if (isExtractingArchive) extractDoneCount else completedCount,
                                    totalTaskCount = if (isExtractingArchive) extractTotalCount else totalTaskCount,
                                    obfuscationKeyText = obfuscationKeyText,
                                    isQuickHubExpanded = activeLayer2Menu == LiquidGlassLayer2Menu.FAB_QUICK_HUB,
                                    onToggleQuickHub = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        activeLayer2Menu = if (activeLayer2Menu == LiquidGlassLayer2Menu.FAB_QUICK_HUB) {
                                            LiquidGlassLayer2Menu.NONE
                                        } else {
                                            LiquidGlassLayer2Menu.FAB_QUICK_HUB
                                        }
                                    },
                                    onMissingKeyOpenSheet = {
                                        activeLayer2Menu = LiquidGlassLayer2Menu.OBFUSCATION_KEY
                                    },
                                    onStartClick = triggerBatchExecution,
                                    onCancelClick = cancelRunningTask
                                )
                            }

                            if (!isWideScreen) {
                                FlClashFloatingLiquidDockBar(
                                    continuousPagePositionProvider = continuousPagePositionProvider,
                                    currentMode = currentMode,
                                    isProcessing = isProcessing,
                                    onSelectMode = animateToMode
                                )
                            }
                        }
                    }
                }
            }

            // ====== Apple 液态玻璃第二层弹出面板（点击任意空白处自动缩回按钮） ======
            LiquidGlassLayer2PopoverHost(
                activeMenu = activeLayer2Menu,
                onDismiss = {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    activeLayer2Menu = LiquidGlassLayer2Menu.NONE
                },
                selectedFormat = selectedFormat,
                onSelectFormat = { selectedFormat = it },
                qualitySliderValue = qualitySliderValue,
                onQualityChange = { qualitySliderValue = it },
                selectedResolution = selectedResolution,
                onSelectResolution = { selectedResolution = it },
                stripExifMetadata = stripExifMetadata,
                onToggleStripExif = { stripExifMetadata = it },
                selectedRenameTemplate = selectedRenameTemplate,
                onSelectRenameTemplate = { selectedRenameTemplate = it },
                customRenamePrefix = customRenamePrefix,
                onCustomRenamePrefixChange = { customRenamePrefix = it },
                obfuscationKeyText = obfuscationKeyText,
                onKeyTextChange = { obfuscationKeyText = it },
                selectedBlockGrid = selectedBlockGrid,
                onSelectBlockGrid = { selectedBlockGrid = it },
                autoTagBlockSizeInName = autoTagBlockSizeInName,
                onToggleAutoTagBlock = { autoTagBlockSizeInName = it },
                packResultIntoArchive = packResultIntoArchive,
                onTogglePackResultIntoArchive = { packResultIntoArchive = it },
                archiveSubMode = archiveSubMode,
                onSelectArchiveSubMode = { archiveSubMode = it },
                selectedArchiveFormat = selectedArchiveFormat,
                onSelectArchiveFormat = { selectedArchiveFormat = it },
                selectedArchiveLevel = selectedArchiveLevel,
                onSelectArchiveLevel = { selectedArchiveLevel = it },
                archivePassword = archivePassword,
                onArchivePasswordChange = { archivePassword = it },
                customArchiveName = customArchiveName,
                onCustomArchiveNameChange = { customArchiveName = it },
                readerLayoutMode = readerLayoutMode,
                onSelectReaderLayoutMode = { readerLayoutMode = it },
                readerLiveDecryptEnabled = readerLiveDecryptEnabled,
                onToggleReaderLiveDecrypt = { readerLiveDecryptEnabled = it },
                readerVolumeKeyPaging = readerVolumeKeyPaging,
                onToggleReaderVolumeKeyPaging = { readerVolumeKeyPaging = it },
                readerTapEdgePaging = readerTapEdgePaging,
                onToggleReaderTapEdgePaging = { readerTapEdgePaging = it },
                savedObfuscationKeys = savedObfuscationKeys,
                onSaveCurrentObfuscationKey = {
                    if (obfuscationKeyText.isNotBlank()) {
                        savedObfuscationKeys = ImageCompressor.saveObfuscationKeyToHistory(context, obfuscationKeyText)
                        Toast.makeText(context, "已存入常用口令", Toast.LENGTH_SHORT).show()
                    }
                },
                onRemoveObfuscationKey = { keyToRemove ->
                    savedObfuscationKeys = ImageCompressor.removeObfuscationKeyFromHistory(context, keyToRemove)
                },
                savedArchivePasswords = savedArchivePasswords,
                onSaveCurrentArchivePassword = {
                    if (archivePassword.isNotBlank()) {
                        savedArchivePasswords = ImageCompressor.saveArchivePasswordToHistory(context, archivePassword)
                        Toast.makeText(context, "已存入常用密码", Toast.LENGTH_SHORT).show()
                    }
                },
                onRemoveArchivePassword = { pwdToRemove ->
                    savedArchivePasswords = ImageCompressor.removeArchivePasswordFromHistory(context, pwdToRemove)
                },
                hasOutputsToShare = compressionResults.isNotEmpty() || lastBatchReport?.archiveSavedUri != null || selectedImages.isNotEmpty(),
                onQuickPickImages = {
                    activeLayer2Menu = LiquidGlassLayer2Menu.NONE
                    pickMultipleImagesLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                onQuickImportArchive = {
                    activeLayer2Menu = LiquidGlassLayer2Menu.NONE
                    openArchiveInReaderFlag = false
                    pickArchiveLauncher.launch(arrayOf("*/*"))
                },
                onQuickOpenArchiveInReader = {
                    activeLayer2Menu = LiquidGlassLayer2Menu.NONE
                    openArchiveInReaderFlag = true
                    pickArchiveLauncher.launch(arrayOf("*/*"))
                },
                onQuickShareOutputs = {
                    activeLayer2Menu = LiquidGlassLayer2Menu.NONE
                    shareLatestOutputs()
                },
                onQuickPickDirectory = {
                    activeLayer2Menu = LiquidGlassLayer2Menu.NONE
                    pickOutputDirectoryLauncher.launch(customTreeUri)
                },
                onQuickClearQueue = {
                    activeLayer2Menu = LiquidGlassLayer2Menu.NONE
                    selectedImages = emptyList()
                    compressionResults.clear()
                    readerDecryptedUriCache.clear()
                    lastBatchReport = null
                },
                onSwitchMode = animateToMode
            )

            // ====== 加密压缩包密码解锁液态玻璃弹窗 ======
            AnimatedVisibility(
                visible = pendingPasswordArchiveUris.isNotEmpty(),
                enter = fadeIn(spring(stiffness = JELLY_STIFFNESS)),
                exit = fadeOut(spring(stiffness = JELLY_STIFFNESS))
            ) {
                ArchivePasswordUnlockModal(
                    archiveNames = pendingPasswordArchiveNames,
                    passwordInput = unlockPasswordInput,
                    errorText = unlockPasswordError,
                    savedPasswords = savedArchivePasswords,
                    onRemoveSavedPassword = { pwd ->
                        savedArchivePasswords = ImageCompressor.removeArchivePasswordFromHistory(context, pwd)
                    },
                    onPasswordChange = {
                        unlockPasswordInput = it
                        unlockPasswordError = null
                    },
                    onDismiss = {
                        pendingPasswordArchiveUris = emptyList()
                        unlockPasswordError = null
                    },
                    onConfirmUnlock = {
                        if (unlockPasswordInput.isBlank()) {
                            unlockPasswordError = "请输入压缩包密码"
                        } else {
                            archivePassword = unlockPasswordInput
                            handleArchiveImport(
                                pendingPasswordArchiveUris,
                                unlockPasswordInput,
                                jumpToReaderAfterUnlock
                            )
                        }
                    }
                )
            }

            // ====== Container Transform 卡片展开大图详情视图（含拉帘对比 Before/After Slider） ======
            AnimatedVisibility(
                visible = inspectedItem != null,
                enter = fadeIn(animationSpec = spring(stiffness = JELLY_STIFFNESS)),
                exit = fadeOut(animationSpec = spring(stiffness = JELLY_STIFFNESS))
            ) {
                val activeItem = inspectedItem
                if (activeItem != null) {
                    ImageDetailContainerTransformModal(
                        item = activeItem,
                        result = compressionResults[activeItem.uri],
                        onDismiss = { inspectedItem = null },
                        onShare = {
                            val targetUri = compressionResults[activeItem.uri]?.outputUri ?: activeItem.uri
                            ImageCompressor.shareOutputUris(
                                context = context,
                                uris = listOf(targetUri),
                                mimeType = "image/*",
                                chooserTitle = activeItem.displayName
                            )
                        },
                        onRemove = {
                            selectedImages = selectedImages.filterNot { it.uri == activeItem.uri }
                            compressionResults.remove(activeItem.uri)
                            inspectedItem = null
                        }
                    )
                }
            }

            // ====== 主题设定面板（无全屏灰色遮罩块，直接由右上角主题按钮形变展开） ======
            FlClashThemeSettingsModal(
                visible = showFlClashThemeModal,
                themeProps = themeProps,
                onUpdateThemeProps = onUpdateThemeProps,
                onDismiss = { showFlClashThemeModal = false }
            )
        }
    }
}

/**
 * 一级液态玻璃参数按钮矩阵：
 * 将原本堆叠在卡片里的多行选项收纳为整齐的 2x2 液态玻璃胶囊按钮，点击任意按钮以果冻弹簧展开对应的二级玻璃菜单
 */
@Composable
private fun FlClashLiquidGlassTriggerMatrix(
    pageMode: ProcessMode,
    activeMenu: LiquidGlassLayer2Menu,
    isProcessing: Boolean,
    selectedFormat: OutputFormat,
    quality: Int,
    selectedResolution: ResolutionOption,
    stripExifMetadata: Boolean,
    selectedRenameTemplate: RenameTemplate,
    obfuscationKeyText: String,
    selectedBlockGrid: BlockGridSize,
    autoTagBlockSizeInName: Boolean,
    packResultIntoArchive: Boolean,
    archiveSubMode: ArchiveSubMode,
    selectedArchiveFormat: ArchiveOutputFormat,
    selectedArchiveLevel: ArchiveCompressionLevel,
    archivePassword: String,
    onOpenMenu: (LiquidGlassLayer2Menu) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        when (pageMode) {
            ProcessMode.COMPRESS_TRANSCODE -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    LiquidGlassTriggerTile(
                        icon = Icons.Default.Transform,
                        title = "输出格式",
                        valueText = selectedFormat.shortLabel,
                        isActive = activeMenu == LiquidGlassLayer2Menu.FORMAT_PICKER,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.FORMAT_PICKER) }
                    )
                    LiquidGlassTriggerTile(
                        icon = Icons.Default.Tune,
                        title = "画质与尺寸",
                        valueText = if (selectedFormat.supportsQualitySlider) {
                            "$quality% · ${selectedResolution.label}"
                        } else {
                            "无损 · ${selectedResolution.label}"
                        },
                        isActive = activeMenu == LiquidGlassLayer2Menu.QUALITY_SLIDER,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.QUALITY_SLIDER) }
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    LiquidGlassTriggerTile(
                        icon = Icons.Default.PrivacyTip,
                        title = "隐私与命名",
                        valueText = "${if (stripExifMetadata) "抹除EXIF" else "保留EXIF"} · ${selectedRenameTemplate.shortLabel}",
                        isActive = activeMenu == LiquidGlassLayer2Menu.PRIVACY_AND_RENAME,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.PRIVACY_AND_RENAME) }
                    )
                    LiquidGlassTriggerTile(
                        icon = Icons.Default.Archive,
                        title = "直压归档",
                        valueText = if (packResultIntoArchive) {
                            "${selectedArchiveFormat.shortLabel}${if (archivePassword.isNotBlank()) " · 加密" else ""}"
                        } else {
                            "不打包 (单图)"
                        },
                        isActive = activeMenu == LiquidGlassLayer2Menu.DIRECT_ARCHIVE_PACK,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.DIRECT_ARCHIVE_PACK) }
                    )
                }
            }

            ProcessMode.OBFUSCATE_ENCRYPT, ProcessMode.DEOBFUSCATE_RESTORE -> {
                val isEncrypt = pageMode == ProcessMode.OBFUSCATE_ENCRYPT
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    LiquidGlassTriggerTile(
                        icon = Icons.Default.Key,
                        title = if (isEncrypt) "加密口令" else "还原口令",
                        valueText = if (obfuscationKeyText.isBlank()) "点击输入口令" else "已设 (${obfuscationKeyText.length}位)",
                        isActive = activeMenu == LiquidGlassLayer2Menu.OBFUSCATION_KEY,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.OBFUSCATION_KEY) }
                    )
                    LiquidGlassTriggerTile(
                        icon = Icons.Default.GridView,
                        title = "色块粒度",
                        valueText = "${selectedBlockGrid.shortLabel}${if (autoTagBlockSizeInName) " · 自动标记" else ""}",
                        isActive = activeMenu == LiquidGlassLayer2Menu.BLOCK_GRID_PICKER,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.BLOCK_GRID_PICKER) }
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    LiquidGlassTriggerTile(
                        icon = Icons.Default.DriveFileRenameOutline,
                        title = "命名与格式",
                        valueText = "${selectedRenameTemplate.shortLabel} · ${if (isEncrypt) "PNG" else selectedFormat.shortLabel}",
                        isActive = activeMenu == LiquidGlassLayer2Menu.PRIVACY_AND_RENAME,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.PRIVACY_AND_RENAME) }
                    )
                    LiquidGlassTriggerTile(
                        icon = Icons.Default.Lock,
                        title = "直压加密包",
                        valueText = if (packResultIntoArchive) {
                            "${selectedArchiveFormat.shortLabel}${if (archivePassword.isNotBlank()) " · 密码保护" else ""}"
                        } else {
                            "不打包 (单图)"
                        },
                        isActive = activeMenu == LiquidGlassLayer2Menu.DIRECT_ARCHIVE_PACK,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.DIRECT_ARCHIVE_PACK) }
                    )
                }
            }

            ProcessMode.ARCHIVE_HUB -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    LiquidGlassTriggerTile(
                        icon = if (archiveSubMode == ArchiveSubMode.PACK_TO_ARCHIVE) Icons.Default.Archive else Icons.Default.Unarchive,
                        title = "归档动作",
                        valueText = archiveSubMode.label,
                        isActive = activeMenu == LiquidGlassLayer2Menu.ARCHIVE_SUBMODE,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.ARCHIVE_SUBMODE) }
                    )
                    LiquidGlassTriggerTile(
                        icon = Icons.Default.FolderZip,
                        title = "格式与等级",
                        valueText = "${selectedArchiveFormat.shortLabel} · ${selectedArchiveLevel.label}",
                        isActive = activeMenu == LiquidGlassLayer2Menu.ARCHIVE_FORMAT_LEVEL,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.ARCHIVE_FORMAT_LEVEL) }
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    LiquidGlassTriggerTile(
                        icon = Icons.Default.Password,
                        title = "压缩包密码",
                        valueText = if (archivePassword.isBlank()) "无密码 (点击设置)" else "AES 密码已设",
                        isActive = activeMenu == LiquidGlassLayer2Menu.ARCHIVE_PASSWORD_NAMING,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.ARCHIVE_PASSWORD_NAMING) }
                    )
                    LiquidGlassTriggerTile(
                        icon = Icons.Default.DriveFileRenameOutline,
                        title = "包内重命名",
                        valueText = selectedRenameTemplate.shortLabel,
                        isActive = activeMenu == LiquidGlassLayer2Menu.PRIVACY_AND_RENAME,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.PRIVACY_AND_RENAME) }
                    )
                }
            }

            ProcessMode.ARCHIVE_READER -> Unit
        }
    }
}

/**
 * Apple 液态玻璃第二层弹出菜单宿主：
 * - 点击一级按钮时，面板以 0.44f 低阻尼果冻弹簧放大弹出
 * - 点击面板外部的任意空白区域（透明模糊遮罩层），面板自动平滑缩回按钮本身
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun LiquidGlassLayer2PopoverHost(
    activeMenu: LiquidGlassLayer2Menu,
    onDismiss: () -> Unit,
    selectedFormat: OutputFormat,
    onSelectFormat: (OutputFormat) -> Unit,
    qualitySliderValue: Float,
    onQualityChange: (Float) -> Unit,
    selectedResolution: ResolutionOption,
    onSelectResolution: (ResolutionOption) -> Unit,
    stripExifMetadata: Boolean,
    onToggleStripExif: (Boolean) -> Unit,
    selectedRenameTemplate: RenameTemplate,
    onSelectRenameTemplate: (RenameTemplate) -> Unit,
    customRenamePrefix: String,
    onCustomRenamePrefixChange: (String) -> Unit,
    obfuscationKeyText: String,
    onKeyTextChange: (String) -> Unit,
    selectedBlockGrid: BlockGridSize,
    onSelectBlockGrid: (BlockGridSize) -> Unit,
    autoTagBlockSizeInName: Boolean,
    onToggleAutoTagBlock: (Boolean) -> Unit,
    packResultIntoArchive: Boolean,
    onTogglePackResultIntoArchive: (Boolean) -> Unit,
    archiveSubMode: ArchiveSubMode,
    onSelectArchiveSubMode: (ArchiveSubMode) -> Unit,
    selectedArchiveFormat: ArchiveOutputFormat,
    onSelectArchiveFormat: (ArchiveOutputFormat) -> Unit,
    selectedArchiveLevel: ArchiveCompressionLevel,
    onSelectArchiveLevel: (ArchiveCompressionLevel) -> Unit,
    archivePassword: String,
    onArchivePasswordChange: (String) -> Unit,
    customArchiveName: String,
    onCustomArchiveNameChange: (String) -> Unit,
    readerLayoutMode: ReaderLayoutMode,
    onSelectReaderLayoutMode: (ReaderLayoutMode) -> Unit,
    readerLiveDecryptEnabled: Boolean,
    onToggleReaderLiveDecrypt: (Boolean) -> Unit,
    readerVolumeKeyPaging: Boolean,
    onToggleReaderVolumeKeyPaging: (Boolean) -> Unit,
    readerTapEdgePaging: Boolean = true,
    onToggleReaderTapEdgePaging: (Boolean) -> Unit = {},
    savedObfuscationKeys: List<String>,
    onSaveCurrentObfuscationKey: () -> Unit,
    onRemoveObfuscationKey: (String) -> Unit,
    savedArchivePasswords: List<String>,
    onSaveCurrentArchivePassword: () -> Unit,
    onRemoveArchivePassword: (String) -> Unit,
    hasOutputsToShare: Boolean,
    onQuickPickImages: () -> Unit,
    onQuickImportArchive: () -> Unit,
    onQuickOpenArchiveInReader: () -> Unit,
    onQuickShareOutputs: () -> Unit,
    onQuickPickDirectory: () -> Unit,
    onQuickClearQueue: () -> Unit,
    onSwitchMode: (ProcessMode) -> Unit
) {
    // 记忆最近一次打开的菜单枚举，使面板收起动画（exit）也能精准缩回原本点击的那颗按钮
    var rememberedMenu by remember { mutableStateOf(LiquidGlassLayer2Menu.FORMAT_PICKER) }
    if (activeMenu != LiquidGlassLayer2Menu.NONE) {
        rememberedMenu = activeMenu
    }

    val isVisible = activeMenu != LiquidGlassLayer2Menu.NONE
    val isFabMenu = rememberedMenu == LiquidGlassLayer2Menu.FAB_QUICK_HUB
    val isReaderMenu = rememberedMenu == LiquidGlassLayer2Menu.READER_CONTROL_PANEL
    val isLeftButton = rememberedMenu == LiquidGlassLayer2Menu.FORMAT_PICKER ||
        rememberedMenu == LiquidGlassLayer2Menu.OBFUSCATION_KEY ||
        rememberedMenu == LiquidGlassLayer2Menu.ARCHIVE_SUBMODE ||
        rememberedMenu == LiquidGlassLayer2Menu.PRIVACY_AND_RENAME ||
        rememberedMenu == LiquidGlassLayer2Menu.ARCHIVE_PASSWORD_NAMING
    val isSecondRowButton = rememberedMenu == LiquidGlassLayer2Menu.PRIVACY_AND_RENAME ||
        rememberedMenu == LiquidGlassLayer2Menu.ARCHIVE_PASSWORD_NAMING ||
        rememberedMenu == LiquidGlassLayer2Menu.DIRECT_ARCHIVE_PACK

    // 二级菜单自身相对于触发按钮的形变锚点（无全屏灰色遮罩块，仅卡片本身从按钮位置直接果冻形变展开与缩回）
    val cardTransformOrigin = when {
        isFabMenu -> TransformOrigin(0.32f, 1.0f)
        isReaderMenu -> TransformOrigin(0.88f, 0.0f)
        isLeftButton -> TransformOrigin(0.22f, 0.06f)
        else -> TransformOrigin(0.78f, 0.06f)
    }

    val expandAnchor = when {
        isFabMenu -> Alignment.BottomCenter
        isReaderMenu -> Alignment.TopEnd
        isLeftButton -> Alignment.TopStart
        else -> Alignment.TopEnd
    }

    val boxAlignment = when {
        isFabMenu -> Alignment.BottomEnd
        isReaderMenu -> Alignment.TopEnd
        isLeftButton -> Alignment.TopStart
        else -> Alignment.TopEnd
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (isVisible) {
            BackHandler(onBack = onDismiss)
            // 纯透明点击空白处收起拦截层（绝不渲染任何灰色遮罩块或缩放色块）
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onDismiss
                    )
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(
                    start = 16.dp,
                    end = 16.dp,
                    top = when {
                        isReaderMenu -> 58.dp
                        isSecondRowButton -> 228.dp
                        else -> 156.dp
                    },
                    bottom = if (isFabMenu) 132.dp else 24.dp
                ),
            contentAlignment = boxAlignment
        ) {
            AnimatedVisibility(
                visible = isVisible,
                enter = fadeIn(animationSpec = spring(stiffness = 520f)) +
                    scaleIn(
                        initialScale = 0.14f,
                        transformOrigin = cardTransformOrigin,
                        animationSpec = spring(
                            dampingRatio = FLCLASH_PRESS_DAMPING,
                            stiffness = FLCLASH_TRAVEL_STIFFNESS
                        )
                    ) +
                    expandIn(
                        expandFrom = expandAnchor,
                        initialSize = { IntSize((it.width * 0.38f).toInt(), (it.height * 0.22f).toInt()) },
                        animationSpec = spring(
                            dampingRatio = 0.76f,
                            stiffness = FLCLASH_TRAVEL_STIFFNESS
                        ),
                        clip = true
                    ),
                exit = fadeOut(animationSpec = spring(stiffness = 600f)) +
                    scaleOut(
                        targetScale = 0.14f,
                        transformOrigin = cardTransformOrigin,
                        animationSpec = spring(
                            dampingRatio = FLCLASH_TRAVEL_DAMPING,
                            stiffness = 520f
                        )
                    ) +
                    shrinkOut(
                        shrinkTowards = expandAnchor,
                        targetSize = { IntSize((it.width * 0.38f).toInt(), (it.height * 0.22f).toInt()) },
                        animationSpec = spring(
                            dampingRatio = FLCLASH_TRAVEL_DAMPING,
                            stiffness = 520f
                        ),
                        clip = true
                    )
            ) {
                LiquidGlassSurfaceCard(
                    cornerRadius = 24.dp,
                    isHighlighted = true,
                    containerColor = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.98f),
                    modifier = Modifier
                        .widthIn(max = if (isFabMenu) 280.dp else 440.dp)
                        .fillMaxWidth()
                        .shadow(
                            elevation = 18.dp,
                            shape = RoundedCornerShape(24.dp),
                            ambientColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f),
                            spotColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.28f)
                        )
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = {}
                        )
                ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateContentSize(
                            animationSpec = spring(
                                dampingRatio = 0.56f,
                                stiffness = JELLY_STIFFNESS
                            )
                        )
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    when (rememberedMenu) {
                        LiquidGlassLayer2Menu.FORMAT_PICKER -> {
                            Layer2Header("选择输出格式", "点击空白处自动收起", onDismiss)
                            FlClashSegmentedRow(
                                items = OutputFormat.entries,
                                selectedItem = selectedFormat,
                                itemLabel = { it.shortLabel },
                                onItemSelected = {
                                    onSelectFormat(it)
                                    onDismiss()
                                }
                            )
                            Text(
                                text = selectedFormat.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        LiquidGlassLayer2Menu.QUALITY_SLIDER -> {
                            Layer2Header("画质与尺寸缩放", "点击空白处自动收起", onDismiss)
                            if (selectedFormat.supportsQualitySlider) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("输出画质", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        "${qualitySliderValue.roundToInt()}%",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Slider(
                                    value = qualitySliderValue,
                                    onValueChange = onQualityChange,
                                    valueRange = 10f..100f,
                                    steps = 17
                                )
                            }
                            Text("最长边尺寸限制", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            FlClashSegmentedRow(
                                items = ResolutionOption.entries,
                                selectedItem = selectedResolution,
                                itemLabel = { it.label },
                                onItemSelected = onSelectResolution
                            )
                        }

                        LiquidGlassLayer2Menu.PRIVACY_AND_RENAME -> {
                            Layer2Header("隐私抹除与批量命名", "点击空白处自动收起", onDismiss)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onToggleStripExif(!stripExifMetadata) }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("抹除 EXIF 拍摄与定位隐私", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                    Text("清除 GPS 经纬度与设备信息", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(checked = stripExifMetadata, onCheckedChange = onToggleStripExif)
                            }

                            HorizontalDivider(thickness = 1.dp, color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                            Text("批量重命名模板", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            FlClashSegmentedRow(
                                items = RenameTemplate.entries,
                                selectedItem = selectedRenameTemplate,
                                itemLabel = { it.shortLabel },
                                onItemSelected = onSelectRenameTemplate
                            )

                            if (selectedRenameTemplate == RenameTemplate.PREFIX_INDEX) {
                                OutlinedTextField(
                                    value = customRenamePrefix,
                                    onValueChange = onCustomRenamePrefixChange,
                                    label = { Text("自定义前缀") },
                                    placeholder = { Text("例如：Manga") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            Text("还原导出格式", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            FlClashSegmentedRow(
                                items = OutputFormat.entries,
                                selectedItem = selectedFormat,
                                itemLabel = { it.shortLabel },
                                onItemSelected = onSelectFormat
                            )
                        }

                        LiquidGlassLayer2Menu.DIRECT_ARCHIVE_PACK -> {
                            Layer2Header("直接打入压缩包", "支持 AES-256 加密", onDismiss)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onTogglePackResultIntoArchive(!packResultIntoArchive) }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("处理后直接压入单个压缩包", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                    Text("不在相册散存单张图", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(checked = packResultIntoArchive, onCheckedChange = onTogglePackResultIntoArchive)
                            }

                            if (packResultIntoArchive) {
                                ArchivePackConfigControls(
                                    selectedArchiveFormat = selectedArchiveFormat,
                                    onSelectArchiveFormat = onSelectArchiveFormat,
                                    selectedArchiveLevel = selectedArchiveLevel,
                                    onSelectArchiveLevel = onSelectArchiveLevel,
                                    archivePassword = archivePassword,
                                    onArchivePasswordChange = onArchivePasswordChange,
                                    savedArchivePasswords = savedArchivePasswords,
                                    onSaveCurrentArchivePassword = onSaveCurrentArchivePassword,
                                    onRemoveArchivePassword = onRemoveArchivePassword,
                                    customArchiveName = customArchiveName,
                                    onCustomArchiveNameChange = onCustomArchiveNameChange
                                )
                            }
                        }

                        LiquidGlassLayer2Menu.OBFUSCATION_KEY -> {
                            Layer2Header("设置文字加密/还原口令", "相同口令可 100% 无损还原", onDismiss)
                            OutlinedTextField(
                                value = obfuscationKeyText,
                                onValueChange = onKeyTextChange,
                                label = { Text("文字口令") },
                                placeholder = { Text("输入任意文字、数字或短句") },
                                leadingIcon = { Icon(Icons.Default.Key, contentDescription = null) },
                                trailingIcon = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (obfuscationKeyText.isNotEmpty()) {
                                            IconButton(onClick = { onKeyTextChange("") }) {
                                                Icon(Icons.Default.Clear, contentDescription = "清空")
                                            }
                                        }
                                        IconButton(
                                            onClick = {
                                                onKeyTextChange("KEY_" + Random.nextInt(100000, 999999))
                                            }
                                        ) {
                                            Icon(Icons.Default.Casino, contentDescription = "随机生成")
                                        }
                                    }
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                            SavedSecretHistoryChipsRow(
                                label = "常用口令",
                                currentInput = obfuscationKeyText,
                                savedItems = savedObfuscationKeys,
                                onSelect = onKeyTextChange,
                                onSaveCurrent = onSaveCurrentObfuscationKey,
                                onRemove = onRemoveObfuscationKey
                            )
                        }

                        LiquidGlassLayer2Menu.BLOCK_GRID_PICKER -> {
                            Layer2Header("色块粒度与自动标记", "点击空白处自动收起", onDismiss)
                            FlClashSegmentedRow(
                                items = BlockGridSize.entries,
                                selectedItem = selectedBlockGrid,
                                itemLabel = { it.shortLabel },
                                onItemSelected = onSelectBlockGrid
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onToggleAutoTagBlock(!autoTagBlockSizeInName) }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("文件名自动标记粒度 (如 OBF_B16_)", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                    Text("还原时自动识别粒度，无需手选", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(checked = autoTagBlockSizeInName, onCheckedChange = onToggleAutoTagBlock)
                            }
                        }

                        LiquidGlassLayer2Menu.ARCHIVE_SUBMODE -> {
                            Layer2Header("归档工作模式", "点击空白处自动收起", onDismiss)
                            FlClashSegmentedRow(
                                items = ArchiveSubMode.entries,
                                selectedItem = archiveSubMode,
                                itemLabel = { it.label },
                                onItemSelected = {
                                    onSelectArchiveSubMode(it)
                                    onDismiss()
                                }
                            )
                            if (archiveSubMode == ArchiveSubMode.EXTRACT_FROM_ARCHIVE) {
                                Text("提取图片后一键流转：", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FilledTonalButton(
                                        onClick = { onSwitchMode(ProcessMode.COMPRESS_TRANSCODE) },
                                        modifier = Modifier.weight(1f)
                                    ) { Text("去压缩") }
                                    FilledTonalButton(
                                        onClick = { onSwitchMode(ProcessMode.OBFUSCATE_ENCRYPT) },
                                        modifier = Modifier.weight(1f)
                                    ) { Text("去混淆") }
                                    FilledTonalButton(
                                        onClick = { onSwitchMode(ProcessMode.ARCHIVE_READER) },
                                        modifier = Modifier.weight(1f)
                                    ) { Text("去阅读") }
                                }
                            }
                        }

                        LiquidGlassLayer2Menu.ARCHIVE_FORMAT_LEVEL -> {
                            Layer2Header("归档格式与压缩率", "点击空白处自动收起", onDismiss)
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                ArchiveOutputFormat.entries.forEach { format ->
                                    FlClashChoicePill(
                                        selected = selectedArchiveFormat == format,
                                        label = format.shortLabel,
                                        onClick = { onSelectArchiveFormat(format) }
                                    )
                                }
                            }
                            if (selectedArchiveFormat == ArchiveOutputFormat.ZIP ||
                                selectedArchiveFormat == ArchiveOutputFormat.CBZ
                            ) {
                                Text("压缩率等级", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                FlClashSegmentedRow(
                                    items = ArchiveCompressionLevel.entries,
                                    selectedItem = selectedArchiveLevel,
                                    itemLabel = { it.label },
                                    onItemSelected = onSelectArchiveLevel
                                )
                            }
                        }

                        LiquidGlassLayer2Menu.ARCHIVE_PASSWORD_NAMING -> {
                            Layer2Header("归档密码与包名", "支持 ZIP/CBZ AES-256 加密及 7Z/RAR 解锁", onDismiss)
                            OutlinedTextField(
                                value = archivePassword,
                                onValueChange = onArchivePasswordChange,
                                label = { Text("压缩包密码（打包加密 / 解压解锁通用）") },
                                placeholder = { Text("留空则不设密码") },
                                leadingIcon = { Icon(Icons.Default.Password, contentDescription = null) },
                                trailingIcon = {
                                    if (archivePassword.isNotEmpty()) {
                                        IconButton(onClick = { onArchivePasswordChange("") }) {
                                            Icon(Icons.Default.Clear, contentDescription = "清除")
                                        }
                                    }
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                            SavedSecretHistoryChipsRow(
                                label = "常用归档密码",
                                currentInput = archivePassword,
                                savedItems = savedArchivePasswords,
                                onSelect = onArchivePasswordChange,
                                onSaveCurrent = onSaveCurrentArchivePassword,
                                onRemove = onRemoveArchivePassword
                            )
                            OutlinedTextField(
                                value = customArchiveName,
                                onValueChange = onCustomArchiveNameChange,
                                label = { Text("归档包名称（选填）") },
                                placeholder = { Text("留空自动按时间命名") },
                                leadingIcon = { Icon(Icons.Default.Archive, contentDescription = null) },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        LiquidGlassLayer2Menu.FAB_QUICK_HUB -> {
                            Layer2Header("快捷操作中心", "点击空白处自动缩回按钮", onDismiss)
                            LiquidGlassMenuActionRow(
                                icon = Icons.Default.AddPhotoAlternate,
                                title = "从相册选择图片",
                                onClick = onQuickPickImages
                            )
                            LiquidGlassMenuActionRow(
                                icon = Icons.Default.FolderZip,
                                title = "导入压缩包 (支持密码)",
                                onClick = onQuickImportArchive
                            )
                            LiquidGlassMenuActionRow(
                                icon = Icons.Default.AutoStories,
                                title = "打开压缩包阅读器",
                                onClick = onQuickOpenArchiveInReader
                            )
                            if (hasOutputsToShare) {
                                LiquidGlassMenuActionRow(
                                    icon = Icons.Default.Share,
                                    title = "一键向外分享结果",
                                    onClick = onQuickShareOutputs
                                )
                            }
                            LiquidGlassMenuActionRow(
                                icon = Icons.Outlined.FolderOpen,
                                title = "更改输出保存目录",
                                onClick = onQuickPickDirectory
                            )
                            if (hasOutputsToShare) {
                                LiquidGlassMenuActionRow(
                                    icon = Icons.Outlined.DeleteSweep,
                                    title = "清空当前队列",
                                    onClick = onQuickClearQueue
                                )
                            }
                        }

                        LiquidGlassLayer2Menu.READER_CONTROL_PANEL -> {
                            Layer2Header("阅读器控制面板", "支持条漫、单页、双页跨页、点击屏幕左右侧翻页与音量键翻页", onDismiss)
                            Text("翻页阅读模式", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            FlClashSegmentedRow(
                                items = ReaderLayoutMode.entries,
                                selectedItem = readerLayoutMode,
                                itemLabel = { it.label },
                                onItemSelected = onSelectReaderLayoutMode
                            )

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onToggleReaderTapEdgePaging(!readerTapEdgePaging) }
                                    .padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("点击屏幕左右侧翻页", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                    Text("点击左侧上一页 · 右侧下一页（日漫右→左模式自动反转）· 中间全屏", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(checked = readerTapEdgePaging, onCheckedChange = onToggleReaderTapEdgePaging)
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onToggleReaderVolumeKeyPaging(!readerVolumeKeyPaging) }
                                    .padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("音量上下键翻页", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                    Text("音量下键下一页 · 音量上键上一页", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(checked = readerVolumeKeyPaging, onCheckedChange = onToggleReaderVolumeKeyPaging)
                            }

                            OutlinedTextField(
                                value = archivePassword,
                                onValueChange = onArchivePasswordChange,
                                label = { Text("加密压缩包解锁密码") },
                                placeholder = { Text("若压缩包有密码请在此输入") },
                                leadingIcon = { Icon(Icons.Default.Password, contentDescription = null) },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                            SavedSecretHistoryChipsRow(
                                label = "常用归档密码",
                                currentInput = archivePassword,
                                savedItems = savedArchivePasswords,
                                onSelect = onArchivePasswordChange,
                                onSaveCurrent = onSaveCurrentArchivePassword,
                                onRemove = onRemoveArchivePassword
                            )

                            HorizontalDivider(thickness = 1.dp, color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onToggleReaderLiveDecrypt(!readerLiveDecryptEnabled) }
                                    .padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("口令实时还原色块图", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                    Text("阅读被色块混淆的图集时自动解密显示", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(checked = readerLiveDecryptEnabled, onCheckedChange = onToggleReaderLiveDecrypt)
                            }

                            if (readerLiveDecryptEnabled) {
                                Text("色块还原粒度（文件名含 OBF_B16_ 时自动识别）", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                FlClashSegmentedRow(
                                    items = BlockGridSize.entries,
                                    selectedItem = selectedBlockGrid,
                                    itemLabel = { it.label },
                                    onItemSelected = onSelectBlockGrid
                                )
                                OutlinedTextField(
                                    value = obfuscationKeyText,
                                    onValueChange = onKeyTextChange,
                                    label = { Text("色块还原口令") },
                                    placeholder = { Text("输入加密时的文字口令") },
                                    leadingIcon = { Icon(Icons.Default.Key, contentDescription = null) },
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth()
                                )
                                SavedSecretHistoryChipsRow(
                                    label = "常用还原口令",
                                    currentInput = obfuscationKeyText,
                                    savedItems = savedObfuscationKeys,
                                    onSelect = onKeyTextChange,
                                    onSaveCurrent = onSaveCurrentObfuscationKey,
                                    onRemove = onRemoveObfuscationKey
                                )
                            }
                        }

                        LiquidGlassLayer2Menu.NONE -> Unit
                    }
                }
            }
            }
        }
    }
}

@Composable
private fun Layer2Header(
    title: String,
    subtitle: String,
    onClose: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
        }
        IconButton(onClick = onClose, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Close, contentDescription = "收起", modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun LiquidGlassMenuActionRow(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .flClashJellyClick(
                pressScale = 0.92f,
                shape = RoundedCornerShape(14.dp),
                onClick = onClick
            )
            .background(MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.85f))
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp)
        )
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold
        )
    }
}

/**
 * 常用密码本 / 口令历史记忆胶囊条（支持一键填入、存入当前口令与单条移除）
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SavedSecretHistoryChipsRow(
    label: String,
    currentInput: String,
    savedItems: List<String>,
    onSelect: (String) -> Unit,
    onSaveCurrent: (() -> Unit)? = null,
    onRemove: (String) -> Unit
) {
    if (savedItems.isEmpty() && (onSaveCurrent == null || currentInput.isBlank())) return

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "$label (点选一键填入)",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (onSaveCurrent != null && currentInput.isNotBlank() && currentInput.trim() !in savedItems) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.flClashJellyClick(
                        pressScale = 0.88f,
                        shape = RoundedCornerShape(8.dp),
                        onClick = onSaveCurrent
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.BookmarkAdd,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = "存入常用",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }
        }

        if (savedItems.isNotEmpty()) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                savedItems.forEach { secret ->
                    val isSelected = secret == currentInput
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) {
                            MaterialTheme.colorScheme.primaryContainer
                        } else {
                            MaterialTheme.colorScheme.surfaceContainerHigh
                        },
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                        ),
                        modifier = Modifier.flClashJellyClick(
                            pressScale = 0.90f,
                            shape = RoundedCornerShape(10.dp),
                            onClick = { onSelect(secret) }
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(start = 10.dp, end = 6.dp, top = 5.dp, bottom = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = secret,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) {
                                    MaterialTheme.colorScheme.onPrimaryContainer
                                } else {
                                    MaterialTheme.colorScheme.onSurface
                                },
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "删除此条记录",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier
                                    .size(14.dp)
                                    .clip(CircleShape)
                                    .clickable { onRemove(secret) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ArchivePackConfigControls(
    selectedArchiveFormat: ArchiveOutputFormat,
    onSelectArchiveFormat: (ArchiveOutputFormat) -> Unit,
    selectedArchiveLevel: ArchiveCompressionLevel,
    onSelectArchiveLevel: (ArchiveCompressionLevel) -> Unit,
    archivePassword: String,
    onArchivePasswordChange: (String) -> Unit,
    savedArchivePasswords: List<String> = emptyList(),
    onSaveCurrentArchivePassword: (() -> Unit)? = null,
    onRemoveArchivePassword: (String) -> Unit = {},
    customArchiveName: String,
    onCustomArchiveNameChange: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            ArchiveOutputFormat.entries.forEach { format ->
                FlClashChoicePill(
                    selected = selectedArchiveFormat == format,
                    label = format.shortLabel,
                    onClick = { onSelectArchiveFormat(format) }
                )
            }
        }
        if (selectedArchiveFormat == ArchiveOutputFormat.ZIP ||
            selectedArchiveFormat == ArchiveOutputFormat.CBZ
        ) {
            FlClashSegmentedRow(
                items = ArchiveCompressionLevel.entries,
                selectedItem = selectedArchiveLevel,
                itemLabel = { it.label },
                onItemSelected = onSelectArchiveLevel
            )
            OutlinedTextField(
                value = archivePassword,
                onValueChange = onArchivePasswordChange,
                label = { Text("AES-256 归档密码（选填）") },
                placeholder = { Text("留空则不加密") },
                leadingIcon = { Icon(Icons.Default.Password, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
            SavedSecretHistoryChipsRow(
                label = "常用归档密码",
                currentInput = archivePassword,
                savedItems = savedArchivePasswords,
                onSelect = onArchivePasswordChange,
                onSaveCurrent = onSaveCurrentArchivePassword,
                onRemove = onRemoveArchivePassword
            )
        }
        OutlinedTextField(
            value = customArchiveName,
            onValueChange = onCustomArchiveNameChange,
            label = { Text("归档包名称（选填）") },
            placeholder = { Text("留空按时间命名") },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/**
 * 独立压缩包图片阅读器视图（支持加密压缩包密码解锁、条漫连读 / 左右翻页、手势双指缩放、实时色块解密阅读）
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FlClashArchiveImageReaderView(
    images: List<SelectedImageItem>,
    decryptedUriMap: Map<Uri, Uri>,
    liveDecryptEnabled: Boolean,
    readerLayoutMode: ReaderLayoutMode,
    isImmersive: Boolean,
    archiveBanner: String?,
    hasArchivePassword: Boolean,
    isExtracting: Boolean,
    extractDoneCount: Int,
    extractTotalCount: Int,
    extractCurrentFile: String,
    volumePageStepSignal: Int = 0,
    volumePageDirection: Int = 0,
    tapEdgePagingEnabled: Boolean = true,
    onCancelExtract: () -> Unit,
    onToggleImmersive: () -> Unit,
    onToggleLayoutMode: () -> Unit,
    onOpenReaderLayer2Menu: () -> Unit,
    onPickArchiveToRead: () -> Unit,
    onPickImagesToRead: () -> Unit,
    onSaveSingleImage: (SelectedImageItem) -> Unit,
    onShareSingleImage: (SelectedImageItem) -> Unit
) {
    val context = LocalContext.current
    val extractProgressTarget = if (extractTotalCount > 0) {
        (extractDoneCount.toFloat() / extractTotalCount.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }
    val animatedExtractProgress by animateFloatAsState(
        targetValue = extractProgressTarget,
        animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = JELLY_STIFFNESS),
        label = "ReaderExtractProgress"
    )

    if (images.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            LiquidGlassSurfaceCard(
                cornerRadius = 24.dp,
                isHighlighted = isExtracting,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(64.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (isExtracting) Icons.Default.Unarchive else Icons.Default.AutoStories,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(30.dp)
                            )
                        }
                    }
                    Text(
                        text = if (isExtracting) "正在解压压缩包..." else "压缩包图片阅读器",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    if (isExtracting) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = when {
                                        extractTotalCount > 0 -> "已解压 $extractDoneCount / $extractTotalCount 张"
                                        extractDoneCount > 0 -> "已解压 $extractDoneCount 张"
                                        else -> "正在读取压缩包索引..."
                                    },
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                if (extractTotalCount > 0) {
                                    Text(
                                        text = "${(animatedExtractProgress * 100).roundToInt()}%",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                            if (extractTotalCount > 0) {
                                LinearProgressIndicator(
                                    progress = { animatedExtractProgress },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp)),
                                    color = MaterialTheme.colorScheme.primary,
                                    trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                                )
                            } else {
                                LinearProgressIndicator(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp)),
                                    color = MaterialTheme.colorScheme.primary,
                                    trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                                )
                            }
                            if (extractCurrentFile.isNotBlank()) {
                                Text(
                                    text = extractCurrentFile,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            FilledTonalButton(
                                onClick = onCancelExtract,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("取消解压")
                            }
                        }
                    } else {
                        Text(
                            text = "直接阅读 .zip · .cbz · .7z · .rar · .tar.gz 内的图片，自动检测并支持输入压缩包密码解锁",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = onPickArchiveToRead,
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Default.FolderZip, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("打开压缩包")
                            }
                            FilledTonalButton(
                                onClick = onPickImagesToRead,
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("选择图片")
                            }
                        }
                    }
                }
            }
        }
        return
    }

    val listState = rememberLazyListState()
    val readerPagerState = rememberPagerState(
        initialPage = 0,
        pageCount = { images.size }
    )
    // 双页跨页模式：将相邻两页分组为跨页对（左→右 或 日漫右→左）
    val doubleSpreadPairs = remember(images) { images.chunked(2) }
    val spreadPagerState = rememberPagerState(
        initialPage = 0,
        pageCount = { doubleSpreadPairs.size.coerceAtLeast(1) }
    )
    val coroutineScope = rememberCoroutineScope()

    val isDoublePageMode = readerLayoutMode == ReaderLayoutMode.DOUBLE_PAGE_LTR ||
        readerLayoutMode == ReaderLayoutMode.DOUBLE_PAGE_RTL

    // 自动书签键值：按当前压缩包文件名或首图归属包名记忆上次阅读位置
    val archiveBookmarkKey = remember(archiveBanner, images.firstOrNull()?.uri) {
        archiveBanner?.substringBefore(" · ")?.trim()?.takeIf { it.isNotBlank() }
            ?: images.firstOrNull()?.fromArchiveName
            ?: images.firstOrNull()?.displayName
            ?: ""
    }

    val currentPageIndex = when (readerLayoutMode) {
        ReaderLayoutMode.VERTICAL_STRIP ->
            listState.firstVisibleItemIndex.coerceIn(0, (images.size - 1).coerceAtLeast(0))
        ReaderLayoutMode.HORIZONTAL_PAGER ->
            readerPagerState.currentPage.coerceIn(0, (images.size - 1).coerceAtLeast(0))
        ReaderLayoutMode.DOUBLE_PAGE_LTR, ReaderLayoutMode.DOUBLE_PAGE_RTL ->
            (spreadPagerState.currentPage * 2).coerceIn(0, (images.size - 1).coerceAtLeast(0))
    }

    // 统一翻页执行器（同时供音量上下键翻页与点击屏幕左右侧翻页调用）
    val stepReaderPage: (Int) -> Unit = { stepDirection ->
        if (stepDirection != 0 && images.isNotEmpty()) {
            coroutineScope.launch {
                when (readerLayoutMode) {
                    ReaderLayoutMode.VERTICAL_STRIP -> {
                        val target = (listState.firstVisibleItemIndex + stepDirection)
                            .coerceIn(0, images.size - 1)
                        listState.animateScrollToItem(target)
                    }
                    ReaderLayoutMode.HORIZONTAL_PAGER -> {
                        val target = (readerPagerState.currentPage + stepDirection)
                            .coerceIn(0, images.size - 1)
                        readerPagerState.animateScrollToPage(
                            page = target,
                            animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = JELLY_STIFFNESS)
                        )
                    }
                    ReaderLayoutMode.DOUBLE_PAGE_LTR, ReaderLayoutMode.DOUBLE_PAGE_RTL -> {
                        val targetSpread = (spreadPagerState.currentPage + stepDirection)
                            .coerceIn(0, (doubleSpreadPairs.size - 1).coerceAtLeast(0))
                        spreadPagerState.animateScrollToPage(
                            page = targetSpread,
                            animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = JELLY_STIFFNESS)
                        )
                    }
                }
            }
        }
    }

    // 响应手机音量上下键翻页（音量下键=下一页/下一跨页，音量上键=上一页/上一跨页）
    LaunchedEffect(volumePageStepSignal) {
        if (volumePageStepSignal > 0 && volumePageDirection != 0 && images.isNotEmpty()) {
            stepReaderPage(volumePageDirection)
        }
    }

    // 打开压缩包时自动恢复到上次阅读页码
    var hasRestoredBookmarkForKey by remember(archiveBookmarkKey, images.size) { mutableStateOf(false) }
    LaunchedEffect(archiveBookmarkKey, images.size) {
        if (!hasRestoredBookmarkForKey && archiveBookmarkKey.isNotBlank() && images.size > 1) {
            hasRestoredBookmarkForKey = true
            val savedPage = ImageCompressor.getReaderBookmark(context, archiveBookmarkKey)
            if (savedPage in 1 until images.size) {
                listState.scrollToItem(savedPage)
                readerPagerState.scrollToPage(savedPage)
                spreadPagerState.scrollToPage((savedPage / 2).coerceIn(0, (doubleSpreadPairs.size - 1).coerceAtLeast(0)))
                Toast.makeText(
                    context,
                    "已恢复至上次阅读位置：第 ${savedPage + 1} / ${images.size} 页",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    // 翻页/滑动时自动保存当前阅读页码书签
    LaunchedEffect(currentPageIndex, archiveBookmarkKey) {
        if (hasRestoredBookmarkForKey && archiveBookmarkKey.isNotBlank() && images.size > 1) {
            ImageCompressor.saveReaderBookmark(context, archiveBookmarkKey, currentPageIndex)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        when (readerLayoutMode) {
            ReaderLayoutMode.VERTICAL_STRIP -> {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .cdsSevenStopScrollFadeMask(
                            topFadeHeight = if (isImmersive) 0.dp else 22.dp,
                            bottomFadeHeight = 28.dp,
                            showTopFade = !isImmersive && listState.canScrollBackward,
                            showBottomFade = listState.canScrollForward
                        ),
                    contentPadding = PaddingValues(
                        top = if (isImmersive) 0.dp else 64.dp,
                        bottom = if (isImmersive) 64.dp else 148.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    itemsIndexed(
                        items = images,
                        key = { _, item -> item.uri.toString() }
                    ) { idx, item ->
                        val displayUri = if (liveDecryptEnabled) {
                            decryptedUriMap[item.uri] ?: item.uri
                        } else {
                            item.uri
                        }
                        ReaderZoomablePageItem(
                            uri = displayUri,
                            pageLabel = "${idx + 1} / ${images.size} · ${item.displayName}",
                            isVerticalMode = true,
                            onTapPage = onToggleImmersive,
                            onTapLeftEdge = if (tapEdgePagingEnabled) ({ stepReaderPage(-1) }) else null,
                            onTapRightEdge = if (tapEdgePagingEnabled) ({ stepReaderPage(1) }) else null,
                            onSavePage = { onSaveSingleImage(item) },
                            onSharePage = { onShareSingleImage(item) }
                        )
                    }
                }
            }

            ReaderLayoutMode.HORIZONTAL_PAGER -> {
                HorizontalPager(
                    state = readerPagerState,
                    beyondBoundsPageCount = 1,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(
                            top = if (isImmersive) 0.dp else 58.dp,
                            bottom = if (isImmersive) 0.dp else 90.dp
                        )
                ) { idx ->
                    val item = images[idx]
                    val displayUri = if (liveDecryptEnabled) {
                        decryptedUriMap[item.uri] ?: item.uri
                    } else {
                        item.uri
                    }
                    ReaderZoomablePageItem(
                        uri = displayUri,
                        pageLabel = "${idx + 1} / ${images.size} · ${item.displayName}",
                        isVerticalMode = false,
                        onTapPage = onToggleImmersive,
                        onTapLeftEdge = if (tapEdgePagingEnabled) ({ stepReaderPage(-1) }) else null,
                        onTapRightEdge = if (tapEdgePagingEnabled) ({ stepReaderPage(1) }) else null,
                        onSavePage = { onSaveSingleImage(item) },
                        onSharePage = { onShareSingleImage(item) }
                    )
                }
            }

            ReaderLayoutMode.DOUBLE_PAGE_LTR, ReaderLayoutMode.DOUBLE_PAGE_RTL -> {
                val isRtlManga = readerLayoutMode == ReaderLayoutMode.DOUBLE_PAGE_RTL
                val leftEdgeDir = if (isRtlManga) 1 else -1
                val rightEdgeDir = if (isRtlManga) -1 else 1
                HorizontalPager(
                    state = spreadPagerState,
                    beyondBoundsPageCount = 1,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(
                            top = if (isImmersive) 0.dp else 58.dp,
                            bottom = if (isImmersive) 0.dp else 90.dp
                        )
                ) { spreadIdx ->
                    val pair = doubleSpreadPairs.getOrNull(spreadIdx) ?: emptyList()
                    val orderedPair = if (isRtlManga && pair.size == 2) {
                        listOf(pair[1], pair[0])
                    } else {
                        pair
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        orderedPair.forEachIndexed { pairIdx, item ->
                            val realPageIdx = images.indexOf(item).coerceAtLeast(0)
                            val displayUri = if (liveDecryptEnabled) {
                                decryptedUriMap[item.uri] ?: item.uri
                            } else {
                                item.uri
                            }
                            val leftLimit = when {
                                orderedPair.size == 2 && pairIdx == 0 -> 0.64f
                                orderedPair.size == 2 && pairIdx == 1 -> -0.01f
                                else -> 0.32f
                            }
                            val rightStart = when {
                                orderedPair.size == 2 && pairIdx == 0 -> 1.01f
                                orderedPair.size == 2 && pairIdx == 1 -> 0.36f
                                else -> 0.68f
                            }
                            Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                                ReaderZoomablePageItem(
                                    uri = displayUri,
                                    pageLabel = "P.${realPageIdx + 1}",
                                    isVerticalMode = false,
                                    onTapPage = onToggleImmersive,
                                    onTapLeftEdge = if (tapEdgePagingEnabled) ({ stepReaderPage(leftEdgeDir) }) else null,
                                    onTapRightEdge = if (tapEdgePagingEnabled) ({ stepReaderPage(rightEdgeDir) }) else null,
                                    leftZoneLimit = leftLimit,
                                    rightZoneStart = rightStart,
                                    onSavePage = { onSaveSingleImage(item) },
                                    onSharePage = { onShareSingleImage(item) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // 顶部液态玻璃阅读器悬浮控制条（沉浸阅读时自动连同状态栏一起隐藏，点击画面中央唤出）
        AnimatedVisibility(
            visible = !isImmersive || isExtracting,
            enter = fadeIn(spring(stiffness = JELLY_STIFFNESS)) +
                scaleIn(initialScale = 0.92f, transformOrigin = TransformOrigin(0.5f, 0f), animationSpec = spring(dampingRatio = JELLY_DAMPING, stiffness = JELLY_STIFFNESS)),
            exit = fadeOut(spring(stiffness = 460f)) +
                scaleOut(targetScale = 0.92f, transformOrigin = TransformOrigin(0.5f, 0f), animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = 460f)),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
        LiquidGlassSurfaceCard(
            cornerRadius = 20.dp,
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.92f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Text(
                            text = "${currentPageIndex + 1} / ${images.size}",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    Text(
                        text = archiveBanner ?: images[currentPageIndex].displayName,
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        modifier = Modifier.flClashJellyClick(
                            pressScale = 0.88f,
                            shape = RoundedCornerShape(10.dp),
                            onClick = onToggleLayoutMode
                        )
                    ) {
                        Text(
                            text = readerLayoutMode.label,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                        )
                    }

                    IconButton(onClick = onPickArchiveToRead, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = Icons.Default.FolderZip,
                            contentDescription = "打开其他压缩包",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(onClick = onOpenReaderLayer2Menu, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = if (hasArchivePassword || liveDecryptEnabled) Icons.Default.Key else Icons.Default.Tune,
                            contentDescription = "阅读设置与密码",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(onClick = onToggleImmersive, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = if (isImmersive) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                            contentDescription = "全屏阅读",
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
            AnimatedVisibility(visible = isExtracting) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 12.dp, end = 12.dp, bottom = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = when {
                                extractTotalCount > 0 -> "正在解压 ($extractDoneCount/$extractTotalCount) · $extractCurrentFile"
                                extractDoneCount > 0 -> "正在解压 ($extractDoneCount 张) · $extractCurrentFile"
                                else -> "正在解析压缩包条目..."
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        if (extractTotalCount > 0) {
                            Text(
                                text = "${(animatedExtractProgress * 100).roundToInt()}%",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    if (extractTotalCount > 0) {
                        LinearProgressIndicator(
                            progress = { animatedExtractProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                        )
                    } else {
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                        )
                    }
                }
            }
        }
        }

        AnimatedVisibility(
            visible = !isImmersive && images.size > 1,
            enter = fadeIn(spring(stiffness = JELLY_STIFFNESS)) +
                scaleIn(initialScale = 0.92f, transformOrigin = TransformOrigin(0.5f, 1f), animationSpec = spring(dampingRatio = JELLY_DAMPING, stiffness = JELLY_STIFFNESS)),
            exit = fadeOut(spring(stiffness = 460f)) +
                scaleOut(targetScale = 0.92f, transformOrigin = TransformOrigin(0.5f, 1f), animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = 460f)),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(start = 20.dp, end = 20.dp, bottom = 78.dp)
        ) {
            LiquidGlassSurfaceCard(
                cornerRadius = 20.dp,
                containerColor = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.92f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("${currentPageIndex + 1}", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Slider(
                        value = currentPageIndex.toFloat(),
                        onValueChange = { target ->
                            val targetIdx = target.roundToInt().coerceIn(0, images.size - 1)
                            coroutineScope.launch {
                                when (readerLayoutMode) {
                                    ReaderLayoutMode.VERTICAL_STRIP -> listState.scrollToItem(targetIdx)
                                    ReaderLayoutMode.HORIZONTAL_PAGER -> readerPagerState.scrollToPage(targetIdx)
                                    ReaderLayoutMode.DOUBLE_PAGE_LTR, ReaderLayoutMode.DOUBLE_PAGE_RTL ->
                                        spreadPagerState.scrollToPage((targetIdx / 2).coerceIn(0, (doubleSpreadPairs.size - 1).coerceAtLeast(0)))
                                }
                            }
                        },
                        valueRange = 0f..(images.size - 1).toFloat(),
                        modifier = Modifier.weight(1f)
                    )
                    Text("${images.size}", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

@Composable
private fun ReaderZoomablePageItem(
    uri: Uri,
    pageLabel: String,
    isVerticalMode: Boolean,
    onTapPage: () -> Unit,
    onTapLeftEdge: (() -> Unit)? = null,
    onTapRightEdge: (() -> Unit)? = null,
    leftZoneLimit: Float = 0.32f,
    rightZoneStart: Float = 0.68f,
    onSavePage: () -> Unit,
    onSharePage: () -> Unit
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    var scale by remember(uri) { mutableFloatStateOf(1f) }
    var offsetX by remember(uri) { mutableFloatStateOf(0f) }
    var offsetY by remember(uri) { mutableFloatStateOf(0f) }
    var boxWidthPx by remember { mutableIntStateOf(0) }
    var boxHeightPx by remember { mutableIntStateOf(0) }

    // 超大图片读取加速：启用 GPU 硬件位图直传 (allowHardware) + 智能降采样边界 (2560x3840)，百兆大图滑动 0 卡顿
    val fastPageImageRequest = remember(uri, context) {
        ImageRequest.Builder(context)
            .data(uri)
            .size(2560, 3840)
            .precision(Precision.INEXACT)
            .allowHardware(true)
            .crossfade(false)
            .build()
    }

    val animatedScale by animateFloatAsState(
        targetValue = scale,
        animationSpec = spring(dampingRatio = JELLY_DAMPING, stiffness = JELLY_STIFFNESS),
        label = "ReaderPageZoom"
    )
    // 平移偏移量同样接入果冻弹簧动画，使双击复位或缩回 1.0x 时画面沿抛物线顺滑回正
    val animatedOffsetX by animateFloatAsState(
        targetValue = offsetX,
        animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = 420f),
        label = "ReaderPagePanX"
    )
    val animatedOffsetY by animateFloatAsState(
        targetValue = offsetY,
        animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = 420f),
        label = "ReaderPagePanY"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (isVerticalMode) Modifier else Modifier.fillMaxHeight())
            .clip(RoundedCornerShape(if (isVerticalMode) 8.dp else 14.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerLow)
            .onSizeChanged {
                boxWidthPx = it.width
                boxHeightPx = it.height
            }
            .pointerInput(uri, onTapLeftEdge != null, onTapRightEdge != null, leftZoneLimit, rightZoneStart) {
                detectTapGestures(
                    onDoubleTap = { tapOffset ->
                        if (scale > 1.05f) {
                            scale = 1f
                            offsetX = 0f
                            offsetY = 0f
                        } else {
                            val targetZoom = 2.25f
                            scale = targetZoom
                            if (boxWidthPx > 0 && boxHeightPx > 0) {
                                val centerX = boxWidthPx / 2f
                                val centerY = boxHeightPx / 2f
                                val maxDx = (boxWidthPx * (targetZoom - 1f)) / 2f
                                val maxDy = (boxHeightPx * (targetZoom - 1f)) / 2f
                                offsetX = ((centerX - tapOffset.x) * 1.1f).coerceIn(-maxDx, maxDx)
                                offsetY = ((centerY - tapOffset.y) * 1.1f).coerceIn(-maxDy, maxDy)
                            }
                        }
                    },
                    onTap = { tapOffset ->
                        if (scale <= 1.05f && boxWidthPx > 0 && (onTapLeftEdge != null || onTapRightEdge != null)) {
                            val xRatio = tapOffset.x / boxWidthPx.toFloat()
                            when {
                                xRatio < leftZoneLimit && onTapLeftEdge != null -> {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    onTapLeftEdge()
                                }
                                xRatio > rightZoneStart && onTapRightEdge != null -> {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    onTapRightEdge()
                                }
                                else -> onTapPage()
                            }
                        } else {
                            onTapPage()
                        }
                    }
                )
            }
            .then(
                if (!isVerticalMode || scale > 1.01f) {
                    Modifier.pointerInput(uri, boxWidthPx, boxHeightPx) {
                        detectTransformGestures { centroid, pan, zoom, _ ->
                            val prevScale = scale
                            val newScale = (prevScale * zoom).coerceIn(1f, 4.0f)
                            val scaleRatio = if (prevScale > 0.01f) newScale / prevScale else 1f
                            scale = newScale
                            if (newScale > 1.02f) {
                                val centerX = if (boxWidthPx > 0) boxWidthPx / 2f else 0f
                                val centerY = if (boxHeightPx > 0) boxHeightPx / 2f else 0f
                                val originDx = centroid.x - centerX
                                val originDy = centroid.y - centerY
                                // Open Claude UI 反编译手势缩放不动点仿射方程：
                                // idealTx = Ox - (Ox - prevTx) * (Starget / Scurrent)
                                val effectivePanX = if (hypot(pan.x, pan.y) >= 4f || zoom != 1f) pan.x else 0f
                                val effectivePanY = if (hypot(pan.x, pan.y) >= 4f || zoom != 1f) pan.y else 0f
                                val idealTx = originDx - (originDx - offsetX) * scaleRatio + effectivePanX
                                val idealTy = originDy - (originDy - offsetY) * scaleRatio + effectivePanY
                                val maxDx = if (boxWidthPx > 0) (boxWidthPx * (newScale - 1f)) / 2f else 1200f
                                val maxDy = if (boxHeightPx > 0) (boxHeightPx * (newScale - 1f)) / 2f else 1600f
                                // 0.7f 边界阻尼缓冲：超出边界时施加 0.3x 柔性收敛
                                offsetX = if (idealTx in -maxDx..maxDx) {
                                    idealTx
                                } else {
                                    val clampedX = idealTx.coerceIn(-maxDx, maxDx)
                                    clampedX + (idealTx - clampedX) * 0.3f
                                }.coerceIn(-maxDx * 1.15f, maxDx * 1.15f)
                                offsetY = if (idealTy in -maxDy..maxDy) {
                                    idealTy
                                } else {
                                    val clampedY = idealTy.coerceIn(-maxDy, maxDy)
                                    clampedY + (idealTy - clampedY) * 0.3f
                                }.coerceIn(-maxDy * 1.15f, maxDy * 1.15f)
                            } else {
                                scale = 1f
                                offsetX = 0f
                                offsetY = 0f
                            }
                        }
                    }
                } else {
                    Modifier
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = fastPageImageRequest,
            contentDescription = pageLabel,
            contentScale = if (isVerticalMode) ContentScale.FillWidth else ContentScale.Fit,
            modifier = Modifier
                .fillMaxWidth()
                .graphicsLayer {
                    scaleX = animatedScale
                    scaleY = animatedScale
                    translationX = animatedOffsetX
                    translationY = animatedOffsetY
                }
        )

        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color.Black.copy(alpha = 0.52f)
            ) {
                Text(
                    text = pageLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
            Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.52f),
                modifier = Modifier
                    .size(28.dp)
                    .clickable { onSavePage() }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = "保存此页到相册",
                        tint = Color.White,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }
            Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.52f),
                modifier = Modifier
                    .size(28.dp)
                    .clickable { onSharePage() }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "分享此页",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

/**
 * 加密压缩包密码解锁液态玻璃弹窗
 */
@Composable
private fun ArchivePasswordUnlockModal(
    archiveNames: String,
    passwordInput: String,
    errorText: String?,
    savedPasswords: List<String> = emptyList(),
    onRemoveSavedPassword: (String) -> Unit = {},
    onPasswordChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onConfirmUnlock: () -> Unit
) {
    var passwordVisible by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismiss
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        LiquidGlassSurfaceCard(
            cornerRadius = 26.dp,
            isHighlighted = true,
            modifier = Modifier
                .widthIn(max = 420.dp)
                .fillMaxWidth()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {}
                )
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "压缩包受密码保护",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = archiveNames,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                OutlinedTextField(
                    value = passwordInput,
                    onValueChange = onPasswordChange,
                    label = { Text("输入压缩包密码") },
                    singleLine = true,
                    isError = errorText != null,
                    visualTransformation = if (passwordVisible) {
                        VisualTransformation.None
                    } else {
                        PasswordVisualTransformation()
                    },
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = "切换密码可见"
                            )
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                if (savedPasswords.isNotEmpty()) {
                    SavedSecretHistoryChipsRow(
                        label = "常用解锁密码",
                        currentInput = passwordInput,
                        savedItems = savedPasswords,
                        onSelect = onPasswordChange,
                        onSaveCurrent = null,
                        onRemove = onRemoveSavedPassword
                    )
                }

                if (errorText != null) {
                    Text(
                        text = errorText,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FilledTonalButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("取消")
                    }
                    Button(
                        onClick = onConfirmUnlock,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("解锁并打开")
                    }
                }
            }
        }
    }
}

/**
 * 右下角液态玻璃双层启动按钮组：
 * 左侧为圆形液态玻璃二级菜单触发钮（点击弹出第二层菜单，点击空白处缩回），右侧为 FlClash 主启动胶囊
 */
@OptIn(ExperimentalAnimationApi::class)
@Composable
private fun FlClashLiquidGlassFloatingBarActions(
    currentMode: ProcessMode,
    archiveSubMode: ArchiveSubMode,
    packResultIntoArchive: Boolean,
    archiveFormat: ArchiveOutputFormat,
    selectedCount: Int,
    isProcessing: Boolean,
    completedCount: Int,
    totalTaskCount: Int,
    obfuscationKeyText: String,
    isQuickHubExpanded: Boolean,
    onToggleQuickHub: () -> Unit,
    onMissingKeyOpenSheet: () -> Unit,
    onStartClick: () -> Unit,
    onCancelClick: () -> Unit
) {
    val requiresKey = currentMode == ProcessMode.OBFUSCATE_ENCRYPT ||
        currentMode == ProcessMode.DEOBFUSCATE_RESTORE
    val missingKey = requiresKey && obfuscationKeyText.isBlank()

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        val hubRotation by animateFloatAsState(
            targetValue = if (isQuickHubExpanded) 45f else 0f,
            animationSpec = spring(dampingRatio = JELLY_DAMPING, stiffness = JELLY_STIFFNESS),
            label = "QuickHubRotate"
        )
        val plusBgColor by animateColorAsState(
            targetValue = if (isQuickHubExpanded) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.96f)
            },
            animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = JELLY_STIFFNESS),
            label = "PlusHubBg"
        )
        val plusIconColor by animateColorAsState(
            targetValue = if (isQuickHubExpanded) {
                MaterialTheme.colorScheme.onPrimary
            } else {
                MaterialTheme.colorScheme.primary
            },
            animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = JELLY_STIFFNESS),
            label = "PlusHubIcon"
        )

        // 左侧圆形「+」快捷按钮：固定 48.dp 正圆容器 + Canvas 几何中心绘制加号，确保加号在任何分辨率与字重下 100% 绝对中置
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(48.dp)
                .shadow(
                    elevation = 8.dp,
                    shape = CircleShape,
                    ambientColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f),
                    spotColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.28f)
                )
                .flClashJellyClick(
                    enabled = true,
                    pressScale = 0.88f,
                    shape = CircleShape,
                    onClick = onToggleQuickHub
                )
                .background(plusBgColor, CircleShape)
                .border(
                    width = 1.dp,
                    color = if (isQuickHubExpanded) {
                        Color.White.copy(alpha = 0.45f)
                    } else {
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.32f)
                    },
                    shape = CircleShape
                )
        ) {
            Canvas(
                modifier = Modifier
                    .size(18.dp)
                    .graphicsLayer { rotationZ = hubRotation }
            ) {
                val strokePx = 2.4.dp.toPx()
                val cx = size.width / 2f
                val cy = size.height / 2f
                val halfArm = size.minDimension * 0.42f
                drawLine(
                    color = plusIconColor,
                    start = Offset(cx - halfArm, cy),
                    end = Offset(cx + halfArm, cy),
                    strokeWidth = strokePx,
                    cap = StrokeCap.Round
                )
                drawLine(
                    color = plusIconColor,
                    start = Offset(cx, cy - halfArm),
                    end = Offset(cx, cy + halfArm),
                    strokeWidth = strokePx,
                    cap = StrokeCap.Round
                )
            }
        }

        val containerColor by animateColorAsState(
            targetValue = when {
                isProcessing -> MaterialTheme.colorScheme.tertiaryContainer
                selectedCount == 0 -> MaterialTheme.colorScheme.secondaryContainer
                missingKey -> MaterialTheme.colorScheme.errorContainer
                else -> MaterialTheme.colorScheme.primary
            },
            animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = JELLY_STIFFNESS),
            label = "RunFabColor"
        )

        val contentColor = when {
            isProcessing -> MaterialTheme.colorScheme.onTertiaryContainer
            selectedCount == 0 -> MaterialTheme.colorScheme.onSecondaryContainer
            missingKey -> MaterialTheme.colorScheme.onErrorContainer
            else -> MaterialTheme.colorScheme.onPrimary
        }

        // 右侧主操作胶囊按钮：与左侧 48.dp 正圆加号按钮保持严格等高 (48.dp) 与水平中轴线对齐
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .height(48.dp)
                .shadow(
                    elevation = 8.dp,
                    shape = CircleShape,
                    ambientColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.25f),
                    spotColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.30f)
                )
                .flClashJellyClick(
                    enabled = true,
                    pressScale = 0.88f,
                    shape = CircleShape,
                    onClick = {
                        when {
                            isProcessing -> onCancelClick()
                            selectedCount == 0 -> onToggleQuickHub()
                            missingKey -> onMissingKeyOpenSheet()
                            else -> onStartClick()
                        }
                    }
                )
                .background(containerColor, CircleShape)
                .border(
                    width = 1.dp,
                    color = Color.White.copy(alpha = 0.35f),
                    shape = CircleShape
                )
                .padding(horizontal = 20.dp)
        ) {
            AnimatedContent(
                targetState = Triple(currentMode, selectedCount, isProcessing),
                contentAlignment = Alignment.Center,
                transitionSpec = {
                    (scaleIn(
                        initialScale = 0.85f,
                        animationSpec = spring(dampingRatio = JELLY_DAMPING, stiffness = JELLY_STIFFNESS)
                    ) + fadeIn()).togetherWith(
                        scaleOut(targetScale = 0.85f) + fadeOut()
                    )
                },
                label = "AppFabTextMorph"
            ) { (mode, count, running) ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    val icon = when {
                        running -> Icons.Default.Close
                        count == 0 -> Icons.Default.FolderZip
                        missingKey -> Icons.Default.Key
                        mode == ProcessMode.ARCHIVE_HUB && archiveSubMode == ArchiveSubMode.PACK_TO_ARCHIVE -> Icons.Default.Archive
                        mode == ProcessMode.ARCHIVE_HUB && archiveSubMode == ArchiveSubMode.EXTRACT_FROM_ARCHIVE -> Icons.Default.Unarchive
                        packResultIntoArchive -> Icons.Default.Archive
                        else -> Icons.Default.PlayArrow
                    }
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = contentColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))

                    val text = when {
                        running -> if (totalTaskCount > 0) "$completedCount / $totalTaskCount · 取消" else "执行中 · 点击取消"
                        count == 0 -> "导入压缩包 / 图片"
                        missingKey -> "设置口令"
                        mode == ProcessMode.COMPRESS_TRANSCODE ->
                            if (packResultIntoArchive) "压缩打包 ($count)" else "开始压缩 ($count)"
                        mode == ProcessMode.OBFUSCATE_ENCRYPT ->
                            if (packResultIntoArchive) "混淆打包 ($count)" else "开始混淆 ($count)"
                        mode == ProcessMode.DEOBFUSCATE_RESTORE ->
                            if (packResultIntoArchive) "还原打包 ($count)" else "开始还原 ($count)"
                        mode == ProcessMode.ARCHIVE_HUB && archiveSubMode == ArchiveSubMode.PACK_TO_ARCHIVE ->
                            "打包 .${archiveFormat.extension} ($count)"
                        else -> "导出 ($count)"
                    }

                    Text(
                        text = text,
                        style = MaterialTheme.typography.titleSmall.copy(
                            platformStyle = PlatformTextStyle(includeFontPadding = false),
                            lineHeightStyle = LineHeightStyle(
                                alignment = LineHeightStyle.Alignment.Center,
                                trim = LineHeightStyle.Trim.Both
                            )
                        ),
                        fontWeight = FontWeight.Bold,
                        color = contentColor
                    )
                }
            }
        }
    }
}

/**
 * 底部悬浮果冻胶囊导航栏 (5个页签：压缩 · 混淆 · 还原 · 归档 · 阅读)
 * 支持手指按住底栏直接左右拖动滑块切换 + 点击果冻过冲回弹 + 全屏滑页实时联动
 */
/**
 * 1:1 源码级复刻 FlClash-0.9.1 FloatingNavigationBar + LiquidGlass (lib/ui/navigation_dock.dart & lib/ui/liquid_glass.dart):
 * 1. 整体按压膨胀与越界橡皮筋拉伸 (_PressTransform: _swell + _stretch, _pressSpring: stiffness=311, ratio=0.593)
 * 2. 指尖触控径向流光 (_touchGlow: LiquidGlassGlow, _glowReach=28dp*(1+3*_glowSpread), 随手指实时游走并在松手时扩散消散)
 * 3. 静态沉降托盘 (_Lens: 亮色 Tone 90 / 暗色 Tone 4 下沉托盘) 与 抬升液态玻璃凸透镜 (_GlassLens: 按住/拖动时 _lift 0->1，
 *    透镜上下向外膨胀溢出底栏 _lensGrowth*2 = +16dp，带红蓝边缘色散折射 dispersion=6.5 与上下镜面弧光 facing=smoothstep)
 * 4. 速度与制动驱动的果冻拉伸挤压 (_wobble: _jellyStretch=0.20 * saturate(|v|/3) - _jellySquash=0.15 * saturate(braking/25))
 * 5. 双通道像素级透镜裁剪染色放大 (_RenderLensTint: 透镜外 clipPath(Difference) 保持 1.0x 原色，透镜内 clipPath(Intersect)
 *    实时放大 1 + 0.16 * _lift 倍并染为 Primary 高光色，滑过任意图标与文字时呈现逐像素切分变色与透镜放大！)
 */
@Composable
private fun FlClashFloatingLiquidDockBar(
    continuousPagePositionProvider: () -> Float,
    currentMode: ProcessMode,
    isProcessing: Boolean,
    onSelectMode: (ProcessMode) -> Unit
) {
    val themeProps = LocalFlClashThemeProps.current
    val isFloating = themeProps.floatingNavigationBar
    val glassMode = themeProps.liquidGlass
    val isGlass = glassMode != FlClashLiquidGlassMode.NONE
    val isUltraGlass = glassMode == FlClashLiquidGlassMode.ULTRA
    val isDark = isFlClashDarkTheme()

    val modes = ProcessMode.entries
    val tabCount = modes.size
    val lastIndex = (tabCount - 1).coerceAtLeast(0)
    val continuousPagePosition = continuousPagePositionProvider().coerceIn(0f, lastIndex.toFloat())

    var barWidthPx by remember { mutableIntStateOf(0) }
    var barHeightPx by remember { mutableIntStateOf(0) }
    var isPointerDown by remember { mutableStateOf(false) }
    var isDraggingBar by remember { mutableStateOf(false) }
    var dragLensTarget by remember { mutableFloatStateOf(continuousPagePosition) }
    var rawBarOvershootStretch by remember { mutableFloatStateOf(0f) }
    var glowCenter by remember { mutableStateOf(Offset.Zero) }
    var lastDragVelocity by remember { mutableFloatStateOf(0f) }
    var prevLensVal by remember { mutableFloatStateOf(continuousPagePosition) }

    val coroutineScope = rememberCoroutineScope()
    val density = LocalDensity.current

    // _lens position: dragging uses _followSpring (stiffness=1024, ratio=0.9), release/tap uses _travelSpring (stiffness=380, ratio=0.72)
    val targetLensPosition = if (isPointerDown || isDraggingBar) {
        dragLensTarget
    } else {
        continuousPagePosition
    }

    val animatedLens by animateFloatAsState(
        targetValue = targetLensPosition,
        animationSpec = spring(
            dampingRatio = if (isDraggingBar) FLCLASH_FOLLOW_DAMPING else FLCLASH_TRAVEL_DAMPING,
            stiffness = if (isDraggingBar) FLCLASH_FOLLOW_STIFFNESS else FLCLASH_TRAVEL_STIFFNESS
        ),
        label = "AppLensPosition"
    )

    // 计算实时透镜速度与制动量，驱动 _wobble 果冻拉伸挤压 (_jellySpring: stiffness=100, ratio=0.4)
    val frameDelta = (animatedLens - prevLensVal)
    LaunchedEffect(animatedLens) {
        lastDragVelocity = frameDelta * 28f
        prevLensVal = animatedLens
    }
    val remainingDist = abs(targetLensPosition - animatedLens)
    val rawJellyTarget = when {
        abs(frameDelta) > 0.002f -> {
            val speedTerm = FLCLASH_JELLY_STRETCH * flClashSaturate(abs(frameDelta) * 32f / 3f)
            val brakeTerm = if (remainingDist < 0.28f) FLCLASH_JELLY_SQUASH * (1f - remainingDist / 0.28f) else 0f
            (speedTerm - brakeTerm * 0.55f).coerceIn(-0.15f, 0.22f)
        }
        else -> 0f
    }
    val animatedJelly by animateFloatAsState(
        targetValue = rawJellyTarget,
        animationSpec = spring(
            dampingRatio = FLCLASH_JELLY_DAMPING,
            stiffness = FLCLASH_JELLY_STIFFNESS
        ),
        label = "AppLensJelly"
    )

    // _lift (透镜抬升: 按下或透镜运动途中保持抬升，到达目标后回落)
    val isLensMoving = abs(targetLensPosition - animatedLens) > 0.04f
    val animatedLift by animateFloatAsState(
        targetValue = if (isPointerDown || isDraggingBar || isLensMoving) 1f else 0f,
        animationSpec = spring(
            dampingRatio = 0.68f,
            stiffness = 340f
        ),
        label = "AppLensLift"
    )

    // _swell & _stretch (整条底栏的 ElasticPress 膨胀与越界拉拽形变)
    val animatedBarSwell by animateFloatAsState(
        targetValue = if (isPointerDown) 1f else 0f,
        animationSpec = spring(
            dampingRatio = FLCLASH_PRESS_DAMPING,
            stiffness = FLCLASH_PRESS_STIFFNESS
        ),
        label = "AppBarSwell"
    )
    val animatedBarStretch by animateFloatAsState(
        targetValue = if (isPointerDown) rawBarOvershootStretch else 0f,
        animationSpec = spring(
            dampingRatio = if (isPointerDown) 0.85f else FLCLASH_PRESS_DAMPING,
            stiffness = if (isPointerDown) 850f else FLCLASH_PRESS_STIFFNESS
        ),
        label = "AppBarStretch"
    )

    // _glow & _glowSpread (指尖触控径向流光)
    val animatedGlow by animateFloatAsState(
        targetValue = if (isPointerDown) 1f else 0f,
        animationSpec = spring(
            dampingRatio = 0.82f,
            stiffness = if (isPointerDown) 750f else 220f
        ),
        label = "AppDockGlow"
    )
    val animatedGlowSpread by animateFloatAsState(
        targetValue = if (isPointerDown) 0f else 1f,
        animationSpec = spring(dampingRatio = 0.85f, stiffness = 220f),
        label = "AppDockGlowSpread"
    )

    val barPaddingPx = with(density) { 4.dp.toPx() }
    val lensGrowthPx = with(density) { 8.dp.toPx() }
    val maxPressGrowthPx = with(density) { 16.dp.toPx() }
    val glowBaseReachPx = with(density) { 46.dp.toPx() }

    val colorScheme = MaterialTheme.colorScheme
    val primaryColor = colorScheme.primary
    val onSurfaceVariantColor = colorScheme.onSurfaceVariant

    // LiquidGlassStyle.pill(colorScheme) 底色 (lib/ui/liquid_glass.dart lines 130-151)
    val dockBaseFill = when {
        !isGlass -> if (isDark) colorScheme.surfaceContainerHigh else colorScheme.surfaceContainerLow
        isDark -> colorScheme.surfaceContainerHighest.copy(alpha = 0.64f)
        else -> Color(0xD8F5F5F8)
    }

    // _Lens 静态托盘底色 (lib/ui/navigation_dock.dart lines 1340-1360: Light Tone 90, Dark Sunken Tone 4)
    val restingPlatterColor = when {
        isGlass && isDark -> Color(0xFF0A0A0D).copy(alpha = 0.86f)
        isGlass && !isDark -> Color(0xFFE3E4EA).copy(alpha = 0.88f)
        isDark -> colorScheme.surfaceContainerHighest
        else -> colorScheme.surfaceContainer
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = if (isFloating) 5.dp else 0.dp)
            .height(62.dp) // _barHeight = 62 in navigation_dock.dart line 20
            .onSizeChanged {
                barWidthPx = it.width
                barHeightPx = it.height
            }
            .graphicsLayer {
                // FlClash _PressTransform on the whole dock bar (navigation_dock.dart lines 1280-1286)
                val w = size.width.coerceAtLeast(1f)
                val h = size.height.coerceAtLeast(1f)
                val swell = 1f + animatedBarSwell * min(0.22f, maxPressGrowthPx / max(w, h))
                val stretchScaleX = 1f + (abs(animatedBarStretch) / w) * FLCLASH_PULL_STRETCH
                scaleX = swell * stretchScaleX
                scaleY = swell
                translationX = animatedBarStretch
                clip = false // 允许抬升的 _GlassLens 上下溢出底栏边界 (+8dp)
            }
            .pointerInput(barWidthPx, tabCount) {
                if (barWidthPx <= 0 || tabCount <= 0) return@pointerInput
                val innerSpan = (barWidthPx - barPaddingPx * 2f).coerceAtLeast(1f)
                val pitch = innerSpan / tabCount.toFloat()
                val shortestSide = barHeightPx.toFloat().coerceAtLeast(62f)
                val pullLimitPx = shortestSide * FLCLASH_PULL_LIMIT

                fun positionAt(dx: Float): Float {
                    val rawPos = (dx - barPaddingPx) / pitch - 0.5f
                    return when {
                        rawPos < 0f -> flClashRubberBand(rawPos, FLCLASH_OVERDRAG)
                        rawPos > lastIndex -> lastIndex + flClashRubberBand(rawPos - lastIndex, FLCLASH_OVERDRAG)
                        else -> rawPos
                    }
                }

                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    isPointerDown = true
                    isDraggingBar = false
                    glowCenter = down.position
                    rawBarOvershootStretch = 0f

                    val startPos = positionAt(down.position.x)
                    val initialIdx = startPos.roundToInt().coerceIn(0, lastIndex)
                    var activeIdx = initialIdx
                    dragLensTarget = initialIdx.toFloat()

                    do {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: event.changes.firstOrNull() ?: break
                        if (change.pressed) {
                            glowCenter = change.position
                            val dxFromDown = abs(change.position.x - down.position.x)
                            if (!isDraggingBar && dxFromDown > 6f) {
                                isDraggingBar = true
                            }
                            if (isDraggingBar) {
                                change.consume()
                                // 计算手指越过底栏左右两端时的橡皮筋拉伸量 (_stretch)
                                val overshootPx = change.position.x - change.position.x.coerceIn(0f, barWidthPx.toFloat())
                                rawBarOvershootStretch = flClashRubberBand(overshootPx, pullLimitPx)

                                val pos = positionAt(change.position.x)
                                dragLensTarget = pos
                                val hoveredIdx = pos.roundToInt().coerceIn(0, lastIndex)
                                if (hoveredIdx != activeIdx) {
                                    activeIdx = hoveredIdx
                                    onSelectMode(modes[hoveredIdx])
                                }
                            }
                        }
                    } while (event.changes.any { it.pressed })

                    val committedIdx = dragLensTarget.roundToInt().coerceIn(0, lastIndex)
                    dragLensTarget = committedIdx.toFloat()
                    rawBarOvershootStretch = 0f
                    isDraggingBar = false
                    onSelectMode(modes[committedIdx])
                    coroutineScope.launch {
                        delay(70L)
                        isPointerDown = false
                    }
                }
            }
    ) {
        val innerWidthPx = (barWidthPx - barPaddingPx * 2f).coerceAtLeast(1f)
        val innerHeightPx = (barHeightPx - barPaddingPx * 2f).coerceAtLeast(1f)
        val pitchPx = innerWidthPx / tabCount.toFloat()
        val baseLensWidthPx = pitchPx + barPaddingPx * 1.2f

        // FlClash _lensRect (lib/ui/navigation_dock.dart lines 108-125):
        // growth = _lensGrowth * 2 * lift
        // lensWidth = (width + growth) * (1 + stretch)
        // lensHeight = (height + growth) * (1 - stretch * _jellyAspect)
        val liftVal = animatedLift.coerceIn(0f, 1f)
        val growthPx = lensGrowthPx * 2f * liftVal
        val lensWidthPx = (baseLensWidthPx + growthPx) * (1f + animatedJelly)
        val lensHeightPx = (innerHeightPx + growthPx) * (1f - animatedJelly * FLCLASH_JELLY_ASPECT)
        val lensCenterX = barPaddingPx + (animatedLens + 0.5f) * pitchPx
        val lensCenterY = barHeightPx / 2f
        val lensLeft = lensCenterX - lensWidthPx / 2f
        val lensTop = lensCenterY - lensHeightPx / 2f
        val lensRect = Rect(
            left = lensLeft,
            top = lensTop,
            right = lensLeft + lensWidthPx,
            bottom = lensTop + lensHeightPx
        )

        // 1. 底层：_DockSurface (LiquidGlassStyle.pill + 顶底镜面折射边 + _touchGlow 指尖流光)
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .shadow(
                    elevation = if (isFloating) 12.dp else 4.dp,
                    shape = if (isFloating) CircleShape else RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                    ambientColor = Color.Black.copy(alpha = if (isDark) 0.42f else 0.14f),
                    spotColor = Color.Black.copy(alpha = if (isDark) 0.52f else 0.18f)
                )
        ) {
            val barCorner = if (isFloating) size.height / 2f else 20.dp.toPx()
            val barRoundRect = RoundRect(
                rect = Rect(0f, 0f, size.width, size.height),
                cornerRadius = CornerRadius(barCorner, barCorner)
            )
            val barPath = Path().apply { addRoundRect(barRoundRect) }

            clipPath(barPath) {
                // Pill 主玻璃基底
                drawRect(color = dockBaseFill)

                // LiquidGlassStyle.pill 顶底漫反射环境光泽
                if (isGlass) {
                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color.White.copy(alpha = if (isDark) 0.14f else 0.55f),
                                Color.Transparent,
                                Color.Black.copy(alpha = if (isDark) 0.18f else 0.04f)
                            )
                        )
                    )
                }

                // _touchGlow: 指尖触控径向流光 (navigation_dock.dart lines 866-874)
                if (animatedGlow > 0.01f) {
                    val reach = glowBaseReachPx * (1f + 2.4f * animatedGlowSpread)
                    drawRect(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                primaryColor.copy(alpha = 0.24f * animatedGlow),
                                Color.White.copy(alpha = 0.16f * animatedGlow),
                                Color.Transparent
                            ),
                            center = glowCenter,
                            radius = reach.coerceAtLeast(32f)
                        )
                    )
                }
            }

            // LiquidGlassStyle.pill 0.67dp 镜面高光描边 (kLine = 0.67 in liquid_glass.frag)
            drawRoundRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = if (isDark) 0.35f else 0.82f),
                        onSurfaceVariantColor.copy(alpha = 0.14f),
                        Color.White.copy(alpha = if (isDark) 0.22f else 0.52f)
                    )
                ),
                cornerRadius = CornerRadius(barCorner, barCorner),
                style = Stroke(width = 0.85.dp.toPx())
            )
        }

        // 2. 中层：静态沉降托盘 (_Lens) 与 抬升液态玻璃凸透镜 (_GlassLens)
        // 当手指按下或拖动时 (liftVal > 0)，_Lens 渐隐并抬升转化为溢出底栏边界的透明折射凸透镜 _GlassLens！
        Canvas(modifier = Modifier.fillMaxSize()) {
            val r = (lensRect.height / 2f).coerceAtLeast(1f)
            val topLeft = Offset(lensRect.left, lensRect.top)
            val lSize = Size(lensRect.width.coerceAtLeast(1f), lensRect.height.coerceAtLeast(1f))
            val cRadius = CornerRadius(r, r)

            // 2a. _Lens (静态托盘: alpha 随 liftVal 升高而平滑消退)
            val platterAlpha = (1f - liftVal * 0.72f).coerceIn(0f, 1f)
            if (platterAlpha > 0.01f) {
                drawRoundRect(
                    color = restingPlatterColor.copy(alpha = restingPlatterColor.alpha * platterAlpha),
                    topLeft = topLeft,
                    size = lSize,
                    cornerRadius = cRadius
                )
                // 静态托盘微细高光环
                drawRoundRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = (if (isDark) 0.18f else 0.75f) * platterAlpha),
                            primaryColor.copy(alpha = 0.22f * platterAlpha),
                            Color.White.copy(alpha = (if (isDark) 0.08f else 0.45f) * platterAlpha)
                        ),
                        startY = lensRect.top,
                        endY = lensRect.bottom
                    ),
                    topLeft = topLeft,
                    size = lSize,
                    cornerRadius = cRadius,
                    style = Stroke(width = 0.8.dp.toPx())
                )
            }

            // 2b. _GlassLens (抬升液态玻璃凸透镜: lib/ui/liquid_glass.dart lines 193-224 & shaders/liquid_glass.frag)
            if (liftVal > 0.01f) {
                // 透镜底部悬浮投影 (_lensShadows: offset = (0, 8dp), blur = 5dp)
                drawRoundRect(
                    color = Color.Black.copy(alpha = (if (isDark) 0.34f else 0.12f) * liftVal),
                    topLeft = Offset(lensRect.left, lensRect.top + 4.dp.toPx() * liftVal),
                    size = lSize,
                    cornerRadius = cRadius
                )

                // 透镜通透折射球面层 (refraction = -4.3, bevel = 5.5, brightness = 1.33)
                drawRoundRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = (if (isDark) 0.24f else 0.68f) * liftVal),
                            primaryColor.copy(alpha = (if (isDark) 0.18f else 0.12f) * liftVal),
                            if (isDark) Color(0xFF22242C).copy(alpha = 0.52f * liftVal) else Color.White.copy(alpha = 0.46f * liftVal),
                            Color.White.copy(alpha = (if (isDark) 0.20f else 0.58f) * liftVal)
                        ),
                        startY = lensRect.top,
                        endY = lensRect.bottom
                    ),
                    topLeft = topLeft,
                    size = lSize,
                    cornerRadius = cRadius
                )

                // 透镜两端暗角折射 (endShade = 0.045, kEndShade = 3.0 in liquid_glass.frag)
                drawRoundRect(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.06f * liftVal),
                            Color.Transparent,
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.06f * liftVal)
                        ),
                        startX = lensRect.left,
                        endX = lensRect.right
                    ),
                    topLeft = topLeft,
                    size = lSize,
                    cornerRadius = cRadius
                )

                // Ultra 液态玻璃色散折射边缘 (dispersion = 6.5 in LiquidGlassStyle.lens: 左侧微青蓝、右侧微珊瑚红弧光)
                if (isUltraGlass) {
                    drawRoundRect(
                        brush = Brush.horizontalGradient(
                            colors = listOf(
                                Color(0xFF38BDF8).copy(alpha = 0.45f * liftVal),
                                Color.Transparent,
                                Color.Transparent,
                                Color(0xFFFB7185).copy(alpha = 0.45f * liftVal)
                            ),
                            startX = lensRect.left,
                            endX = lensRect.right
                        ),
                        topLeft = topLeft,
                        size = lSize,
                        cornerRadius = cRadius,
                        style = Stroke(width = 1.6.dp.toPx())
                    )
                }

                // 透镜上下极亮镜面高光弧 (facing = smoothstep(0.65, 0.95, |normal.y|), rim = 0.6, rimWidth = 1.1dp)
                drawRoundRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = (if (isDark) 0.72f else 0.96f) * liftVal),
                            primaryColor.copy(alpha = 0.35f * liftVal),
                            Color.Transparent,
                            primaryColor.copy(alpha = 0.25f * liftVal),
                            Color.White.copy(alpha = (if (isDark) 0.55f else 0.88f) * liftVal)
                        ),
                        startY = lensRect.top,
                        endY = lensRect.bottom
                    ),
                    topLeft = topLeft,
                    size = lSize,
                    cornerRadius = cRadius,
                    style = Stroke(width = 1.25.dp.toPx())
                )
            }
        }

        // 3. 顶层双通道像素级透镜裁剪层 (_RenderLensTint in lib/ui/navigation_dock.dart lines 1634-1992):
        // - 第一遍 (Outside Lens): 裁剪掉 lensRect 内部区域，以 1.0x 尺寸与 onSurfaceVariant 颜色绘制透镜外部
        // - 第二遍 (Inside Lens): 仅裁剪保留 lensRect 内部区域，将处于透镜下的图标与文字部分放大 (1 + 0.16 * lift) 倍并染为 Primary 高光色！
        val lensClipPath = remember(lensRect) {
            Path().apply {
                val r = (lensRect.height / 2f).coerceAtLeast(1f)
                addRoundRect(
                    RoundRect(
                        rect = lensRect,
                        cornerRadius = CornerRadius(r, r)
                    )
                )
            }
        }

        // Pass 1: Outside Lens (未进入透镜的部分)
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(4.dp)
                .drawWithContent {
                    // 将父坐标系下的 lensRect 转换到减去 4.dp 内边距后的局部坐标系
                    val localLensPath = Path().apply {
                        val localRect = lensRect.translate(-barPaddingPx, -barPaddingPx)
                        val r = (localRect.height / 2f).coerceAtLeast(1f)
                        addRoundRect(RoundRect(localRect, CornerRadius(r, r)))
                    }
                    clipPath(localLensPath, clipOp = ClipOp.Difference) {
                        this@drawWithContent.drawContent()
                    }
                }
        ) {
            modes.forEachIndexed { index, mode ->
                val icon = when (mode) {
                    ProcessMode.COMPRESS_TRANSCODE -> Icons.Outlined.Transform
                    ProcessMode.OBFUSCATE_ENCRYPT -> Icons.Outlined.EnhancedEncryption
                    ProcessMode.DEOBFUSCATE_RESTORE -> Icons.Outlined.LockOpen
                    ProcessMode.ARCHIVE_HUB -> Icons.Outlined.FolderZip
                    ProcessMode.ARCHIVE_READER -> Icons.Outlined.AutoStories
                }
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = mode.shortTitle,
                        tint = onSurfaceVariantColor,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = mode.shortTitle,
                        fontSize = 10.sp,
                        lineHeight = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = onSurfaceVariantColor,
                        maxLines = 1
                    )
                }
            }
        }

        // Pass 2: Inside Lens (进入透镜内部的局部：放大 1 + 0.16 * lift 倍 + Primary 高光染色！)
        val insideLensMagnify = 1f + FLCLASH_LENS_MAGNIFY * liftVal
        val insideLensTint = if (isDark && isGlass) {
            // LiquidGlassStyle.lensContent dark mode brightness = 1.33 boost (navigation_dock.dart line 1552)
            Color(
                red = (primaryColor.red * 1.18f).coerceAtMost(1f),
                green = (primaryColor.green * 1.18f).coerceAtMost(1f),
                blue = (primaryColor.blue * 1.18f).coerceAtMost(1f),
                alpha = 1f
            )
        } else {
            primaryColor
        }

        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(4.dp)
                .drawWithContent {
                    val localLensPath = Path().apply {
                        val localRect = lensRect.translate(-barPaddingPx, -barPaddingPx)
                        val r = (localRect.height / 2f).coerceAtLeast(1f)
                        addRoundRect(RoundRect(localRect, CornerRadius(r, r)))
                    }
                    clipPath(localLensPath, clipOp = ClipOp.Intersect) {
                        this@drawWithContent.drawContent()
                    }
                }
        ) {
            modes.forEachIndexed { index, mode ->
                val icon = when (mode) {
                    ProcessMode.COMPRESS_TRANSCODE -> Icons.Filled.Transform
                    ProcessMode.OBFUSCATE_ENCRYPT -> Icons.Filled.EnhancedEncryption
                    ProcessMode.DEOBFUSCATE_RESTORE -> Icons.Filled.LockOpen
                    ProcessMode.ARCHIVE_HUB -> Icons.Filled.FolderZip
                    ProcessMode.ARCHIVE_READER -> Icons.Filled.AutoStories
                }
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .graphicsLayer {
                            scaleX = insideLensMagnify
                            scaleY = insideLensMagnify
                        },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = mode.shortTitle,
                        tint = insideLensTint,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = mode.shortTitle,
                        fontSize = 10.sp,
                        lineHeight = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = insideLensTint,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

/**
 * FlClash 仪表盘 2x2 Bento 状态卡片组
 */
@Composable
private fun FlClashBentoDashboardGrid(
    pageMode: ProcessMode,
    selectedImages: List<SelectedImageItem>,
    resultsMap: Map<Uri, CompressionResult>,
    selectedFormat: OutputFormat,
    quality: Int,
    selectedBlockGrid: BlockGridSize,
    selectedArchiveFormat: ArchiveOutputFormat,
    customDirName: String?,
    isDirectArchiveActive: Boolean,
    isProcessing: Boolean,
    lastImportedArchiveBanner: String?,
    onPickImages: () -> Unit,
    onPickArchives: () -> Unit,
    onOpenReader: () -> Unit,
    onPickDirectory: () -> Unit,
    onResetDirectory: () -> Unit
) {
    val totalOrigBytes = selectedImages.sumOf { it.originalSize }
    val doneCount = selectedImages.count { resultsMap[it.uri]?.isSuccess == true }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            LiquidGlassSurfaceCard(
                cornerRadius = 18.dp,
                modifier = Modifier
                    .weight(1f)
                    .flClashJellyClick(enabled = !isProcessing, onClick = onPickImages)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            CdsStatusBreathingDot(
                                isActive = selectedImages.isNotEmpty(),
                                isBusy = isProcessing
                            )
                            Text("图片队列", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = "${selectedImages.size} 张",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (selectedImages.isEmpty()) {
                            "点击选图"
                        } else {
                            "${ImageCompressor.formatFileSize(totalOrigBytes)} · 完成 $doneCount"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            LiquidGlassSurfaceCard(
                cornerRadius = 18.dp,
                modifier = Modifier
                    .weight(1f)
                    .flClashJellyClick(enabled = !isProcessing, onClick = onPickArchives)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("归档导入", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Icon(
                            imageVector = Icons.Default.FolderZip,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = "导入压缩包",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "支持密码 · ZIP/7Z/RAR",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            LiquidGlassSurfaceCard(
                cornerRadius = 18.dp,
                modifier = Modifier
                    .weight(1f)
                    .flClashJellyClick(enabled = !isProcessing, onClick = onOpenReader)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("图集阅读器", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Icon(
                            imageVector = Icons.Default.AutoStories,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = if (selectedImages.isNotEmpty()) "阅读 (${selectedImages.size}页)" else "归档直读",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "条漫连读 · 口令实时预览",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            LiquidGlassSurfaceCard(
                cornerRadius = 18.dp,
                modifier = Modifier
                    .weight(1f)
                    .flClashJellyClick(enabled = !isProcessing, onClick = onPickDirectory)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("保存位置", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (customDirName != null && !isProcessing) {
                            Icon(
                                imageVector = Icons.Default.Restore,
                                contentDescription = "重置",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .size(16.dp)
                                    .clickable { onResetDirectory() }
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Outlined.FolderOpen,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Text(
                        text = customDirName ?: if (isDirectArchiveActive) "Download" else "系统相册",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = if (customDirName != null) "自定义目录" else "点击更改",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

/**
 * Q 弹果冻分段选择器
 */
/**
 * 1:1 复刻 FlClash-0.9.1 DashboardConnectedGroup + DashboardConnectedButton + Sliding Lens:
 * - 选中项呈现饱满的 solid Primary 高光填充 + 顶部镜面折射高光 + 圆润胶囊形变
 * - 每一个分段按钮都支持按住膨胀与拖动橡皮筋拉伸形变 (flClashJellyClick)
 */
@Composable
private fun <T> FlClashSegmentedRow(
    items: List<T>,
    selectedItem: T,
    itemLabel: (T) -> String,
    enabled: Boolean = true,
    onItemSelected: (T) -> Unit
) {
    val selectedIndex = items.indexOf(selectedItem).coerceAtLeast(0)
    var rowWidthPx by remember { mutableIntStateOf(0) }

    val animatedIndex by animateFloatAsState(
        targetValue = selectedIndex.toFloat(),
        animationSpec = spring(
            dampingRatio = FLCLASH_TRAVEL_DAMPING,
            stiffness = FLCLASH_TRAVEL_STIFFNESS
        ),
        label = "AppSegmentLens"
    )

    val stretchDelta = abs(selectedIndex.toFloat() - animatedIndex).coerceIn(0f, 1f)
    val pillScaleX = 1f + (stretchDelta * 0.22f)
    val pillScaleY = 1f - (stretchDelta * 0.12f)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(42.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.65f))
            .onSizeChanged { rowWidthPx = it.width }
    ) {
        val itemWidthPx = if (rowWidthPx > 0 && items.isNotEmpty()) rowWidthPx / items.size else 0
        val itemWidthDp = with(LocalDensity.current) { itemWidthPx.toDp() }

        // 选中项高光胶囊滑块 (Solid Primary + 液态玻璃镜面顶边高光)
        if (itemWidthPx > 0) {
            val offsetXPx = (animatedIndex * itemWidthPx).roundToInt()
            Box(
                modifier = Modifier
                    .offset { IntOffset(x = offsetXPx, y = 0) }
                    .width(itemWidthDp)
                    .fillMaxHeight()
                    .padding(3.dp)
                    .graphicsLayer {
                        scaleX = pillScaleX
                        scaleY = pillScaleY
                    }
                    .shadow(
                        elevation = 4.dp,
                        shape = CircleShape,
                        ambientColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f),
                        spotColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)
                    )
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary)
                    .drawWithContent {
                        drawContent()
                        drawRoundRect(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color.White.copy(alpha = 0.28f),
                                    Color.Transparent
                                ),
                                startY = 0f,
                                endY = size.height * 0.55f
                            ),
                            cornerRadius = CornerRadius(size.height / 2f, size.height / 2f)
                        )
                    }
                    .border(
                        width = 0.8.dp,
                        color = Color.White.copy(alpha = 0.38f),
                        shape = CircleShape
                    )
            )
        }

        Row(modifier = Modifier.fillMaxSize()) {
            items.forEach { item ->
                val isSelected = item == selectedItem
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .flClashJellyClick(
                            enabled = enabled,
                            shape = CircleShape,
                            onClick = { onItemSelected(item) }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = itemLabel(item),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) {
                            MaterialTheme.colorScheme.onPrimary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                }
            }
        }
    }
}

/**
 * 桌面/平板端左侧 M3 NavigationRail
 */
@Composable
private fun FlClashNavigationRail(
    continuousPagePositionProvider: () -> Float = { 0f },
    currentMode: ProcessMode,
    selectedCount: Int,
    isProcessing: Boolean,
    onSelectMode: (ProcessMode) -> Unit,
    onOpenThemeModal: () -> Unit = {}
) {
    // 1:1 复刻 lib/ui/sidebar.dart (NavigationSidebar):
    // _compactWidth = 48.dp (+ 左右 8.dp 边距 = 64.dp), _expandedWidth = 204.dp,
    // _itemSize = 40.dp, _itemGap = 4.dp, _toggleGap = 8.dp, _indicatorWidth = 3.dp, _indicatorHeight = 16.dp,
    // _itemShape = RoundedCornerShape(10.dp), selectedFill = onSurface.copy(alpha = 0.08f)
    var isExpanded by remember { mutableStateOf(true) }
    val sidebarWidth by animateDpAsState(
        targetValue = if (isExpanded) 208.dp else 64.dp,
        animationSpec = spring(dampingRatio = 0.82f, stiffness = 420f),
        label = "SidebarWidth"
    )
    val modes = ProcessMode.entries
    val selectedFillColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)
    val primaryColor = MaterialTheme.colorScheme.primary
    val itemHeight = 40.dp
    val itemGap = 4.dp

    // 连续追踪当前页面位置，驱动左侧 3.dp × 16.dp 胶囊指示条毛毛虫拉伸过渡动画 (_SelectionIndicator)
    val selectedIdx = modes.indexOf(currentMode).coerceAtLeast(0)
    val animatedIndicatorPos by animateFloatAsState(
        targetValue = continuousPagePositionProvider().coerceIn(0f, (modes.size - 1).coerceAtLeast(0).toFloat()),
        animationSpec = spring(dampingRatio = 0.80f, stiffness = 380f),
        label = "SidebarIndicatorPos"
    )

    Surface(
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        modifier = Modifier
            .width(sidebarWidth)
            .fillMaxHeight()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // 顶部展开/收起切换按钮 (_ToggleButton)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(itemHeight)
                        .flClashJellyClick(
                            pressScale = 0.92f,
                            shape = RoundedCornerShape(10.dp),
                            onClick = { isExpanded = !isExpanded }
                        )
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier.size(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.MenuOpen else Icons.Outlined.ViewSidebar,
                            contentDescription = if (isExpanded) "收起侧边栏" else "展开侧边栏",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    AnimatedVisibility(
                        visible = isExpanded,
                        enter = fadeIn(tween(150)) + expandHorizontally(),
                        exit = fadeOut(tween(100)) + shrinkHorizontally()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "导航菜单",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1
                            )
                            if (selectedCount > 0) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primaryContainer
                                ) {
                                    Text(
                                        text = "$selectedCount",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // 侧边栏导航列表 + 左侧毛毛虫拉伸胶囊选中指示条 (_SelectionIndicator)
                Box(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(itemGap)
                    ) {
                        modes.forEachIndexed { idx, mode ->
                            val isSelected = idx == selectedIdx
                            val rowFill by animateColorAsState(
                                targetValue = if (isSelected) selectedFillColor else Color.Transparent,
                                animationSpec = tween(180),
                                label = "SidebarRowFill"
                            )
                            val icon = when (mode) {
                                ProcessMode.COMPRESS_TRANSCODE -> if (isSelected) Icons.Filled.Transform else Icons.Outlined.Transform
                                ProcessMode.OBFUSCATE_ENCRYPT -> if (isSelected) Icons.Filled.EnhancedEncryption else Icons.Outlined.EnhancedEncryption
                                ProcessMode.DEOBFUSCATE_RESTORE -> if (isSelected) Icons.Filled.LockOpen else Icons.Outlined.LockOpen
                                ProcessMode.ARCHIVE_HUB -> if (isSelected) Icons.Filled.FolderZip else Icons.Outlined.FolderZip
                                ProcessMode.ARCHIVE_READER -> if (isSelected) Icons.Filled.AutoStories else Icons.Outlined.AutoStories
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(itemHeight)
                                    .flClashJellyClick(
                                        pressScale = 0.94f,
                                        shape = RoundedCornerShape(10.dp),
                                        onClick = { onSelectMode(mode) }
                                    )
                                    .background(rowFill, RoundedCornerShape(10.dp))
                                    .padding(horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier.size(24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = mode.shortTitle,
                                        tint = if (isSelected) {
                                            MaterialTheme.colorScheme.primary
                                        } else {
                                            MaterialTheme.colorScheme.onSurfaceVariant
                                        },
                                        modifier = Modifier.size(22.dp)
                                    )
                                }

                                AnimatedVisibility(
                                    visible = isExpanded,
                                    enter = fadeIn(tween(150)) + expandHorizontally(),
                                    exit = fadeOut(tween(100)) + shrinkHorizontally()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .padding(start = 12.dp)
                                            .fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = mode.fullTitle,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                            color = if (isSelected) {
                                                MaterialTheme.colorScheme.onSurface
                                            } else {
                                                MaterialTheme.colorScheme.onSurfaceVariant
                                            },
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        if (isSelected) {
                                            Text(
                                                text = mode.shortTitle,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.primary,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 左侧 3.dp × 16.dp 毛毛虫弹性胶囊指示条 (_SelectionIndicator in sidebar.dart)
                    Canvas(
                        modifier = Modifier
                            .width(3.dp)
                            .height(itemHeight * modes.size + itemGap * (modes.size - 1).coerceAtLeast(0))
                            .align(Alignment.TopStart)
                    ) {
                        val extentPx = (itemHeight + itemGap).toPx()
                        val indicatorH = 16.dp.toPx()
                        val baseOffsetPx = (itemHeight.toPx() - indicatorH) / 2f
                        val floorIdx = kotlin.math.floor(animatedIndicatorPos).toInt().coerceIn(0, (modes.size - 1).coerceAtLeast(0))
                        val ceilIdx = kotlin.math.ceil(animatedIndicatorPos).toInt().coerceIn(0, (modes.size - 1).coerceAtLeast(0))
                        val frac = (animatedIndicatorPos - floorIdx).coerceIn(0f, 1f)

                        val fromY = baseOffsetPx + floorIdx * extentPx
                        val toY = baseOffsetPx + ceilIdx * extentPx
                        val leadFrac = (frac * 2f).coerceIn(0f, 1f)
                        val trailFrac = ((frac - 0.5f) * 2f).coerceIn(0f, 1f)

                        val y1 = fromY + (toY - fromY) * leadFrac
                        val y2 = fromY + (toY - fromY) * trailFrac
                        val topY = min(y1, y2)
                        val bottomY = max(y1, y2) + indicatorH

                        drawRoundRect(
                            color = primaryColor,
                            topLeft = Offset(0f, topY),
                            size = Size(size.width, (bottomY - topY).coerceAtLeast(indicatorH)),
                            cornerRadius = CornerRadius(size.width / 2f, size.width / 2f)
                        )
                    }
                }
            }

            // 底部主题快捷入口（方便平板端直接从侧边栏唤出主题设定）
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(itemHeight)
                    .flClashJellyClick(
                        pressScale = 0.92f,
                        shape = RoundedCornerShape(10.dp),
                        onClick = onOpenThemeModal
                    )
                    .background(
                        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.04f),
                        RoundedCornerShape(10.dp)
                    )
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Palette,
                        contentDescription = "主题",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
                AnimatedVisibility(
                    visible = isExpanded,
                    enter = fadeIn(tween(150)) + expandHorizontally(),
                    exit = fadeOut(tween(100)) + shrinkHorizontally()
                ) {
                    Text(
                        text = "主题",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        modifier = Modifier.padding(start = 12.dp)
                    )
                }
            }
        }
    }
}

/**
 * 极简沉浸式顶栏（与软件主背景色调完全融为一体，无突兀底部分割线）
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FlClashTopBar(
    currentMode: ProcessMode,
    selectedCount: Int,
    customTreeUri: Uri?,
    useDynamicColor: Boolean,
    isProcessing: Boolean,
    onToggleDynamicColor: () -> Unit,
    onPickDirectory: () -> Unit,
    onClearQueue: () -> Unit
) {
    TopAppBar(
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "像素工坊",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                Text(
                    text = "像素工坊 · ${currentMode.fullTitle}",
                    style = MaterialTheme.typography.titleMedium,
                    fontFamily = FontFamily.Serif
                )
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    border = BorderStroke(0.6.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f))
                ) {
                    Text(
                        text = currentMode.shortTitle,
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }
        },
        actions = {
            IconButton(onClick = onToggleDynamicColor) {
                Icon(
                    imageVector = if (useDynamicColor) Icons.Default.AutoAwesome else Icons.Outlined.Palette,
                    contentDescription = "主题",
                    tint = if (useDynamicColor) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    }
                )
            }

            IconButton(
                onClick = onPickDirectory,
                enabled = !isProcessing
            ) {
                Icon(
                    imageVector = Icons.Outlined.FolderOpen,
                    contentDescription = "输出目录",
                    tint = if (customTreeUri != null) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    }
                )
            }

            if (selectedCount > 0 && !isProcessing) {
                IconButton(onClick = onClearQueue) {
                    Icon(
                        imageVector = Icons.Outlined.DeleteSweep,
                        contentDescription = "清空队列",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.background,
            scrolledContainerColor = MaterialTheme.colorScheme.background
        )
    )
}

/**
 * 批处理完成统计与一键分享接力卡片
 */
@Composable
private fun BatchSummaryBanner(
    selectedImages: List<SelectedImageItem>,
    resultsMap: Map<Uri, CompressionResult>,
    batchReport: BatchExecutionReport?,
    onShareClick: () -> Unit
) {
    val successfulResults = selectedImages.mapNotNull { resultsMap[it.uri] }.filter { it.isSuccess }
    if (successfulResults.isEmpty()) return

    val totalOriginalBytes = successfulResults.sumOf { it.source.originalSize }
    val totalCompressedBytes = successfulResults.sumOf { it.compressedSize }
    val diffBytes = totalOriginalBytes - totalCompressedBytes
    val ratioPercent = if (totalOriginalBytes > 0) {
        (diffBytes.toDouble() / totalOriginalBytes.toDouble() * 100.0)
    } else {
        0.0
    }
    val mode = successfulResults.first().mode

    LiquidGlassSurfaceCard(
        cornerRadius = 18.dp,
        isHighlighted = true,
        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = if (batchReport?.archiveFileName != null) {
                        "已打包：${batchReport.archiveFileName}${if (batchReport.isArchiveEncrypted) " (AES加密)" else ""}"
                    } else {
                        "${mode.shortTitle}完成 (${successfulResults.size}/${selectedImages.size})"
                    },
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )

                val outBytesToShow = if (batchReport != null && batchReport.archiveTotalBytes > 0L) {
                    batchReport.archiveTotalBytes
                } else {
                    totalCompressedBytes
                }
                Text(
                    text = "${ImageCompressor.formatFileSize(totalOriginalBytes)} → ${ImageCompressor.formatFileSize(outBytesToShow)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )

                val footerNote = when {
                    batchReport?.archiveSavedPathLabel != null ->
                        batchReport.archiveSavedPathLabel
                    diffBytes >= 0 ->
                        String.format(Locale.US, "已省 %s (-%.1f%%)", ImageCompressor.formatFileSize(diffBytes), ratioPercent)
                    else ->
                        String.format(Locale.US, "无损转换 +%s", ImageCompressor.formatFileSize(abs(diffBytes)))
                }
                Text(
                    text = footerNote,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Button(
                onClick = onShareClick,
                shape = RoundedCornerShape(14.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Icon(Icons.Default.Share, contentDescription = "分享", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("分享", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

/**
 * 18dp 液态玻璃图片列表卡片
 */
@Composable
private fun ImageComparisonItemCard(
    item: SelectedImageItem,
    result: CompressionResult?,
    isProcessing: Boolean,
    modifier: Modifier = Modifier,
    onCardClick: () -> Unit,
    onRemoveItem: () -> Unit
) {
    LiquidGlassSurfaceCard(
        cornerRadius = 14.dp,
        modifier = modifier
            .fillMaxWidth()
            .flClashJellyClick(
                enabled = true,
                pressScale = 0.96f,
                shape = RoundedCornerShape(14.dp),
                onClick = onCardClick
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val context = LocalContext.current
            val sourceThumbRequest = remember(item.uri) {
                ImageRequest.Builder(context)
                    .data(item.uri)
                    .size(180, 180)
                    .crossfade(false)
                    .build()
            }
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainer)
            ) {
                AsyncImage(
                    model = sourceThumbRequest,
                    contentDescription = item.displayName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Surface(
                    color = Color.Black.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(bottomEnd = 6.dp),
                    modifier = Modifier.align(Alignment.TopStart)
                ) {
                    Text(
                        text = "原图",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                    )
                }
            }

            if (result != null && result.isSuccess && result.outputUri != null) {
                val outThumbRequest = remember(result.outputUri) {
                    ImageRequest.Builder(context)
                        .data(result.outputUri)
                        .size(180, 180)
                        .crossfade(false)
                        .build()
                }
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainer)
                ) {
                    AsyncImage(
                        model = outThumbRequest,
                        contentDescription = result.outputName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.88f),
                        shape = RoundedCornerShape(bottomEnd = 6.dp),
                        modifier = Modifier.align(Alignment.TopStart)
                    ) {
                        Text(
                            text = when {
                                result.packedIntoArchiveName != null -> "已入包"
                                result.mode == ProcessMode.OBFUSCATE_ENCRYPT -> "色块"
                                result.mode == ProcessMode.DEOBFUSCATE_RESTORE -> "还原"
                                else -> "结果"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text(
                    text = item.displayName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                val srcFormatShort = item.mimeType.substringAfterLast('/').uppercase(Locale.ROOT)
                Text(
                    text = "$srcFormatShort · ${item.width}×${item.height} · ${ImageCompressor.formatFileSize(item.originalSize)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (result != null) {
                    if (result.isSuccess) {
                        val deltaRatio = if (item.originalSize > 0) {
                            ((result.compressedSize - item.originalSize).toDouble() / item.originalSize.toDouble()) * 100.0
                        } else {
                            0.0
                        }
                        val ratioLabel = if (deltaRatio <= 0) {
                            String.format(Locale.US, "%.1f%%", deltaRatio)
                        } else {
                            String.format(Locale.US, "+%.1f%%", deltaRatio)
                        }
                        val badgeColor = if (deltaRatio <= 0) {
                            MaterialTheme.colorScheme.tertiary
                        } else {
                            MaterialTheme.colorScheme.primary
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = badgeColor,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${result.outputName} · ${ImageCompressor.formatFileSize(result.compressedSize)} ($ratioLabel)",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = badgeColor,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.ErrorOutline,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = result.errorMessage ?: "失败",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }

            Icon(
                imageVector = Icons.Default.Compare,
                contentDescription = "拉帘对比",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )

            if (!isProcessing) {
                IconButton(
                    onClick = onRemoveItem,
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "移除",
                        tint = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

/**
 * Container Transform 卡片展开大图详情视图（内置交互式拉帘对比 Before/After Split Slider + 一键分享）
 */
@Composable
private fun ImageDetailContainerTransformModal(
    item: SelectedImageItem,
    result: CompressionResult?,
    onDismiss: () -> Unit,
    onShare: () -> Unit,
    onRemove: () -> Unit
) {
    BackHandler(onBack = onDismiss)

    val hasProcessedImage = result != null && result.isSuccess && result.outputUri != null
    var useSplitCurtain by remember(hasProcessedImage) { mutableStateOf(hasProcessedImage) }
    var splitFraction by remember { mutableFloatStateOf(0.5f) }
    var previewContainerWidthPx by remember { mutableIntStateOf(0) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.50f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismiss
            )
            .padding(18.dp),
        contentAlignment = Alignment.Center
    ) {
        LiquidGlassSurfaceCard(
            cornerRadius = 24.dp,
            isHighlighted = true,
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.96f),
            modifier = Modifier
                .widthIn(max = 560.dp)
                .fillMaxWidth()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {}
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.displayName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = if (hasProcessedImage) "左右拖动分割线实时对比原图与处理结果" else "${item.width}×${item.height} · ${ImageCompressor.formatFileSize(item.originalSize)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(onClick = onShare) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = "分享", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "关闭")
                    }
                }

                if (hasProcessedImage) {
                    FlClashSegmentedRow(
                        items = listOf(true, false),
                        selectedItem = useSplitCurtain,
                        itemLabel = { isSplit -> if (isSplit) "拉帘对比 (左右拖动)" else "处理后单图" },
                        onItemSelected = { useSplitCurtain = it }
                    )
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainer)
                        .border(
                            1.dp,
                            MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                            RoundedCornerShape(16.dp)
                        )
                        .onSizeChanged { previewContainerWidthPx = it.width }
                        .then(
                            if (hasProcessedImage && useSplitCurtain) {
                                Modifier.pointerInput(previewContainerWidthPx) {
                                    if (previewContainerWidthPx <= 0) return@pointerInput
                                    detectHorizontalDragGestures { change, _ ->
                                        change.consume()
                                        splitFraction = (change.position.x / previewContainerWidthPx.toFloat())
                                            .coerceIn(0.05f, 0.95f)
                                    }
                                }
                            } else {
                                Modifier
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (hasProcessedImage && useSplitCurtain && result?.outputUri != null) {
                        AsyncImage(
                            model = result.outputUri,
                            contentDescription = "处理后",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(6.dp)
                        )

                        AsyncImage(
                            model = item.uri,
                            contentDescription = "原图",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(6.dp)
                                .drawWithContent {
                                    clipRect(right = size.width * splitFraction) {
                                        this@drawWithContent.drawContent()
                                    }
                                }
                        )

                        val dividerOffsetDp = with(LocalDensity.current) {
                            ((previewContainerWidthPx * splitFraction).roundToInt()).toDp()
                        }
                        Box(
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .offset(x = dividerOffsetDp - 1.dp)
                                .width(2.dp)
                                .fillMaxHeight()
                                .background(Color.White)
                        )
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary,
                            border = BorderStroke(2.dp, Color.White),
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .offset(x = dividerOffsetDp - 16.dp)
                                .size(32.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.SwapHoriz,
                                    contentDescription = "拖动对比",
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color.Black.copy(alpha = 0.6f),
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(8.dp)
                        ) {
                            Text(
                                text = "原图 (${ImageCompressor.formatFileSize(item.originalSize)})",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(8.dp)
                        ) {
                            Text(
                                text = "处理后 (${ImageCompressor.formatFileSize(result.compressedSize)})",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    } else {
                        val singleUri = if (hasProcessedImage && result?.outputUri != null) {
                            result.outputUri
                        } else {
                            item.uri
                        }
                        AsyncImage(
                            model = singleUri,
                            contentDescription = item.displayName,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(8.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FilledTonalButton(
                        onClick = onRemove,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("移除")
                    }
                    Button(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("完成")
                    }
                }
            }
        }
    }
}

/**
 * 极简空状态引导卡片
 */
@Composable
private fun EmptyWorkbenchCard(
    currentMode: ProcessMode,
    isExtracting: Boolean = false,
    extractDoneCount: Int = 0,
    extractTotalCount: Int = 0,
    extractCurrentFile: String = "",
    onCancelExtract: () -> Unit = {},
    onPickImages: () -> Unit,
    onPickArchives: () -> Unit
) {
    val extractProgressTarget = if (extractTotalCount > 0) {
        (extractDoneCount.toFloat() / extractTotalCount.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }
    val animatedExtractProgress by animateFloatAsState(
        targetValue = extractProgressTarget,
        animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = JELLY_STIFFNESS),
        label = "WorkbenchExtractProgress"
    )

    LiquidGlassSurfaceCard(
        cornerRadius = 20.dp,
        isHighlighted = isExtracting,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                modifier = Modifier.size(56.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (isExtracting) {
                            Icons.Default.Unarchive
                        } else if (currentMode == ProcessMode.ARCHIVE_HUB) {
                            Icons.Outlined.FolderZip
                        } else {
                            Icons.Outlined.PhotoLibrary
                        },
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            Text(
                text = if (isExtracting) "正在解压压缩包..." else "暂无待处理图片",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            if (isExtracting) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = when {
                                extractTotalCount > 0 -> "已解压 $extractDoneCount / $extractTotalCount 张"
                                extractDoneCount > 0 -> "已解压 $extractDoneCount 张"
                                else -> "正在读取压缩包索引..."
                            },
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        if (extractTotalCount > 0) {
                            Text(
                                text = "${(animatedExtractProgress * 100).roundToInt()}%",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    if (extractTotalCount > 0) {
                        LinearProgressIndicator(
                            progress = { animatedExtractProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                        )
                    } else {
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                        )
                    }
                    if (extractCurrentFile.isNotBlank()) {
                        Text(
                            text = extractCurrentFile,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    FilledTonalButton(
                        onClick = onCancelExtract,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("取消解压")
                    }
                }
            } else {
                Text(
                    text = "点击上方液态玻璃按钮展开二级配置，点击空白处自动缩回",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    FilledTonalButton(
                        onClick = onPickImages,
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("选择图片")
                    }
                    FilledTonalButton(
                        onClick = onPickArchives,
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FolderZip,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("导入压缩包")
                    }
                }
            }
        }
    }
}

/**
 * 1:1 源码级复刻 FlClash-0.9.1 ThemeView (lib/views/theme.dart):
 * 包含：
 * 1. ThemeLivePreview (MiniScreen 实时浅色/深色分屏主题与液态玻璃底栏预览)
 * 2. _ThemeModeItem (自动 / 浅色 / 深色)
 * 3. _PureBlackItem (标准 / 纯黑 OLED)
 * 4. _PrimaryColorItem (_ColorSwatches: 跟随系统吸管徽标 + 8 颗 Apple macOS 官方种子色圆点 + 重置按钮 + 色彩风格 Vivid/Tinted/Soft/Mono)
 * 5. _NavigationBarItem (悬浮胶囊 Floating / 贴底栏 Docked)
 * 6. _TabAnimationItem (滑动 Slide / 渐隐 Fade)
 * 7. _LiquidGlassItem (关闭 None / 标准 Standard / 极致 Ultra)
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FlClashThemeSettingsModal(
    visible: Boolean = true,
    themeProps: FlClashThemeProps,
    onUpdateThemeProps: (FlClashThemeProps) -> Unit,
    onDismiss: () -> Unit
) {
    val haptic = LocalHapticFeedback.current

    Box(modifier = Modifier.fillMaxSize()) {
        if (visible) {
            BackHandler(onBack = onDismiss)
            // 纯透明点击外部收起区域（无全屏灰色遮罩块）
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onDismiss
                    )
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(start = 16.dp, end = 16.dp, top = 56.dp, bottom = 24.dp),
            contentAlignment = Alignment.TopEnd
        ) {
            AnimatedVisibility(
                visible = visible,
                enter = fadeIn(animationSpec = spring(stiffness = 520f)) +
                    scaleIn(
                        initialScale = 0.14f,
                        transformOrigin = TransformOrigin(0.90f, 0.0f),
                        animationSpec = spring(
                            dampingRatio = FLCLASH_PRESS_DAMPING,
                            stiffness = FLCLASH_TRAVEL_STIFFNESS
                        )
                    ) +
                    expandIn(
                        expandFrom = Alignment.TopEnd,
                        initialSize = { IntSize((it.width * 0.35f).toInt(), (it.height * 0.18f).toInt()) },
                        animationSpec = spring(
                            dampingRatio = 0.76f,
                            stiffness = FLCLASH_TRAVEL_STIFFNESS
                        ),
                        clip = true
                    ),
                exit = fadeOut(animationSpec = spring(stiffness = 600f)) +
                    scaleOut(
                        targetScale = 0.14f,
                        transformOrigin = TransformOrigin(0.90f, 0.0f),
                        animationSpec = spring(
                            dampingRatio = FLCLASH_TRAVEL_DAMPING,
                            stiffness = 520f
                        )
                    ) +
                    shrinkOut(
                        shrinkTowards = Alignment.TopEnd,
                        targetSize = { IntSize((it.width * 0.35f).toInt(), (it.height * 0.18f).toInt()) },
                        animationSpec = spring(
                            dampingRatio = FLCLASH_TRAVEL_DAMPING,
                            stiffness = 520f
                        ),
                        clip = true
                    )
            ) {
                LiquidGlassSurfaceCard(
                    cornerRadius = 28.dp,
                    isHighlighted = true,
                    containerColor = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.98f),
                    modifier = Modifier
                        .widthIn(max = 460.dp)
                        .fillMaxWidth()
                        .shadow(
                            elevation = 18.dp,
                            shape = RoundedCornerShape(28.dp),
                            ambientColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f),
                            spotColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.28f)
                        )
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = {}
                        )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                            .padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Header：简洁命名为「主题」
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Outlined.Palette,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onPrimary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "主题",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (!themeProps.isDefault) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.errorContainer,
                                modifier = Modifier.flClashJellyClick(
                                    shape = CircleShape,
                                    onClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        onUpdateThemeProps(FlClashThemeProps())
                                    }
                                )
                            ) {
                                Text(
                                    text = "重置",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                )
                            }
                        }
                        IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "关闭", modifier = Modifier.size(18.dp))
                        }
                    }
                }

                // 1. ThemeLivePreview (MiniSplitScreen Light / Dark 实时微缩预览卡片)
                FlClashMiniScreenPreviewCard(themeProps = themeProps)

                // 2. 主题模式 (_ThemeModeItem: 自动 / 浅色 / 深色)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("主题模式", style = MaterialTheme.typography.labelLarge)
                    FlClashSegmentedRow(
                        items = FlClashThemeMode.entries,
                        selectedItem = themeProps.themeMode,
                        itemLabel = { it.label },
                        onItemSelected = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onUpdateThemeProps(themeProps.copy(themeMode = it))
                        }
                    )
                }

                // 3. 纯黑模式 (_PureBlackItem: 标准 / 纯黑 OLED)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainer)
                        .flClashJellyClick(
                            shape = RoundedCornerShape(16.dp),
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onUpdateThemeProps(themeProps.copy(pureBlack = !themeProps.pureBlack))
                            }
                        )
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("纯黑模式", style = MaterialTheme.typography.titleSmall)
                        Text(
                            text = "深色模式下将页面背景降为 #000000 纯黑并同步下潜卡片色阶",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = themeProps.pureBlack,
                        onCheckedChange = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onUpdateThemeProps(themeProps.copy(pureBlack = it))
                        }
                    )
                }

                // 4. 主题色色盘 (_ColorSwatches: 跟随系统 + 8 颗 FlClash 官方 macOS 种子色)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("主题色", style = MaterialTheme.typography.labelLarge)
                    Surface(
                        shape = RoundedCornerShape(22.dp),
                        color = MaterialTheme.colorScheme.surfaceContainer
                    ) {
                        FlowRow(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            val allSwatches: List<Int?> = remember(themeProps.primaryColors) {
                                listOf<Int?>(null) + themeProps.primaryColors
                            }
                            allSwatches.forEach { swatchArgb ->
                                val isSelected = themeProps.primaryColor == swatchArgb
                                val swatchColor = if (swatchArgb == null) {
                                    MaterialTheme.colorScheme.primary
                                } else {
                                    Color(swatchArgb)
                                }
                                FlClashColorSwatchItem(
                                    color = swatchColor,
                                    isSystemFollow = swatchArgb == null,
                                    isSelected = isSelected,
                                    onClick = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        onUpdateThemeProps(themeProps.copy(primaryColor = swatchArgb))
                                    }
                                )
                            }
                        }
                    }
                }

                // 5. 色彩风格 (ColorStyle: Vivid / Tinted / Soft / Monochrome)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "色彩风格 (${themeProps.colorStyle.desc})",
                        style = MaterialTheme.typography.labelLarge
                    )
                    FlClashSegmentedRow(
                        items = FlClashColorStyle.entries,
                        selectedItem = themeProps.colorStyle,
                        itemLabel = { it.label.substringBefore(" ") },
                        onItemSelected = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onUpdateThemeProps(themeProps.copy(colorStyle = it))
                        }
                    )
                }

                // 6. 液态玻璃模式 (_LiquidGlassItem: 关闭 / 标准 / 极致)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("液态玻璃", style = MaterialTheme.typography.labelLarge)
                    FlClashSegmentedRow(
                        items = FlClashLiquidGlassMode.entries,
                        selectedItem = themeProps.liquidGlass,
                        itemLabel = { it.label },
                        onItemSelected = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onUpdateThemeProps(themeProps.copy(liquidGlass = it))
                        }
                    )
                }

                // 7. 导航栏样式与切页动画 (_NavigationBarItem & _TabAnimationItem)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("底栏样式", style = MaterialTheme.typography.labelLarge)
                        FlClashSegmentedRow(
                            items = listOf(true, false),
                            selectedItem = themeProps.floatingNavigationBar,
                            itemLabel = { if (it) "悬浮胶囊" else "贴底栏" },
                            onItemSelected = {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onUpdateThemeProps(themeProps.copy(floatingNavigationBar = it))
                            }
                        )
                    }
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("标签页动画", style = MaterialTheme.typography.labelLarge)
                        FlClashSegmentedRow(
                            items = FlClashTabAnimation.entries,
                            selectedItem = themeProps.tabAnimation,
                            itemLabel = { it.label },
                            onItemSelected = {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onUpdateThemeProps(themeProps.copy(tabAnimation = it))
                            }
                        )
                    }
                }

                Button(
                    onClick = onDismiss,
                    shape = CircleShape,
                    modifier = Modifier
                        .fillMaxWidth()
                        .flClashJellyClick(shape = CircleShape, onClick = onDismiss)
                ) {
                    Text("完成", fontWeight = FontWeight.Bold)
                }
            }
        }
            }
        }
    }
}

/**
 * 1:1 复刻 FlClash-0.9.1 _ColorSwatch (lib/views/theme.dart lines 381-491):
 * size = 44dp, dot = 32dp, ring = 2.5dp, badge = 20dp (_EyedropperBadge)
 */
@Composable
private fun FlClashColorSwatchItem(
    color: Color,
    isSystemFollow: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val ringScale by animateFloatAsState(
        targetValue = if (isSelected) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 420f),
        label = "SwatchCheckScale"
    )
    val luma = 0.2126f * color.red + 0.7152f * color.green + 0.0722f * color.blue
    val checkColor = if (luma > 0.62f) Color.Black else Color.White

    Box(
        modifier = Modifier
            .size(44.dp)
            .flClashJellyClick(shape = CircleShape, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (isSelected) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .border(2.5.dp, color, CircleShape)
            )
        }
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(color),
            contentAlignment = Alignment.Center
        ) {
            if (isSelected) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "已选中",
                    tint = checkColor,
                    modifier = Modifier
                        .size(18.dp)
                        .graphicsLayer {
                            scaleX = ringScale
                            scaleY = ringScale
                        }
                )
            }
        }
        if (isSystemFollow) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surfaceContainerLow,
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.surfaceContainer),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(18.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Colorize,
                        contentDescription = "跟随系统",
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(11.dp)
                    )
                }
            }
        }
    }
}

/**
 * 1:1 复刻 FlClash-0.9.1 ThemeLivePreview / MiniSplitScreen (lib/views/theme_preview.dart):
 * 实时展示当前种子色在浅色模式与深色（或纯黑）模式下的页面、卡片、主色按钮与悬浮液态玻璃底栏效果
 */
@Composable
private fun FlClashMiniScreenPreviewCard(themeProps: FlClashThemeProps) {
    val seedColor = if (themeProps.primaryColor != null) {
        Color(themeProps.primaryColor)
    } else {
        MaterialTheme.colorScheme.primary
    }
    val lightScheme = remember(seedColor, themeProps.colorStyle) {
        buildFlClashSeededColorScheme(seedColor, darkTheme = false, style = themeProps.colorStyle, pureBlack = false)
    }
    val darkScheme = remember(seedColor, themeProps.colorStyle, themeProps.pureBlack) {
        buildFlClashSeededColorScheme(seedColor, darkTheme = true, style = themeProps.colorStyle, pureBlack = themeProps.pureBlack)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(92.dp)
            .clip(RoundedCornerShape(20.dp))
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(20.dp)),
        horizontalArrangement = Arrangement.spacedBy(0.dp)
    ) {
        listOf(
            Triple("浅色预览", lightScheme, Icons.Default.LightMode),
            Triple(if (themeProps.pureBlack) "纯黑预览" else "深色预览", darkScheme, Icons.Default.DarkMode)
        ).forEach { (title, scheme, modeIcon) ->
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(scheme.background)
                    .padding(10.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = modeIcon,
                                contentDescription = null,
                                tint = scheme.primary,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelSmall,
                                color = scheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Box(
                            modifier = Modifier
                                .size(18.dp, 10.dp)
                                .clip(CircleShape)
                                .background(scheme.primary)
                        )
                    }

                    // 模拟卡片与液态玻璃底栏
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(20.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(scheme.surfaceContainerLow)
                        )
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(20.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(scheme.primary)
                        )
                    }

                    // 模拟底部悬浮液态玻璃胶囊与透镜
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(16.dp)
                            .padding(horizontal = if (themeProps.floatingNavigationBar) 6.dp else 0.dp)
                            .clip(CircleShape)
                            .background(scheme.surfaceContainerHighest.copy(alpha = 0.75f))
                            .border(0.6.dp, Color.White.copy(alpha = 0.35f), CircleShape),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 3.dp)
                                .width(26.dp)
                                .height(12.dp)
                                .clip(CircleShape)
                                .background(scheme.primary.copy(alpha = 0.25f))
                                .border(0.6.dp, scheme.primary, CircleShape)
                        )
                    }
                }
            }
        }
    }
}


/**
 * FlClash-0.9.1 胶囊选择按键 (选中时带有 Solid Primary + 液态玻璃镜面高光与光晕，按住拖动带有橡皮筋拉伸形变)
 */
@Composable
private fun FlClashChoicePill(
    selected: Boolean,
    label: String,
    onClick: () -> Unit
) {
    val bgColor by animateColorAsState(
        targetValue = if (selected) {
            MaterialTheme.colorScheme.primary
        } else {
            MaterialTheme.colorScheme.surfaceContainerHigh
        },
        animationSpec = spring(dampingRatio = FLCLASH_TRAVEL_DAMPING, stiffness = FLCLASH_TRAVEL_STIFFNESS),
        label = "AppChoicePillBg"
    )
    Box(
        modifier = Modifier
            .then(
                if (selected) {
                    Modifier.shadow(
                        elevation = 5.dp,
                        shape = CircleShape,
                        ambientColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.38f),
                        spotColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.48f)
                    )
                } else {
                    Modifier
                }
            )
            .flClashJellyClick(shape = CircleShape, onClick = onClick)
            .background(bgColor, CircleShape)
            .drawWithContent {
                drawContent()
                if (selected) {
                    drawRoundRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.30f),
                                Color.Transparent
                            ),
                            startY = 0f,
                            endY = size.height * 0.55f
                        ),
                        cornerRadius = CornerRadius(size.height / 2f, size.height / 2f)
                    )
                }
            }
            .border(
                width = if (selected) 0.9.dp else 0.5.dp,
                color = if (selected) Color.White.copy(alpha = 0.42f) else MaterialTheme.colorScheme.outlineVariant,
                shape = CircleShape
            )
            .padding(horizontal = 14.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}