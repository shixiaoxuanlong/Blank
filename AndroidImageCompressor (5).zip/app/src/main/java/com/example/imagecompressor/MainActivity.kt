package com.example.imagecompressor

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Password
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.FolderZip
import androidx.compose.material3.Badge
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.VerticalDivider
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.util.Consumer
import androidx.documentfile.provider.DocumentFile
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

/**
 * ============================================================================
 * Open Claude UI (CDS - Claude Design System) 令牌体系与交互物理常数
 * 依据 https://github.com/Caho1/open-claude-ui 规范高保真还原：
 * 1. 温润的人文质感 (Editorial Warmth)：纯正陶土橙 Clay (#D97757) + 四层微对比表面阶梯 (Surface 0-3)
 * 2. 视网膜 0.5dp 发丝细边补偿 (Hairline Ring) + 双环 Popover 漫反射暖光投影 (wl-glow)
 * 3. 精密圆角矩阵：外框 Composer 20dp、模态对话框/气泡 16-18dp、二级面板 12dp、原子按钮 8-10dp、分段胶囊 999dp
 * 4. 严苛的交互物理学：4 套生产级物理弹簧、active:scale-[0.98] 触觉微缩、4px 指针移动死区
 * 5. 7 档非线性幂律渐隐遮罩 (7-Stop Non-Linear Fade Mask, y ≈ x^1.5)
 * 6. 以触点为物理不动点的仿射 Pan/Zoom 方程 + 0.7 边界溢出阻尼
 * ============================================================================
 */
private val ClayBrand = Color(0xFFD97757)
private val ClayBrandHover = Color(0xFFC66143)
private val CdsSuccessGreen = Color(0xFF2E7D4F)
private val CdsDangerRed = Color(0xFFD94E4E)

// CDS 4 套生产级物理弹簧常数
private const val CDS_SPRING_SNAPPY_DAMPING = 0.76f
private const val CDS_SPRING_SNAPPY_STIFFNESS = 620f
private const val CDS_SPRING_POPOVER_DAMPING = 0.54f
private const val CDS_SPRING_POPOVER_STIFFNESS = 380f
private const val CDS_SPRING_LAYOUT_DAMPING = 0.64f
private const val CDS_SPRING_LAYOUT_STIFFNESS = 420f

/**
 * CDS 四层表面微阶梯与发丝细边令牌
 */
@Immutable
data class CdsDesignTokens(
    val isDark: Boolean,
    val surface0: Color,       // 底层画布背景 (Light #F5F5F3 / Dark #0B0B0A)
    val surface1: Color,       // 凹陷轨道与次级容器 (Light #EEEEEC / Dark #141413)
    val surface2: Color,       // 标准卡片与附件磁贴 (Light #FAF9F6 / Dark #1A1A18)
    val surface3: Color,       // 顶层悬浮面板与滑块胶囊 (Light #FFFFFF / Dark #20201E)
    val clay: Color,           // 品牌陶土橙 (#D97757)
    val claySoftBg: Color,     // 陶土暖光漫反射浅底
    val clayBorder: Color,     // 陶土高光细边
    val textPrimary: Color,    // 主人文墨色
    val textSecondary: Color,  // 次级灰褐文字
    val textMuted: Color,      // 辅助说明文字
    val hairlineBorder: Color, // 0.5dp 发丝细边
    val popoverGlow: Color,    // wl-glow 漫反射光场
    val danger: Color,
    val success: Color
) {
    // 1.5 深色模式视网膜字重逆补偿：暗色下轻微减细防止文字在 OLED 屏幕上发胀
    val headingWeight: FontWeight get() = if (isDark) FontWeight.Medium else FontWeight.SemiBold
    val bodyStrongWeight: FontWeight get() = if (isDark) FontWeight.Normal else FontWeight.Medium
}

private val LightCdsTokens = CdsDesignTokens(
    isDark = false,
    surface0 = Color(0xFFF5F5F3),
    surface1 = Color(0xFFEEEEEC),
    surface2 = Color(0xFFFAF9F6),
    surface3 = Color(0xFFFFFFFF),
    clay = ClayBrand,
    claySoftBg = Color(0xFFF7E6DF),
    clayBorder = Color(0xFFE5A48E),
    textPrimary = Color(0xFF141413),
    textSecondary = Color(0xFF5C5B56),
    textMuted = Color(0xFF8C8B84),
    hairlineBorder = Color(0xFFE3E2DC),
    popoverGlow = Color(0x28D97757),
    danger = CdsDangerRed,
    success = CdsSuccessGreen
)

private val DarkCdsTokens = CdsDesignTokens(
    isDark = true,
    surface0 = Color(0xFF0B0B0A),
    surface1 = Color(0xFF141413),
    surface2 = Color(0xFF1A1A18),
    surface3 = Color(0xFF20201E),
    clay = ClayBrand,
    claySoftBg = Color(0xFF331F18),
    clayBorder = Color(0xFF8C4932),
    textPrimary = Color(0xFFF0EFEA),
    textSecondary = Color(0xFFA6A59D),
    textMuted = Color(0xFF6E6D66),
    hairlineBorder = Color(0xFF2C2C29),
    popoverGlow = Color(0x36D97757),
    danger = Color(0xFFE56B6B),
    success = Color(0xFF57B87B)
)

private val LocalCdsTokens = staticCompositionLocalOf { LightCdsTokens }

/**
 * 二级弹出面板枚举（保留点击按钮从对应象限展开第二层、点击空白处缩回按钮的交互）
 */
private enum class CdsLayer2Menu {
    NONE,
    PASSWORD_BOOK_PANEL,   // 左上：解压密码与常用密码本二级面板
    RENAME_TEMPLATE_PANEL, // 右上：存相册批量重命名二级面板
    QUEUE_SORT_PANEL,      // 左下：图片列表排序与筛选二级面板
    READER_PRESET_PANEL,   // 右下：阅读模式（条漫/单页/双页跨页）与音量键翻页二级面板
    FAB_QUICK_HUB,         // 右下角快捷指令面板（导入压缩包/打开阅读器/一键存相册/一键分享/清空）
    READER_CONTROL_PANEL   // 阅读器右上角二级控制面板
}

/**
 * Open Claude UI (CDS) 2.1 五大按钮变体与四级尺寸阶梯
 */
private enum class CdsButtonVariant {
    PRIMARY,   // 陶土橙实心主按钮 (#D97757)
    SECONDARY, // Surface 3 抬升面板 + 0.5dp 发丝细边
    GHOST,     // 零边框透明人文按钮
    OUTLINE,   // 陶土细边轮廓按钮
    DANGER     // 危险/中断操作按钮
}

private enum class CdsButtonSize(
    val height: Dp,
    val horizontalPadding: Dp,
    val cornerRadius: Dp,
    val iconSize: Dp
) {
    XS(height = 28.dp, horizontalPadding = 10.dp, cornerRadius = 6.dp, iconSize = 14.dp),
    SM(height = 34.dp, horizontalPadding = 12.dp, cornerRadius = 8.dp, iconSize = 15.dp),
    MD(height = 40.dp, horizontalPadding = 16.dp, cornerRadius = 10.dp, iconSize = 17.dp),
    LG(height = 46.dp, horizontalPadding = 20.dp, cornerRadius = 12.dp, iconSize = 18.dp)
}

@Composable
fun OpenClaudeTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val tokens = if (darkTheme) DarkCdsTokens else LightCdsTokens
    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = tokens.clay,
            onPrimary = Color.White,
            primaryContainer = tokens.claySoftBg,
            onPrimaryContainer = Color(0xFFFADCD2),
            secondary = tokens.textSecondary,
            secondaryContainer = tokens.surface3,
            onSecondaryContainer = tokens.textPrimary,
            tertiary = tokens.success,
            tertiaryContainer = Color(0xFF163824),
            onTertiaryContainer = Color(0xFFC8F2D8),
            background = tokens.surface0,
            surface = tokens.surface0,
            surfaceContainerLow = tokens.surface1,
            surfaceContainer = tokens.surface2,
            surfaceContainerHigh = tokens.surface3,
            outlineVariant = tokens.hairlineBorder,
            error = tokens.danger
        )
    } else {
        lightColorScheme(
            primary = tokens.clay,
            onPrimary = Color.White,
            primaryContainer = tokens.claySoftBg,
            onPrimaryContainer = Color(0xFF4A1E10),
            secondary = tokens.textSecondary,
            secondaryContainer = tokens.surface1,
            onSecondaryContainer = tokens.textPrimary,
            tertiary = tokens.success,
            tertiaryContainer = Color(0xFFD9F2E3),
            onTertiaryContainer = Color(0xFF0E3B22),
            background = tokens.surface0,
            surface = tokens.surface0,
            surfaceContainerLow = tokens.surface2,
            surfaceContainer = tokens.surface1,
            surfaceContainerHigh = tokens.surface3,
            outlineVariant = tokens.hairlineBorder,
            error = tokens.danger
        )
    }

    CompositionLocalProvider(LocalCdsTokens provides tokens) {
        MaterialTheme(
            colorScheme = colorScheme,
            content = content
        )
    }
}

/**
 * CDS 2.1 active:scale-[0.98] 物理触觉微缩修饰符（70ms 触觉下压 + 弹簧回弹）
 */
private fun Modifier.cdsTactileScale(
    enabled: Boolean = true,
    activeScale: Float = 0.975f,
    shape: Shape = RoundedCornerShape(10.dp),
    onClick: () -> Unit
): Modifier = composed {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (enabled && isPressed) activeScale else 1f,
        animationSpec = spring(
            dampingRatio = if (isPressed) 0.82f else CDS_SPRING_POPOVER_DAMPING,
            stiffness = if (isPressed) 750f else CDS_SPRING_SNAPPY_STIFFNESS
        ),
        label = "CdsTactileScale"
    )
    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clip(shape)
        .clickable(
            interactionSource = interactionSource,
            indication = LocalIndication.current,
            enabled = enabled,
            onClick = onClick
        )
}

/**
 * Open Claude UI 核心算法 1：7 档渐隐非线性透明度遮罩 (7-Stop Non-Linear Fade Mask, y ≈ x^1.5)
 * 采样位置：15% -> 5.1% (#0d), 30% -> 14.9% (#26), 45% -> 30.2% (#4d), 60% -> 50.2% (#80),
 *          75% -> 70.2% (#b3), 87% -> 85.1% (#d9), 100% -> 100% (#ff)
 * 搭配触顶/触底动态归零传感器，彻底消除高分屏线性遮罩的色阶断层
 */
private fun Modifier.cdsSevenStopScrollFadeMask(
    showTopFade: Boolean,
    showBottomFade: Boolean,
    fadeHeightDp: Dp = 26.dp
): Modifier = composed {
    val density = LocalDensity.current
    val topAlpha by animateFloatAsState(
        targetValue = if (showTopFade) 1f else 0f,
        animationSpec = tween(durationMillis = 180, easing = FastOutSlowInEasing),
        label = "CdsTopFadeAlpha"
    )
    val bottomAlpha by animateFloatAsState(
        targetValue = if (showBottomFade) 1f else 0f,
        animationSpec = tween(durationMillis = 180, easing = FastOutSlowInEasing),
        label = "CdsBottomFadeAlpha"
    )

    this
        .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
        .drawWithContent {
            drawContent()
            val fadePx = with(density) { fadeHeightDp.toPx() }.coerceAtMost(size.height * 0.22f)
            if (topAlpha > 0.01f && fadePx > 1f) {
                val topBrush = Brush.verticalGradient(
                    0.00f to Color.Black.copy(alpha = 1f - topAlpha),
                    0.15f to Color.Black.copy(alpha = 1f - topAlpha * (1f - 0.051f)),
                    0.30f to Color.Black.copy(alpha = 1f - topAlpha * (1f - 0.149f)),
                    0.45f to Color.Black.copy(alpha = 1f - topAlpha * (1f - 0.302f)),
                    0.60f to Color.Black.copy(alpha = 1f - topAlpha * (1f - 0.502f)),
                    0.75f to Color.Black.copy(alpha = 1f - topAlpha * (1f - 0.702f)),
                    0.87f to Color.Black.copy(alpha = 1f - topAlpha * (1f - 0.851f)),
                    1.00f to Color.Black,
                    startY = 0f,
                    endY = fadePx
                )
                drawRect(
                    brush = topBrush,
                    topLeft = Offset.Zero,
                    size = Size(size.width, fadePx),
                    blendMode = BlendMode.DstIn
                )
            }
            if (bottomAlpha > 0.01f && fadePx > 1f) {
                val startY = size.height - fadePx
                val bottomBrush = Brush.verticalGradient(
                    0.00f to Color.Black,
                    0.13f to Color.Black.copy(alpha = 1f - bottomAlpha * (1f - 0.851f)),
                    0.25f to Color.Black.copy(alpha = 1f - bottomAlpha * (1f - 0.702f)),
                    0.40f to Color.Black.copy(alpha = 1f - bottomAlpha * (1f - 0.502f)),
                    0.55f to Color.Black.copy(alpha = 1f - bottomAlpha * (1f - 0.302f)),
                    0.70f to Color.Black.copy(alpha = 1f - bottomAlpha * (1f - 0.149f)),
                    0.85f to Color.Black.copy(alpha = 1f - bottomAlpha * (1f - 0.051f)),
                    1.00f to Color.Black.copy(alpha = 1f - bottomAlpha),
                    startY = startY,
                    endY = size.height
                )
                drawRect(
                    brush = bottomBrush,
                    topLeft = Offset(0f, startY),
                    size = Size(size.width, fadePx),
                    blendMode = BlendMode.DstIn
                )
            }
        }
}

/**
 * CDS 1.2 & 1.4 表面卡片容器：
 * 遵循「单闭合 0.5dp 发丝细边 (Hairline Ring)」与「wl-glow 陶土漫反射微光」原则
 */
@Composable
private fun CdsSurfaceCard(
    modifier: Modifier = Modifier,
    surfaceLevel: Int = 2,
    cornerRadius: Dp = 16.dp,
    isHighlighted: Boolean = false,
    content: @Composable () -> Unit
) {
    val tokens = LocalCdsTokens.current
    val bgColor = when (surfaceLevel) {
        0 -> tokens.surface0
        1 -> tokens.surface1
        3 -> tokens.surface3
        else -> tokens.surface2
    }
    val borderColor = if (isHighlighted) tokens.clayBorder else tokens.hairlineBorder
    val borderWidth = if (isHighlighted) 1.dp else 0.6.dp

    OutlinedCard(
        shape = RoundedCornerShape(cornerRadius),
        colors = CardDefaults.outlinedCardColors(containerColor = bgColor),
        border = BorderStroke(borderWidth, borderColor),
        elevation = CardDefaults.outlinedCardElevation(defaultElevation = 0.dp),
        modifier = modifier
    ) {
        content()
    }
}

/**
 * CDS 2.1 全能原子按钮 (`CdsButton`)：支持 4 级尺寸 (XS/SM/MD/LG)、5 大变体与 0.98 物理触觉微缩
 */
@Composable
private fun CdsButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    variant: CdsButtonVariant = CdsButtonVariant.PRIMARY,
    size: CdsButtonSize = CdsButtonSize.MD,
    enabled: Boolean = true
) {
    val tokens = LocalCdsTokens.current
    val bgColor = when (variant) {
        CdsButtonVariant.PRIMARY -> if (enabled) tokens.clay else tokens.clay.copy(alpha = 0.45f)
        CdsButtonVariant.SECONDARY -> tokens.surface3
        CdsButtonVariant.GHOST -> Color.Transparent
        CdsButtonVariant.OUTLINE -> tokens.claySoftBg.copy(alpha = 0.65f)
        CdsButtonVariant.DANGER -> tokens.danger.copy(alpha = 0.14f)
    }
    val contentColor = when (variant) {
        CdsButtonVariant.PRIMARY -> Color.White
        CdsButtonVariant.SECONDARY -> tokens.textPrimary
        CdsButtonVariant.GHOST -> tokens.textSecondary
        CdsButtonVariant.OUTLINE -> tokens.clay
        CdsButtonVariant.DANGER -> tokens.danger
    }
    val borderStroke = when (variant) {
        CdsButtonVariant.PRIMARY -> BorderStroke(0.5.dp, Color.White.copy(alpha = 0.18f))
        CdsButtonVariant.SECONDARY -> BorderStroke(0.6.dp, tokens.hairlineBorder)
        CdsButtonVariant.GHOST -> null
        CdsButtonVariant.OUTLINE -> BorderStroke(0.8.dp, tokens.clayBorder)
        CdsButtonVariant.DANGER -> BorderStroke(0.8.dp, tokens.danger.copy(alpha = 0.45f))
    }

    val shape = RoundedCornerShape(size.cornerRadius)
    Surface(
        shape = shape,
        color = bgColor,
        border = borderStroke,
        modifier = modifier
            .height(size.height)
            .cdsTactileScale(
                enabled = enabled,
                activeScale = 0.975f,
                shape = shape,
                onClick = onClick
            )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = size.horizontalPadding),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = text,
                    tint = contentColor,
                    modifier = Modifier.size(size.iconSize)
                )
                Spacer(modifier = Modifier.width(6.dp))
            }
            Text(
                text = text,
                style = when (size) {
                    CdsButtonSize.XS -> MaterialTheme.typography.labelSmall
                    CdsButtonSize.SM -> MaterialTheme.typography.labelMedium
                    CdsButtonSize.MD, CdsButtonSize.LG -> MaterialTheme.typography.labelLarge
                },
                fontWeight = tokens.bodyStrongWeight,
                color = contentColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * CDS 2.3 陶土明度呼吸指示灯 (2.4s Clay Breathing Status Indicator) & 1.2s 实时活动脉冲
 */
@Composable
private fun CdsStatusBreathingDot(
    isActive: Boolean,
    isPulsing: Boolean = false
) {
    val tokens = LocalCdsTokens.current
    val infiniteTransition = rememberInfiniteTransition(label = "CdsBreathingDot")
    val duration = if (isPulsing) 1200 else 2400
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.38f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = duration / 2, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "CdsDotAlpha"
    )
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = if (isPulsing) 1.22f else 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = duration / 2, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "CdsDotScale"
    )

    val dotColor = when {
        isPulsing -> tokens.clay
        isActive -> tokens.success
        else -> tokens.textMuted.copy(alpha = 0.55f)
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.size(12.dp)
    ) {
        if (isActive || isPulsing) {
            Box(
                modifier = Modifier
                    .size(11.dp)
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        this.alpha = alpha * 0.32f
                    }
                    .clip(CircleShape)
                    .background(dotColor)
            )
        }
        Box(
            modifier = Modifier
                .size(6.5.dp)
                .clip(CircleShape)
                .background(if (isActive || isPulsing) dotColor.copy(alpha = alpha) else dotColor)
        )
    }
}

/**
 * CDS 一级参数磁贴按钮（2x2 矩阵：点击后从按钮所在象限弹出二级面板，点击空白处缩回按钮本身）
 */
@Composable
private fun CdsTriggerTile(
    icon: ImageVector,
    title: String,
    valueText: String,
    isActive: Boolean,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val tokens = LocalCdsTokens.current
    val activeScale by animateFloatAsState(
        targetValue = if (isActive) 1.02f else 1f,
        animationSpec = spring(
            dampingRatio = CDS_SPRING_POPOVER_DAMPING,
            stiffness = CDS_SPRING_POPOVER_STIFFNESS
        ),
        label = "CdsTriggerTileScale"
    )

    val bgColor by animateColorAsState(
        targetValue = if (isActive) tokens.claySoftBg else tokens.surface2,
        animationSpec = spring(
            dampingRatio = CDS_SPRING_LAYOUT_DAMPING,
            stiffness = CDS_SPRING_LAYOUT_STIFFNESS
        ),
        label = "CdsTriggerTileBg"
    )

    OutlinedCard(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.outlinedCardColors(containerColor = bgColor),
        border = BorderStroke(
            width = if (isActive) 1.dp else 0.6.dp,
            color = if (isActive) tokens.clayBorder else tokens.hairlineBorder
        ),
        elevation = CardDefaults.outlinedCardElevation(defaultElevation = 0.dp),
        modifier = modifier
            .graphicsLayer {
                scaleX = activeScale
                scaleY = activeScale
            }
            .cdsTactileScale(
                enabled = enabled,
                activeScale = 0.96f,
                shape = RoundedCornerShape(12.dp),
                onClick = onClick
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isActive) tokens.clay else tokens.surface1,
                border = BorderStroke(0.5.dp, if (isActive) tokens.clayBorder else tokens.hairlineBorder),
                modifier = Modifier.size(32.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = if (isActive) Color.White else tokens.clay,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = tokens.textMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = valueText,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = tokens.headingWeight,
                    color = tokens.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Icon(
                imageVector = if (isActive) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                contentDescription = null,
                tint = if (isActive) tokens.clay else tokens.textMuted,
                modifier = Modifier.size(15.dp)
            )
        }
    }
}

class MainActivity : ComponentActivity() {

    private var incomingExternalIntent by mutableStateOf<Intent?>(null)
    private var interceptVolumeKeysForReader by mutableStateOf(false)
    private var volumePageStepSignal by mutableIntStateOf(0)
    private var volumePageDirection by mutableIntStateOf(0)

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (interceptVolumeKeysForReader &&
            (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || event.keyCode == KeyEvent.KEYCODE_VOLUME_UP)
        ) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                volumePageDirection = if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) 1 else -1
                volumePageStepSignal++
            }
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null && intent != null) {
            incomingExternalIntent = intent
        }

        addOnNewIntentListener(Consumer { newIntent ->
            incomingExternalIntent = newIntent
        })

        setContent {
            val systemDark = isSystemInDarkTheme()
            var isDarkThemeOverride by remember { mutableStateOf<Boolean?>(null) }
            val effectiveDark = isDarkThemeOverride ?: systemDark

            OpenClaudeTheme(darkTheme = effectiveDark) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = LocalCdsTokens.current.surface0
                ) {
                    OpenClaudeArchiveExtractorReaderApp(
                        externalIntent = incomingExternalIntent,
                        onExternalIntentConsumed = { incomingExternalIntent = null },
                        isDarkTheme = effectiveDark,
                        onToggleDarkTheme = { isDarkThemeOverride = !effectiveDark },
                        volumePageStepSignal = volumePageStepSignal,
                        volumePageDirection = volumePageDirection,
                        onUpdateVolumeKeyIntercept = { interceptVolumeKeysForReader = it }
                    )
                }
            }
        }
    }
}

private fun extractUrisFromIntent(intent: Intent): List<Uri> {
    val uris = LinkedHashSet<Uri>()
    when (intent.action) {
        Intent.ACTION_VIEW -> {
            intent.data?.let { uris.add(it) }
        }
        Intent.ACTION_SEND -> {
            val streamUri: Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            }
            streamUri?.let { uris.add(it) }
            intent.data?.let { uris.add(it) }
        }
        Intent.ACTION_SEND_MULTIPLE -> {
            val streamList: java.util.ArrayList<Uri>? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
            }
            streamList?.forEach { uris.add(it) }
        }
    }
    intent.clipData?.let { clip ->
        for (i in 0 until clip.itemCount) {
            clip.getItemAt(i)?.uri?.let { uris.add(it) }
        }
    }
    return uris.toList()
}

@OptIn(
    ExperimentalMaterial3Api::class,
    ExperimentalLayoutApi::class,
    ExperimentalFoundationApi::class,
    ExperimentalAnimationApi::class
)
@Composable
fun OpenClaudeArchiveExtractorReaderApp(
    externalIntent: Intent?,
    onExternalIntentConsumed: () -> Unit,
    isDarkTheme: Boolean,
    onToggleDarkTheme: () -> Unit,
    volumePageStepSignal: Int = 0,
    volumePageDirection: Int = 0,
    onUpdateVolumeKeyIntercept: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val coroutineScope = rememberCoroutineScope()
    val tokens = LocalCdsTokens.current

    // 两大核心工作空间左右滑页 Pager（解压 · 阅读）
    val pagerState = rememberPagerState(
        initialPage = 0,
        pageCount = { ProcessMode.entries.size }
    )
    var pagerScrollJob by remember { mutableStateOf<Job?>(null) }
    val currentMode = ProcessMode.entries[pagerState.currentPage]

    // 当前展开的第二层 CDS 弹出面板（点击空白区域即置为 NONE 缩回源按钮）
    var activeLayer2Menu by remember { mutableStateOf(CdsLayer2Menu.NONE) }

    // 解压出的图片队列与存相册结果映射
    var selectedImages by remember { mutableStateOf<List<SelectedImageItem>>(emptyList()) }
    val exportResults = remember { mutableStateMapOf<Uri, ExportSaveResult>() }
    var lastExportReport by remember { mutableStateOf<BatchExportReport?>(null) }
    var lastImportedArchiveBanner by remember { mutableStateOf<String?>(null) }

    // 大图详情预览弹窗状态
    var inspectedItem by remember { mutableStateOf<SelectedImageItem?>(null) }

    // 1. 常用密码本与默认解压密码状态
    var archivePassword by remember { mutableStateOf("") }
    var savedArchivePasswords by remember {
        mutableStateOf(ImageCompressor.getSavedArchivePasswords(context))
    }

    // 2. 加密压缩包导入密码解锁弹窗状态
    var pendingPasswordArchiveUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var pendingPasswordArchiveNames by remember { mutableStateOf("") }
    var unlockPasswordInput by remember { mutableStateOf("") }
    var unlockPasswordError by remember { mutableStateOf<String?>(null) }
    var jumpToReaderAfterUnlock by remember { mutableStateOf(false) }

    // 3. 批量存相册重命名与自定义目录状态
    var selectedRenameTemplate by remember { mutableStateOf(RenameTemplate.KEEP_ORIGINAL) }
    var customRenamePrefix by remember { mutableStateOf("IMG") }
    var customTreeUri by remember { mutableStateOf<Uri?>(null) }
    var customDirName by remember { mutableStateOf<String?>(null) }

    // 4. 归档阅读器、音量键翻页与队列排序筛选状态
    var readerLayoutMode by remember { mutableStateOf(ReaderLayoutMode.VERTICAL_STRIP) }
    var isImmersiveReader by remember { mutableStateOf(false) }
    var readerVolumeKeyPaging by remember { mutableStateOf(true) }
    var queueSortOrder by remember { mutableStateOf(QueueSortOrder.NAME_ASC) }
    var showOnlyUnsaved by remember { mutableStateOf(false) }

    // 5. 实时解压进度与批量存相册进度状态
    var isExtractingArchive by remember { mutableStateOf(false) }
    var extractDoneCount by remember { mutableIntStateOf(0) }
    var extractTotalCount by remember { mutableIntStateOf(0) }
    var extractCurrentFile by remember { mutableStateOf("") }

    var isSavingBatch by remember { mutableStateOf(false) }
    var completedCount by remember { mutableIntStateOf(0) }
    var totalTaskCount by remember { mutableIntStateOf(0) }
    var activeTaskJob by remember { mutableStateOf<Job?>(null) }

    val displayedQueueImages = remember(
        selectedImages,
        queueSortOrder,
        showOnlyUnsaved,
        exportResults.size
    ) {
        val sorted = ImageCompressor.sortImageQueue(selectedImages, queueSortOrder)
        if (showOnlyUnsaved && exportResults.isNotEmpty()) {
            sorted.filter { exportResults[it.uri]?.isSuccess != true }
        } else {
            sorted
        }
    }

    // 仅当处于「阅读」页、已有图片且未打开二级弹窗时，启用音量上下键翻页拦截
    LaunchedEffect(
        currentMode,
        readerVolumeKeyPaging,
        selectedImages.isNotEmpty(),
        activeLayer2Menu,
        pendingPasswordArchiveUris.isEmpty()
    ) {
        val shouldIntercept = currentMode == ProcessMode.ARCHIVE_READER &&
            readerVolumeKeyPaging &&
            selectedImages.isNotEmpty() &&
            activeLayer2Menu == CdsLayer2Menu.NONE &&
            pendingPasswordArchiveUris.isEmpty()
        onUpdateVolumeKeyIntercept(shouldIntercept)
    }

    val cancelRunningTask: () -> Unit = {
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        activeTaskJob?.cancel()
        activeTaskJob = null
        isSavingBatch = false
        isExtractingArchive = false
        Toast.makeText(context, "已中止当前任务（已完成项已保留）", Toast.LENGTH_SHORT).show()
    }

    // 动画跳转工作台
    val animateToMode: (ProcessMode) -> Unit = { targetMode ->
        activeLayer2Menu = CdsLayer2Menu.NONE
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        pagerScrollJob?.cancel()
        pagerScrollJob = coroutineScope.launch {
            pagerState.animateScrollToPage(
                page = targetMode.ordinal,
                animationSpec = spring(
                    dampingRatio = CDS_SPRING_LAYOUT_DAMPING,
                    stiffness = CDS_SPRING_LAYOUT_STIFFNESS
                )
            )
        }
    }

    // 统一处理压缩包解压导入（含加密检测、主线程实时解压进度条、随时取消与密码弹窗）
    val handleArchiveImport: (List<Uri>, String, Boolean) -> Unit = { uris, pwd, openInReader ->
        activeTaskJob?.cancel()
        activeTaskJob = coroutineScope.launch {
            if (openInReader && currentMode != ProcessMode.ARCHIVE_READER) {
                animateToMode(ProcessMode.ARCHIVE_READER)
            }
            isExtractingArchive = true
            extractDoneCount = 0
            extractTotalCount = 0
            extractCurrentFile = ""
            try {
                val summary = ImageCompressor.extractImagesFromArchiveUris(
                    context = context,
                    archiveUris = uris,
                    password = pwd
                ) { done, total, currentName ->
                    coroutineScope.launch(Dispatchers.Main.immediate) {
                        extractDoneCount = done
                        extractTotalCount = total
                        extractCurrentFile = currentName
                    }
                }
                isExtractingArchive = false

                if (summary.needsPassword) {
                    pendingPasswordArchiveUris = summary.pendingUris
                    pendingPasswordArchiveNames = summary.archiveNames.joinToString(", ")
                    unlockPasswordError = if (summary.wrongPassword) "密码不正确，请重新输入" else null
                    jumpToReaderAfterUnlock = openInReader
                } else if (summary.extractedImages.isNotEmpty()) {
                    if (pwd.isNotBlank()) {
                        savedArchivePasswords = ImageCompressor.saveArchivePasswordToHistory(context, pwd)
                    }
                    pendingPasswordArchiveUris = emptyList()
                    unlockPasswordError = null
                    selectedImages = ImageCompressor.sortImageQueue(summary.extractedImages, queueSortOrder)
                    lastImportedArchiveBanner = "${summary.archiveNames.joinToString(", ")} · ${summary.extractedImages.size}P"
                    exportResults.clear()
                    lastExportReport = null
                    completedCount = 0
                    totalTaskCount = summary.extractedImages.size
                    if (openInReader) {
                        animateToMode(ProcessMode.ARCHIVE_READER)
                    }
                    Toast.makeText(context, "已解压载入 ${summary.extractedImages.size} 张图片", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(
                        context,
                        summary.errorNote ?: "压缩包内未找到支持的图片",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (_: CancellationException) {
                isExtractingArchive = false
            } finally {
                isExtractingArchive = false
            }
        }
    }

    // 响应外部应用「打开方式 / 分享导入」传入的压缩包或图片
    LaunchedEffect(externalIntent) {
        val intentToHandle = externalIntent ?: return@LaunchedEffect
        val incomingUris = extractUrisFromIntent(intentToHandle)
        onExternalIntentConsumed()

        if (incomingUris.isNotEmpty()) {
            val archiveUris = incomingUris.filter { ImageCompressor.isArchiveUri(context, it) }
            val imageUris = incomingUris.filterNot { ImageCompressor.isArchiveUri(context, it) }

            if (archiveUris.isNotEmpty() && imageUris.isEmpty()) {
                handleArchiveImport(archiveUris, archivePassword, true)
            } else {
                val mergedList = mutableListOf<SelectedImageItem>()
                if (archiveUris.isNotEmpty()) {
                    isExtractingArchive = true
                    extractDoneCount = 0
                    extractTotalCount = 0
                    extractCurrentFile = ""
                    val summary = ImageCompressor.extractImagesFromArchiveUris(
                        context = context,
                        archiveUris = archiveUris,
                        password = archivePassword
                    ) { done, total, currentName ->
                        coroutineScope.launch(Dispatchers.Main.immediate) {
                            extractDoneCount = done
                            extractTotalCount = total
                            extractCurrentFile = currentName
                        }
                    }
                    isExtractingArchive = false
                    if (summary.needsPassword) {
                        pendingPasswordArchiveUris = summary.pendingUris
                        pendingPasswordArchiveNames = summary.archiveNames.joinToString(", ")
                        jumpToReaderAfterUnlock = true
                    }
                    mergedList.addAll(summary.extractedImages)
                }
                if (imageUris.isNotEmpty()) {
                    mergedList.addAll(ImageCompressor.inspectImages(context, imageUris))
                }
                if (mergedList.isNotEmpty()) {
                    selectedImages = ImageCompressor.sortImageQueue(mergedList, queueSortOrder)
                    exportResults.clear()
                    lastExportReport = null
                    completedCount = 0
                    totalTaskCount = mergedList.size
                }
            }
        }
    }

    // 1. 压缩包导入启动器
    var openArchiveInReaderFlag by remember { mutableStateOf(false) }
    val pickArchiveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            handleArchiveImport(uris, archivePassword, openArchiveInReaderFlag)
        }
    }

    // 2. 相册选图启动器
    val pickMultipleImagesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 50)
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            coroutineScope.launch {
                val inspected = ImageCompressor.inspectImages(context, uris)
                selectedImages = ImageCompressor.sortImageQueue(inspected, queueSortOrder)
                lastImportedArchiveBanner = "相册图片 · ${inspected.size}P"
                exportResults.clear()
                lastExportReport = null
                completedCount = 0
                totalTaskCount = inspected.size
            }
        }
    }

    // 3. SAF 自定义保存目录选择器
    val pickOutputDirectoryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        if (treeUri != null) {
            runCatching {
                val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(treeUri, takeFlags)
            }
            customTreeUri = treeUri
            val docDir = DocumentFile.fromTreeUri(context, treeUri)
            customDirName = docDir?.name ?: treeUri.lastPathSegment ?: "自定义目录"
            Toast.makeText(context, "存相册目录：$customDirName", Toast.LENGTH_SHORT).show()
        }
    }

    // 一键批量存相册入口
    val triggerBatchSaveToGallery: () -> Unit = {
        if (selectedImages.isNotEmpty()) {
            activeLayer2Menu = CdsLayer2Menu.NONE
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            isSavingBatch = true
            completedCount = 0
            totalTaskCount = selectedImages.size
            exportResults.clear()
            lastExportReport = null

            val config = GalleryExportConfig(
                renameTemplate = selectedRenameTemplate,
                customRenamePrefix = customRenamePrefix,
                customTreeUri = customTreeUri
            )

            activeTaskJob?.cancel()
            activeTaskJob = coroutineScope.launch {
                try {
                    val report = ImageCompressor.saveBatchToGallery(
                        context = context,
                        items = selectedImages,
                        config = config,
                        onProgress = { done, total, latest ->
                            coroutineScope.launch(Dispatchers.Main.immediate) {
                                completedCount = done
                                totalTaskCount = total
                                exportResults[latest.source.uri] = latest
                            }
                        }
                    )
                    lastExportReport = report
                    isSavingBatch = false
                    val successCount = report.itemResults.count { it.isSuccess }
                    Toast.makeText(
                        context,
                        "已存相册 $successCount / ${report.itemResults.size} 张 (${report.targetFolderLabel})",
                        Toast.LENGTH_SHORT
                    ).show()
                } catch (_: CancellationException) {
                    isSavingBatch = false
                } finally {
                    isSavingBatch = false
                    activeTaskJob = null
                }
            }
        }
    }

    // 单张图片一键保存到系统相册/自定义目录
    val saveSingleImageItemToGallery: (SelectedImageItem) -> Unit = { item ->
        coroutineScope.launch {
            val saved = ImageCompressor.saveSingleImageToGallery(
                context = context,
                sourceUri = item.uri,
                originalDisplayName = item.displayName,
                customTreeUri = customTreeUri
            )
            if (saved != null) {
                exportResults[item.uri] = ExportSaveResult(
                    source = item,
                    isSuccess = true,
                    savedUri = saved.first,
                    savedName = saved.second.substringAfterLast('/'),
                    savedSize = item.originalSize,
                    savedPathLabel = saved.second
                )
                Toast.makeText(context, "已存入相册：${saved.second}", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "保存图片失败", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // 一键分享全部解压图片
    val shareAllExtractedImages: () -> Unit = {
        val savedUris = selectedImages.mapNotNull { exportResults[it.uri]?.savedUri }
        val targetUris = if (savedUris.isNotEmpty()) savedUris else selectedImages.map { it.uri }
        ImageCompressor.shareOutputUris(
            context = context,
            uris = targetUris,
            mimeType = "image/*",
            chooserTitle = "分享解压图片 (${targetUris.size}张)"
        )
    }

    val hasModalOrLayer2 = inspectedItem != null ||
        activeLayer2Menu != CdsLayer2Menu.NONE ||
        pendingPasswordArchiveUris.isNotEmpty()

    val continuousPagePositionProvider: () -> Float = {
        pagerState.currentPage + pagerState.currentPageOffsetFraction
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth >= 600.dp

        Box(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .then(
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && hasModalOrLayer2) {
                            Modifier.blur(10.dp)
                        } else {
                            Modifier
                        }
                    )
            ) {
                if (isWideScreen && !isImmersiveReader) {
                    CdsNavigationRail(
                        currentMode = currentMode,
                        selectedCount = selectedImages.size,
                        onSelectMode = animateToMode
                    )
                    VerticalDivider(
                        thickness = 0.6.dp,
                        color = tokens.hairlineBorder
                    )
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        containerColor = tokens.surface0,
                        topBar = {
                            if (!isImmersiveReader) {
                                CdsEditorialTopBar(
                                    currentMode = currentMode,
                                    selectedCount = selectedImages.size,
                                    customTreeUri = customTreeUri,
                                    isDarkTheme = isDarkTheme,
                                    isBusy = isSavingBatch || isExtractingArchive,
                                    onToggleDarkTheme = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        onToggleDarkTheme()
                                    },
                                    onPickDirectory = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        pickOutputDirectoryLauncher.launch(customTreeUri)
                                    },
                                    onShareAll = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        shareAllExtractedImages()
                                    },
                                    onClearQueue = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        selectedImages = emptyList()
                                        exportResults.clear()
                                        lastExportReport = null
                                        lastImportedArchiveBanner = null
                                        completedCount = 0
                                        totalTaskCount = 0
                                    }
                                )
                            }
                        }
                    ) { innerPadding ->
                        HorizontalPager(
                            state = pagerState,
                            userScrollEnabled = !isImmersiveReader,
                            beyondBoundsPageCount = 1,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(if (isImmersiveReader) PaddingValues(0.dp) else innerPadding)
                        ) { pageIndex ->
                            val pageMode = ProcessMode.entries[pageIndex]

                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .graphicsLayer {
                                        val pageOffset = ((pagerState.currentPage - pageIndex) + pagerState.currentPageOffsetFraction)
                                        val absOffset = abs(pageOffset).coerceIn(0f, 1f)
                                        val pageScale = 1f - (absOffset * 0.05f)
                                        val pageAlpha = 1f - (absOffset * 0.22f)
                                        scaleX = pageScale
                                        scaleY = pageScale
                                        alpha = pageAlpha
                                    }
                            ) {
                                if (pageMode == ProcessMode.ARCHIVE_READER) {
                                    // ====== 页签 2：Open Claude UI 归档画廊阅读器 (内置触点仿射 Pan/Zoom 与 7 档非线性渐隐遮罩) ======
                                    CdsArchiveImageReaderView(
                                        images = displayedQueueImages,
                                        readerLayoutMode = readerLayoutMode,
                                        isImmersive = isImmersiveReader,
                                        archiveBanner = lastImportedArchiveBanner,
                                        hasArchivePassword = archivePassword.isNotBlank(),
                                        isExtracting = isExtractingArchive,
                                        extractDoneCount = extractDoneCount,
                                        extractTotalCount = extractTotalCount,
                                        extractCurrentFile = extractCurrentFile,
                                        volumePageStepSignal = volumePageStepSignal,
                                        volumePageDirection = volumePageDirection,
                                        onCancelExtract = cancelRunningTask,
                                        onToggleImmersive = { isImmersiveReader = !isImmersiveReader },
                                        onToggleLayoutMode = {
                                            val modes = ReaderLayoutMode.entries
                                            val nextIdx = (modes.indexOf(readerLayoutMode) + 1) % modes.size
                                            readerLayoutMode = modes[nextIdx]
                                        },
                                        onOpenReaderLayer2Menu = {
                                            activeLayer2Menu = CdsLayer2Menu.READER_CONTROL_PANEL
                                        },
                                        onPickArchiveToRead = {
                                            openArchiveInReaderFlag = true
                                            pickArchiveLauncher.launch(arrayOf("*/*"))
                                        },
                                        onPickImagesToRead = {
                                            pickMultipleImagesLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        },
                                        onSaveSingleImage = saveSingleImageItemToGallery,
                                        onShareSingleImage = { item ->
                                            ImageCompressor.shareOutputUris(
                                                context = context,
                                                uris = listOf(exportResults[item.uri]?.savedUri ?: item.uri),
                                                mimeType = item.mimeType,
                                                chooserTitle = item.displayName
                                            )
                                        }
                                    )
                                } else {
                                    // ====== 页签 1：Open Claude UI 解压工作台（7 档非线性渐隐滚动视口） ======
                                    val workbenchListState = rememberLazyListState()
                                    LazyColumn(
                                        state = workbenchListState,
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .cdsSevenStopScrollFadeMask(
                                                showTopFade = workbenchListState.canScrollBackward,
                                                showBottomFade = workbenchListState.canScrollForward,
                                                fadeHeightDp = 24.dp
                                            ),
                                        contentPadding = PaddingValues(
                                            start = 16.dp,
                                            end = 16.dp,
                                            top = 12.dp,
                                            bottom = 148.dp
                                        ),
                                        verticalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        // 1. CDS 2x2 状态磁贴仪表盘（带 2.4s 陶土呼吸指示灯与等宽数据标签）
                                        item {
                                            CdsExtractorDashboardGrid(
                                                selectedImages = selectedImages,
                                                exportResultsMap = exportResults,
                                                readerLayoutMode = readerLayoutMode,
                                                customDirName = customDirName,
                                                isExtracting = isExtractingArchive,
                                                lastImportedArchiveBanner = lastImportedArchiveBanner,
                                                onPickArchives = {
                                                    openArchiveInReaderFlag = false
                                                    pickArchiveLauncher.launch(arrayOf("*/*"))
                                                },
                                                onOpenReader = {
                                                    animateToMode(ProcessMode.ARCHIVE_READER)
                                                },
                                                onSaveAllToGallery = triggerBatchSaveToGallery,
                                                onShareAll = shareAllExtractedImages,
                                                onPickDirectory = {
                                                    pickOutputDirectoryLauncher.launch(customTreeUri)
                                                },
                                                onResetDirectory = {
                                                    customTreeUri = null
                                                    customDirName = null
                                                }
                                            )
                                        }

                                        // 2. CDS 2x2 一级参数触发磁贴矩阵（点击展开二级 Popover，点击空白处缩回）
                                        item {
                                            CdsExtractorTriggerMatrix(
                                                activeMenu = activeLayer2Menu,
                                                archivePassword = archivePassword,
                                                savedPasswordCount = savedArchivePasswords.size,
                                                selectedRenameTemplate = selectedRenameTemplate,
                                                queueSortOrder = queueSortOrder,
                                                readerLayoutMode = readerLayoutMode,
                                                readerVolumeKeyPaging = readerVolumeKeyPaging,
                                                onOpenMenu = { menu ->
                                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                    activeLayer2Menu = if (activeLayer2Menu == menu) {
                                                        CdsLayer2Menu.NONE
                                                    } else {
                                                        menu
                                                    }
                                                }
                                            )
                                        }

                                        // 3. 实时解压进度条横幅（含 105° 陶土流光进度条与随时取消）
                                        if (isExtractingArchive && selectedImages.isNotEmpty()) {
                                            item {
                                                CdsExtractionProgressCard(
                                                    extractDoneCount = extractDoneCount,
                                                    extractTotalCount = extractTotalCount,
                                                    extractCurrentFile = extractCurrentFile,
                                                    onCancelExtract = cancelRunningTask
                                                )
                                            }
                                        }

                                        // 4. 批量存相册完成横幅（含一键分享）
                                        if (exportResults.isNotEmpty()) {
                                            item {
                                                CdsBatchExportSummaryBanner(
                                                    selectedImages = selectedImages,
                                                    resultsMap = exportResults,
                                                    exportReport = lastExportReport,
                                                    onShareClick = shareAllExtractedImages
                                                )
                                            }
                                        }

                                        // 5. 解压图片附件磁贴列表或 20dp Composer 空状态引导面板
                                        if (selectedImages.isEmpty()) {
                                            item {
                                                CdsEmptyComposerCard(
                                                    isExtracting = isExtractingArchive,
                                                    extractDoneCount = extractDoneCount,
                                                    extractTotalCount = extractTotalCount,
                                                    extractCurrentFile = extractCurrentFile,
                                                    onCancelExtract = cancelRunningTask,
                                                    onPickArchives = {
                                                        openArchiveInReaderFlag = false
                                                        pickArchiveLauncher.launch(arrayOf("*/*"))
                                                    },
                                                    onPickArchivesAndRead = {
                                                        openArchiveInReaderFlag = true
                                                        pickArchiveLauncher.launch(arrayOf("*/*"))
                                                    }
                                                )
                                            }
                                        } else {
                                            item {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 4.dp, vertical = 2.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                    ) {
                                                        Text(
                                                            text = "解压产物队列",
                                                            style = MaterialTheme.typography.titleSmall,
                                                            fontFamily = FontFamily.Serif,
                                                            fontWeight = tokens.headingWeight,
                                                            color = tokens.textPrimary
                                                        )
                                                        Surface(
                                                            shape = RoundedCornerShape(6.dp),
                                                            color = tokens.surface1,
                                                            border = BorderStroke(0.5.dp, tokens.hairlineBorder)
                                                        ) {
                                                            Text(
                                                                text = "${displayedQueueImages.size}/${selectedImages.size}",
                                                                style = MaterialTheme.typography.labelSmall,
                                                                fontFamily = FontFamily.Monospace,
                                                                color = tokens.textSecondary,
                                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                            )
                                                        }
                                                    }

                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                    ) {
                                                        if (exportResults.isNotEmpty()) {
                                                            CdsButton(
                                                                text = if (showOnlyUnsaved) "仅未存相册" else "全部图片",
                                                                icon = Icons.Default.FilterAlt,
                                                                variant = if (showOnlyUnsaved) CdsButtonVariant.OUTLINE else CdsButtonVariant.SECONDARY,
                                                                size = CdsButtonSize.XS,
                                                                onClick = {
                                                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                                    showOnlyUnsaved = !showOnlyUnsaved
                                                                }
                                                            )
                                                        }

                                                        CdsButton(
                                                            text = queueSortOrder.label,
                                                            icon = Icons.Default.Sort,
                                                            variant = CdsButtonVariant.SECONDARY,
                                                            size = CdsButtonSize.XS,
                                                            onClick = {
                                                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                                val orders = QueueSortOrder.entries
                                                                val nextOrder = orders[(orders.indexOf(queueSortOrder) + 1) % orders.size]
                                                                queueSortOrder = nextOrder
                                                                selectedImages = ImageCompressor.sortImageQueue(selectedImages, nextOrder)
                                                            }
                                                        )
                                                    }
                                                }
                                            }

                                            items(
                                                items = displayedQueueImages,
                                                key = { it.uri.toString() }
                                            ) { item ->
                                                CdsAttachmentItemCard(
                                                    item = item,
                                                    exportResult = exportResults[item.uri],
                                                    modifier = Modifier.animateItemPlacement(
                                                        animationSpec = spring(
                                                            dampingRatio = CDS_SPRING_POPOVER_DAMPING,
                                                            stiffness = CDS_SPRING_POPOVER_STIFFNESS
                                                        )
                                                    ),
                                                    onCardClick = { inspectedItem = item },
                                                    onSaveSingleClick = { saveSingleImageItemToGallery(item) },
                                                    onShareSingleClick = {
                                                        ImageCompressor.shareOutputUris(
                                                            context = context,
                                                            uris = listOf(exportResults[item.uri]?.savedUri ?: item.uri),
                                                            mimeType = item.mimeType,
                                                            chooserTitle = item.displayName
                                                        )
                                                    },
                                                    onRemoveItem = {
                                                        selectedImages = selectedImages.filterNot { it.uri == item.uri }
                                                        exportResults.remove(item.uri)
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // ====== 底部：右下角 CDS 陶土操作组 + 999px 全圆角分段滑动导航胶囊 ======
                    if (!isImmersiveReader) {
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            horizontalAlignment = Alignment.End,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (currentMode != ProcessMode.ARCHIVE_READER) {
                                CdsFloatingActionBar(
                                    selectedCount = selectedImages.size,
                                    isBusy = isSavingBatch || isExtractingArchive,
                                    isExtracting = isExtractingArchive,
                                    completedCount = if (isExtractingArchive) extractDoneCount else completedCount,
                                    totalTaskCount = if (isExtractingArchive) extractTotalCount else totalTaskCount,
                                    isQuickHubExpanded = activeLayer2Menu == CdsLayer2Menu.FAB_QUICK_HUB,
                                    onToggleQuickHub = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        activeLayer2Menu = if (activeLayer2Menu == CdsLayer2Menu.FAB_QUICK_HUB) {
                                            CdsLayer2Menu.NONE
                                        } else {
                                            CdsLayer2Menu.FAB_QUICK_HUB
                                        }
                                    },
                                    onPickArchives = {
                                        openArchiveInReaderFlag = false
                                        pickArchiveLauncher.launch(arrayOf("*/*"))
                                    },
                                    onSaveAllToGallery = triggerBatchSaveToGallery,
                                    onShareAll = shareAllExtractedImages,
                                    onCancelClick = cancelRunningTask
                                )
                            }

                            if (!isWideScreen) {
                                CdsBottomSegmentedDockBar(
                                    continuousPagePositionProvider = continuousPagePositionProvider,
                                    onSelectMode = animateToMode
                                )
                            }
                        }
                    }
                }
            }

            // ====== Open Claude UI 第二层双环投影弹出面板（按源按钮象限弹出，点击空白处自动缩回） ======
            CdsLayer2PopoverHost(
                activeMenu = activeLayer2Menu,
                onDismiss = {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    activeLayer2Menu = CdsLayer2Menu.NONE
                },
                archivePassword = archivePassword,
                onArchivePasswordChange = { archivePassword = it },
                savedArchivePasswords = savedArchivePasswords,
                onSaveCurrentArchivePassword = {
                    if (archivePassword.isNotBlank()) {
                        savedArchivePasswords = ImageCompressor.saveArchivePasswordToHistory(context, archivePassword)
                        Toast.makeText(context, "已存入常用密码本", Toast.LENGTH_SHORT).show()
                    }
                },
                onRemoveArchivePassword = { pwdToRemove ->
                    savedArchivePasswords = ImageCompressor.removeArchivePasswordFromHistory(context, pwdToRemove)
                },
                selectedRenameTemplate = selectedRenameTemplate,
                onSelectRenameTemplate = { selectedRenameTemplate = it },
                customRenamePrefix = customRenamePrefix,
                onCustomRenamePrefixChange = { customRenamePrefix = it },
                queueSortOrder = queueSortOrder,
                onSelectQueueSortOrder = { newOrder ->
                    queueSortOrder = newOrder
                    selectedImages = ImageCompressor.sortImageQueue(selectedImages, newOrder)
                },
                showOnlyUnsaved = showOnlyUnsaved,
                onToggleShowOnlyUnsaved = { showOnlyUnsaved = it },
                readerLayoutMode = readerLayoutMode,
                onSelectReaderLayoutMode = { readerLayoutMode = it },
                readerVolumeKeyPaging = readerVolumeKeyPaging,
                onToggleReaderVolumeKeyPaging = { readerVolumeKeyPaging = it },
                hasExtractedImages = selectedImages.isNotEmpty(),
                onQuickImportArchive = {
                    activeLayer2Menu = CdsLayer2Menu.NONE
                    openArchiveInReaderFlag = false
                    pickArchiveLauncher.launch(arrayOf("*/*"))
                },
                onQuickOpenArchiveInReader = {
                    activeLayer2Menu = CdsLayer2Menu.NONE
                    if (selectedImages.isNotEmpty()) {
                        animateToMode(ProcessMode.ARCHIVE_READER)
                    } else {
                        openArchiveInReaderFlag = true
                        pickArchiveLauncher.launch(arrayOf("*/*"))
                    }
                },
                onQuickSaveAllToGallery = {
                    activeLayer2Menu = CdsLayer2Menu.NONE
                    triggerBatchSaveToGallery()
                },
                onQuickShareAll = {
                    activeLayer2Menu = CdsLayer2Menu.NONE
                    shareAllExtractedImages()
                },
                onQuickPickDirectory = {
                    activeLayer2Menu = CdsLayer2Menu.NONE
                    pickOutputDirectoryLauncher.launch(customTreeUri)
                },
                onQuickClearQueue = {
                    activeLayer2Menu = CdsLayer2Menu.NONE
                    selectedImages = emptyList()
                    exportResults.clear()
                    lastExportReport = null
                    lastImportedArchiveBanner = null
                }
            )

            // ====== CDS 2.4 模态确认对话框：16dp 圆角加密压缩包密码解锁弹窗（含常用密码胶囊） ======
            AnimatedVisibility(
                visible = pendingPasswordArchiveUris.isNotEmpty(),
                enter = fadeIn(spring(stiffness = CDS_SPRING_POPOVER_STIFFNESS)) +
                    scaleIn(
                        initialScale = 0.86f,
                        animationSpec = spring(
                            dampingRatio = CDS_SPRING_POPOVER_DAMPING,
                            stiffness = CDS_SPRING_POPOVER_STIFFNESS
                        )
                    ),
                exit = fadeOut(spring(stiffness = CDS_SPRING_SNAPPY_STIFFNESS)) +
                    scaleOut(
                        targetScale = 0.88f,
                        animationSpec = spring(
                            dampingRatio = CDS_SPRING_LAYOUT_DAMPING,
                            stiffness = CDS_SPRING_SNAPPY_STIFFNESS
                        )
                    )
            ) {
                CdsArchivePasswordDialog(
                    archiveNames = pendingPasswordArchiveNames,
                    passwordInput = unlockPasswordInput,
                    errorText = unlockPasswordError,
                    savedPasswords = savedArchivePasswords,
                    onRemoveSavedPassword = { pwd ->
                        savedArchivePasswords = ImageCompressor.removeArchivePasswordFromHistory(context, pwd)
                    },
                    onPasswordChange = {
                        unlockPasswordInput = it
                        unlockPasswordError = null
                    },
                    onDismiss = {
                        pendingPasswordArchiveUris = emptyList()
                        unlockPasswordError = null
                    },
                    onConfirmUnlock = {
                        if (unlockPasswordInput.isBlank()) {
                            unlockPasswordError = "请输入压缩包密码"
                        } else {
                            archivePassword = unlockPasswordInput
                            savedArchivePasswords = ImageCompressor.saveArchivePasswordToHistory(context, unlockPasswordInput)
                            handleArchiveImport(
                                pendingPasswordArchiveUris,
                                unlockPasswordInput,
                                jumpToReaderAfterUnlock
                            )
                        }
                    }
                )
            }

            // ====== CDS 5.2 多模态媒体查看器 Lightbox 弹窗（支持一键存相册与一键分享） ======
            AnimatedVisibility(
                visible = inspectedItem != null,
                enter = fadeIn(animationSpec = spring(stiffness = CDS_SPRING_POPOVER_STIFFNESS)) +
                    scaleIn(
                        initialScale = 0.84f,
                        animationSpec = spring(
                            dampingRatio = CDS_SPRING_POPOVER_DAMPING,
                            stiffness = CDS_SPRING_POPOVER_STIFFNESS
                        )
                    ),
                exit = fadeOut(animationSpec = spring(stiffness = CDS_SPRING_SNAPPY_STIFFNESS)) +
                    scaleOut(
                        targetScale = 0.86f,
                        animationSpec = spring(
                            dampingRatio = CDS_SPRING_LAYOUT_DAMPING,
                            stiffness = CDS_SPRING_SNAPPY_STIFFNESS
                        )
                    )
            ) {
                val activeItem = inspectedItem
                if (activeItem != null) {
                    CdsImageLightboxModal(
                        item = activeItem,
                        exportResult = exportResults[activeItem.uri],
                        onDismiss = { inspectedItem = null },
                        onSaveToGallery = { saveSingleImageItemToGallery(activeItem) },
                        onShare = {
                            val targetUri = exportResults[activeItem.uri]?.savedUri ?: activeItem.uri
                            ImageCompressor.shareOutputUris(
                                context = context,
                                uris = listOf(targetUri),
                                mimeType = activeItem.mimeType,
                                chooserTitle = activeItem.displayName
                            )
                        },
                        onOpenInReader = {
                            inspectedItem = null
                            animateToMode(ProcessMode.ARCHIVE_READER)
                        },
                        onRemove = {
                            selectedImages = selectedImages.filterNot { it.uri == activeItem.uri }
                            exportResults.remove(activeItem.uri)
                            inspectedItem = null
                        }
                    )
                }
            }
        }
    }
}

/**
 * CDS 2x2 一级参数触发磁贴矩阵
 */
@Composable
private fun CdsExtractorTriggerMatrix(
    activeMenu: CdsLayer2Menu,
    archivePassword: String,
    savedPasswordCount: Int,
    selectedRenameTemplate: RenameTemplate,
    queueSortOrder: QueueSortOrder,
    readerLayoutMode: ReaderLayoutMode,
    readerVolumeKeyPaging: Boolean,
    onOpenMenu: (CdsLayer2Menu) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CdsTriggerTile(
                icon = Icons.Default.Password,
                title = "常用密码本",
                valueText = when {
                    archivePassword.isNotBlank() -> "已设预设密码"
                    savedPasswordCount > 0 -> "$savedPasswordCount 条常用密码"
                    else -> "管理解锁密码"
                },
                isActive = activeMenu == CdsLayer2Menu.PASSWORD_BOOK_PANEL,
                modifier = Modifier.weight(1f),
                onClick = { onOpenMenu(CdsLayer2Menu.PASSWORD_BOOK_PANEL) }
            )
            CdsTriggerTile(
                icon = Icons.Default.DriveFileRenameOutline,
                title = "存相册命名",
                valueText = selectedRenameTemplate.shortLabel,
                isActive = activeMenu == CdsLayer2Menu.RENAME_TEMPLATE_PANEL,
                modifier = Modifier.weight(1f),
                onClick = { onOpenMenu(CdsLayer2Menu.RENAME_TEMPLATE_PANEL) }
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CdsTriggerTile(
                icon = Icons.Default.Sort,
                title = "列表排序",
                valueText = queueSortOrder.label,
                isActive = activeMenu == CdsLayer2Menu.QUEUE_SORT_PANEL,
                modifier = Modifier.weight(1f),
                onClick = { onOpenMenu(CdsLayer2Menu.QUEUE_SORT_PANEL) }
            )
            CdsTriggerTile(
                icon = Icons.Default.AutoStories,
                title = "阅读器预设",
                valueText = "${readerLayoutMode.label}${if (readerVolumeKeyPaging) " · 音量翻页" else ""}",
                isActive = activeMenu == CdsLayer2Menu.READER_PRESET_PANEL,
                modifier = Modifier.weight(1f),
                onClick = { onOpenMenu(CdsLayer2Menu.READER_PRESET_PANEL) }
            )
        }
    }
}

/**
 * Open Claude UI 第二层双环投影弹出面板宿主 (`CdsLayer2PopoverHost`)：
 * - 16dp 精密圆角 + Surface 3 顶层表面 + 0.5dp 发丝细边 + wl-glow 陶土漫反射光场
 * - 点击一级按钮从对应象限弹出，点击面板外任意空白区域缩回原按钮
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CdsLayer2PopoverHost(
    activeMenu: CdsLayer2Menu,
    onDismiss: () -> Unit,
    archivePassword: String,
    onArchivePasswordChange: (String) -> Unit,
    savedArchivePasswords: List<String>,
    onSaveCurrentArchivePassword: () -> Unit,
    onRemoveArchivePassword: (String) -> Unit,
    selectedRenameTemplate: RenameTemplate,
    onSelectRenameTemplate: (RenameTemplate) -> Unit,
    customRenamePrefix: String,
    onCustomRenamePrefixChange: (String) -> Unit,
    queueSortOrder: QueueSortOrder,
    onSelectQueueSortOrder: (QueueSortOrder) -> Unit,
    showOnlyUnsaved: Boolean,
    onToggleShowOnlyUnsaved: (Boolean) -> Unit,
    readerLayoutMode: ReaderLayoutMode,
    onSelectReaderLayoutMode: (ReaderLayoutMode) -> Unit,
    readerVolumeKeyPaging: Boolean,
    onToggleReaderVolumeKeyPaging: (Boolean) -> Unit,
    hasExtractedImages: Boolean,
    onQuickImportArchive: () -> Unit,
    onQuickOpenArchiveInReader: () -> Unit,
    onQuickSaveAllToGallery: () -> Unit,
    onQuickShareAll: () -> Unit,
    onQuickPickDirectory: () -> Unit,
    onQuickClearQueue: () -> Unit
) {
    val tokens = LocalCdsTokens.current
    var rememberedMenu by remember { mutableStateOf(CdsLayer2Menu.PASSWORD_BOOK_PANEL) }
    if (activeMenu != CdsLayer2Menu.NONE) {
        rememberedMenu = activeMenu
    }

    val isFabMenu = rememberedMenu == CdsLayer2Menu.FAB_QUICK_HUB
    val isReaderMenu = rememberedMenu == CdsLayer2Menu.READER_CONTROL_PANEL

    val origin = when (rememberedMenu) {
        CdsLayer2Menu.PASSWORD_BOOK_PANEL -> TransformOrigin(0.24f, 0.28f)
        CdsLayer2Menu.RENAME_TEMPLATE_PANEL -> TransformOrigin(0.76f, 0.28f)
        CdsLayer2Menu.QUEUE_SORT_PANEL -> TransformOrigin(0.24f, 0.44f)
        CdsLayer2Menu.READER_PRESET_PANEL -> TransformOrigin(0.76f, 0.44f)
        CdsLayer2Menu.READER_CONTROL_PANEL -> TransformOrigin(0.86f, 0.12f)
        CdsLayer2Menu.FAB_QUICK_HUB -> TransformOrigin(0.92f, 0.90f)
        CdsLayer2Menu.NONE -> TransformOrigin(0.5f, 0.35f)
    }

    AnimatedVisibility(
        visible = activeMenu != CdsLayer2Menu.NONE,
        enter = fadeIn(animationSpec = spring(stiffness = CDS_SPRING_POPOVER_STIFFNESS)) +
            scaleIn(
                initialScale = 0.68f,
                transformOrigin = origin,
                animationSpec = spring(
                    dampingRatio = CDS_SPRING_POPOVER_DAMPING,
                    stiffness = CDS_SPRING_POPOVER_STIFFNESS
                )
            ),
        exit = fadeOut(animationSpec = spring(stiffness = CDS_SPRING_SNAPPY_STIFFNESS)) +
            scaleOut(
                targetScale = 0.68f,
                transformOrigin = origin,
                animationSpec = spring(
                    dampingRatio = CDS_SPRING_LAYOUT_DAMPING,
                    stiffness = CDS_SPRING_SNAPPY_STIFFNESS
                )
            )
    ) {
        BackHandler(onBack = onDismiss)

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = if (tokens.isDark) 0.48f else 0.24f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss
                )
                .padding(horizontal = 20.dp, vertical = if (isReaderMenu) 64.dp else 88.dp),
            contentAlignment = when {
                isFabMenu -> Alignment.BottomEnd
                isReaderMenu -> Alignment.TopEnd
                else -> Alignment.Center
            }
        ) {
            CdsSurfaceCard(
                surfaceLevel = 3,
                cornerRadius = 16.dp,
                isHighlighted = true,
                modifier = Modifier
                    .widthIn(max = if (isFabMenu) 296.dp else 460.dp)
                    .fillMaxWidth()
                    .shadow(
                        elevation = 18.dp,
                        shape = RoundedCornerShape(16.dp),
                        ambientColor = tokens.popoverGlow,
                        spotColor = tokens.popoverGlow
                    )
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {}
                    )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateContentSize(
                            animationSpec = spring(
                                dampingRatio = CDS_SPRING_LAYOUT_DAMPING,
                                stiffness = CDS_SPRING_LAYOUT_STIFFNESS
                            )
                        )
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    when (rememberedMenu) {
                        CdsLayer2Menu.PASSWORD_BOOK_PANEL -> {
                            CdsPopoverHeader("解压密码与常用密码本", "支持 ZIP · CBZ · 7Z · RAR 加密包解锁", onDismiss)
                            CdsTextField(
                                value = archivePassword,
                                onValueChange = onArchivePasswordChange,
                                label = "默认解压密码（选填）",
                                placeholder = "导入加密包时优先使用此密码自动解锁",
                                leadingIcon = Icons.Default.Password,
                                onClear = if (archivePassword.isNotEmpty()) ({ onArchivePasswordChange("") }) else null
                            )
                            CdsSavedPasswordChipsRow(
                                label = "常用解压密码",
                                currentInput = archivePassword,
                                savedItems = savedArchivePasswords,
                                onSelect = onArchivePasswordChange,
                                onSaveCurrent = onSaveCurrentArchivePassword,
                                onRemove = onRemoveArchivePassword
                            )
                        }

                        CdsLayer2Menu.RENAME_TEMPLATE_PANEL -> {
                            CdsPopoverHeader("一键存相册命名规则", "点击空白区域自动收起", onDismiss)
                            CdsSegmentedControl(
                                items = RenameTemplate.entries,
                                selectedItem = selectedRenameTemplate,
                                itemLabel = { it.shortLabel },
                                onItemSelected = onSelectRenameTemplate
                            )
                            if (selectedRenameTemplate == RenameTemplate.PREFIX_INDEX) {
                                CdsTextField(
                                    value = customRenamePrefix,
                                    onValueChange = onCustomRenamePrefixChange,
                                    label = "自定义前缀",
                                    placeholder = "例如：Archive_Page",
                                    leadingIcon = Icons.Default.DriveFileRenameOutline
                                )
                            }
                        }

                        CdsLayer2Menu.QUEUE_SORT_PANEL -> {
                            CdsPopoverHeader("解压列表排序与筛选", "同步决定阅读器画廊页码顺序", onDismiss)
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                QueueSortOrder.entries.forEach { order ->
                                    val selected = queueSortOrder == order
                                    CdsButton(
                                        text = order.label,
                                        variant = if (selected) CdsButtonVariant.PRIMARY else CdsButtonVariant.SECONDARY,
                                        size = CdsButtonSize.SM,
                                        onClick = {
                                            onSelectQueueSortOrder(order)
                                            onDismiss()
                                        }
                                    )
                                }
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { onToggleShowOnlyUnsaved(!showOnlyUnsaved) }
                                    .padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        "仅显示尚未存入相册的图片",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = tokens.headingWeight,
                                        color = tokens.textPrimary
                                    )
                                    Text(
                                        "快速筛选未导出的剩余图片",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = tokens.textMuted
                                    )
                                }
                                Switch(
                                    checked = showOnlyUnsaved,
                                    onCheckedChange = onToggleShowOnlyUnsaved,
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = tokens.clay
                                    )
                                )
                            }
                        }

                        CdsLayer2Menu.READER_PRESET_PANEL,
                        CdsLayer2Menu.READER_CONTROL_PANEL -> {
                            CdsPopoverHeader("阅读器控制面板", "支持条漫、单页、双页跨页与音量键翻页", onDismiss)
                            Text(
                                "画廊阅读排版",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = tokens.headingWeight,
                                color = tokens.textSecondary
                            )
                            CdsSegmentedControl(
                                items = ReaderLayoutMode.entries,
                                selectedItem = readerLayoutMode,
                                itemLabel = { it.label },
                                onItemSelected = onSelectReaderLayoutMode
                            )

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { onToggleReaderVolumeKeyPaging(!readerVolumeKeyPaging) }
                                    .padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        "音量上下键翻页",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = tokens.headingWeight,
                                        color = tokens.textPrimary
                                    )
                                    Text(
                                        "音量下键下一页 · 音量上键上一页",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = tokens.textMuted
                                    )
                                }
                                Switch(
                                    checked = readerVolumeKeyPaging,
                                    onCheckedChange = onToggleReaderVolumeKeyPaging,
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = tokens.clay
                                    )
                                )
                            }

                            CdsTextField(
                                value = archivePassword,
                                onValueChange = onArchivePasswordChange,
                                label = "加密压缩包解锁密码",
                                placeholder = "若压缩包有密码请在此输入",
                                leadingIcon = Icons.Default.Password,
                                onClear = if (archivePassword.isNotEmpty()) ({ onArchivePasswordChange("") }) else null
                            )
                            CdsSavedPasswordChipsRow(
                                label = "常用解压密码",
                                currentInput = archivePassword,
                                savedItems = savedArchivePasswords,
                                onSelect = onArchivePasswordChange,
                                onSaveCurrent = onSaveCurrentArchivePassword,
                                onRemove = onRemoveArchivePassword
                            )

                            if (hasExtractedImages) {
                                HorizontalDivider(thickness = 0.6.dp, color = tokens.hairlineBorder)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    CdsButton(
                                        text = "一键分享全部",
                                        icon = Icons.Default.Share,
                                        variant = CdsButtonVariant.SECONDARY,
                                        size = CdsButtonSize.MD,
                                        modifier = Modifier.weight(1f),
                                        onClick = onQuickShareAll
                                    )
                                    CdsButton(
                                        text = "一键存相册",
                                        icon = Icons.Default.Download,
                                        variant = CdsButtonVariant.PRIMARY,
                                        size = CdsButtonSize.MD,
                                        modifier = Modifier.weight(1f),
                                        onClick = onQuickSaveAllToGallery
                                    )
                                }
                            }
                        }

                        CdsLayer2Menu.FAB_QUICK_HUB -> {
                            CdsPopoverHeader("快捷指令中心", "点击空白区域缩回按钮", onDismiss)
                            CdsMenuActionRow(
                                icon = Icons.Default.FolderZip,
                                title = "导入压缩包解压 (支持密码)",
                                onClick = onQuickImportArchive
                            )
                            CdsMenuActionRow(
                                icon = Icons.Default.AutoStories,
                                title = if (hasExtractedImages) "切换到阅读器看图" else "选择压缩包直接阅读",
                                onClick = onQuickOpenArchiveInReader
                            )
                            if (hasExtractedImages) {
                                CdsMenuActionRow(
                                    icon = Icons.Default.Download,
                                    title = "一键保存全部到相册",
                                    onClick = onQuickSaveAllToGallery
                                )
                                CdsMenuActionRow(
                                    icon = Icons.Default.Share,
                                    title = "一键分享全部图片",
                                    onClick = onQuickShareAll
                                )
                            }
                            CdsMenuActionRow(
                                icon = Icons.Outlined.FolderOpen,
                                title = "更改存相册目录",
                                onClick = onQuickPickDirectory
                            )
                            if (hasExtractedImages) {
                                CdsMenuActionRow(
                                    icon = Icons.Outlined.DeleteSweep,
                                    title = "清空当前解压列表",
                                    isDanger = true,
                                    onClick = onQuickClearQueue
                                )
                            }
                        }

                        CdsLayer2Menu.NONE -> Unit
                    }
                }
            }
        }
    }
}

@Composable
private fun CdsPopoverHeader(
    title: String,
    subtitle: String,
    onClose: () -> Unit
) {
    val tokens = LocalCdsTokens.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontFamily = FontFamily.Serif,
                fontWeight = tokens.headingWeight,
                color = tokens.textPrimary
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = tokens.clay
            )
        }
        IconButton(onClick = onClose, modifier = Modifier.size(30.dp)) {
            Icon(
                Icons.Default.Close,
                contentDescription = "收起",
                tint = tokens.textMuted,
                modifier = Modifier.size(17.dp)
            )
        }
    }
}

@Composable
private fun CdsTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String,
    leadingIcon: ImageVector,
    onClear: (() -> Unit)? = null
) {
    val tokens = LocalCdsTokens.current
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        placeholder = { Text(placeholder) },
        leadingIcon = { Icon(leadingIcon, contentDescription = null, tint = tokens.clay) },
        trailingIcon = if (onClear != null) {
            {
                IconButton(onClick = onClear) {
                    Icon(Icons.Default.Clear, contentDescription = "清除", tint = tokens.textMuted)
                }
            }
        } else null,
        singleLine = true,
        shape = RoundedCornerShape(10.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = tokens.clay,
            unfocusedBorderColor = tokens.hairlineBorder,
            focusedContainerColor = tokens.surface2,
            unfocusedContainerColor = tokens.surface2,
            cursorColor = tokens.clay,
            focusedLabelColor = tokens.clay
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun CdsMenuActionRow(
    icon: ImageVector,
    title: String,
    isDanger: Boolean = false,
    onClick: () -> Unit
) {
    val tokens = LocalCdsTokens.current
    val tintColor = if (isDanger) tokens.danger else tokens.clay
    val textColor = if (isDanger) tokens.danger else tokens.textPrimary

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .cdsTactileScale(
                activeScale = 0.97f,
                shape = RoundedCornerShape(10.dp),
                onClick = onClick
            )
            .background(tokens.surface2)
            .border(0.5.dp, tokens.hairlineBorder, RoundedCornerShape(10.dp))
            .padding(horizontal = 13.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = tintColor,
            modifier = Modifier.size(18.dp)
        )
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = tokens.bodyStrongWeight,
            color = textColor
        )
    }
}

/**
 * 常用密码本行内胶囊组件 (`CdsSavedPasswordChipsRow`)
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CdsSavedPasswordChipsRow(
    label: String,
    currentInput: String,
    savedItems: List<String>,
    onSelect: (String) -> Unit,
    onSaveCurrent: (() -> Unit)? = null,
    onRemove: (String) -> Unit
) {
    val tokens = LocalCdsTokens.current
    if (savedItems.isEmpty() && (onSaveCurrent == null || currentInput.isBlank())) return

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "$label (点选一键填入)",
                style = MaterialTheme.typography.labelSmall,
                color = tokens.textMuted
            )
            if (onSaveCurrent != null && currentInput.isNotBlank() && currentInput.trim() !in savedItems) {
                CdsButton(
                    text = "存入常用",
                    icon = Icons.Default.BookmarkAdd,
                    variant = CdsButtonVariant.OUTLINE,
                    size = CdsButtonSize.XS,
                    onClick = onSaveCurrent
                )
            }
        }

        if (savedItems.isNotEmpty()) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                savedItems.forEach { secret ->
                    val isSelected = secret == currentInput
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) tokens.claySoftBg else tokens.surface1,
                        border = BorderStroke(
                            0.6.dp,
                            if (isSelected) tokens.clayBorder else tokens.hairlineBorder
                        ),
                        modifier = Modifier.cdsTactileScale(
                            activeScale = 0.95f,
                            shape = RoundedCornerShape(8.dp),
                            onClick = { onSelect(secret) }
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(start = 10.dp, end = 6.dp, top = 5.dp, bottom = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Text(
                                text = secret,
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) tokens.clay else tokens.textPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "删除此条密码",
                                tint = tokens.textMuted,
                                modifier = Modifier
                                    .size(13.dp)
                                    .clip(CircleShape)
                                    .clickable { onRemove(secret) }
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Open Claude UI 5.2 多模态媒体画廊阅读器视图 (`CdsArchiveImageReaderView`)：
 * - 集成 7 档非线性渐隐滚动遮罩 (7-Stop Non-Linear Fade Mask)
 * - 集成以触点为物理不动点的仿射 Pan/Zoom 方程 + 4px 移动死区 + 0.7 边界阻尼
 * - 支持条漫连读 / 单页翻页 / 双页左→右 / 日漫右→左、音量上下键翻页、自动页码书签与单页存相册/分享
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CdsArchiveImageReaderView(
    images: List<SelectedImageItem>,
    readerLayoutMode: ReaderLayoutMode,
    isImmersive: Boolean,
    archiveBanner: String?,
    hasArchivePassword: Boolean,
    isExtracting: Boolean,
    extractDoneCount: Int,
    extractTotalCount: Int,
    extractCurrentFile: String,
    volumePageStepSignal: Int = 0,
    volumePageDirection: Int = 0,
    onCancelExtract: () -> Unit,
    onToggleImmersive: () -> Unit,
    onToggleLayoutMode: () -> Unit,
    onOpenReaderLayer2Menu: () -> Unit,
    onPickArchiveToRead: () -> Unit,
    onPickImagesToRead: () -> Unit,
    onSaveSingleImage: (SelectedImageItem) -> Unit,
    onShareSingleImage: (SelectedImageItem) -> Unit
) {
    val context = LocalContext.current
    val tokens = LocalCdsTokens.current
    val extractProgressTarget = if (extractTotalCount > 0) {
        (extractDoneCount.toFloat() / extractTotalCount.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }
    val animatedExtractProgress by animateFloatAsState(
        targetValue = extractProgressTarget,
        animationSpec = spring(
            dampingRatio = CDS_SPRING_LAYOUT_DAMPING,
            stiffness = CDS_SPRING_LAYOUT_STIFFNESS
        ),
        label = "ReaderExtractProgress"
    )

    if (images.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            CdsSurfaceCard(
                surfaceLevel = 2,
                cornerRadius = 20.dp,
                isHighlighted = isExtracting,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = tokens.claySoftBg,
                        border = BorderStroke(0.6.dp, tokens.clayBorder),
                        modifier = Modifier.size(56.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (isExtracting) Icons.Default.Unarchive else Icons.Default.AutoStories,
                                contentDescription = null,
                                tint = tokens.clay,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }
                    Text(
                        text = if (isExtracting) "正在解压归档流..." else "归档画廊阅读器",
                        style = MaterialTheme.typography.titleLarge,
                        fontFamily = FontFamily.Serif,
                        fontWeight = tokens.headingWeight,
                        color = tokens.textPrimary
                    )
                    if (isExtracting) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    CdsStatusBreathingDot(isActive = true, isPulsing = true)
                                    Text(
                                        text = when {
                                            extractTotalCount > 0 -> "已解压 $extractDoneCount / $extractTotalCount 张"
                                            extractDoneCount > 0 -> "已解压 $extractDoneCount 张"
                                            else -> "正在扫描归档索引..."
                                        },
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = tokens.headingWeight,
                                        color = tokens.clay
                                    )
                                }
                                if (extractTotalCount > 0) {
                                    Text(
                                        text = "${(animatedExtractProgress * 100).roundToInt()}%",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = tokens.clay
                                    )
                                }
                            }
                            if (extractTotalCount > 0) {
                                LinearProgressIndicator(
                                    progress = { animatedExtractProgress },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(3.dp)),
                                    color = tokens.clay,
                                    trackColor = tokens.surface1
                                )
                            } else {
                                LinearProgressIndicator(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(3.dp)),
                                    color = tokens.clay,
                                    trackColor = tokens.surface1
                                )
                            }
                            if (extractCurrentFile.isNotBlank()) {
                                Text(
                                    text = extractCurrentFile,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = FontFamily.Monospace,
                                    color = tokens.textMuted,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            CdsButton(
                                text = "取消解压",
                                icon = Icons.Default.Close,
                                variant = CdsButtonVariant.DANGER,
                                size = CdsButtonSize.SM,
                                modifier = Modifier.align(Alignment.CenterHorizontally),
                                onClick = onCancelExtract
                            )
                        }
                    } else {
                        Text(
                            text = "直接阅读 .zip · .cbz · .7z · .rar · .tar.gz 内置图片，支持常用密码本、触点仿射缩放与单页直存相册",
                            style = MaterialTheme.typography.bodySmall,
                            color = tokens.textSecondary,
                            textAlign = TextAlign.Center
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            CdsButton(
                                text = "打开压缩包",
                                icon = Icons.Default.FolderZip,
                                variant = CdsButtonVariant.PRIMARY,
                                size = CdsButtonSize.MD,
                                onClick = onPickArchiveToRead
                            )
                            CdsButton(
                                text = "选择图片",
                                icon = Icons.Default.AddPhotoAlternate,
                                variant = CdsButtonVariant.SECONDARY,
                                size = CdsButtonSize.MD,
                                onClick = onPickImagesToRead
                            )
                        }
                    }
                }
            }
        }
        return
    }

    val listState = rememberLazyListState()
    val readerPagerState = rememberPagerState(
        initialPage = 0,
        pageCount = { images.size }
    )
    val doubleSpreadPairs = remember(images) { images.chunked(2) }
    val spreadPagerState = rememberPagerState(
        initialPage = 0,
        pageCount = { doubleSpreadPairs.size.coerceAtLeast(1) }
    )
    val coroutineScope = rememberCoroutineScope()

    val archiveBookmarkKey = remember(archiveBanner, images.firstOrNull()?.uri) {
        archiveBanner?.substringBefore(" · ")?.trim()?.takeIf { it.isNotBlank() }
            ?: images.firstOrNull()?.fromArchiveName
            ?: images.firstOrNull()?.displayName
            ?: ""
    }

    val currentPageIndex = when (readerLayoutMode) {
        ReaderLayoutMode.VERTICAL_STRIP ->
            listState.firstVisibleItemIndex.coerceIn(0, (images.size - 1).coerceAtLeast(0))
        ReaderLayoutMode.HORIZONTAL_PAGER ->
            readerPagerState.currentPage.coerceIn(0, (images.size - 1).coerceAtLeast(0))
        ReaderLayoutMode.DOUBLE_PAGE_LTR, ReaderLayoutMode.DOUBLE_PAGE_RTL ->
            (spreadPagerState.currentPage * 2).coerceIn(0, (images.size - 1).coerceAtLeast(0))
    }

    // 响应手机音量上下键翻页
    LaunchedEffect(volumePageStepSignal) {
        if (volumePageStepSignal > 0 && volumePageDirection != 0 && images.isNotEmpty()) {
            when (readerLayoutMode) {
                ReaderLayoutMode.VERTICAL_STRIP -> {
                    val target = (listState.firstVisibleItemIndex + volumePageDirection)
                        .coerceIn(0, images.size - 1)
                    listState.animateScrollToItem(target)
                }
                ReaderLayoutMode.HORIZONTAL_PAGER -> {
                    val target = (readerPagerState.currentPage + volumePageDirection)
                        .coerceIn(0, images.size - 1)
                    readerPagerState.animateScrollToPage(
                        page = target,
                        animationSpec = spring(
                            dampingRatio = CDS_SPRING_LAYOUT_DAMPING,
                            stiffness = CDS_SPRING_LAYOUT_STIFFNESS
                        )
                    )
                }
                ReaderLayoutMode.DOUBLE_PAGE_LTR, ReaderLayoutMode.DOUBLE_PAGE_RTL -> {
                    val targetSpread = (spreadPagerState.currentPage + volumePageDirection)
                        .coerceIn(0, (doubleSpreadPairs.size - 1).coerceAtLeast(0))
                    spreadPagerState.animateScrollToPage(
                        page = targetSpread,
                        animationSpec = spring(
                            dampingRatio = CDS_SPRING_LAYOUT_DAMPING,
                            stiffness = CDS_SPRING_LAYOUT_STIFFNESS
                        )
                    )
                }
            }
        }
    }

    // 打开压缩包时自动恢复到上次阅读页码
    var hasRestoredBookmarkForKey by remember(archiveBookmarkKey, images.size) { mutableStateOf(false) }
    LaunchedEffect(archiveBookmarkKey, images.size) {
        if (!hasRestoredBookmarkForKey && archiveBookmarkKey.isNotBlank() && images.size > 1) {
            hasRestoredBookmarkForKey = true
            val savedPage = ImageCompressor.getReaderBookmark(context, archiveBookmarkKey)
            if (savedPage in 1 until images.size) {
                listState.scrollToItem(savedPage)
                readerPagerState.scrollToPage(savedPage)
                spreadPagerState.scrollToPage((savedPage / 2).coerceIn(0, (doubleSpreadPairs.size - 1).coerceAtLeast(0)))
                Toast.makeText(
                    context,
                    "已恢复至上次阅读位置：第 ${savedPage + 1} / ${images.size} 页",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    // 翻页/滑动时自动保存当前阅读页码书签
    LaunchedEffect(currentPageIndex, archiveBookmarkKey) {
        if (hasRestoredBookmarkForKey && archiveBookmarkKey.isNotBlank() && images.size > 1) {
            ImageCompressor.saveReaderBookmark(context, archiveBookmarkKey, currentPageIndex)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        when (readerLayoutMode) {
            ReaderLayoutMode.VERTICAL_STRIP -> {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .cdsSevenStopScrollFadeMask(
                            showTopFade = !isImmersive && listState.canScrollBackward,
                            showBottomFade = !isImmersive && listState.canScrollForward,
                            fadeHeightDp = 28.dp
                        ),
                    contentPadding = PaddingValues(
                        top = if (isImmersive) 0.dp else 64.dp,
                        bottom = if (isImmersive) 64.dp else 148.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    itemsIndexed(
                        items = images,
                        key = { _, item -> item.uri.toString() }
                    ) { idx, item ->
                        CdsReaderZoomablePageItem(
                            uri = item.uri,
                            pageLabel = "${idx + 1} / ${images.size} · ${item.displayName}",
                            isVerticalMode = true,
                            onTapPage = onToggleImmersive,
                            onSavePage = { onSaveSingleImage(item) },
                            onSharePage = { onShareSingleImage(item) }
                        )
                    }
                }
            }

            ReaderLayoutMode.HORIZONTAL_PAGER -> {
                HorizontalPager(
                    state = readerPagerState,
                    beyondBoundsPageCount = 1,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(
                            top = if (isImmersive) 0.dp else 58.dp,
                            bottom = if (isImmersive) 0.dp else 90.dp
                        )
                ) { idx ->
                    val item = images[idx]
                    CdsReaderZoomablePageItem(
                        uri = item.uri,
                        pageLabel = "${idx + 1} / ${images.size} · ${item.displayName}",
                        isVerticalMode = false,
                        onTapPage = onToggleImmersive,
                        onSavePage = { onSaveSingleImage(item) },
                        onSharePage = { onShareSingleImage(item) }
                    )
                }
            }

            ReaderLayoutMode.DOUBLE_PAGE_LTR, ReaderLayoutMode.DOUBLE_PAGE_RTL -> {
                val isRtlManga = readerLayoutMode == ReaderLayoutMode.DOUBLE_PAGE_RTL
                HorizontalPager(
                    state = spreadPagerState,
                    beyondBoundsPageCount = 1,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(
                            top = if (isImmersive) 0.dp else 58.dp,
                            bottom = if (isImmersive) 0.dp else 90.dp
                        )
                ) { spreadIdx ->
                    val pair = doubleSpreadPairs.getOrNull(spreadIdx) ?: emptyList()
                    val orderedPair = if (isRtlManga && pair.size == 2) {
                        listOf(pair[1], pair[0])
                    } else {
                        pair
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        orderedPair.forEach { item ->
                            val realPageIdx = images.indexOf(item).coerceAtLeast(0)
                            Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                                CdsReaderZoomablePageItem(
                                    uri = item.uri,
                                    pageLabel = "P.${realPageIdx + 1}",
                                    isVerticalMode = false,
                                    onTapPage = onToggleImmersive,
                                    onSavePage = { onSaveSingleImage(item) },
                                    onSharePage = { onShareSingleImage(item) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // 顶部 CDS Surface 3 悬浮阅读控制条
        CdsSurfaceCard(
            surfaceLevel = 3,
            cornerRadius = 14.dp,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp)
                .shadow(
                    elevation = 8.dp,
                    shape = RoundedCornerShape(14.dp),
                    ambientColor = Color.Black.copy(alpha = 0.12f)
                )
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = tokens.claySoftBg,
                            border = BorderStroke(0.5.dp, tokens.clayBorder)
                        ) {
                            Text(
                                text = "${currentPageIndex + 1} / ${images.size}",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = tokens.clay,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                            )
                        }
                        Text(
                            text = archiveBanner ?: images[currentPageIndex].displayName,
                            style = MaterialTheme.typography.labelMedium,
                            color = tokens.textPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        CdsButton(
                            text = readerLayoutMode.label,
                            variant = CdsButtonVariant.SECONDARY,
                            size = CdsButtonSize.XS,
                            onClick = onToggleLayoutMode
                        )

                        IconButton(onClick = onPickArchiveToRead, modifier = Modifier.size(30.dp)) {
                            Icon(
                                imageVector = Icons.Default.FolderZip,
                                contentDescription = "打开其他压缩包",
                                tint = tokens.clay,
                                modifier = Modifier.size(17.dp)
                            )
                        }

                        IconButton(onClick = onOpenReaderLayer2Menu, modifier = Modifier.size(30.dp)) {
                            Icon(
                                imageVector = if (hasArchivePassword) Icons.Default.Key else Icons.Default.Tune,
                                contentDescription = "阅读设置与常用密码",
                                tint = tokens.clay,
                                modifier = Modifier.size(17.dp)
                            )
                        }

                        IconButton(onClick = onToggleImmersive, modifier = Modifier.size(30.dp)) {
                            Icon(
                                imageVector = if (isImmersive) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                                contentDescription = "全屏阅读",
                                tint = tokens.textSecondary,
                                modifier = Modifier.size(17.dp)
                            )
                        }
                    }
                }

                AnimatedVisibility(visible = isExtracting) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 12.dp, end = 12.dp, bottom = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = when {
                                    extractTotalCount > 0 -> "正在解压 ($extractDoneCount/$extractTotalCount) · $extractCurrentFile"
                                    extractDoneCount > 0 -> "正在解压 ($extractDoneCount 张) · $extractCurrentFile"
                                    else -> "正在解析压缩包条目..."
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = tokens.clay,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            if (extractTotalCount > 0) {
                                Text(
                                    text = "${(animatedExtractProgress * 100).roundToInt()}%",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = tokens.clay
                                )
                            }
                        }
                        if (extractTotalCount > 0) {
                            LinearProgressIndicator(
                                progress = { animatedExtractProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(5.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = tokens.clay,
                                trackColor = tokens.surface1
                            )
                        } else {
                            LinearProgressIndicator(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(5.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = tokens.clay,
                                trackColor = tokens.surface1
                            )
                        }
                    }
                }
            }
        }

        if (isImmersive && images.size > 1) {
            CdsSurfaceCard(
                surfaceLevel = 3,
                cornerRadius = 14.dp,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        "${currentPageIndex + 1}",
                        style = MaterialTheme.typography.labelMedium,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = tokens.clay
                    )
                    Slider(
                        value = currentPageIndex.toFloat(),
                        onValueChange = { target ->
                            val targetIdx = target.roundToInt().coerceIn(0, images.size - 1)
                            coroutineScope.launch {
                                when (readerLayoutMode) {
                                    ReaderLayoutMode.VERTICAL_STRIP -> listState.scrollToItem(targetIdx)
                                    ReaderLayoutMode.HORIZONTAL_PAGER -> readerPagerState.scrollToPage(targetIdx)
                                    ReaderLayoutMode.DOUBLE_PAGE_LTR, ReaderLayoutMode.DOUBLE_PAGE_RTL ->
                                        spreadPagerState.scrollToPage((targetIdx / 2).coerceIn(0, (doubleSpreadPairs.size - 1).coerceAtLeast(0)))
                                }
                            }
                        },
                        valueRange = 0f..(images.size - 1).toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = tokens.clay,
                            activeTrackColor = tokens.clay,
                            inactiveTrackColor = tokens.surface1
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        "${images.size}",
                        style = MaterialTheme.typography.labelMedium,
                        fontFamily = FontFamily.Monospace,
                        color = tokens.textMuted
                    )
                }
            }
        }
    }
}

/**
 * Open Claude UI 核心算法 5：以触点/光标为物理不动点的仿射 Pan/Zoom 方程
 * idealTx = Ox - (Ox - prevTx) * (Starget / Scurrent)
 * 配合 4px 手部微抖死区与视口边界溢出阻尼系数 (0.7)
 */
@Composable
private fun CdsReaderZoomablePageItem(
    uri: Uri,
    pageLabel: String,
    isVerticalMode: Boolean,
    onTapPage: () -> Unit,
    onSavePage: () -> Unit,
    onSharePage: () -> Unit
) {
    val tokens = LocalCdsTokens.current
    var scale by remember(uri) { mutableFloatStateOf(1f) }
    var offsetX by remember(uri) { mutableFloatStateOf(0f) }
    var offsetY by remember(uri) { mutableFloatStateOf(0f) }
    var boxWidthPx by remember { mutableIntStateOf(0) }
    var boxHeightPx by remember { mutableIntStateOf(0) }

    val animatedScale by animateFloatAsState(
        targetValue = scale,
        animationSpec = spring(
            dampingRatio = CDS_SPRING_POPOVER_DAMPING,
            stiffness = CDS_SPRING_POPOVER_STIFFNESS
        ),
        label = "CdsReaderPageZoom"
    )
    val animatedOffsetX by animateFloatAsState(
        targetValue = offsetX,
        animationSpec = spring(
            dampingRatio = CDS_SPRING_LAYOUT_DAMPING,
            stiffness = CDS_SPRING_LAYOUT_STIFFNESS
        ),
        label = "CdsReaderPagePanX"
    )
    val animatedOffsetY by animateFloatAsState(
        targetValue = offsetY,
        animationSpec = spring(
            dampingRatio = CDS_SPRING_LAYOUT_DAMPING,
            stiffness = CDS_SPRING_LAYOUT_STIFFNESS
        ),
        label = "CdsReaderPagePanY"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (isVerticalMode) Modifier else Modifier.fillMaxHeight())
            .clip(RoundedCornerShape(if (isVerticalMode) 8.dp else 12.dp))
            .background(tokens.surface1)
            .border(
                0.5.dp,
                tokens.hairlineBorder,
                RoundedCornerShape(if (isVerticalMode) 8.dp else 12.dp)
            )
            .onSizeChanged {
                boxWidthPx = it.width
                boxHeightPx = it.height
            }
            .pointerInput(uri, boxWidthPx, boxHeightPx) {
                detectTapGestures(
                    onDoubleTap = { tapOffset ->
                        if (scale > 1.05f) {
                            scale = 1f
                            offsetX = 0f
                            offsetY = 0f
                        } else {
                            // 仿射不动点放大：将双击触点 (Ox, Oy) 作为物理世界不动点
                            val targetZoom = 2.35f
                            val ratio = targetZoom / scale.coerceAtLeast(1f)
                            val ox = tapOffset.x - (boxWidthPx / 2f)
                            val oy = tapOffset.y - (boxHeightPx / 2f)
                            val idealTx = ox - (ox - offsetX) * ratio
                            val idealTy = oy - (oy - offsetY) * ratio
                            val maxDx = (boxWidthPx * (targetZoom - 1f)) / 2f
                            val maxDy = (boxHeightPx * (targetZoom - 1f)) / 2f
                            scale = targetZoom
                            offsetX = idealTx.coerceIn(-maxDx, maxDx)
                            offsetY = idealTy.coerceIn(-maxDy, maxDy)
                        }
                    },
                    onTap = { onTapPage() }
                )
            }
            .then(
                if (!isVerticalMode || scale > 1.01f) {
                    Modifier.pointerInput(uri, boxWidthPx, boxHeightPx) {
                        detectTransformGestures { centroid, pan, zoom, _ ->
                            // 4px 指针移动死区过滤手部微抖
                            val effectivePan = if (hypot(pan.x, pan.y) < 4f && abs(zoom - 1f) < 0.01f) {
                                Offset.Zero
                            } else {
                                pan
                            }
                            val prevScale = scale
                            val newScale = (prevScale * zoom).coerceIn(1f, 3.6f)
                            val scaleRatio = newScale / prevScale.coerceAtLeast(1f)

                            if (newScale > 1.02f) {
                                val ox = centroid.x - (boxWidthPx / 2f)
                                val oy = centroid.y - (boxHeightPx / 2f)
                                val rawTx = ox - (ox - offsetX) * scaleRatio + effectivePan.x
                                val rawTy = oy - (oy - offsetY) * scaleRatio + effectivePan.y
                                val maxDx = if (boxWidthPx > 0) (boxWidthPx * (newScale - 1f)) / 2f else 1200f
                                val maxDy = if (boxHeightPx > 0) (boxHeightPx * (newScale - 1f)) / 2f else 1600f
                                // 0.7 视口边界溢出阻尼
                                offsetX = if (rawTx in -maxDx..maxDx) rawTx else rawTx.coerceIn(-maxDx, maxDx) * 0.7f + rawTx * 0.3f
                                offsetY = if (rawTy in -maxDy..maxDy) rawTy else rawTy.coerceIn(-maxDy, maxDy) * 0.7f + rawTy * 0.3f
                                offsetX = offsetX.coerceIn(-maxDx * 1.15f, maxDx * 1.15f)
                                offsetY = offsetY.coerceIn(-maxDy * 1.15f, maxDy * 1.15f)
                                scale = newScale
                            } else {
                                scale = 1f
                                offsetX = 0f
                                offsetY = 0f
                            }
                        }
                    }
                } else {
                    Modifier
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = uri,
            contentDescription = pageLabel,
            contentScale = if (isVerticalMode) ContentScale.FillWidth else ContentScale.Fit,
            modifier = Modifier
                .fillMaxWidth()
                .graphicsLayer {
                    scaleX = animatedScale
                    scaleY = animatedScale
                    translationX = animatedOffsetX
                    translationY = animatedOffsetY
                }
        )

        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = Color(0xCC141413),
                border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.14f))
            ) {
                Text(
                    text = pageLabel,
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    color = Color(0xFFF0EFEA),
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xCC141413),
                border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.16f)),
                modifier = Modifier
                    .size(28.dp)
                    .clickable { onSavePage() }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = "一键存相册",
                        tint = ClayBrand,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xCC141413),
                border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.16f)),
                modifier = Modifier
                    .size(28.dp)
                    .clickable { onSharePage() }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "一键分享此页",
                        tint = Color(0xFFF0EFEA),
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

/**
 * CDS 2.4 模态确认对话框：16dp 圆角、双环 Popover 投影、加密压缩包密码解锁弹窗
 */
@Composable
private fun CdsArchivePasswordDialog(
    archiveNames: String,
    passwordInput: String,
    errorText: String?,
    savedPasswords: List<String> = emptyList(),
    onRemoveSavedPassword: (String) -> Unit = {},
    onPasswordChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onConfirmUnlock: () -> Unit
) {
    val tokens = LocalCdsTokens.current
    var passwordVisible by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = if (tokens.isDark) 0.56f else 0.32f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismiss
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        CdsSurfaceCard(
            surfaceLevel = 3,
            cornerRadius = 16.dp,
            isHighlighted = true,
            modifier = Modifier
                .widthIn(max = 420.dp)
                .fillMaxWidth()
                .shadow(
                    elevation = 20.dp,
                    shape = RoundedCornerShape(16.dp),
                    ambientColor = tokens.popoverGlow,
                    spotColor = tokens.popoverGlow
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {}
                )
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = tokens.claySoftBg,
                        border = BorderStroke(0.6.dp, tokens.clayBorder),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = tokens.clay,
                                modifier = Modifier.size(19.dp)
                            )
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "归档受密码保护",
                            style = MaterialTheme.typography.titleMedium,
                            fontFamily = FontFamily.Serif,
                            fontWeight = tokens.headingWeight,
                            color = tokens.textPrimary
                        )
                        Text(
                            text = archiveNames,
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = tokens.textMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                OutlinedTextField(
                    value = passwordInput,
                    onValueChange = onPasswordChange,
                    label = { Text("输入压缩包密码") },
                    singleLine = true,
                    isError = errorText != null,
                    visualTransformation = if (passwordVisible) {
                        VisualTransformation.None
                    } else {
                        PasswordVisualTransformation()
                    },
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = "切换密码可见",
                                tint = tokens.textMuted
                            )
                        }
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = tokens.clay,
                        unfocusedBorderColor = tokens.hairlineBorder,
                        focusedContainerColor = tokens.surface2,
                        unfocusedContainerColor = tokens.surface2,
                        cursorColor = tokens.clay
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                if (savedPasswords.isNotEmpty()) {
                    CdsSavedPasswordChipsRow(
                        label = "常用解锁密码",
                        currentInput = passwordInput,
                        savedItems = savedPasswords,
                        onSelect = onPasswordChange,
                        onSaveCurrent = null,
                        onRemove = onRemoveSavedPassword
                    )
                }

                if (errorText != null) {
                    Text(
                        text = errorText,
                        style = MaterialTheme.typography.labelSmall,
                        color = tokens.danger
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    CdsButton(
                        text = "取消",
                        variant = CdsButtonVariant.SECONDARY,
                        size = CdsButtonSize.MD,
                        modifier = Modifier.weight(1f),
                        onClick = onDismiss
                    )
                    CdsButton(
                        text = "解锁并提取",
                        variant = CdsButtonVariant.PRIMARY,
                        size = CdsButtonSize.MD,
                        modifier = Modifier.weight(1f),
                        onClick = onConfirmUnlock
                    )
                }
            }
        }
    }
}

/**
 * 右下角 Open Claude UI 双层操作栏：
 * 左侧为 `+` 快捷指令触发钮，中间为「一键分享」，右侧为陶土橙主按钮「导入压缩包」/「一键存相册」
 */
@OptIn(ExperimentalAnimationApi::class)
@Composable
private fun CdsFloatingActionBar(
    selectedCount: Int,
    isBusy: Boolean,
    isExtracting: Boolean,
    completedCount: Int,
    totalTaskCount: Int,
    isQuickHubExpanded: Boolean,
    onToggleQuickHub: () -> Unit,
    onPickArchives: () -> Unit,
    onSaveAllToGallery: () -> Unit,
    onShareAll: () -> Unit,
    onCancelClick: () -> Unit
) {
    val tokens = LocalCdsTokens.current

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        val hubRotation by animateFloatAsState(
            targetValue = if (isQuickHubExpanded) 45f else 0f,
            animationSpec = spring(
                dampingRatio = CDS_SPRING_POPOVER_DAMPING,
                stiffness = CDS_SPRING_POPOVER_STIFFNESS
            ),
            label = "CdsQuickHubRotate"
        )
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = if (isQuickHubExpanded) tokens.claySoftBg else tokens.surface3,
            border = BorderStroke(
                width = if (isQuickHubExpanded) 1.dp else 0.6.dp,
                color = if (isQuickHubExpanded) tokens.clayBorder else tokens.hairlineBorder
            ),
            modifier = Modifier
                .size(44.dp)
                .shadow(
                    elevation = 8.dp,
                    shape = RoundedCornerShape(12.dp),
                    ambientColor = Color.Black.copy(alpha = 0.14f)
                )
                .cdsTactileScale(
                    enabled = true,
                    activeScale = 0.94f,
                    shape = RoundedCornerShape(12.dp),
                    onClick = onToggleQuickHub
                )
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "展开快捷指令中心",
                    tint = tokens.clay,
                    modifier = Modifier
                        .size(20.dp)
                        .graphicsLayer { rotationZ = hubRotation }
                )
            }
        }

        AnimatedVisibility(visible = selectedCount > 0 && !isBusy) {
            CdsButton(
                text = "一键分享",
                icon = Icons.Default.Share,
                variant = CdsButtonVariant.SECONDARY,
                size = CdsButtonSize.LG,
                onClick = onShareAll,
                modifier = Modifier.shadow(
                    elevation = 6.dp,
                    shape = RoundedCornerShape(12.dp),
                    ambientColor = Color.Black.copy(alpha = 0.12f)
                )
            )
        }

        val mainBgColor by animateColorAsState(
            targetValue = if (isBusy) tokens.surface3 else tokens.clay,
            animationSpec = spring(
                dampingRatio = CDS_SPRING_LAYOUT_DAMPING,
                stiffness = CDS_SPRING_LAYOUT_STIFFNESS
            ),
            label = "CdsMainFabColor"
        )
        val mainContentColor = if (isBusy) tokens.danger else Color.White

        Surface(
            shape = RoundedCornerShape(12.dp),
            color = mainBgColor,
            border = BorderStroke(
                0.6.dp,
                if (isBusy) tokens.danger.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.22f)
            ),
            modifier = Modifier
                .height(46.dp)
                .shadow(
                    elevation = 10.dp,
                    shape = RoundedCornerShape(12.dp),
                    ambientColor = tokens.popoverGlow,
                    spotColor = tokens.popoverGlow
                )
                .cdsTactileScale(
                    enabled = true,
                    activeScale = 0.96f,
                    shape = RoundedCornerShape(12.dp),
                    onClick = {
                        when {
                            isBusy -> onCancelClick()
                            selectedCount == 0 -> onPickArchives()
                            else -> onSaveAllToGallery()
                        }
                    }
                )
        ) {
            AnimatedContent(
                targetState = Triple(selectedCount, isBusy, isExtracting),
                transitionSpec = {
                    (scaleIn(
                        initialScale = 0.90f,
                        animationSpec = spring(
                            dampingRatio = CDS_SPRING_POPOVER_DAMPING,
                            stiffness = CDS_SPRING_POPOVER_STIFFNESS
                        )
                    ) + fadeIn()).togetherWith(
                        scaleOut(targetScale = 0.90f) + fadeOut()
                    )
                },
                label = "CdsMainFabMorph"
            ) { (count, busy, extracting) ->
                Row(
                    modifier = Modifier.padding(horizontal = 18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val icon = when {
                        busy -> Icons.Default.Close
                        count == 0 -> Icons.Default.FolderZip
                        else -> Icons.Default.Download
                    }
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = mainContentColor,
                        modifier = Modifier.size(18.dp)
                    )

                    val text = when {
                        busy && extracting ->
                            if (totalTaskCount > 0) "解压 $completedCount/$totalTaskCount · 取消" else "解压中 · 取消"
                        busy ->
                            if (totalTaskCount > 0) "存相册 $completedCount/$totalTaskCount · 取消" else "保存中 · 取消"
                        count == 0 -> "导入压缩包"
                        else -> "一键存相册 ($count)"
                    }

                    Text(
                        text = text,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = mainContentColor
                    )
                }
            }
        }
    }
}

/**
 * CDS 2.2 分段滑动选择胶囊底栏 (`CdsBottomSegmentedDockBar`)：
 * 严格遵循 Open Claude UI 规范：999px (CircleShape) 全圆角轨道 + 3dp 几何内边距 + Surface 3 抬升滑块 + 0.5dp 发丝细边
 */
@Composable
private fun CdsBottomSegmentedDockBar(
    continuousPagePositionProvider: () -> Float,
    onSelectMode: (ProcessMode) -> Unit
) {
    val tokens = LocalCdsTokens.current
    val tabCount = ProcessMode.entries.size
    val continuousPagePosition = continuousPagePositionProvider()
    var barWidthPx by remember { mutableIntStateOf(0) }
    var isDraggingBar by remember { mutableStateOf(false) }
    var dragFractionPosition by remember { mutableFloatStateOf(continuousPagePosition) }
    var pressedTabIndex by remember { mutableIntStateOf(-1) }

    val targetFraction = if (isDraggingBar) {
        dragFractionPosition.coerceIn(0f, (tabCount - 1).toFloat())
    } else {
        continuousPagePosition.coerceIn(0f, (tabCount - 1).toFloat())
    }

    val animatedTabPosition by animateFloatAsState(
        targetValue = targetFraction,
        animationSpec = spring(
            dampingRatio = if (isDraggingBar) 0.78f else CDS_SPRING_POPOVER_DAMPING,
            stiffness = if (isDraggingBar) 680f else CDS_SPRING_POPOVER_STIFFNESS
        ),
        label = "CdsDockPillPosition"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(54.dp)
            .shadow(
                elevation = 10.dp,
                shape = CircleShape,
                ambientColor = Color.Black.copy(alpha = 0.14f)
            )
            .clip(CircleShape)
            .background(tokens.surface1)
            .border(0.6.dp, tokens.hairlineBorder, CircleShape)
            .padding(3.dp)
            .onSizeChanged { barWidthPx = it.width }
            .pointerInput(barWidthPx) {
                if (barWidthPx <= 0) return@pointerInput
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val startFrac = ((down.position.x / barWidthPx.toFloat()) * tabCount - 0.5f)
                        .coerceIn(0f, (tabCount - 1).toFloat())
                    var currentFrac = startFrac
                    var hasDragged = false
                    var lastTriggeredIdx = ((down.position.x / barWidthPx.toFloat()) * tabCount)
                        .toInt()
                        .coerceIn(0, tabCount - 1)
                    pressedTabIndex = lastTriggeredIdx

                    do {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull() ?: break
                        if (change.pressed) {
                            val dx = abs(change.position.x - down.position.x)
                            // 4px 移动死区
                            if (dx > 4f) {
                                hasDragged = true
                                isDraggingBar = true
                            }
                            if (hasDragged) {
                                change.consume()
                                currentFrac = ((change.position.x / barWidthPx.toFloat()) * tabCount - 0.5f)
                                    .coerceIn(0f, (tabCount - 1).toFloat())
                                dragFractionPosition = currentFrac
                                val hoveredIdx = ((change.position.x / barWidthPx.toFloat()) * tabCount)
                                    .toInt()
                                    .coerceIn(0, tabCount - 1)
                                pressedTabIndex = hoveredIdx
                                if (hoveredIdx != lastTriggeredIdx) {
                                    lastTriggeredIdx = hoveredIdx
                                    onSelectMode(ProcessMode.entries[hoveredIdx])
                                }
                            }
                        }
                    } while (event.changes.any { it.pressed })

                    pressedTabIndex = -1
                    if (hasDragged) {
                        isDraggingBar = false
                        val finalIdx = currentFrac.roundToInt().coerceIn(0, tabCount - 1)
                        onSelectMode(ProcessMode.entries[finalIdx])
                    } else {
                        val tappedIdx = ((down.position.x / barWidthPx.toFloat()) * tabCount)
                            .toInt()
                            .coerceIn(0, tabCount - 1)
                        onSelectMode(ProcessMode.entries[tappedIdx])
                    }
                }
            }
    ) {
        val tabWidthPx = if (barWidthPx > 0) barWidthPx / tabCount else 0
        val tabWidthDp = with(LocalDensity.current) { tabWidthPx.toDp() }

        if (tabWidthPx > 0) {
            val offsetXPx = (animatedTabPosition * tabWidthPx).roundToInt()
            Box(
                modifier = Modifier
                    .offset { IntOffset(x = offsetXPx, y = 0) }
                    .width(tabWidthDp)
                    .fillMaxHeight()
                    .clip(CircleShape)
                    .background(tokens.surface3)
                    .border(0.6.dp, tokens.clayBorder, CircleShape)
            )
        }

        Row(modifier = Modifier.fillMaxSize()) {
            ProcessMode.entries.forEachIndexed { index, mode ->
                val distance = abs(animatedTabPosition - index).coerceIn(0f, 1f)
                val isSelected = distance < 0.45f
                val isFingerPressing = pressedTabIndex == index

                val itemScale by animateFloatAsState(
                    targetValue = when {
                        isFingerPressing -> 0.94f
                        isSelected -> 1.02f
                        else -> 0.98f
                    },
                    animationSpec = spring(
                        dampingRatio = CDS_SPRING_POPOVER_DAMPING,
                        stiffness = CDS_SPRING_SNAPPY_STIFFNESS
                    ),
                    label = "CdsDockItemScale"
                )

                val icon = when (mode) {
                    ProcessMode.ARCHIVE_EXTRACT -> if (isSelected) Icons.Default.FolderZip else Icons.Outlined.FolderZip
                    ProcessMode.ARCHIVE_READER -> if (isSelected) Icons.Default.AutoStories else Icons.Outlined.AutoStories
                }

                val iconTint = if (isSelected) tokens.clay else tokens.textMuted
                val labelColor = if (isSelected) tokens.textPrimary else tokens.textSecondary

                Row(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .graphicsLayer {
                            scaleX = itemScale
                            scaleY = itemScale
                        },
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = mode.shortTitle,
                        tint = iconTint,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = mode.fullTitle,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = if (isSelected) tokens.headingWeight else FontWeight.Normal,
                        color = labelColor
                    )
                }
            }
        }
    }
}

/**
 * Open Claude UI 2x2 状态仪表盘（带 2.4s 陶土呼吸指示灯与人文衬线数字）
 */
@Composable
private fun CdsExtractorDashboardGrid(
    selectedImages: List<SelectedImageItem>,
    exportResultsMap: Map<Uri, ExportSaveResult>,
    readerLayoutMode: ReaderLayoutMode,
    customDirName: String?,
    isExtracting: Boolean,
    lastImportedArchiveBanner: String?,
    onPickArchives: () -> Unit,
    onOpenReader: () -> Unit,
    onSaveAllToGallery: () -> Unit,
    onShareAll: () -> Unit,
    onPickDirectory: () -> Unit,
    onResetDirectory: () -> Unit
) {
    val tokens = LocalCdsTokens.current
    val totalOrigBytes = selectedImages.sumOf { it.originalSize }
    val savedCount = selectedImages.count { exportResultsMap[it.uri]?.isSuccess == true }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CdsSurfaceCard(
                surfaceLevel = 2,
                cornerRadius = 14.dp,
                isHighlighted = selectedImages.isNotEmpty(),
                modifier = Modifier
                    .weight(1f)
                    .cdsTactileScale(
                        activeScale = 0.97f,
                        shape = RoundedCornerShape(14.dp),
                        onClick = onPickArchives
                    )
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            CdsStatusBreathingDot(
                                isActive = selectedImages.isNotEmpty(),
                                isPulsing = isExtracting
                            )
                            Text(
                                "归档源包",
                                style = MaterialTheme.typography.labelSmall,
                                color = tokens.textMuted
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.FolderZip,
                            contentDescription = null,
                            tint = tokens.clay,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = if (selectedImages.isEmpty()) "导入压缩包" else "${selectedImages.size} 张图像",
                        style = MaterialTheme.typography.titleMedium,
                        fontFamily = FontFamily.Serif,
                        fontWeight = tokens.headingWeight,
                        color = tokens.textPrimary
                    )
                    Text(
                        text = lastImportedArchiveBanner
                            ?: if (selectedImages.isEmpty()) "ZIP · 7Z · RAR · CBZ" else ImageCompressor.formatFileSize(totalOrigBytes),
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = tokens.clay,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            CdsSurfaceCard(
                surfaceLevel = 2,
                cornerRadius = 14.dp,
                modifier = Modifier
                    .weight(1f)
                    .cdsTactileScale(
                        activeScale = 0.97f,
                        shape = RoundedCornerShape(14.dp),
                        onClick = onOpenReader
                    )
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "画廊阅读器",
                            style = MaterialTheme.typography.labelSmall,
                            color = tokens.textMuted
                        )
                        Icon(
                            imageVector = Icons.Default.AutoStories,
                            contentDescription = null,
                            tint = tokens.clay,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = if (selectedImages.isNotEmpty()) "阅读 (${selectedImages.size}P)" else "进入阅读器",
                        style = MaterialTheme.typography.titleMedium,
                        fontFamily = FontFamily.Serif,
                        fontWeight = tokens.headingWeight,
                        color = tokens.clay
                    )
                    Text(
                        text = "${readerLayoutMode.label} · 记忆书签",
                        style = MaterialTheme.typography.labelSmall,
                        color = tokens.textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CdsSurfaceCard(
                surfaceLevel = 2,
                cornerRadius = 14.dp,
                modifier = Modifier
                    .weight(1f)
                    .cdsTactileScale(
                        enabled = selectedImages.isNotEmpty(),
                        activeScale = 0.97f,
                        shape = RoundedCornerShape(14.dp),
                        onClick = {
                            if (savedCount == selectedImages.size && savedCount > 0) {
                                onShareAll()
                            } else {
                                onSaveAllToGallery()
                            }
                        }
                    )
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "一键落盘与分享",
                            style = MaterialTheme.typography.labelSmall,
                            color = tokens.textMuted
                        )
                        Icon(
                            imageVector = if (savedCount > 0) Icons.Default.Share else Icons.Default.Download,
                            contentDescription = null,
                            tint = tokens.clay,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = when {
                            selectedImages.isEmpty() -> "待导入图像"
                            savedCount > 0 -> "已存 $savedCount/${selectedImages.size}"
                            else -> "一键存相册"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontFamily = FontFamily.Serif,
                        fontWeight = tokens.headingWeight,
                        color = tokens.textPrimary
                    )
                    Text(
                        text = if (selectedImages.isEmpty()) "解压后可批量存相册或分享" else "点击批量存相册或向外分享",
                        style = MaterialTheme.typography.labelSmall,
                        color = tokens.textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            CdsSurfaceCard(
                surfaceLevel = 2,
                cornerRadius = 14.dp,
                modifier = Modifier
                    .weight(1f)
                    .cdsTactileScale(
                        activeScale = 0.97f,
                        shape = RoundedCornerShape(14.dp),
                        onClick = onPickDirectory
                    )
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "目标路径",
                            style = MaterialTheme.typography.labelSmall,
                            color = tokens.textMuted
                        )
                        if (customDirName != null) {
                            Icon(
                                imageVector = Icons.Default.Restore,
                                contentDescription = "重置为系统相册",
                                tint = tokens.clay,
                                modifier = Modifier
                                    .size(16.dp)
                                    .clickable { onResetDirectory() }
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Outlined.FolderOpen,
                                contentDescription = null,
                                tint = tokens.clay,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Text(
                        text = customDirName ?: "系统相册",
                        style = MaterialTheme.typography.titleMedium,
                        fontFamily = FontFamily.Serif,
                        fontWeight = tokens.headingWeight,
                        color = tokens.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = if (customDirName != null) "SAF 自定义目录" else "Pictures/Extracted",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = tokens.textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

/**
 * 实时解压进度条横幅卡片 (`CdsExtractionProgressCard`)
 */
@Composable
private fun CdsExtractionProgressCard(
    extractDoneCount: Int,
    extractTotalCount: Int,
    extractCurrentFile: String,
    onCancelExtract: () -> Unit
) {
    val tokens = LocalCdsTokens.current
    val extractProgressTarget = if (extractTotalCount > 0) {
        (extractDoneCount.toFloat() / extractTotalCount.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }
    val animatedExtractProgress by animateFloatAsState(
        targetValue = extractProgressTarget,
        animationSpec = spring(
            dampingRatio = CDS_SPRING_LAYOUT_DAMPING,
            stiffness = CDS_SPRING_LAYOUT_STIFFNESS
        ),
        label = "CdsBannerExtractProgress"
    )

    CdsSurfaceCard(
        surfaceLevel = 2,
        cornerRadius = 14.dp,
        isHighlighted = true,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CdsStatusBreathingDot(isActive = true, isPulsing = true)
                    Text(
                        text = when {
                            extractTotalCount > 0 -> "正在解压 ($extractDoneCount / $extractTotalCount 张)"
                            extractDoneCount > 0 -> "正在解压 ($extractDoneCount 张)"
                            else -> "正在扫描归档条目..."
                        },
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = tokens.headingWeight,
                        color = tokens.clay
                    )
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (extractTotalCount > 0) {
                        Text(
                            text = "${(animatedExtractProgress * 100).roundToInt()}%",
                            style = MaterialTheme.typography.labelMedium,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = tokens.clay
                        )
                    }
                    CdsButton(
                        text = "取消",
                        variant = CdsButtonVariant.DANGER,
                        size = CdsButtonSize.XS,
                        onClick = onCancelExtract
                    )
                }
            }
            if (extractTotalCount > 0) {
                LinearProgressIndicator(
                    progress = { animatedExtractProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = tokens.clay,
                    trackColor = tokens.surface1
                )
            } else {
                LinearProgressIndicator(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = tokens.clay,
                    trackColor = tokens.surface1
                )
            }
            if (extractCurrentFile.isNotBlank()) {
                Text(
                    text = extractCurrentFile,
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    color = tokens.textMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

/**
 * CDS 2.2 分段滑动选择胶囊 (`CdsSegmentedControl`)：
 * 999px 全圆角轨道 + 2dp 几何内边距 + Surface 3 抬升滑块 + 0.5dp 发丝细边
 */
@Composable
private fun <T> CdsSegmentedControl(
    items: List<T>,
    selectedItem: T,
    itemLabel: (T) -> String,
    enabled: Boolean = true,
    onItemSelected: (T) -> Unit
) {
    val tokens = LocalCdsTokens.current
    val selectedIndex = items.indexOf(selectedItem).coerceAtLeast(0)
    var rowWidthPx by remember { mutableIntStateOf(0) }

    val animatedIndex by animateFloatAsState(
        targetValue = selectedIndex.toFloat(),
        animationSpec = spring(
            dampingRatio = CDS_SPRING_POPOVER_DAMPING,
            stiffness = CDS_SPRING_POPOVER_STIFFNESS
        ),
        label = "CdsSegmentOffset"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(38.dp)
            .clip(CircleShape)
            .background(tokens.surface1)
            .border(0.6.dp, tokens.hairlineBorder, CircleShape)
            .padding(2.dp)
            .onSizeChanged { rowWidthPx = it.width }
    ) {
        val itemWidthPx = if (rowWidthPx > 0 && items.isNotEmpty()) rowWidthPx / items.size else 0
        val itemWidthDp = with(LocalDensity.current) { itemWidthPx.toDp() }

        if (itemWidthPx > 0) {
            val offsetXPx = (animatedIndex * itemWidthPx).roundToInt()
            Box(
                modifier = Modifier
                    .offset { IntOffset(x = offsetXPx, y = 0) }
                    .width(itemWidthDp)
                    .fillMaxHeight()
                    .clip(CircleShape)
                    .background(tokens.surface3)
                    .border(0.6.dp, tokens.clayBorder, CircleShape)
            )
        }

        Row(modifier = Modifier.fillMaxSize()) {
            items.forEach { item ->
                val isSelected = item == selectedItem
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .cdsTactileScale(
                            enabled = enabled,
                            activeScale = 0.95f,
                            shape = CircleShape,
                            onClick = { onItemSelected(item) }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = itemLabel(item),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (isSelected) tokens.headingWeight else FontWeight.Normal,
                        color = if (isSelected) tokens.clay else tokens.textSecondary,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                }
            }
        }
    }
}

/**
 * 桌面/平板端左侧 CDS 导航栏 (`CdsNavigationRail`)
 */
@Composable
private fun CdsNavigationRail(
    currentMode: ProcessMode,
    selectedCount: Int,
    onSelectMode: (ProcessMode) -> Unit
) {
    val tokens = LocalCdsTokens.current
    NavigationRail(
        containerColor = tokens.surface1,
        header = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 12.dp, bottom = 8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = tokens.claySoftBg,
                    border = BorderStroke(0.6.dp, tokens.clayBorder),
                    modifier = Modifier.size(42.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "C",
                            style = MaterialTheme.typography.titleLarge,
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            color = tokens.clay
                        )
                    }
                }
                if (selectedCount > 0) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Badge(
                        containerColor = tokens.clay,
                        contentColor = Color.White
                    ) {
                        Text(
                            "$selectedCount",
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        )
                    }
                }
            }
        },
        modifier = Modifier.fillMaxHeight()
    ) {
        Spacer(modifier = Modifier.height(8.dp))
        ProcessMode.entries.forEach { mode ->
            val isSelected = currentMode == mode
            val icon = when (mode) {
                ProcessMode.ARCHIVE_EXTRACT -> if (isSelected) Icons.Default.FolderZip else Icons.Outlined.FolderZip
                ProcessMode.ARCHIVE_READER -> if (isSelected) Icons.Default.AutoStories else Icons.Outlined.AutoStories
            }
            NavigationRailItem(
                selected = isSelected,
                onClick = { onSelectMode(mode) },
                icon = { Icon(imageVector = icon, contentDescription = mode.shortTitle) },
                label = {
                    Text(
                        text = mode.shortTitle,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (isSelected) tokens.headingWeight else FontWeight.Normal
                    )
                },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = tokens.clay,
                    selectedTextColor = tokens.textPrimary,
                    indicatorColor = tokens.claySoftBg,
                    unselectedIconColor = tokens.textMuted,
                    unselectedTextColor = tokens.textMuted
                ),
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }
    }
}

/**
 * Open Claude UI 人文衬线顶栏 (`CdsEditorialTopBar`)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CdsEditorialTopBar(
    currentMode: ProcessMode,
    selectedCount: Int,
    customTreeUri: Uri?,
    isDarkTheme: Boolean,
    isBusy: Boolean,
    onToggleDarkTheme: () -> Unit,
    onPickDirectory: () -> Unit,
    onShareAll: () -> Unit,
    onClearQueue: () -> Unit
) {
    val tokens = LocalCdsTokens.current
    Column {
        TopAppBar(
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = tokens.clay,
                        modifier = Modifier.size(26.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.AutoStories,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(15.dp)
                            )
                        }
                    }
                    Text(
                        text = "像素工坊 · ${currentMode.fullTitle}",
                        style = MaterialTheme.typography.titleMedium.copy(letterSpacing = (-0.2).sp),
                        fontFamily = FontFamily.Serif,
                        fontWeight = tokens.headingWeight,
                        color = tokens.textPrimary
                    )
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = tokens.claySoftBg,
                        border = BorderStroke(0.5.dp, tokens.clayBorder)
                    ) {
                        Text(
                            text = currentMode.shortTitle,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = tokens.clay,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                        )
                    }
                }
            },
            actions = {
                if (selectedCount > 0) {
                    IconButton(onClick = onShareAll) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "一键分享全部",
                            tint = tokens.clay
                        )
                    }
                }

                IconButton(onClick = onToggleDarkTheme) {
                    Icon(
                        imageVector = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                        contentDescription = "切换浅色/深色表面",
                        tint = tokens.textSecondary
                    )
                }

                IconButton(
                    onClick = onPickDirectory,
                    enabled = !isBusy
                ) {
                    Icon(
                        imageVector = Icons.Outlined.FolderOpen,
                        contentDescription = "存相册目录",
                        tint = if (customTreeUri != null) tokens.clay else tokens.textSecondary
                    )
                }

                if (selectedCount > 0 && !isBusy) {
                    IconButton(onClick = onClearQueue) {
                        Icon(
                            imageVector = Icons.Outlined.DeleteSweep,
                            contentDescription = "清空列表",
                            tint = tokens.textMuted
                        )
                    }
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = tokens.surface0
            )
        )
        HorizontalDivider(
            thickness = 0.6.dp,
            color = tokens.hairlineBorder
        )
    }
}

/**
 * 批量存相册完成统计横幅 (`CdsBatchExportSummaryBanner`)
 */
@Composable
private fun CdsBatchExportSummaryBanner(
    selectedImages: List<SelectedImageItem>,
    resultsMap: Map<Uri, ExportSaveResult>,
    exportReport: BatchExportReport?,
    onShareClick: () -> Unit
) {
    val tokens = LocalCdsTokens.current
    val successfulResults = selectedImages.mapNotNull { resultsMap[it.uri] }.filter { it.isSuccess }
    if (successfulResults.isEmpty()) return

    val totalSavedBytes = successfulResults.sumOf { it.savedSize }

    CdsSurfaceCard(
        surfaceLevel = 2,
        cornerRadius = 14.dp,
        isHighlighted = true,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(tokens.claySoftBg.copy(alpha = 0.55f))
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text(
                    text = "已存入相册 (${successfulResults.size}/${selectedImages.size} 张)",
                    style = MaterialTheme.typography.titleSmall,
                    fontFamily = FontFamily.Serif,
                    fontWeight = tokens.headingWeight,
                    color = tokens.textPrimary
                )
                Text(
                    text = "${ImageCompressor.formatFileSize(totalSavedBytes)} · ${exportReport?.targetFolderLabel ?: "Pictures/Extracted"}",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    color = tokens.clay
                )
            }

            CdsButton(
                text = "一键分享",
                icon = Icons.Default.Share,
                variant = CdsButtonVariant.PRIMARY,
                size = CdsButtonSize.SM,
                onClick = onShareClick
            )
        }
    }
}

/**
 * CDS 2.5 附件磁贴卡片 (`CdsAttachmentItemCard`)：
 * 14dp 精密圆角 + 0.5dp 发丝细边 + 等宽元数据标签 + 单张存相册/分享按钮
 */
@Composable
private fun CdsAttachmentItemCard(
    item: SelectedImageItem,
    exportResult: ExportSaveResult?,
    modifier: Modifier = Modifier,
    onCardClick: () -> Unit,
    onSaveSingleClick: () -> Unit,
    onShareSingleClick: () -> Unit,
    onRemoveItem: () -> Unit
) {
    val context = LocalContext.current
    val tokens = LocalCdsTokens.current
    val thumbRequest = remember(item.uri) {
        ImageRequest.Builder(context)
            .data(item.uri)
            .size(180, 180)
            .crossfade(false)
            .build()
    }

    CdsSurfaceCard(
        surfaceLevel = 2,
        cornerRadius = 14.dp,
        modifier = modifier
            .fillMaxWidth()
            .cdsTactileScale(
                enabled = true,
                activeScale = 0.98f,
                shape = RoundedCornerShape(14.dp),
                onClick = onCardClick
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(58.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(tokens.surface1)
                    .border(0.5.dp, tokens.hairlineBorder, RoundedCornerShape(10.dp))
            ) {
                AsyncImage(
                    model = thumbRequest,
                    contentDescription = item.displayName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text(
                    text = item.displayName,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = tokens.headingWeight,
                    color = tokens.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                val srcFormatShort = item.mimeType.substringAfterLast('/').uppercase(Locale.ROOT)
                Text(
                    text = "$srcFormatShort · ${item.width}×${item.height} · ${ImageCompressor.formatFileSize(item.originalSize)}",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    color = tokens.textMuted
                )

                if (exportResult != null) {
                    if (exportResult.isSuccess) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = tokens.success,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "已存相册 · ${exportResult.savedPathLabel}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = tokens.bodyStrongWeight,
                                color = tokens.success,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.ErrorOutline,
                                contentDescription = null,
                                tint = tokens.danger,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = exportResult.errorMessage ?: "保存失败",
                                style = MaterialTheme.typography.labelSmall,
                                color = tokens.danger
                            )
                        }
                    }
                }
            }

            IconButton(
                onClick = onSaveSingleClick,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Download,
                    contentDescription = "存相册",
                    tint = tokens.clay,
                    modifier = Modifier.size(17.dp)
                )
            }

            IconButton(
                onClick = onShareSingleClick,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = "分享",
                    tint = tokens.textSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }

            IconButton(
                onClick = onRemoveItem,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "移除",
                    tint = tokens.textMuted,
                    modifier = Modifier.size(15.dp)
                )
            }
        }
    }
}

/**
 * CDS 5.2 多模态媒体查看器弹窗 (`CdsImageLightboxModal`)
 */
@Composable
private fun CdsImageLightboxModal(
    item: SelectedImageItem,
    exportResult: ExportSaveResult?,
    onDismiss: () -> Unit,
    onSaveToGallery: () -> Unit,
    onShare: () -> Unit,
    onOpenInReader: () -> Unit,
    onRemove: () -> Unit
) {
    val tokens = LocalCdsTokens.current
    BackHandler(onBack = onDismiss)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = if (tokens.isDark) 0.62f else 0.36f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismiss
            )
            .padding(18.dp),
        contentAlignment = Alignment.Center
    ) {
        CdsSurfaceCard(
            surfaceLevel = 3,
            cornerRadius = 18.dp,
            isHighlighted = true,
            modifier = Modifier
                .widthIn(max = 560.dp)
                .fillMaxWidth()
                .shadow(
                    elevation = 20.dp,
                    shape = RoundedCornerShape(18.dp),
                    ambientColor = tokens.popoverGlow,
                    spotColor = tokens.popoverGlow
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {}
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.displayName,
                            style = MaterialTheme.typography.titleMedium,
                            fontFamily = FontFamily.Serif,
                            fontWeight = tokens.headingWeight,
                            color = tokens.textPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = exportResult?.savedPathLabel
                                ?: "${item.width}×${item.height} · ${ImageCompressor.formatFileSize(item.originalSize)}",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = tokens.clay
                        )
                    }
                    IconButton(onClick = onSaveToGallery) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = "存相册", tint = tokens.clay)
                    }
                    IconButton(onClick = onShare) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = "分享", tint = tokens.textSecondary)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "关闭", tint = tokens.textMuted)
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(tokens.surface1)
                        .border(0.6.dp, tokens.hairlineBorder, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = item.uri,
                        contentDescription = item.displayName,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CdsButton(
                        text = "移除",
                        variant = CdsButtonVariant.DANGER,
                        size = CdsButtonSize.MD,
                        modifier = Modifier.weight(1f),
                        onClick = onRemove
                    )
                    CdsButton(
                        text = "阅读器打开",
                        variant = CdsButtonVariant.SECONDARY,
                        size = CdsButtonSize.MD,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenInReader
                    )
                    CdsButton(
                        text = "存相册",
                        icon = Icons.Default.Download,
                        variant = CdsButtonVariant.PRIMARY,
                        size = CdsButtonSize.MD,
                        modifier = Modifier.weight(1f),
                        onClick = onSaveToGallery
                    )
                }
            }
        }
    }
}

/**
 * CDS 1.3 20dp 外框 Composer 空状态引导与实时解压进度面板 (`CdsEmptyComposerCard`)
 */
@Composable
private fun CdsEmptyComposerCard(
    isExtracting: Boolean = false,
    extractDoneCount: Int = 0,
    extractTotalCount: Int = 0,
    extractCurrentFile: String = "",
    onCancelExtract: () -> Unit = {},
    onPickArchives: () -> Unit,
    onPickArchivesAndRead: () -> Unit
) {
    val tokens = LocalCdsTokens.current
    val extractProgressTarget = if (extractTotalCount > 0) {
        (extractDoneCount.toFloat() / extractTotalCount.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }
    val animatedExtractProgress by animateFloatAsState(
        targetValue = extractProgressTarget,
        animationSpec = spring(
            dampingRatio = CDS_SPRING_LAYOUT_DAMPING,
            stiffness = CDS_SPRING_LAYOUT_STIFFNESS
        ),
        label = "CdsWorkbenchExtractProgress"
    )

    CdsSurfaceCard(
        surfaceLevel = 2,
        cornerRadius = 20.dp,
        isHighlighted = isExtracting,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = tokens.claySoftBg,
                border = BorderStroke(0.6.dp, tokens.clayBorder),
                modifier = Modifier.size(54.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (isExtracting) Icons.Default.Unarchive else Icons.Outlined.FolderZip,
                        contentDescription = null,
                        tint = tokens.clay,
                        modifier = Modifier.size(25.dp)
                    )
                }
            }

            Text(
                text = if (isExtracting) "正在解压归档流..." else "导入压缩包提取图像",
                style = MaterialTheme.typography.titleLarge,
                fontFamily = FontFamily.Serif,
                fontWeight = tokens.headingWeight,
                color = tokens.textPrimary
            )

            if (isExtracting) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            CdsStatusBreathingDot(isActive = true, isPulsing = true)
                            Text(
                                text = when {
                                    extractTotalCount > 0 -> "已解压 $extractDoneCount / $extractTotalCount 张"
                                    extractDoneCount > 0 -> "已解压 $extractDoneCount 张"
                                    else -> "正在读取压缩包索引..."
                                },
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = tokens.headingWeight,
                                color = tokens.clay
                            )
                        }
                        if (extractTotalCount > 0) {
                            Text(
                                text = "${(animatedExtractProgress * 100).roundToInt()}%",
                                style = MaterialTheme.typography.labelMedium,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = tokens.clay
                            )
                        }
                    }
                    if (extractTotalCount > 0) {
                        LinearProgressIndicator(
                            progress = { animatedExtractProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = tokens.clay,
                            trackColor = tokens.surface1
                        )
                    } else {
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = tokens.clay,
                            trackColor = tokens.surface1
                        )
                    }
                    if (extractCurrentFile.isNotBlank()) {
                        Text(
                            text = extractCurrentFile,
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = tokens.textMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    CdsButton(
                        text = "取消解压",
                        icon = Icons.Default.Close,
                        variant = CdsButtonVariant.DANGER,
                        size = CdsButtonSize.SM,
                        modifier = Modifier.align(Alignment.CenterHorizontally),
                        onClick = onCancelExtract
                    )
                }
            } else {
                Text(
                    text = "支持加密 .zip · .cbz · .7z · .rar · .tar.gz 解压，内置常用密码本、一键存相册与外部应用分享导入",
                    style = MaterialTheme.typography.bodySmall,
                    color = tokens.textSecondary,
                    textAlign = TextAlign.Center
                )

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CdsButton(
                        text = "导入压缩包",
                        icon = Icons.Default.FolderZip,
                        variant = CdsButtonVariant.PRIMARY,
                        size = CdsButtonSize.MD,
                        onClick = onPickArchives
                    )
                    CdsButton(
                        text = "解压并阅读",
                        icon = Icons.Default.AutoStories,
                        variant = CdsButtonVariant.SECONDARY,
                        size = CdsButtonSize.MD,
                        onClick = onPickArchivesAndRead
                    )
                }
            }
        }
    }
}