package com.example.imagecompressor

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import androidx.exifinterface.media.ExifInterface
import com.github.junrar.Archive
import com.github.junrar.rarfile.FileHeader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorOutputStream
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.charset.Charset
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * 底部导航栏四大工作空间（遵循 Apple HIG Tab Bars 简短单字/双字命名原则）：
 * 1. COMPRESS_TRANSCODE：画质压缩、分辨率缩放与格式解码转码
 * 2. OBFUSCATE_ENCRYPT：输入文字口令，将图片混淆成彩色色块（无损 PNG）
 * 3. DEOBFUSCATE_RESTORE：输入相同文字口令，将色块图 100% 像素级无损还原为原图
 * 4. ARCHIVE_HUB：支持多格式压缩包（ZIP/7Z/RAR/TAR/GZ/BZ2/XZ/CBZ）解压提取图片，以及将图片直接打包压入压缩包
 */
enum class ProcessMode(
    val shortTitle: String,
    val fullTitle: String,
    val subtitle: String
) {
    COMPRESS_TRANSCODE(
        shortTitle = "压缩",
        fullTitle = "画质压缩与格式转码",
        subtitle = "批量调节画质、尺寸缩放，支持直接压入压缩包"
    ),
    OBFUSCATE_ENCRYPT(
        shortTitle = "混淆",
        fullTitle = "文字口令色块加密",
        subtitle = "用一串文字将图片打乱为彩色色块，支持无损还原"
    ),
    DEOBFUSCATE_RESTORE(
        shortTitle = "还原",
        fullTitle = "文字口令无损还原",
        subtitle = "输入加密时的同一串文字，将色块图 100% 还原为原图"
    ),
    ARCHIVE_HUB(
        shortTitle = "归档",
        fullTitle = "多格式压缩包解压与打包",
        subtitle = "兼容 ZIP / 7Z / RAR / TAR.GZ / XZ / CBZ 解压与图片直接打包"
    )
}

/**
 * 「归档」工作台下的两个子模式（Apple Segmented Control 分段切换）
 */
enum class ArchiveSubMode(val label: String, val desc: String) {
    PACK_TO_ARCHIVE(
        label = "图片打入压缩包",
        desc = "将当前队列中的所有图片直接打包封装为一个压缩包文件"
    ),
    EXTRACT_FROM_ARCHIVE(
        label = "从压缩包解压图片",
        desc = "支持外部「打开方式/分享」传入或本地导入 .zip/.7z/.rar/.tar.gz/.xz/.cbz 并无损导出图片"
    )
}

/**
 * 支持直接把图片打包压入的目标压缩包格式
 */
enum class ArchiveOutputFormat(
    val label: String,
    val shortLabel: String,
    val extension: String,
    val mimeType: String,
    val description: String
) {
    ZIP(
        label = "ZIP 压缩包 (.zip)",
        shortLabel = "ZIP",
        extension = "zip",
        mimeType = "application/zip",
        description = "全平台通用，支持手机文件管理器与电脑直接预览解压"
    ),
    SEVEN_Z(
        label = "7Z 高压缩包 (.7z)",
        shortLabel = "7Z",
        extension = "7z",
        mimeType = "application/x-7z-compressed",
        description = "采用 LZMA2 算法的高压缩比归档格式，适合大批量图片归档"
    ),
    CBZ(
        label = "CBZ 漫画图集 (.cbz)",
        shortLabel = "CBZ",
        extension = "cbz",
        mimeType = "application/x-cbz",
        description = "漫画与连续图集专用归档格式，阅读器可直接翻页浏览"
    ),
    TAR_GZ(
        label = "TAR.GZ 归档 (.tar.gz)",
        shortLabel = "TAR.GZ",
        extension = "tar.gz",
        mimeType = "application/gzip",
        description = "Linux / 极客常用 GZIP 压缩流归档格式"
    ),
    TAR_XZ(
        label = "TAR.XZ 归档 (.tar.xz)",
        shortLabel = "TAR.XZ",
        extension = "tar.xz",
        mimeType = "application/x-xz",
        description = "采用 XZ 算法的紧凑型流式归档包"
    ),
    TAR(
        label = "TAR 纯归档 (.tar)",
        shortLabel = "TAR",
        extension = "tar",
        mimeType = "application/x-tar",
        description = "零二次压缩损耗，极速将多张图片合并为单一归档文件"
    )
}

/**
 * 压缩包打包压缩率等级
 */
enum class ArchiveCompressionLevel(val label: String, val zipLevel: Int) {
    STORE_ONLY("极速仅存储 (0级)", Deflater.NO_COMPRESSION),
    STANDARD("标准均衡 (6级)", Deflater.DEFAULT_COMPRESSION),
    ULTRA("极限压缩 (9级)", Deflater.BEST_COMPRESSION)
}

/**
 * 色块混淆粒度选项
 */
enum class BlockGridSize(val label: String, val shortLabel: String, val blockPx: Int) {
    BLOCK_8("细密 (8×8)", "8×8", 8),
    BLOCK_16("标准 (16×16)", "16×16", 16),
    BLOCK_32("大块 (32×32)", "32×32", 32),
    BLOCK_64("超大 (64×64)", "64×64", 64)
}

/**
 * 支持的目标编码/转码格式
 */
enum class OutputFormat(
    val label: String,
    val shortLabel: String,
    val extension: String,
    val mimeType: String,
    val supportsQualitySlider: Boolean,
    val description: String
) {
    JPEG(
        label = "JPEG (有损)",
        shortLabel = "JPEG",
        extension = "jpg",
        mimeType = "image/jpeg",
        supportsQualitySlider = true,
        description = "兼容性最佳，适合照片体积瘦身（透明区域自动补白底）"
    ),
    WEBP_LOSSY(
        label = "WebP (高压缩)",
        shortLabel = "WebP有损",
        extension = "webp",
        mimeType = "image/webp",
        supportsQualitySlider = true,
        description = "比同画质 JPEG 体积再减 25%~35%，支持透明通道"
    ),
    WEBP_LOSSLESS(
        label = "WebP (无损)",
        shortLabel = "WebP无损",
        extension = "webp",
        mimeType = "image/webp",
        supportsQualitySlider = false,
        description = "100% 保留原始像素无损转码，体积比 PNG 更紧凑"
    ),
    PNG(
        label = "PNG (无损)",
        shortLabel = "PNG无损",
        extension = "png",
        mimeType = "image/png",
        supportsQualitySlider = false,
        description = "无损 PNG 格式，保留完整透明通道与像素精度"
    )
}

/**
 * 分辨率限制选项（按最长边等比缩放）
 */
enum class ResolutionOption(val label: String, val maxDimensionPx: Int?) {
    ORIGINAL("原图尺寸", null),
    MAX_2560("2K (2560px)", 2560),
    MAX_1920("1080P (1920px)", 1920),
    MAX_1080("高清 (1080px)", 1080),
    MAX_720("轻量 (720px)", 720)
}

/**
 * 批量处理与打包配置参数
 */
data class CompressionConfig(
    val mode: ProcessMode = ProcessMode.COMPRESS_TRANSCODE,
    val archiveSubMode: ArchiveSubMode = ArchiveSubMode.PACK_TO_ARCHIVE,
    val format: OutputFormat = OutputFormat.JPEG,
    val quality: Int = 80,
    val resolutionOption: ResolutionOption = ResolutionOption.ORIGINAL,
    val customTreeUri: Uri? = null,
    val obfuscationKey: String = "",
    val blockGridSize: BlockGridSize = BlockGridSize.BLOCK_16,
    val packResultIntoArchive: Boolean = false,
    val archiveOutputFormat: ArchiveOutputFormat = ArchiveOutputFormat.ZIP,
    val archiveCompressionLevel: ArchiveCompressionLevel = ArchiveCompressionLevel.STANDARD,
    val customArchiveBaseName: String = ""
)

/**
 * 待处理的单张原图元数据
 */
data class SelectedImageItem(
    val uri: Uri,
    val displayName: String,
    val originalSize: Long,
    val mimeType: String,
    val width: Int,
    val height: Int,
    val fromArchiveName: String? = null
)

/**
 * 单张图片或归档处理后的结果
 */
data class CompressionResult(
    val source: SelectedImageItem,
    val isSuccess: Boolean,
    val mode: ProcessMode = ProcessMode.COMPRESS_TRANSCODE,
    val outputUri: Uri? = null,
    val outputName: String = "",
    val compressedSize: Long = 0L,
    val outputWidth: Int = 0,
    val outputHeight: Int = 0,
    val outputFormat: OutputFormat = OutputFormat.JPEG,
    val savedPathLabel: String = "",
    val packedIntoArchiveName: String? = null,
    val errorMessage: String? = null
)

/**
 * 批量执行完成后的汇总报告（包含可选的生成压缩包信息）
 */
data class BatchExecutionReport(
    val itemResults: List<CompressionResult>,
    val archiveSavedUri: Uri? = null,
    val archiveFileName: String? = null,
    val archiveSavedPathLabel: String? = null,
    val archiveTotalBytes: Long = 0L
)

/**
 * 多格式压缩包导入结果汇总
 */
data class ArchiveImportSummary(
    val archiveCount: Int,
    val extractedImages: List<SelectedImageItem>,
    val archiveNames: List<String>,
    val errorNote: String? = null
)

/**
 * 基于文字口令 (SHA-256 + SplitMix64) 的跨平台确定性伪随机数生成器
 */
private class KeySeededRandom(secretText: String, saltTag: String) {
    private var state: Long

    init {
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(secretText.toByteArray(Charsets.UTF_8))
        digest.update(0.toByte())
        digest.update(saltTag.toByteArray(Charsets.UTF_8))
        val hashBytes = digest.digest()
        val buf = ByteBuffer.wrap(hashBytes)
        var acc = 0L
        repeat(4) {
            acc = acc xor buf.long
        }
        state = if (acc == 0L) -0x61c8864680b583ebL else acc
    }

    fun nextLong(): Long {
        var z = (state + -0x61c8864680b583ebL).also { state = it }
        z = (z xor (z ushr 30)) * -0x40a7b892e31b1a47L
        z = (z xor (z ushr 27)) * -0x6b2fb644ecceee15L
        return z xor (z ushr 31)
    }

    fun nextInt(bound: Int): Int {
        if (bound <= 1) return 0
        return ((nextLong() ushr 1) % bound.toLong()).toInt()
    }

    fun nextByteMask(): Int = (nextLong() and 0xFFL).toInt()
}

/**
 * 核心图片批量解码、转码、压缩、文字色块混淆/还原与多格式压缩包引擎
 */
object ImageCompressor {

    private val SUPPORTED_IMAGE_EXTENSIONS = setOf(
        "jpg", "jpeg", "png", "webp", "bmp", "heic", "heif"
    )

    private val SUPPORTED_ARCHIVE_EXTENSIONS = setOf(
        "zip", "cbz", "7z", "rar", "cbr", "tar", "gz", "tgz", "bz2", "tbz2", "xz", "txz", "jar", "apk"
    )

    /**
     * 判断某个 Uri 是否为受支持的压缩包格式（ZIP / 7Z / RAR / TAR / GZ / BZ2 / XZ / CBZ / CBR）
     */
    fun isArchiveUri(context: Context, uri: Uri): Boolean {
        val mime = context.contentResolver.getType(uri)?.lowercase(Locale.ROOT) ?: ""
        if (mime.contains("zip") ||
            mime.contains("7z") ||
            mime.contains("rar") ||
            mime.contains("tar") ||
            mime.contains("gzip") ||
            mime.contains("bzip2") ||
            mime.contains("xz") ||
            mime.contains("cbz") ||
            mime.contains("cbr") ||
            mime.contains("compressed")
        ) {
            return true
        }
        val displayName = queryDisplayName(context, uri).lowercase(Locale.ROOT)
        val ext = displayName.substringAfterLast('.', "")
        if (ext in SUPPORTED_ARCHIVE_EXTENSIONS) return true

        val pathSeg = uri.lastPathSegment?.lowercase(Locale.ROOT) ?: ""
        val pathExt = pathSeg.substringAfterLast('.', "")
        return pathExt in SUPPORTED_ARCHIVE_EXTENSIONS
    }

    /**
     * 从一个或多个多格式压缩包（.zip / .7z / .rar / .tar / .tar.gz / .tar.bz2 / .tar.xz / .cbz）中提取所有图片
     */
    suspend fun extractImagesFromArchiveUris(
        context: Context,
        archiveUris: List<Uri>
    ): ArchiveImportSummary = withContext(Dispatchers.IO) {
        val cacheRoot = File(context.cacheDir, "archive_imports").apply {
            if (!exists()) mkdirs()
        }
        val extractedItems = mutableListOf<SelectedImageItem>()
        val archiveNames = mutableListOf<String>()
        var lastError: String? = null

        archiveUris.forEachIndexed { idx, archiveUri ->
            ensureActive()
            val displayName = queryDisplayName(context, archiveUri).ifBlank {
                "archive_${idx + 1}.zip"
            }
            archiveNames.add(displayName)

            val batchFolder = File(cacheRoot, "arc_${System.currentTimeMillis()}_$idx").apply {
                mkdirs()
            }

            val lowerName = displayName.lowercase(Locale.ROOT)
            val mime = context.contentResolver.getType(archiveUri)?.lowercase(Locale.ROOT) ?: ""

            try {
                val items = when {
                    lowerName.endsWith(".7z") || mime.contains("7z") -> {
                        extractSevenZArchive(context, archiveUri, displayName, batchFolder)
                    }
                    lowerName.endsWith(".rar") || lowerName.endsWith(".cbr") || mime.contains("rar") -> {
                        extractRarArchive(context, archiveUri, displayName, batchFolder)
                    }
                    lowerName.endsWith(".tar.gz") || lowerName.endsWith(".tgz") ||
                        (lowerName.endsWith(".gz") && !lowerName.endsWith(".svgz")) || mime.contains("gzip") -> {
                        extractTarStreamArchive(context, archiveUri, displayName, batchFolder, "gz")
                    }
                    lowerName.endsWith(".tar.bz2") || lowerName.endsWith(".tbz2") ||
                        lowerName.endsWith(".bz2") || mime.contains("bzip2") -> {
                        extractTarStreamArchive(context, archiveUri, displayName, batchFolder, "bz2")
                    }
                    lowerName.endsWith(".tar.xz") || lowerName.endsWith(".txz") ||
                        lowerName.endsWith(".xz") || mime.contains("xz") -> {
                        extractTarStreamArchive(context, archiveUri, displayName, batchFolder, "xz")
                    }
                    lowerName.endsWith(".tar") || mime.contains("tar") -> {
                        extractTarStreamArchive(context, archiveUri, displayName, batchFolder, "plain")
                    }
                    else -> {
                        // 默认按 ZIP / CBZ / JAR 处理（支持 UTF-8 与 GBK 双编码自动回退）
                        tryExtractZipWithCharset(context, archiveUri, displayName, batchFolder, Charsets.UTF_8)
                            ?: tryExtractZipWithCharset(context, archiveUri, displayName, batchFolder, Charset.forName("GBK"))
                            ?: emptyList()
                    }
                }
                extractedItems.addAll(items)
            } catch (e: Exception) {
                lastError = e.localizedMessage ?: "部分压缩包解析失败"
            }
        }

        ArchiveImportSummary(
            archiveCount = archiveUris.size,
            extractedImages = extractedItems,
            archiveNames = archiveNames,
            errorNote = lastError
        )
    }

    /**
     * 解析 7z 格式压缩包 (SevenZFile 需要本地 File 随机访问，因此先拷贝至临时文件)
     */
    @Suppress("DEPRECATION")
    private fun extractSevenZArchive(
        context: Context,
        archiveUri: Uri,
        archiveDisplayName: String,
        destFolder: File
    ): List<SelectedImageItem> {
        val items = mutableListOf<SelectedImageItem>()
        val tempFile = File(destFolder, "temp_source.7z")
        try {
            context.contentResolver.openInputStream(archiveUri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return emptyList()

            SevenZFile(tempFile).use { sevenZ ->
                var entry = sevenZ.nextEntry
                var counter = 0
                val buffer = ByteArray(16 * 1024)
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val rawName = entry.name.replace('\\', '/')
                        val simpleName = rawName.substringAfterLast('/')
                        val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                        if (isValidImageEntry(rawName, simpleName, ext)) {
                            counter++
                            val outFile = File(destFolder, "${counter}_${sanitizeFileName(simpleName)}")
                            if (outFile.canonicalPath.startsWith(destFolder.canonicalPath)) {
                                FileOutputStream(outFile).use { fos ->
                                    var len: Int
                                    while (sevenZ.read(buffer).also { len = it } > 0) {
                                        fos.write(buffer, 0, len)
                                    }
                                    fos.flush()
                                }
                                buildSelectedImageIfValid(outFile, simpleName, archiveDisplayName)?.let {
                                    items.add(it)
                                }
                            }
                        }
                    }
                    entry = sevenZ.nextEntry
                }
            }
        } finally {
            tempFile.delete()
        }
        return items
    }

    /**
     * 解析 RAR / CBR 格式压缩包 (Junrar)
     */
    private fun extractRarArchive(
        context: Context,
        archiveUri: Uri,
        archiveDisplayName: String,
        destFolder: File
    ): List<SelectedImageItem> {
        val items = mutableListOf<SelectedImageItem>()
        val tempFile = File(destFolder, "temp_source.rar")
        try {
            context.contentResolver.openInputStream(archiveUri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return emptyList()

            Archive(tempFile).use { rarArchive ->
                var header: FileHeader? = rarArchive.nextFileHeader()
                var counter = 0
                while (header != null) {
                    val currentHeader = header
                    if (!currentHeader.isDirectory) {
                        val rawName = currentHeader.fileName.replace('\\', '/')
                        val simpleName = rawName.substringAfterLast('/')
                        val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                        if (isValidImageEntry(rawName, simpleName, ext)) {
                            counter++
                            val outFile = File(destFolder, "${counter}_${sanitizeFileName(simpleName)}")
                            if (outFile.canonicalPath.startsWith(destFolder.canonicalPath)) {
                                FileOutputStream(outFile).use { fos ->
                                    rarArchive.extractFile(currentHeader, fos)
                                    fos.flush()
                                }
                                buildSelectedImageIfValid(outFile, simpleName, archiveDisplayName)?.let {
                                    items.add(it)
                                }
                            }
                        }
                    }
                    header = rarArchive.nextFileHeader()
                }
            }
        } finally {
            tempFile.delete()
        }
        return items
    }

    /**
     * 解析 TAR / TAR.GZ / TAR.BZ2 / TAR.XZ 流式归档包
     */
    private fun extractTarStreamArchive(
        context: Context,
        archiveUri: Uri,
        archiveDisplayName: String,
        destFolder: File,
        compressionType: String
    ): List<SelectedImageItem> {
        val items = mutableListOf<SelectedImageItem>()
        context.contentResolver.openInputStream(archiveUri)?.use { rawInput ->
            val buffered = BufferedInputStream(rawInput)
            val decompressedStream: InputStream = when (compressionType) {
                "gz" -> GzipCompressorInputStream(buffered)
                "bz2" -> BZip2CompressorInputStream(buffered)
                "xz" -> XZCompressorInputStream(buffered)
                else -> buffered
            }
            TarArchiveInputStream(decompressedStream).use { tarIn ->
                var entry = tarIn.nextEntry
                var counter = 0
                val buffer = ByteArray(16 * 1024)
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val rawName = entry.name.replace('\\', '/')
                        val simpleName = rawName.substringAfterLast('/')
                        val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                        if (isValidImageEntry(rawName, simpleName, ext)) {
                            counter++
                            val outFile = File(destFolder, "${counter}_${sanitizeFileName(simpleName)}")
                            if (outFile.canonicalPath.startsWith(destFolder.canonicalPath)) {
                                FileOutputStream(outFile).use { fos ->
                                    var len: Int
                                    while (tarIn.read(buffer).also { len = it } > 0) {
                                        fos.write(buffer, 0, len)
                                    }
                                    fos.flush()
                                }
                                buildSelectedImageIfValid(outFile, simpleName, archiveDisplayName)?.let {
                                    items.add(it)
                                }
                            }
                        }
                    }
                    entry = tarIn.nextEntry
                }
            }
        }
        return items
    }

    /**
     * 解析 ZIP / CBZ 压缩包（支持 UTF-8 与 GBK 回退）
     */
    private fun tryExtractZipWithCharset(
        context: Context,
        zipUri: Uri,
        zipDisplayName: String,
        destFolder: File,
        charset: Charset
    ): List<SelectedImageItem>? {
        val items = mutableListOf<SelectedImageItem>()
        return try {
            context.contentResolver.openInputStream(zipUri)?.use { rawInput ->
                val zis = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    ZipInputStream(BufferedInputStream(rawInput), charset)
                } else {
                    ZipInputStream(BufferedInputStream(rawInput))
                }

                var entry: ZipEntry? = zis.nextEntry
                var fileCounter = 0
                val buffer = ByteArray(16 * 1024)
                while (entry != null) {
                    val currentEntry = entry
                    if (!currentEntry.isDirectory) {
                        val rawName = currentEntry.name.replace('\\', '/')
                        val simpleName = rawName.substringAfterLast('/')
                        val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)

                        if (isValidImageEntry(rawName, simpleName, ext)) {
                            fileCounter++
                            val outFile = File(destFolder, "${fileCounter}_${sanitizeFileName(simpleName)}")

                            if (outFile.canonicalPath.startsWith(destFolder.canonicalPath)) {
                                FileOutputStream(outFile).use { fos ->
                                    var len: Int
                                    while (zis.read(buffer).also { len = it } > 0) {
                                        fos.write(buffer, 0, len)
                                    }
                                    fos.flush()
                                }
                                buildSelectedImageIfValid(outFile, simpleName, zipDisplayName)?.let {
                                    items.add(it)
                                }
                            }
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
            items
        } catch (e: IllegalArgumentException) {
            null
        } catch (e: Exception) {
            items
        }
    }

    private fun isValidImageEntry(rawName: String, simpleName: String, ext: String): Boolean {
        return !simpleName.startsWith("._") &&
            !rawName.contains("__MACOSX/") &&
            ext in SUPPORTED_IMAGE_EXTENSIONS
    }

    private fun sanitizeFileName(simpleName: String): String {
        return buildString {
            for (ch in simpleName) {
                if (ch.isLetterOrDigit() || ch == '.' || ch == '_' || ch == '-') {
                    append(ch)
                } else {
                    append('_')
                }
            }
        }
    }

    private fun buildSelectedImageIfValid(
        outFile: File,
        simpleName: String,
        archiveDisplayName: String
    ): SelectedImageItem? {
        val boundsOptions = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }
        BitmapFactory.decodeFile(outFile.absolutePath, boundsOptions)
        return if (boundsOptions.outWidth > 0 && boundsOptions.outHeight > 0) {
            SelectedImageItem(
                uri = Uri.fromFile(outFile),
                displayName = simpleName,
                originalSize = outFile.length(),
                mimeType = guessMimeTypeFromName(simpleName),
                width = boundsOptions.outWidth,
                height = boundsOptions.outHeight,
                fromArchiveName = archiveDisplayName
            )
        } else {
            outFile.delete()
            null
        }
    }

    /**
     * 读取选中图片的元数据（文件名、原始字节大小、MIME 类型、原始宽高）
     */
    suspend fun inspectImages(context: Context, uris: List<Uri>): List<SelectedImageItem> =
        withContext(Dispatchers.IO) {
            uris.mapNotNull { uri ->
                runCatching {
                    val resolver = context.contentResolver
                    val name = queryDisplayName(context, uri).ifBlank {
                        "image_${System.currentTimeMillis()}.jpg"
                    }
                    var size = 0L

                    resolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                        if (cursor.moveToFirst()) {
                            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                            if (sizeIndex != -1 && !cursor.isNull(sizeIndex)) {
                                size = cursor.getLong(sizeIndex)
                            }
                        }
                    }

                    if (size <= 0L) {
                        resolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                            size = afd.length.coerceAtLeast(0L)
                        }
                    }

                    val mimeType = resolver.getType(uri) ?: guessMimeTypeFromName(name)

                    val boundsOptions = BitmapFactory.Options().apply {
                        inJustDecodeBounds = true
                    }
                    resolver.openInputStream(uri)?.use { input ->
                        BitmapFactory.decodeStream(input, null, boundsOptions)
                    }

                    SelectedImageItem(
                        uri = uri,
                        displayName = name,
                        originalSize = size,
                        mimeType = mimeType,
                        width = boundsOptions.outWidth.coerceAtLeast(0),
                        height = boundsOptions.outHeight.coerceAtLeast(0)
                    )
                }.getOrNull()
            }
        }

    private fun queryDisplayName(context: Context, uri: Uri): String {
        if (uri.scheme == "file") {
            return uri.lastPathSegment ?: ""
        }
        runCatching {
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx != -1 && !cursor.isNull(idx)) {
                        return cursor.getString(idx)
                    }
                }
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: ""
    }

    /**
     * 批量执行图片处理或直接压入压缩包：
     * - 支持常规逐张保存
     * - 支持在任意模式下开启“直接压入压缩包 (packResultIntoArchive = true)”
     * - 支持在「归档」模式下直接将所选图片打包为 .zip / .cbz / .tar.gz / .tar
     */
    suspend fun processBatch(
        context: Context,
        items: List<SelectedImageItem>,
        config: CompressionConfig,
        onProgress: (completedCount: Int, totalCount: Int, latestResult: CompressionResult) -> Unit
    ): BatchExecutionReport = withContext(Dispatchers.IO) {
        val total = items.size
        val results = ArrayList<CompressionResult>(total)

        val shouldPackIntoArchive = (config.mode == ProcessMode.ARCHIVE_HUB &&
            config.archiveSubMode == ArchiveSubMode.PACK_TO_ARCHIVE) ||
            (config.mode != ProcessMode.ARCHIVE_HUB && config.packResultIntoArchive)

        if (!shouldPackIntoArchive) {
            // 逐张导出到目录或相册
            items.forEachIndexed { index, item ->
                ensureActive()
                val result = if (config.mode == ProcessMode.ARCHIVE_HUB) {
                    exportRawImageDirectly(context, item, config, index)
                } else {
                    processSingleImageToSavedFile(context, item, config, index)
                }
                results.add(result)
                onProgress(index + 1, total, result)
            }
            return@withContext BatchExecutionReport(itemResults = results)
        }

        // ====== 直接把图片（原图或处理后的数据）压入单一压缩包 (.zip / .cbz / .tar.gz / .tar) ======
        val timestamp = SimpleDateFormat("MMdd_HHmmss", Locale.US).format(Date())
        val baseArchiveName = config.customArchiveBaseName.trim().ifBlank {
            when (config.mode) {
                ProcessMode.COMPRESS_TRANSCODE -> "Compressed_$timestamp"
                ProcessMode.OBFUSCATE_ENCRYPT -> "Obfuscated_$timestamp"
                ProcessMode.DEOBFUSCATE_RESTORE -> "Restored_$timestamp"
                ProcessMode.ARCHIVE_HUB -> "Photos_$timestamp"
            }
        }
        val archiveFileName = "${sanitizeFileName(baseArchiveName)}.${config.archiveOutputFormat.extension}"
        val tempArchiveFile = File(context.cacheDir, "pack_tmp_${System.currentTimeMillis()}.${config.archiveOutputFormat.extension}")

        val usedEntryNames = HashSet<String>()

        try {
            FileOutputStream(tempArchiveFile).use { rawFos ->
                val bufferedOut = BufferedOutputStream(rawFos)
                when (config.archiveOutputFormat) {
                    ArchiveOutputFormat.ZIP, ArchiveOutputFormat.CBZ -> {
                        ZipOutputStream(bufferedOut).use { zos ->
                            zos.setLevel(config.archiveCompressionLevel.zipLevel)
                            items.forEachIndexed { index, item ->
                                ensureActive()
                                val prepared = prepareImageBytesForArchive(context, item, config, index)
                                if (prepared.result.isSuccess && prepared.bytes != null) {
                                    val uniqueName = allocateUniqueEntryName(prepared.result.outputName, usedEntryNames)
                                    val entry = ZipEntry(uniqueName).apply {
                                        time = System.currentTimeMillis()
                                    }
                                    zos.putNextEntry(entry)
                                    zos.write(prepared.bytes)
                                    zos.closeEntry()
                                    val updatedRes = prepared.result.copy(
                                        savedPathLabel = "已压入压缩包: $archiveFileName/$uniqueName",
                                        packedIntoArchiveName = archiveFileName
                                    )
                                    results.add(updatedRes)
                                    onProgress(index + 1, total, updatedRes)
                                } else {
                                    results.add(prepared.result)
                                    onProgress(index + 1, total, prepared.result)
                                }
                            }
                            zos.finish()
                        }
                    }

                    ArchiveOutputFormat.SEVEN_Z -> {
                        bufferedOut.close()
                        SevenZOutputFile(tempArchiveFile).use { sevenZOut ->
                            items.forEachIndexed { index, item ->
                                ensureActive()
                                val prepared = prepareImageBytesForArchive(context, item, config, index)
                                if (prepared.result.isSuccess && prepared.bytes != null) {
                                    val uniqueName = allocateUniqueEntryName(prepared.result.outputName, usedEntryNames)
                                    val entry = SevenZArchiveEntry().apply {
                                        setName(uniqueName)
                                        setDirectory(false)
                                        setLastModifiedDate(Date())
                                        setSize(prepared.bytes.size.toLong())
                                    }
                                    sevenZOut.putArchiveEntry(entry)
                                    sevenZOut.write(prepared.bytes)
                                    sevenZOut.closeArchiveEntry()
                                    val updatedRes = prepared.result.copy(
                                        savedPathLabel = "已压入 7Z 包: $archiveFileName/$uniqueName",
                                        packedIntoArchiveName = archiveFileName
                                    )
                                    results.add(updatedRes)
                                    onProgress(index + 1, total, updatedRes)
                                } else {
                                    results.add(prepared.result)
                                    onProgress(index + 1, total, prepared.result)
                                }
                            }
                            sevenZOut.finish()
                        }
                    }

                    ArchiveOutputFormat.TAR, ArchiveOutputFormat.TAR_GZ, ArchiveOutputFormat.TAR_XZ -> {
                        val tarStream = when (config.archiveOutputFormat) {
                            ArchiveOutputFormat.TAR_GZ -> TarArchiveOutputStream(GzipCompressorOutputStream(bufferedOut))
                            ArchiveOutputFormat.TAR_XZ -> TarArchiveOutputStream(XZCompressorOutputStream(bufferedOut))
                            else -> TarArchiveOutputStream(bufferedOut)
                        }
                        tarStream.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX)
                        tarStream.use { tos ->
                            items.forEachIndexed { index, item ->
                                ensureActive()
                                val prepared = prepareImageBytesForArchive(context, item, config, index)
                                if (prepared.result.isSuccess && prepared.bytes != null) {
                                    val uniqueName = allocateUniqueEntryName(prepared.result.outputName, usedEntryNames)
                                    val tarEntry = TarArchiveEntry(uniqueName).apply {
                                        setSize(prepared.bytes.size.toLong())
                                        setModTime(Date())
                                    }
                                    tos.putArchiveEntry(tarEntry)
                                    tos.write(prepared.bytes)
                                    tos.closeArchiveEntry()
                                    val updatedRes = prepared.result.copy(
                                        savedPathLabel = "已压入归档包: $archiveFileName/$uniqueName",
                                        packedIntoArchiveName = archiveFileName
                                    )
                                    results.add(updatedRes)
                                    onProgress(index + 1, total, updatedRes)
                                } else {
                                    results.add(prepared.result)
                                    onProgress(index + 1, total, prepared.result)
                                }
                            }
                            tos.finish()
                        }
                    }
                }
            }

            // 将生成的临时压缩包写入用户自定义目录或系统 Download/CompressedArchives 目录
            val archiveSize = tempArchiveFile.length()
            val (savedArchiveUri, archivePathLabel) = saveArchiveFileToTarget(
                context = context,
                sourceFile = tempArchiveFile,
                fileName = archiveFileName,
                mimeType = config.archiveOutputFormat.mimeType,
                customTreeUri = config.customTreeUri
            )

            // 更新每张图片的最终保存位置描述
            val finalResults = results.map { res ->
                if (res.isSuccess) {
                    res.copy(savedPathLabel = "$archivePathLabel (内含 ${res.outputName})")
                } else {
                    res
                }
            }

            BatchExecutionReport(
                itemResults = finalResults,
                archiveSavedUri = savedArchiveUri,
                archiveFileName = archiveFileName,
                archiveSavedPathLabel = archivePathLabel,
                archiveTotalBytes = archiveSize
            )
        } finally {
            tempArchiveFile.delete()
        }
    }

    private data class PreparedArchiveEntry(
        val result: CompressionResult,
        val bytes: ByteArray?
    )

    private fun allocateUniqueEntryName(desiredName: String, used: MutableSet<String>): String {
        if (used.add(desiredName)) return desiredName
        val stem = desiredName.substringBeforeLast('.')
        val ext = desiredName.substringAfterLast('.', "jpg")
        var counter = 2
        while (true) {
            val candidate = "${stem}_$counter.$ext"
            if (used.add(candidate)) return candidate
            counter++
        }
    }

    /**
     * 为压缩包打包准备单张图片的字节数组（若在归档页签则直接读取原图字节；若在压缩/混淆/还原页签则先执行对应处理再压入压缩包）
     */
    private fun prepareImageBytesForArchive(
        context: Context,
        item: SelectedImageItem,
        config: CompressionConfig,
        sequenceIndex: Int
    ): PreparedArchiveEntry {
        if (config.mode == ProcessMode.ARCHIVE_HUB) {
            return try {
                val rawBytes = context.contentResolver.openInputStream(item.uri)?.use { it.readBytes() }
                    ?: return PreparedArchiveEntry(
                        result = CompressionResult(
                            source = item,
                            isSuccess = false,
                            mode = config.mode,
                            errorMessage = "无法读取原图字节流"
                        ),
                        bytes = null
                    )
                val outName = item.displayName.ifBlank { "image_${sequenceIndex + 1}.jpg" }
                PreparedArchiveEntry(
                    result = CompressionResult(
                        source = item,
                        isSuccess = true,
                        mode = config.mode,
                        outputUri = item.uri,
                        outputName = outName,
                        compressedSize = rawBytes.size.toLong(),
                        outputWidth = item.width,
                        outputHeight = item.height,
                        outputFormat = OutputFormat.PNG
                    ),
                    bytes = rawBytes
                )
            } catch (e: Exception) {
                PreparedArchiveEntry(
                    result = CompressionResult(
                        source = item,
                        isSuccess = false,
                        mode = config.mode,
                        errorMessage = e.localizedMessage ?: "读取图片失败"
                    ),
                    bytes = null
                )
            }
        }

        // 在压缩 / 混淆 / 还原模式下开启“直接压入压缩包”：先在内存完成处理并生成缩略预览缓存，再返回字节流写入压缩包
        return encodeSingleImageInMemory(context, item, config, sequenceIndex, cachePreview = true)
    }

    /**
     * 将生成的压缩包文件写入自定义 SAF 目录或系统 Download/CompressedArchives 目录
     */
    private fun saveArchiveFileToTarget(
        context: Context,
        sourceFile: File,
        fileName: String,
        mimeType: String,
        customTreeUri: Uri?
    ): Pair<Uri, String> {
        if (customTreeUri != null) {
            val treeDir = DocumentFile.fromTreeUri(context, customTreeUri)
                ?: throw IllegalStateException("无法访问所选自定义目录，请重新授权")
            val finalName = if (treeDir.findFile(fileName) != null) {
                val stem = fileName.substringBefore('.')
                val ext = fileName.substringAfter('.')
                "${stem}_${System.currentTimeMillis() % 10000}.$ext"
            } else {
                fileName
            }
            val targetFile = treeDir.createFile(mimeType, finalName)
                ?: throw IllegalStateException("无法在自定义目录创建压缩包: $finalName")
            context.contentResolver.openOutputStream(targetFile.uri, "wt")?.use { out ->
                FileInputStream(sourceFile).use { input ->
                    input.copyTo(out)
                }
                out.flush()
            } ?: throw IllegalStateException("无法打开压缩包输出流")
            val dirName = treeDir.name ?: "自定义目录"
            return targetFile.uri to "$dirName/$finalName"
        }

        val resolver = context.contentResolver
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativePath = "${Environment.DIRECTORY_DOWNLOADS}/CompressedArchives"
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.RELATIVE_PATH, relativePath)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("无法在系统下载目录创建压缩包记录")

            resolver.openOutputStream(uri)?.use { out ->
                FileInputStream(sourceFile).use { input ->
                    input.copyTo(out)
                }
                out.flush()
            } ?: throw IllegalStateException("无法写入系统下载目录输出流")

            val completeValues = ContentValues().apply {
                put(MediaStore.Downloads.IS_PENDING, 0)
            }
            resolver.update(uri, completeValues, null, null)
            return uri to "Download/CompressedArchives/$fileName"
        } else {
            @Suppress("DEPRECATION")
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val archiveDir = File(downloadsDir, "CompressedArchives").apply {
                if (!exists()) mkdirs()
            }
            val outFile = File(archiveDir, fileName)
            FileInputStream(sourceFile).use { input ->
                FileOutputStream(outFile).use { out ->
                    input.copyTo(out)
                    out.flush()
                }
            }
            return Uri.fromFile(outFile) to "Download/CompressedArchives/${outFile.name}"
        }
    }

    /**
     * 在「归档 -> 解压」模式下，直接将图片原始字节无损导出到目标目录
     */
    private fun exportRawImageDirectly(
        context: Context,
        item: SelectedImageItem,
        config: CompressionConfig,
        sequenceIndex: Int
    ): CompressionResult {
        return try {
            val rawBytes = context.contentResolver.openInputStream(item.uri)?.use { it.readBytes() }
                ?: return CompressionResult(
                    source = item,
                    isSuccess = false,
                    mode = ProcessMode.ARCHIVE_HUB,
                    errorMessage = "无法读取源文件字节流"
                )

            val outputFileName = item.displayName.ifBlank { "extracted_${sequenceIndex + 1}.jpg" }
            val mimeType = item.mimeType.ifBlank { guessMimeTypeFromName(outputFileName) }

            val (savedUri, locationDesc) = if (config.customTreeUri != null) {
                saveToCustomDocumentTree(
                    context = context,
                    treeUri = config.customTreeUri,
                    fileName = outputFileName,
                    mimeType = mimeType,
                    bytes = rawBytes
                )
            } else {
                saveToSystemGallery(
                    context = context,
                    fileName = outputFileName,
                    mimeType = mimeType,
                    bytes = rawBytes
                )
            }

            CompressionResult(
                source = item,
                isSuccess = true,
                mode = ProcessMode.ARCHIVE_HUB,
                outputUri = savedUri,
                outputName = outputFileName,
                compressedSize = rawBytes.size.toLong(),
                outputWidth = item.width,
                outputHeight = item.height,
                outputFormat = OutputFormat.PNG,
                savedPathLabel = locationDesc
            )
        } catch (e: Exception) {
            CompressionResult(
                source = item,
                isSuccess = false,
                mode = ProcessMode.ARCHIVE_HUB,
                errorMessage = e.localizedMessage ?: "解压导出失败"
            )
        }
    }

    /**
     * 处理单张图片并保存到目标目录或系统相册
     */
    private fun processSingleImageToSavedFile(
        context: Context,
        item: SelectedImageItem,
        config: CompressionConfig,
        sequenceIndex: Int
    ): CompressionResult {
        val prepared = encodeSingleImageInMemory(context, item, config, sequenceIndex, cachePreview = false)
        if (!prepared.result.isSuccess || prepared.bytes == null) {
            return prepared.result
        }

        return try {
            val effectiveFormat = prepared.result.outputFormat
            val outputFileName = prepared.result.outputName
            val (savedUri, locationDesc) = if (config.customTreeUri != null) {
                saveToCustomDocumentTree(
                    context = context,
                    treeUri = config.customTreeUri,
                    fileName = outputFileName,
                    mimeType = effectiveFormat.mimeType,
                    bytes = prepared.bytes
                )
            } else {
                saveToSystemGallery(
                    context = context,
                    fileName = outputFileName,
                    mimeType = effectiveFormat.mimeType,
                    bytes = prepared.bytes
                )
            }
            prepared.result.copy(
                outputUri = savedUri,
                savedPathLabel = locationDesc
            )
        } catch (e: Exception) {
            prepared.result.copy(
                isSuccess = false,
                errorMessage = e.localizedMessage ?: "写入文件失败"
            )
        }
    }

    /**
     * 在内存中完成采样解码、EXIF 校正、尺寸缩放、文字色块混淆/还原与编码
     */
    private fun encodeSingleImageInMemory(
        context: Context,
        item: SelectedImageItem,
        config: CompressionConfig,
        sequenceIndex: Int,
        cachePreview: Boolean
    ): PreparedArchiveEntry {
        return try {
            val resolver = context.contentResolver
            val isObfuscationFlow = config.mode == ProcessMode.OBFUSCATE_ENCRYPT ||
                config.mode == ProcessMode.DEOBFUSCATE_RESTORE

            if (isObfuscationFlow && config.obfuscationKey.isBlank()) {
                return PreparedArchiveEntry(
                    result = CompressionResult(
                        source = item,
                        isSuccess = false,
                        mode = config.mode,
                        errorMessage = "请输入用于加密混淆或解密还原的文字口令"
                    ),
                    bytes = null
                )
            }

            val maxTargetDim = if (config.mode == ProcessMode.DEOBFUSCATE_RESTORE) {
                null
            } else {
                config.resolutionOption.maxDimensionPx
            }

            val sampleSize = if (config.mode == ProcessMode.DEOBFUSCATE_RESTORE) {
                1
            } else {
                calculateInSampleSize(
                    srcWidth = item.width,
                    srcHeight = item.height,
                    maxDimension = maxTargetDim
                )
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
                inScaled = false
            }

            val rawBitmap = resolver.openInputStream(item.uri)?.use { input ->
                BitmapFactory.decodeStream(input, null, decodeOptions)
            } ?: return PreparedArchiveEntry(
                result = CompressionResult(
                    source = item,
                    isSuccess = false,
                    mode = config.mode,
                    errorMessage = "无法解码源图片流"
                ),
                bytes = null
            )

            val orientedBitmap = if (config.mode == ProcessMode.DEOBFUSCATE_RESTORE) {
                rawBitmap
            } else {
                val exifOrientation = resolver.openInputStream(item.uri)?.use { exifStream ->
                    runCatching {
                        val exif = ExifInterface(exifStream)
                        exif.getAttributeInt(
                            ExifInterface.TAG_ORIENTATION,
                            ExifInterface.ORIENTATION_NORMAL
                        )
                    }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
                } ?: ExifInterface.ORIENTATION_NORMAL

                applyExifOrientation(rawBitmap, exifOrientation).also {
                    if (it !== rawBitmap) rawBitmap.recycle()
                }
            }

            val scaledBitmap = if (config.mode == ProcessMode.DEOBFUSCATE_RESTORE) {
                orientedBitmap
            } else {
                scaleDownIfNeeded(orientedBitmap, maxTargetDim).also {
                    if (it !== orientedBitmap) orientedBitmap.recycle()
                }
            }

            val effectiveOutputFormat = when (config.mode) {
                ProcessMode.OBFUSCATE_ENCRYPT -> OutputFormat.PNG
                ProcessMode.DEOBFUSCATE_RESTORE -> config.format
                ProcessMode.COMPRESS_TRANSCODE -> config.format
                ProcessMode.ARCHIVE_HUB -> OutputFormat.PNG
            }

            val processedBitmap = when (config.mode) {
                ProcessMode.OBFUSCATE_ENCRYPT -> {
                    transformImageBlocks(
                        source = scaledBitmap,
                        secretKey = config.obfuscationKey,
                        blockSize = config.blockGridSize.blockPx,
                        isEncrypt = true
                    ).also {
                        if (it !== scaledBitmap) scaledBitmap.recycle()
                    }
                }
                ProcessMode.DEOBFUSCATE_RESTORE -> {
                    transformImageBlocks(
                        source = scaledBitmap,
                        secretKey = config.obfuscationKey,
                        blockSize = config.blockGridSize.blockPx,
                        isEncrypt = false
                    ).also {
                        if (it !== scaledBitmap) scaledBitmap.recycle()
                    }
                }
                else -> scaledBitmap
            }

            val finalBitmap = if (effectiveOutputFormat == OutputFormat.JPEG && processedBitmap.hasAlpha()) {
                flattenAlphaOnWhite(processedBitmap).also {
                    if (it !== processedBitmap) processedBitmap.recycle()
                }
            } else {
                processedBitmap
            }

            val outWidth = finalBitmap.width
            val outHeight = finalBitmap.height

            val encodedBytes = ByteArrayOutputStream().use { buffer ->
                val compressFormat = resolveBitmapCompressFormat(effectiveOutputFormat)
                val effectiveQuality = when (effectiveOutputFormat) {
                    OutputFormat.JPEG, OutputFormat.WEBP_LOSSY -> config.quality.coerceIn(10, 100)
                    OutputFormat.WEBP_LOSSLESS, OutputFormat.PNG -> 100
                }
                val ok = finalBitmap.compress(compressFormat, effectiveQuality, buffer)
                finalBitmap.recycle()
                if (!ok) {
                    return PreparedArchiveEntry(
                        result = CompressionResult(
                            source = item,
                            isSuccess = false,
                            mode = config.mode,
                            errorMessage = "编码为 ${effectiveOutputFormat.label} 失败"
                        ),
                        bytes = null
                    )
                }
                buffer.toByteArray()
            }

            val baseName = item.displayName.substringBeforeLast('.').ifBlank { "image_$sequenceIndex" }
            val modePrefix = when (config.mode) {
                ProcessMode.COMPRESS_TRANSCODE -> "COMP_"
                ProcessMode.OBFUSCATE_ENCRYPT -> "OBF_"
                ProcessMode.DEOBFUSCATE_RESTORE -> "RESTORED_"
                ProcessMode.ARCHIVE_HUB -> "ARC_"
            }
            val outputFileName = "${modePrefix}${baseName}.${effectiveOutputFormat.extension}"

            // 如果直接压入压缩包，写入一个轻量预览缓存文件以便列表展示前后对比缩略图
            val previewUri = if (cachePreview) {
                runCatching {
                    val previewDir = File(context.cacheDir, "packed_previews").apply {
                        if (!exists()) mkdirs()
                    }
                    val previewFile = File(previewDir, "${System.currentTimeMillis()}_${sequenceIndex}_$outputFileName")
                    FileOutputStream(previewFile).use { it.write(encodedBytes) }
                    Uri.fromFile(previewFile)
                }.getOrNull()
            } else {
                null
            }

            PreparedArchiveEntry(
                result = CompressionResult(
                    source = item,
                    isSuccess = true,
                    mode = config.mode,
                    outputUri = previewUri,
                    outputName = outputFileName,
                    compressedSize = encodedBytes.size.toLong(),
                    outputWidth = outWidth,
                    outputHeight = outHeight,
                    outputFormat = effectiveOutputFormat
                ),
                bytes = encodedBytes
            )
        } catch (e: Exception) {
            PreparedArchiveEntry(
                result = CompressionResult(
                    source = item,
                    isSuccess = false,
                    mode = config.mode,
                    errorMessage = e.localizedMessage ?: "处理出错"
                ),
                bytes = null
            )
        }
    }

    /**
     * 核心可逆色块混淆与无损还原算法
     */
    private fun transformImageBlocks(
        source: Bitmap,
        secretKey: String,
        blockSize: Int,
        isEncrypt: Boolean
    ): Bitmap {
        val width = source.width
        val height = source.height
        val totalPixels = width * height
        val srcPixels = IntArray(totalPixels)
        val dstPixels = IntArray(totalPixels)
        source.getPixels(srcPixels, 0, width, 0, 0, width, height)

        val bSize = blockSize.coerceIn(4, 128)
        val fullCols = width / bSize
        val fullRows = height / bSize
        val remW = width % bSize
        val remH = height % bSize

        // 区域 A：主网格色块
        val mainBlockCount = fullCols * fullRows
        if (mainBlockCount > 0) {
            val prng = KeySeededRandom(secretKey, "MAIN_${width}x${height}_$bSize")
            val perm = generatePermutation(mainBlockCount, prng)
            val orientations = IntArray(mainBlockCount) { prng.nextInt(8) }
            val dR = IntArray(mainBlockCount) { prng.nextByteMask() }
            val dG = IntArray(mainBlockCount) { prng.nextByteMask() }
            val dB = IntArray(mainBlockCount) { prng.nextByteMask() }

            for (srcIdx in 0 until mainBlockCount) {
                val dstIdx = perm[srcIdx]
                val orient = orientations[srcIdx]
                val rShift = dR[srcIdx]
                val gShift = dG[srcIdx]
                val bShift = dB[srcIdx]

                val srcCol = srcIdx % fullCols
                val srcRow = srcIdx / fullCols
                val dstCol = dstIdx % fullCols
                val dstRow = dstIdx / fullCols

                val srcStartX = srcCol * bSize
                val srcStartY = srcRow * bSize
                val dstStartX = dstCol * bSize
                val dstStartY = dstRow * bSize

                for (localY in 0 until bSize) {
                    for (localX in 0 until bSize) {
                        val (tx, ty) = transformSquareCoord(localX, localY, bSize, orient)
                        val origPos = (srcStartY + localY) * width + (srcStartX + localX)
                        val obfPos = (dstStartY + ty) * width + (dstStartX + tx)

                        if (isEncrypt) {
                            dstPixels[obfPos] = shiftPixelColor(srcPixels[origPos], rShift, gShift, bShift, true)
                        } else {
                            dstPixels[origPos] = shiftPixelColor(srcPixels[obfPos], rShift, gShift, bShift, false)
                        }
                    }
                }
            }
        }

        // 区域 B：右侧边缘余数色块
        if (remW > 0 && fullRows > 0) {
            val prng = KeySeededRandom(secretKey, "RIGHT_${width}x${height}_$bSize")
            val perm = generatePermutation(fullRows, prng)
            val flipFlags = IntArray(fullRows) { prng.nextInt(4) }
            val dR = IntArray(fullRows) { prng.nextByteMask() }
            val dG = IntArray(fullRows) { prng.nextByteMask() }
            val dB = IntArray(fullRows) { prng.nextByteMask() }
            val startX = fullCols * bSize

            for (srcRow in 0 until fullRows) {
                val dstRow = perm[srcRow]
                val flip = flipFlags[srcRow]
                val rShift = dR[srcRow]
                val gShift = dG[srcRow]
                val bShift = dB[srcRow]

                val srcStartY = srcRow * bSize
                val dstStartY = dstRow * bSize

                for (localY in 0 until bSize) {
                    for (localX in 0 until remW) {
                        val tx = if ((flip and 1) != 0) (remW - 1 - localX) else localX
                        val ty = if ((flip and 2) != 0) (bSize - 1 - localY) else localY
                        val origPos = (srcStartY + localY) * width + (startX + localX)
                        val obfPos = (dstStartY + ty) * width + (startX + tx)

                        if (isEncrypt) {
                            dstPixels[obfPos] = shiftPixelColor(srcPixels[origPos], rShift, gShift, bShift, true)
                        } else {
                            dstPixels[origPos] = shiftPixelColor(srcPixels[obfPos], rShift, gShift, bShift, false)
                        }
                    }
                }
            }
        }

        // 区域 C：底部边缘余数色块
        if (remH > 0 && fullCols > 0) {
            val prng = KeySeededRandom(secretKey, "BOTTOM_${width}x${height}_$bSize")
            val perm = generatePermutation(fullCols, prng)
            val flipFlags = IntArray(fullCols) { prng.nextInt(4) }
            val dR = IntArray(fullCols) { prng.nextByteMask() }
            val dG = IntArray(fullCols) { prng.nextByteMask() }
            val dB = IntArray(fullCols) { prng.nextByteMask() }
            val startY = fullRows * bSize

            for (srcCol in 0 until fullCols) {
                val dstCol = perm[srcCol]
                val flip = flipFlags[srcCol]
                val rShift = dR[srcCol]
                val gShift = dG[srcCol]
                val bShift = dB[srcCol]

                val srcStartX = srcCol * bSize
                val dstStartX = dstCol * bSize

                for (localY in 0 until remH) {
                    for (localX in 0 until bSize) {
                        val tx = if ((flip and 1) != 0) (bSize - 1 - localX) else localX
                        val ty = if ((flip and 2) != 0) (remH - 1 - localY) else localY
                        val origPos = (startY + localY) * width + (srcStartX + localX)
                        val obfPos = (startY + ty) * width + (dstStartX + tx)

                        if (isEncrypt) {
                            dstPixels[obfPos] = shiftPixelColor(srcPixels[origPos], rShift, gShift, bShift, true)
                        } else {
                            dstPixels[origPos] = shiftPixelColor(srcPixels[obfPos], rShift, gShift, bShift, false)
                        }
                    }
                }
            }
        }

        // 区域 D：右下角残余块
        if (remW > 0 && remH > 0) {
            val cornerCount = remW * remH
            val prng = KeySeededRandom(secretKey, "CORNER_${width}x${height}_$bSize")
            val perm = generatePermutation(cornerCount, prng)
            val rShift = prng.nextByteMask()
            val gShift = prng.nextByteMask()
            val bShift = prng.nextByteMask()
            val startX = fullCols * bSize
            val startY = fullRows * bSize

            for (idx in 0 until cornerCount) {
                val dstIdx = perm[idx]
                val origX = startX + (idx % remW)
                val origY = startY + (idx / remW)
                val obfX = startX + (dstIdx % remW)
                val obfY = startY + (dstIdx / remW)

                val origPos = origY * width + origX
                val obfPos = obfY * width + obfX

                if (isEncrypt) {
                    dstPixels[obfPos] = shiftPixelColor(srcPixels[origPos], rShift, gShift, bShift, true)
                } else {
                    dstPixels[origPos] = shiftPixelColor(srcPixels[obfPos], rShift, gShift, bShift, false)
                }
            }
        }

        val outBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        outBitmap.setPixels(dstPixels, 0, width, 0, 0, width, height)
        return outBitmap
    }

    private fun generatePermutation(count: Int, prng: KeySeededRandom): IntArray {
        val arr = IntArray(count) { it }
        for (i in count - 1 downTo 1) {
            val j = prng.nextInt(i + 1)
            val tmp = arr[i]
            arr[i] = arr[j]
            arr[j] = tmp
        }
        return arr
    }

    private fun transformSquareCoord(x: Int, y: Int, size: Int, orient: Int): Pair<Int, Int> {
        val last = size - 1
        return when (orient and 7) {
            0 -> x to y
            1 -> (last - y) to x
            2 -> (last - x) to (last - y)
            3 -> y to (last - x)
            4 -> (last - x) to y
            5 -> x to (last - y)
            6 -> y to x
            else -> (last - y) to (last - x)
        }
    }

    private fun shiftPixelColor(pixel: Int, dR: Int, dG: Int, dB: Int, isEncrypt: Boolean): Int {
        val r = (pixel shr 16) and 0xFF
        val g = (pixel shr 8) and 0xFF
        val b = pixel and 0xFF

        val nr: Int
        val ng: Int
        val nb: Int
        if (isEncrypt) {
            nr = (r + dR) and 0xFF
            ng = (g + dG) and 0xFF
            nb = (b + dB) and 0xFF
        } else {
            nr = (r - dR) and 0xFF
            ng = (g - dG) and 0xFF
            nb = (b - dB) and 0xFF
        }
        return (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
    }

    @Suppress("DEPRECATION")
    private fun resolveBitmapCompressFormat(format: OutputFormat): Bitmap.CompressFormat {
        return when (format) {
            OutputFormat.JPEG -> Bitmap.CompressFormat.JPEG
            OutputFormat.PNG -> Bitmap.CompressFormat.PNG
            OutputFormat.WEBP_LOSSY -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Bitmap.CompressFormat.WEBP_LOSSY
                } else {
                    Bitmap.CompressFormat.WEBP
                }
            }
            OutputFormat.WEBP_LOSSLESS -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Bitmap.CompressFormat.WEBP_LOSSLESS
                } else {
                    Bitmap.CompressFormat.WEBP
                }
            }
        }
    }

    private fun saveToCustomDocumentTree(
        context: Context,
        treeUri: Uri,
        fileName: String,
        mimeType: String,
        bytes: ByteArray
    ): Pair<Uri, String> {
        val treeDir = DocumentFile.fromTreeUri(context, treeUri)
            ?: throw IllegalStateException("无法访问所选自定义目录，请重新授权选择目录")

        val finalName = if (treeDir.findFile(fileName) != null) {
            val stem = fileName.substringBeforeLast('.')
            val ext = fileName.substringAfterLast('.')
            "${stem}_${System.currentTimeMillis() % 100000}.$ext"
        } else {
            fileName
        }

        val targetFile = treeDir.createFile(mimeType, finalName)
            ?: throw IllegalStateException("无法在所选目录创建文件: $finalName")

        context.contentResolver.openOutputStream(targetFile.uri, "wt")?.use { output ->
            output.write(bytes)
            output.flush()
        } ?: throw IllegalStateException("无法打开输出流写入文件")

        val dirName = treeDir.name ?: "自定义目录"
        return targetFile.uri to "$dirName/$finalName"
    }

    private fun saveToSystemGallery(
        context: Context,
        fileName: String,
        mimeType: String,
        bytes: ByteArray
    ): Pair<Uri, String> {
        val resolver = context.contentResolver
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativePath = "${Environment.DIRECTORY_PICTURES}/Compressed"
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, mimeType)
                put(MediaStore.Images.Media.RELATIVE_PATH, relativePath)
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("无法创建系统相册 MediaStore 记录")

            resolver.openOutputStream(uri)?.use { out ->
                out.write(bytes)
                out.flush()
            } ?: throw IllegalStateException("无法写入系统相册输出流")

            val completeValues = ContentValues().apply {
                put(MediaStore.Images.Media.IS_PENDING, 0)
            }
            resolver.update(uri, completeValues, null, null)
            return uri to "Pictures/Compressed/$fileName"
        } else {
            @Suppress("DEPRECATION")
            val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
            val compressedDir = File(picturesDir, "Compressed").apply {
                if (!exists()) mkdirs()
            }
            val outFile = File(compressedDir, fileName)
            FileOutputStream(outFile).use { out ->
                out.write(bytes)
                out.flush()
            }
            @Suppress("DEPRECATION")
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DATA, outFile.absolutePath)
                put(MediaStore.Images.Media.MIME_TYPE, mimeType)
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: Uri.fromFile(outFile)
            return uri to "Pictures/Compressed/${outFile.name}"
        }
    }

    private fun calculateInSampleSize(srcWidth: Int, srcHeight: Int, maxDimension: Int?): Int {
        if (srcWidth <= 0 || srcHeight <= 0) return 1
        val targetMax = maxDimension ?: 4096
        var inSampleSize = 1
        val longestSide = max(srcWidth, srcHeight)
        if (longestSide > targetMax) {
            val halfLongest = longestSide / 2
            while ((halfLongest / inSampleSize) >= targetMax) {
                inSampleSize *= 2
            }
        }
        return inSampleSize.coerceAtLeast(1)
    }

    private fun applyExifOrientation(bitmap: Bitmap, orientation: Int): Bitmap {
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.preScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.preScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> {
                matrix.postRotate(90f)
                matrix.preScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_TRANSVERSE -> {
                matrix.postRotate(270f)
                matrix.preScale(-1f, 1f)
            }
            else -> return bitmap
        }
        return runCatching {
            Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        }.getOrDefault(bitmap)
    }

    private fun scaleDownIfNeeded(bitmap: Bitmap, maxDimension: Int?): Bitmap {
        if (maxDimension == null || maxDimension <= 0) return bitmap
        val width = bitmap.width
        val height = bitmap.height
        val longest = max(width, height)
        if (longest <= maxDimension) return bitmap

        val ratio = maxDimension.toFloat() / longest.toFloat()
        val targetWidth = (width * ratio).roundToInt().coerceAtLeast(1)
        val targetHeight = (height * ratio).roundToInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
    }

    private fun flattenAlphaOnWhite(source: Bitmap): Bitmap {
        val result = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.drawColor(Color.WHITE)
        canvas.drawBitmap(source, 0f, 0f, null)
        return result
    }

    private fun guessMimeTypeFromName(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        return when (ext) {
            "png" -> "image/png"
            "webp" -> "image/webp"
            "heic", "heif" -> "image/heic"
            "bmp" -> "image/bmp"
            else -> "image/jpeg"
        }
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0L) return "0 KB"
        val kb = bytes / 1024.0
        return if (kb < 1024.0) {
            String.format(Locale.US, "%.1f KB", kb)
        } else {
            val mb = kb / 1024.0
            String.format(Locale.US, "%.2f MB", mb)
        }
    }
}
