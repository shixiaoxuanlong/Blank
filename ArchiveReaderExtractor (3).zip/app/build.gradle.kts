plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.imagecompressor"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.archivereader"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "2.1.0"

        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "/META-INF/DEPENDENCIES"
            excludes += "/META-INF/LICENSE*"
            excludes += "/META-INF/NOTICE*"
        }
    }
}

dependencies {
    // AndroidX 与 Kotlin 核心库
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.3")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Jetpack Compose BOM 与 Material 3 组件（含动画与扩展图标）
    val composeBom = platform("androidx.compose:compose-bom:2024.06.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    // Coil 图片异步加载
    implementation("io.coil-kt:coil-compose:2.6.0")

    // ExifInterface（自动纠正图片旋转方向）
    implementation("androidx.exifinterface:exifinterface:1.3.7")

    // DocumentFile（通过 SAF 自定义目录写入图片或压缩包）
    implementation("androidx.documentfile:documentfile:1.0.1")

    // 多格式压缩包支持：Apache Commons Compress (ZIP / 7Z / TAR / GZ / BZ2 / XZ / CBZ) + XZ + Junrar (RAR)
    implementation("org.apache.commons:commons-compress:1.26.1")
    implementation("org.tukaani:xz:1.9")
    implementation("com.github.junrar:junrar:7.5.5")

    debugImplementation("androidx.compose.ui:ui-tooling")
}
