# Android 批量图片压缩与解码转码应用 (Kotlin + Jetpack Compose)

## 目录结构
- `settings.gradle.kts`：工程模块与仓库配置
- `build.gradle.kts`：根工程插件版本配置
- `gradle.properties`：Gradle 与 AndroidX 属性配置
- `app/build.gradle.kts`：应用模块依赖与 Compose 配置（支持 API 26+）
- `app/src/main/AndroidManifest.xml`：应用清单文件
- `app/src/main/java/com/example/imagecompressor/ImageCompressor.kt`：核心图片批量采样解码、EXIF 旋转修复、分辨率缩放、格式互转压缩及目录存储工具类
- `app/src/main/java/com/example/imagecompressor/MainActivity.kt`：Material 3 主界面（批量选图、自定义存储目录选择、格式/画质/尺寸配置、实时进度与前后对比列表）

## 使用方法
1. 解压本压缩包后，使用 Android Studio 直接打开 `AndroidImageCompressor` 文件夹（或将 `app/src/main` 下的源码与 `app/build.gradle.kts` 复制到你现有的 Android Studio 工程中）。
2. 等待 Gradle Sync 完成，连接真机或模拟器（Android 8.0 / API 26 及以上）即可编译运行。
