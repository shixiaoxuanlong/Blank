package com.example.imagecompressor

import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import androidx.exifinterface.media.ExifInterface
import com.github.junrar.Archive
import com.github.junrar.rarfile.FileHeader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import net.lingala.zip4j.ZipFile
import net.lingala.zip4j.exception.ZipException
import net.lingala.zip4j.model.ZipParameters
import net.lingala.zip4j.model.enums.AesKeyStrength
import net.lingala.zip4j.model.enums.CompressionLevel
import net.lingala.zip4j.model.enums.CompressionMethod
import net.lingala.zip4j.model.enums.EncryptionMethod
import org.apache.commons.compress.PasswordRequiredException
import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorOutputStream
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.charset.Charset
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * 底部导航栏五大工作空间：
 * 1. COMPRESS_TRANSCODE：画质压缩、尺寸缩放与格式转码
 * 2. OBFUSCATE_ENCRYPT：口令色块加密（自动写入粒度标记）
 * 3. DEOBFUSCATE_RESTORE：口令无损还原（自动识别文件名中的粒度标记）
 * 4. ARCHIVE_HUB：多格式压缩包解压与加密打包（支持 AES-256 密码）
 * 5. ARCHIVE_READER：独立压缩包图片阅读器（支持密码解锁、条漫连读、翻页缩放、口令实时解密预览）
 */
enum class ProcessMode(
    val shortTitle: String,
    val fullTitle: String,
    val subtitle: String
) {
    COMPRESS_TRANSCODE(
        shortTitle = "压缩",
        fullTitle = "画质压缩",
        subtitle = "转码与尺寸缩放"
    ),
    OBFUSCATE_ENCRYPT(
        shortTitle = "混淆",
        fullTitle = "色块混淆",
        subtitle = "口令像素加密"
    ),
    DEOBFUSCATE_RESTORE(
        shortTitle = "还原",
        fullTitle = "无损还原",
        subtitle = "口令逆向还原"
    ),
    ARCHIVE_HUB(
        shortTitle = "归档",
        fullTitle = "归档中心",
        subtitle = "加密打包与解压"
    ),
    ARCHIVE_READER(
        shortTitle = "阅读",
        fullTitle = "归档阅读",
        subtitle = "直看加密包与图集"
    )
}

/**
 * 归档中心子模式
 */
enum class ArchiveSubMode(val label: String, val desc: String) {
    PACK_TO_ARCHIVE(
        label = "打包归档",
        desc = "封装为压缩包（支持密码）"
    ),
    EXTRACT_FROM_ARCHIVE(
        label = "解压提取",
        desc = "提取并导出图片（支持密码）"
    )
}

/**
 * 阅读器翻页模式
 */
enum class ReaderLayoutMode(val label: String) {
    VERTICAL_STRIP("条漫连读"),
    HORIZONTAL_PAGER("左右翻页")
}

/**
 * 批量重命名与序号模板
 */
enum class RenameTemplate(val label: String, val shortLabel: String) {
    KEEP_ORIGINAL("保留原名", "原文件名"),
    PREFIX_INDEX("前缀 + 序号 (001)", "前缀+序号"),
    DATE_INDEX("日期 + 序号 (001)", "日期+序号")
}

/**
 * 目标压缩包格式
 */
enum class ArchiveOutputFormat(
    val label: String,
    val shortLabel: String,
    val extension: String,
    val mimeType: String,
    val description: String,
    val supportsPassword: Boolean
) {
    ZIP(
        label = "ZIP (.zip)",
        shortLabel = "ZIP",
        extension = "zip",
        mimeType = "application/zip",
        description = "通用格式，支持 AES-256 密码加密",
        supportsPassword = true
    ),
    SEVEN_Z(
        label = "7Z (.7z)",
        shortLabel = "7Z",
        extension = "7z",
        mimeType = "application/x-7z-compressed",
        description = "LZMA2 高压缩比归档",
        supportsPassword = false
    ),
    CBZ(
        label = "CBZ 漫画 (.cbz)",
        shortLabel = "CBZ",
        extension = "cbz",
        mimeType = "application/x-cbz",
        description = "漫画图集格式，支持 AES-256 密码",
        supportsPassword = true
    ),
    TAR_GZ(
        label = "TAR.GZ (.tar.gz)",
        shortLabel = "TAR.GZ",
        extension = "tar.gz",
        mimeType = "application/gzip",
        description = "GZIP 压缩流归档",
        supportsPassword = false
    ),
    TAR_XZ(
        label = "TAR.XZ (.tar.xz)",
        shortLabel = "TAR.XZ",
        extension = "tar.xz",
        mimeType = "application/x-xz",
        description = "XZ 紧凑流归档",
        supportsPassword = false
    ),
    TAR(
        label = "TAR (.tar)",
        shortLabel = "TAR",
        extension = "tar",
        mimeType = "application/x-tar",
        description = "无损极速合并归档",
        supportsPassword = false
    )
}

/**
 * 压缩包压缩率等级
 */
enum class ArchiveCompressionLevel(val label: String, val zipLevel: Int) {
    STORE_ONLY("仅存储", Deflater.NO_COMPRESSION),
    STANDARD("标准", Deflater.DEFAULT_COMPRESSION),
    ULTRA("极限", Deflater.BEST_COMPRESSION)
}

/**
 * 色块混淆粒度选项
 */
enum class BlockGridSize(val label: String, val shortLabel: String, val blockPx: Int, val fileTag: String) {
    BLOCK_8("8×8 细密", "8×8", 8, "B8"),
    BLOCK_16("16×16 标准", "16×16", 16, "B16"),
    BLOCK_32("32×32 大块", "32×32", 32, "B32"),
    BLOCK_64("64×64 超大", "64×64", 64, "B64")
}

/**
 * 目标编码格式
 */
enum class OutputFormat(
    val label: String,
    val shortLabel: String,
    val extension: String,
    val mimeType: String,
    val supportsQualitySlider: Boolean,
    val description: String
) {
    JPEG(
        label = "JPEG",
        shortLabel = "JPEG",
        extension = "jpg",
        mimeType = "image/jpeg",
        supportsQualitySlider = true,
        description = "适合照片瘦身"
    ),
    WEBP_LOSSY(
        label = "WebP 有损",
        shortLabel = "WebP",
        extension = "webp",
        mimeType = "image/webp",
        supportsQualitySlider = true,
        description = "高压缩率，支持透明"
    ),
    WEBP_LOSSLESS(
        label = "WebP 无损",
        shortLabel = "WebP无损",
        extension = "webp",
        mimeType = "image/webp",
        supportsQualitySlider = false,
        description = "无损像素，比 PNG 更小"
    ),
    PNG(
        label = "PNG 无损",
        shortLabel = "PNG",
        extension = "png",
        mimeType = "image/png",
        supportsQualitySlider = false,
        description = "100% 像素精度无损保存"
    )
}

/**
 * 尺寸限制选项
 */
enum class ResolutionOption(val label: String, val maxDimensionPx: Int?) {
    ORIGINAL("原图", null),
    MAX_2560("2K", 2560),
    MAX_1920("1080P", 1920),
    MAX_1080("1080px", 1080),
    MAX_720("720P", 720)
}

/**
 * 批量处理与打包配置参数
 */
data class CompressionConfig(
    val mode: ProcessMode = ProcessMode.COMPRESS_TRANSCODE,
    val archiveSubMode: ArchiveSubMode = ArchiveSubMode.PACK_TO_ARCHIVE,
    val format: OutputFormat = OutputFormat.JPEG,
    val quality: Int = 80,
    val resolutionOption: ResolutionOption = ResolutionOption.ORIGINAL,
    val stripExifMetadata: Boolean = true,
    val renameTemplate: RenameTemplate = RenameTemplate.KEEP_ORIGINAL,
    val customRenamePrefix: String = "IMG",
    val customTreeUri: Uri? = null,
    val obfuscationKey: String = "",
    val blockGridSize: BlockGridSize = BlockGridSize.BLOCK_16,
    val autoTagBlockSizeInName: Boolean = true,
    val packResultIntoArchive: Boolean = false,
    val archiveOutputFormat: ArchiveOutputFormat = ArchiveOutputFormat.ZIP,
    val archiveCompressionLevel: ArchiveCompressionLevel = ArchiveCompressionLevel.STANDARD,
    val archivePassword: String = "",
    val customArchiveBaseName: String = ""
)

/**
 * 待处理的单张原图元数据
 */
data class SelectedImageItem(
    val uri: Uri,
    val displayName: String,
    val originalSize: Long,
    val mimeType: String,
    val width: Int,
    val height: Int,
    val fromArchiveName: String? = null
)

/**
 * 单张图片处理结果
 */
data class CompressionResult(
    val source: SelectedImageItem,
    val isSuccess: Boolean,
    val mode: ProcessMode = ProcessMode.COMPRESS_TRANSCODE,
    val outputUri: Uri? = null,
    val outputName: String = "",
    val compressedSize: Long = 0L,
    val outputWidth: Int = 0,
    val outputHeight: Int = 0,
    val outputFormat: OutputFormat = OutputFormat.JPEG,
    val savedPathLabel: String = "",
    val packedIntoArchiveName: String? = null,
    val errorMessage: String? = null
)

/**
 * 批量执行完成后的汇总报告
 */
data class BatchExecutionReport(
    val itemResults: List<CompressionResult>,
    val archiveSavedUri: Uri? = null,
    val archiveFileName: String? = null,
    val archiveSavedPathLabel: String? = null,
    val archiveTotalBytes: Long = 0L,
    val isArchiveEncrypted: Boolean = false
)

/**
 * 多格式压缩包导入结果汇总（含加密密码检测状态）
 */
data class ArchiveImportSummary(
    val archiveCount: Int,
    val extractedImages: List<SelectedImageItem>,
    val archiveNames: List<String>,
    val needsPassword: Boolean = false,
    val wrongPassword: Boolean = false,
    val pendingUris: List<Uri> = emptyList(),
    val errorNote: String? = null
)

/**
 * 基于文字口令 (SHA-256 + SplitMix64) 的确定性伪随机数生成器
 */
private class KeySeededRandom(secretText: String, saltTag: String) {
    private var state: Long

    init {
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(secretText.toByteArray(Charsets.UTF_8))
        digest.update(0.toByte())
        digest.update(saltTag.toByteArray(Charsets.UTF_8))
        val hashBytes = digest.digest()
        val buf = ByteBuffer.wrap(hashBytes)
        var acc = 0L
        repeat(4) {
            acc = acc xor buf.long
        }
        state = if (acc == 0L) -0x61c8864680b583ebL else acc
    }

    fun nextLong(): Long {
        var z = (state + -0x61c8864680b583ebL).also { state = it }
        z = (z xor (z ushr 30)) * -0x40a7b892e31b1a47L
        z = (z xor (z ushr 27)) * -0x6b2fb644ecceee15L
        return z xor (z ushr 31)
    }

    fun nextInt(bound: Int): Int {
        if (bound <= 1) return 0
        return ((nextLong() ushr 1) % bound.toLong()).toInt()
    }

    fun nextByteMask(): Int = (nextLong() and 0xFFL).toInt()
}

object ImageCompressor {

    private val SUPPORTED_IMAGE_EXTENSIONS = setOf(
        "jpg", "jpeg", "png", "webp", "bmp", "heic", "heif"
    )

    private val SUPPORTED_ARCHIVE_EXTENSIONS = setOf(
        "zip", "cbz", "7z", "rar", "cbr", "tar", "gz", "tgz", "bz2", "tbz2", "xz", "txz", "jar", "apk"
    )

    private val BLOCK_TAG_REGEX = Regex("(?:^|_)(B8|B16|B32|B64)(?:_|\.)", RegexOption.IGNORE_CASE)

    /**
     * 自动从图片文件名识别加密时写入的色块粒度标记（如 OBF_B16_xxx.png -> BLOCK_16）
     */
    fun detectBlockGridFromItems(items: List<SelectedImageItem>): BlockGridSize? {
        for (item in items) {
            val match = BLOCK_TAG_REGEX.find(item.displayName) ?: continue
            val tag = match.groupValues.getOrNull(1)?.uppercase(Locale.ROOT) ?: continue
            val found = BlockGridSize.entries.firstOrNull { it.fileTag == tag }
            if (found != null) return found
        }
        return null
    }

    /**
     * 一键向外分享处理完的图片或压缩包（支持 MediaStore / SAF / Cache FileProvider）
     */
    fun shareOutputUris(
        context: Context,
        uris: List<Uri>,
        mimeType: String = "*/*",
        chooserTitle: String = "分享文件"
    ) {
        if (uris.isEmpty()) {
            Toast.makeText(context, "暂无可分享的输出文件", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val safeUris = ArrayList<Uri>()
            for (u in uris) {
                if (u.scheme == "file") {
                    val f = File(u.path ?: continue)
                    if (f.exists()) {
                        safeUris.add(
                            FileProvider.getUriForFile(
                                context,
                                "${context.packageName}.fileprovider",
                                f
                            )
                        )
                    }
                } else {
                    safeUris.add(u)
                }
            }
            if (safeUris.isEmpty()) {
                Toast.makeText(context, "未找到可分享的文件路径", Toast.LENGTH_SHORT).show()
                return
            }

            val intent = if (safeUris.size == 1) {
                Intent(Intent.ACTION_SEND).apply {
                    type = mimeType
                    putExtra(Intent.EXTRA_STREAM, safeUris[0])
                    clipData = ClipData.newRawUri("", safeUris[0])
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                    type = mimeType
                    putParcelableArrayListExtra(Intent.EXTRA_STREAM, safeUris)
                    val clip = ClipData.newRawUri("", safeUris[0])
                    for (i in 1 until safeUris.size) {
                        clip.addItem(ClipData.Item(safeUris[i]))
                    }
                    clipData = clip
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            }
            val chooser = Intent.createChooser(intent, chooserTitle).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            Toast.makeText(context, "调起分享失败: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * 判断某个 Uri 是否为受支持的压缩包格式
     */
    fun isArchiveUri(context: Context, uri: Uri): Boolean {
        val mime = context.contentResolver.getType(uri)?.lowercase(Locale.ROOT) ?: ""
        if (mime.contains("zip") ||
            mime.contains("7z") ||
            mime.contains("rar") ||
            mime.contains("tar") ||
            mime.contains("gzip") ||
            mime.contains("bzip2") ||
            mime.contains("xz") ||
            mime.contains("cbz") ||
            mime.contains("cbr") ||
            mime.contains("compressed")
        ) {
            return true
        }
        val displayName = queryDisplayName(context, uri).lowercase(Locale.ROOT)
        val ext = displayName.substringAfterLast('.', "")
        if (ext in SUPPORTED_ARCHIVE_EXTENSIONS) return true

        val pathSeg = uri.lastPathSegment?.lowercase(Locale.ROOT) ?: ""
        val pathExt = pathSeg.substringAfterLast('.', "")
        return pathExt in SUPPORTED_ARCHIVE_EXTENSIONS
    }

    /**
     * 从一个或多个多格式压缩包（支持加密 .zip / .cbz / .7z / .rar 及 .tar.gz / .xz）中提取所有图片
     */
    suspend fun extractImagesFromArchiveUris(
        context: Context,
        archiveUris: List<Uri>,
        password: String = ""
    ): ArchiveImportSummary = withContext(Dispatchers.IO) {
        val cacheRoot = File(context.cacheDir, "archive_imports").apply {
            if (!exists()) mkdirs()
        }
        val extractedItems = mutableListOf<SelectedImageItem>()
        val archiveNames = mutableListOf<String>()
        val pendingEncryptedUris = mutableListOf<Uri>()
        var needsPassword = false
        var wrongPassword = false
        var lastError: String? = null

        archiveUris.forEachIndexed { idx, archiveUri ->
            ensureActive()
            val displayName = queryDisplayName(context, archiveUri).ifBlank {
                "archive_${idx + 1}.zip"
            }
            archiveNames.add(displayName)

            val batchFolder = File(cacheRoot, "arc_${System.currentTimeMillis()}_$idx").apply {
                mkdirs()
            }

            val lowerName = displayName.lowercase(Locale.ROOT)
            val mime = context.contentResolver.getType(archiveUri)?.lowercase(Locale.ROOT) ?: ""

            try {
                val outcome = when {
                    lowerName.endsWith(".7z") || mime.contains("7z") -> {
                        extractSevenZArchive(context, archiveUri, displayName, batchFolder, password)
                    }
                    lowerName.endsWith(".rar") || lowerName.endsWith(".cbr") || mime.contains("rar") -> {
                        extractRarArchive(context, archiveUri, displayName, batchFolder, password)
                    }
                    lowerName.endsWith(".tar.gz") || lowerName.endsWith(".tgz") ||
                        (lowerName.endsWith(".gz") && !lowerName.endsWith(".svgz")) || mime.contains("gzip") -> {
                        SingleArchiveOutcome(
                            items = extractTarStreamArchive(context, archiveUri, displayName, batchFolder, "gz")
                        )
                    }
                    lowerName.endsWith(".tar.bz2") || lowerName.endsWith(".tbz2") ||
                        lowerName.endsWith(".bz2") || mime.contains("bzip2") -> {
                        SingleArchiveOutcome(
                            items = extractTarStreamArchive(context, archiveUri, displayName, batchFolder, "bz2")
                        )
                    }
                    lowerName.endsWith(".tar.xz") || lowerName.endsWith(".txz") ||
                        lowerName.endsWith(".xz") || mime.contains("xz") -> {
                        SingleArchiveOutcome(
                            items = extractTarStreamArchive(context, archiveUri, displayName, batchFolder, "xz")
                        )
                    }
                    lowerName.endsWith(".tar") || mime.contains("tar") -> {
                        SingleArchiveOutcome(
                            items = extractTarStreamArchive(context, archiveUri, displayName, batchFolder, "plain")
                        )
                    }
                    else -> {
                        extractZipArchiveWithPasswordSupport(context, archiveUri, displayName, batchFolder, password)
                    }
                }

                if (outcome.needsPassword) {
                    needsPassword = true
                    if (outcome.wrongPassword) wrongPassword = true
                    pendingEncryptedUris.add(archiveUri)
                }
                if (outcome.errorNote != null) {
                    lastError = outcome.errorNote
                }
                extractedItems.addAll(outcome.items)
            } catch (e: Exception) {
                lastError = e.localizedMessage ?: "压缩包解析失败"
            }
        }

        // 按自然页码排序（如 1.jpg, 2.jpg, 10.jpg），确保阅读器翻页顺序完全正确
        val sortedItems = extractedItems.sortedWith { a, b ->
            compareNaturalStrings(a.displayName, b.displayName)
        }

        ArchiveImportSummary(
            archiveCount = archiveUris.size,
            extractedImages = sortedItems,
            archiveNames = archiveNames,
            needsPassword = needsPassword,
            wrongPassword = wrongPassword,
            pendingUris = if (pendingEncryptedUris.isNotEmpty()) pendingEncryptedUris else archiveUris,
            errorNote = lastError
        )
    }

    private data class SingleArchiveOutcome(
        val items: List<SelectedImageItem> = emptyList(),
        val needsPassword: Boolean = false,
        val wrongPassword: Boolean = false,
        val errorNote: String? = null
    )

    /**
     * 使用 Zip4j + 双字符集回退解析普通或加密 ZIP / CBZ 压缩包
     */
    private fun extractZipArchiveWithPasswordSupport(
        context: Context,
        archiveUri: Uri,
        archiveDisplayName: String,
        destFolder: File,
        password: String
    ): SingleArchiveOutcome {
        val tempZip = File(destFolder, "temp_source.zip")
        try {
            context.contentResolver.openInputStream(archiveUri)?.use { input ->
                FileOutputStream(tempZip).use { output ->
                    input.copyTo(output)
                }
            } ?: return SingleArchiveOutcome(errorNote = "无法读取压缩包文件流")

            val zf = ZipFile(tempZip)
            if (zf.isEncrypted) {
                if (password.isBlank()) {
                    return SingleArchiveOutcome(
                        needsPassword = true,
                        wrongPassword = false,
                        errorNote = "压缩包「$archiveDisplayName」受密码保护"
                    )
                }
                zf.setPassword(password.toCharArray())
            }

            // 尝试用 UTF-8 提取，若文件名含 GBK 编码则自动切换 GBK
            try {
                zf.charset = Charsets.UTF_8
                zf.extractAll(destFolder.absolutePath)
            } catch (e: ZipException) {
                val msg = (e.message ?: "").lowercase(Locale.ROOT)
                if (e.type == ZipException.Type.WRONG_PASSWORD ||
                    msg.contains("password") ||
                    msg.contains("encrypted") ||
                    msg.contains("wrong password")
                ) {
                    return SingleArchiveOutcome(
                        needsPassword = true,
                        wrongPassword = password.isNotBlank(),
                        errorNote = if (password.isNotBlank()) "压缩包密码错误，请重试" else "压缩包受密码保护"
                    )
                }
                // 尝试使用 GBK 编码重新提取
                runCatching {
                    zf.charset = Charset.forName("GBK")
                    zf.extractAll(destFolder.absolutePath)
                }.onFailure { err ->
                    val errMsg = (err.message ?: "").lowercase(Locale.ROOT)
                    if (errMsg.contains("password") || errMsg.contains("encrypted")) {
                        return SingleArchiveOutcome(
                            needsPassword = true,
                            wrongPassword = password.isNotBlank(),
                            errorNote = "压缩包密码错误或受加密保护"
                        )
                    }
                }
            }
        } finally {
            tempZip.delete()
        }

        // 递归扫描解压出的所有有效图片文件
        val collected = mutableListOf<SelectedImageItem>()
        destFolder.walkTopDown()
            .filter { it.isFile }
            .forEach { file ->
                val relPath = file.relativeTo(destFolder).path.replace('\', '/')
                val simpleName = file.name
                val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                if (isValidImageEntry(relPath, simpleName, ext)) {
                    buildSelectedImageIfValid(file, simpleName, archiveDisplayName)?.let {
                        collected.add(it)
                    }
                } else {
                    file.delete()
                }
            }

        if (collected.isNotEmpty()) {
            return SingleArchiveOutcome(items = collected)
        }

        // 如果没有提取出图片，回退流式读取做二次确认
        val fallbackItems = tryExtractZipWithCharset(context, archiveUri, archiveDisplayName, destFolder, Charsets.UTF_8)
            ?: tryExtractZipWithCharset(context, archiveUri, archiveDisplayName, destFolder, Charset.forName("GBK"))
            ?: emptyList()
        return SingleArchiveOutcome(items = fallbackItems)
    }

    /**
     * 解析 7z 格式压缩包（支持 AES-256 密码解锁）
     */
    @Suppress("DEPRECATION")
    private fun extractSevenZArchive(
        context: Context,
        archiveUri: Uri,
        archiveDisplayName: String,
        destFolder: File,
        password: String
    ): SingleArchiveOutcome {
        val items = mutableListOf<SelectedImageItem>()
        val tempFile = File(destFolder, "temp_source.7z")
        try {
            context.contentResolver.openInputStream(archiveUri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return SingleArchiveOutcome()

            val sevenZ = if (password.isNotBlank()) {
                SevenZFile(tempFile, password.toCharArray())
            } else {
                SevenZFile(tempFile)
            }

            sevenZ.use { archive ->
                var entry = archive.nextEntry
                var counter = 0
                val buffer = ByteArray(16 * 1024)
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val rawName = entry.name.replace('\', '/')
                        val simpleName = rawName.substringAfterLast('/')
                        val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                        if (isValidImageEntry(rawName, simpleName, ext)) {
                            counter++
                            val outFile = File(destFolder, "${counter}_${sanitizeFileName(simpleName)}")
                            if (outFile.canonicalPath.startsWith(destFolder.canonicalPath)) {
                                FileOutputStream(outFile).use { fos ->
                                    var len: Int
                                    while (archive.read(buffer).also { len = it } > 0) {
                                        fos.write(buffer, 0, len)
                                    }
                                    fos.flush()
                                }
                                buildSelectedImageIfValid(outFile, simpleName, archiveDisplayName)?.let {
                                    items.add(it)
                                }
                            }
                        }
                    }
                    entry = archive.nextEntry
                }
            }
        } catch (e: PasswordRequiredException) {
            return SingleArchiveOutcome(
                needsPassword = true,
                wrongPassword = password.isNotBlank(),
                errorNote = "7Z 压缩包需要密码解锁"
            )
        } catch (e: Exception) {
            val msg = (e.message ?: "").lowercase(Locale.ROOT)
            if (msg.contains("password") || msg.contains("encrypted") || msg.contains("aes")) {
                return SingleArchiveOutcome(
                    needsPassword = true,
                    wrongPassword = password.isNotBlank(),
                    errorNote = if (password.isNotBlank()) "7Z 密码错误，请重试" else "7Z 压缩包受密码保护"
                )
            }
            return SingleArchiveOutcome(items = items, errorNote = e.localizedMessage)
        } finally {
            tempFile.delete()
        }
        return SingleArchiveOutcome(items = items)
    }

    /**
     * 解析 RAR / CBR 格式压缩包（支持密码检测与解锁）
     */
    private fun extractRarArchive(
        context: Context,
        archiveUri: Uri,
        archiveDisplayName: String,
        destFolder: File,
        password: String
    ): SingleArchiveOutcome {
        val items = mutableListOf<SelectedImageItem>()
        val tempFile = File(destFolder, "temp_source.rar")
        try {
            context.contentResolver.openInputStream(archiveUri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return SingleArchiveOutcome()

            val rarArchive = if (password.isNotBlank()) {
                Archive(tempFile, password)
            } else {
                Archive(tempFile)
            }

            rarArchive.use { archive ->
                if (archive.isEncrypted && password.isBlank()) {
                    return SingleArchiveOutcome(
                        needsPassword = true,
                        wrongPassword = false,
                        errorNote = "RAR 压缩包受密码保护"
                    )
                }
                var header: FileHeader? = archive.nextFileHeader()
                var counter = 0
                while (header != null) {
                    val currentHeader = header
                    if (currentHeader.isEncrypted && password.isBlank()) {
                        return SingleArchiveOutcome(
                            needsPassword = true,
                            wrongPassword = false,
                            errorNote = "RAR 内部文件受密码保护"
                        )
                    }
                    if (!currentHeader.isDirectory) {
                        val rawName = currentHeader.fileName.replace('\', '/')
                        val simpleName = rawName.substringAfterLast('/')
                        val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                        if (isValidImageEntry(rawName, simpleName, ext)) {
                            counter++
                            val outFile = File(destFolder, "${counter}_${sanitizeFileName(simpleName)}")
                            if (outFile.canonicalPath.startsWith(destFolder.canonicalPath)) {
                                FileOutputStream(outFile).use { fos ->
                                    archive.extractFile(currentHeader, fos)
                                    fos.flush()
                                }
                                buildSelectedImageIfValid(outFile, simpleName, archiveDisplayName)?.let {
                                    items.add(it)
                                }
                            }
                        }
                    }
                    header = archive.nextFileHeader()
                }
            }
        } catch (e: Exception) {
            val msg = (e.message ?: "").lowercase(Locale.ROOT)
            if (msg.contains("password") || msg.contains("encrypted") || msg.contains("crc")) {
                return SingleArchiveOutcome(
                    needsPassword = true,
                    wrongPassword = password.isNotBlank(),
                    errorNote = if (password.isNotBlank()) "RAR 密码错误或为 RAR5 加密" else "RAR 压缩包需要密码"
                )
            }
            return SingleArchiveOutcome(items = items, errorNote = e.localizedMessage)
        } finally {
            tempFile.delete()
        }
        return SingleArchiveOutcome(items = items)
    }

    /**
     * 解析 TAR / TAR.GZ / TAR.BZ2 / TAR.XZ 流式归档包
     */
    private fun extractTarStreamArchive(
        context: Context,
        archiveUri: Uri,
        archiveDisplayName: String,
        destFolder: File,
        compressionType: String
    ): List<SelectedImageItem> {
        val items = mutableListOf<SelectedImageItem>()
        context.contentResolver.openInputStream(archiveUri)?.use { rawInput ->
            val buffered = BufferedInputStream(rawInput)
            val decompressedStream: InputStream = when (compressionType) {
                "gz" -> GzipCompressorInputStream(buffered)
                "bz2" -> BZip2CompressorInputStream(buffered)
                "xz" -> XZCompressorInputStream(buffered)
                else -> buffered
            }
            TarArchiveInputStream(decompressedStream).use { tarIn ->
                var entry = tarIn.nextEntry
                var counter = 0
                val buffer = ByteArray(16 * 1024)
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val rawName = entry.name.replace('\', '/')
                        val simpleName = rawName.substringAfterLast('/')
                        val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                        if (isValidImageEntry(rawName, simpleName, ext)) {
                            counter++
                            val outFile = File(destFolder, "${counter}_${sanitizeFileName(simpleName)}")
                            if (outFile.canonicalPath.startsWith(destFolder.canonicalPath)) {
                                FileOutputStream(outFile).use { fos ->
                                    var len: Int
                                    while (tarIn.read(buffer).also { len = it } > 0) {
                                        fos.write(buffer, 0, len)
                                    }
                                    fos.flush()
                                }
                                buildSelectedImageIfValid(outFile, simpleName, archiveDisplayName)?.let {
                                    items.add(it)
                                }
                            }
                        }
                    }
                    entry = tarIn.nextEntry
                }
            }
        }
        return items
    }

    private fun tryExtractZipWithCharset(
        context: Context,
        zipUri: Uri,
        zipDisplayName: String,
        destFolder: File,
        charset: Charset
    ): List<SelectedImageItem>? {
        val items = mutableListOf<SelectedImageItem>()
        return try {
            context.contentResolver.openInputStream(zipUri)?.use { rawInput ->
                val zis = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    ZipInputStream(BufferedInputStream(rawInput), charset)
                } else {
                    ZipInputStream(BufferedInputStream(rawInput))
                }

                var entry: ZipEntry? = zis.nextEntry
                var fileCounter = 0
                val buffer = ByteArray(16 * 1024)
                while (entry != null) {
                    val currentEntry = entry
                    if (!currentEntry.isDirectory) {
                        val rawName = currentEntry.name.replace('\', '/')
                        val simpleName = rawName.substringAfterLast('/')
                        val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)

                        if (isValidImageEntry(rawName, simpleName, ext)) {
                            fileCounter++
                            val outFile = File(destFolder, "${fileCounter}_${sanitizeFileName(simpleName)}")

                            if (outFile.canonicalPath.startsWith(destFolder.canonicalPath)) {
                                FileOutputStream(outFile).use { fos ->
                                    var len: Int
                                    while (zis.read(buffer).also { len = it } > 0) {
                                        fos.write(buffer, 0, len)
                                    }
                                    fos.flush()
                                }
                                buildSelectedImageIfValid(outFile, simpleName, zipDisplayName)?.let {
                                    items.add(it)
                                }
                            }
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
            items
        } catch (e: IllegalArgumentException) {
            null
        } catch (e: Exception) {
            items
        }
    }

    /**
     * 供「归档阅读器」实时口令解混淆预览使用：将色块图在缓存中解混淆并返回预览 Uri
     */
    suspend fun decryptImageForReaderPreview(
        context: Context,
        item: SelectedImageItem,
        secretKey: String,
        fallbackGridSize: BlockGridSize
    ): Uri? = withContext(Dispatchers.IO) {
        if (secretKey.isBlank()) return@withContext null
        runCatching {
            val detectedGrid = detectBlockGridFromItems(listOf(item)) ?: fallbackGridSize
            val previewDir = File(context.cacheDir, "reader_decrypted").apply {
                if (!exists()) mkdirs()
            }
            val keyHash = secretKey.hashCode().toUInt().toString(16)
            val cacheFile = File(
                previewDir,
                "dec_${keyHash}_${detectedGrid.fileTag}_${sanitizeFileName(item.displayName)}.png"
            )
            if (cacheFile.exists() && cacheFile.length() > 0L) {
                return@withContext Uri.fromFile(cacheFile)
            }

            val opts = BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.ARGB_8888
                inScaled = false
            }
            val rawBitmap = context.contentResolver.openInputStream(item.uri)?.use { input ->
                BitmapFactory.decodeStream(input, null, opts)
            } ?: return@withContext null

            val restored = transformImageBlocks(
                source = rawBitmap,
                secretKey = secretKey,
                blockSize = detectedGrid.blockPx,
                isEncrypt = false
            )
            if (restored !== rawBitmap) rawBitmap.recycle()

            FileOutputStream(cacheFile).use { fos ->
                restored.compress(Bitmap.CompressFormat.PNG, 100, fos)
                fos.flush()
            }
            restored.recycle()
            Uri.fromFile(cacheFile)
        }.getOrNull()
    }

    private fun isValidImageEntry(rawName: String, simpleName: String, ext: String): Boolean {
        return !simpleName.startsWith("._") &&
            !rawName.contains("__MACOSX/") &&
            ext in SUPPORTED_IMAGE_EXTENSIONS
    }

    private fun sanitizeFileName(simpleName: String): String {
        return buildString {
            for (ch in simpleName) {
                if (ch.isLetterOrDigit() || ch == '.' || ch == '_' || ch == '-') {
                    append(ch)
                } else {
                    append('_')
                }
            }
        }
    }

    private fun compareNaturalStrings(a: String, b: String): Int {
        val reg = Regex("(\d+)|(\D+)")
        val partsA = reg.findAll(a.lowercase(Locale.ROOT)).map { it.value }.toList()
        val partsB = reg.findAll(b.lowercase(Locale.ROOT)).map { it.value }.toList()
        val len = minOf(partsA.size, partsB.size)
        for (i in 0 until len) {
            val pa = partsA[i]
            val pb = partsB[i]
            val na = pa.toBigIntegerOrNull()
            val nb = pb.toBigIntegerOrNull()
            val cmp = if (na != null && nb != null) {
                na.compareTo(nb)
            } else {
                pa.compareTo(pb)
            }
            if (cmp != 0) return cmp
        }
        return partsA.size.compareTo(partsB.size)
    }

    private fun buildSelectedImageIfValid(
        outFile: File,
        simpleName: String,
        archiveDisplayName: String
    ): SelectedImageItem? {
        val boundsOptions = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }
        BitmapFactory.decodeFile(outFile.absolutePath, boundsOptions)
        return if (boundsOptions.outWidth > 0 && boundsOptions.outHeight > 0) {
            SelectedImageItem(
                uri = Uri.fromFile(outFile),
                displayName = simpleName,
                originalSize = outFile.length(),
                mimeType = guessMimeTypeFromName(simpleName),
                width = boundsOptions.outWidth,
                height = boundsOptions.outHeight,
                fromArchiveName = archiveDisplayName
            )
        } else {
            outFile.delete()
            null
        }
    }

    /**
     * 读取选中图片的元数据
     */
    suspend fun inspectImages(context: Context, uris: List<Uri>): List<SelectedImageItem> =
        withContext(Dispatchers.IO) {
            uris.mapNotNull { uri ->
                runCatching {
                    val resolver = context.contentResolver
                    val name = queryDisplayName(context, uri).ifBlank {
                        "image_${System.currentTimeMillis()}.jpg"
                    }
                    var size = 0L

                    resolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                        if (cursor.moveToFirst()) {
                            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                            if (sizeIndex != -1 && !cursor.isNull(sizeIndex)) {
                                size = cursor.getLong(sizeIndex)
                            }
                        }
                    }

                    if (size <= 0L) {
                        resolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                            size = afd.length.coerceAtLeast(0L)
                        }
                    }

                    val mimeType = resolver.getType(uri) ?: guessMimeTypeFromName(name)

                    val boundsOptions = BitmapFactory.Options().apply {
                        inJustDecodeBounds = true
                    }
                    resolver.openInputStream(uri)?.use { input ->
                        BitmapFactory.decodeStream(input, null, boundsOptions)
                    }

                    SelectedImageItem(
                        uri = uri,
                        displayName = name,
                        originalSize = size,
                        mimeType = mimeType,
                        width = boundsOptions.outWidth.coerceAtLeast(0),
                        height = boundsOptions.outHeight.coerceAtLeast(0)
                    )
                }.getOrNull()
            }
        }

    private fun queryDisplayName(context: Context, uri: Uri): String {
        if (uri.scheme == "file") {
            return uri.lastPathSegment ?: ""
        }
        runCatching {
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx != -1 && !cursor.isNull(idx)) {
                        return cursor.getString(idx)
                    }
                }
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: ""
    }

    /**
     * 批量执行图片处理或直接打包压入压缩包（支持 AES-256 加密 ZIP/CBZ）
     */
    suspend fun processBatch(
        context: Context,
        items: List<SelectedImageItem>,
        config: CompressionConfig,
        onProgress: (completedCount: Int, totalCount: Int, latestResult: CompressionResult) -> Unit
    ): BatchExecutionReport = withContext(Dispatchers.IO) {
        val total = items.size
        val results = ArrayList<CompressionResult>(total)

        val shouldPackIntoArchive = (config.mode == ProcessMode.ARCHIVE_HUB &&
            config.archiveSubMode == ArchiveSubMode.PACK_TO_ARCHIVE) ||
            (config.mode != ProcessMode.ARCHIVE_HUB && config.packResultIntoArchive)

        if (!shouldPackIntoArchive) {
            items.forEachIndexed { index, item ->
                ensureActive()
                val result = if (config.mode == ProcessMode.ARCHIVE_HUB) {
                    exportRawImageDirectly(context, item, config, index)
                } else {
                    processSingleImageToSavedFile(context, item, config, index)
                }
                results.add(result)
                onProgress(index + 1, total, result)
            }
            return@withContext BatchExecutionReport(itemResults = results)
        }

        val timestamp = SimpleDateFormat("MMdd_HHmmss", Locale.US).format(Date())
        val baseArchiveName = config.customArchiveBaseName.trim().ifBlank {
            when (config.mode) {
                ProcessMode.COMPRESS_TRANSCODE -> "Compressed_$timestamp"
                ProcessMode.OBFUSCATE_ENCRYPT -> "Obfuscated_$timestamp"
                ProcessMode.DEOBFUSCATE_RESTORE -> "Restored_$timestamp"
                ProcessMode.ARCHIVE_HUB, ProcessMode.ARCHIVE_READER -> "Photos_$timestamp"
            }
        }
        val archiveFileName = "${sanitizeFileName(baseArchiveName)}.${config.archiveOutputFormat.extension}"
        val tempArchiveFile = File(context.cacheDir, "pack_tmp_${System.currentTimeMillis()}.${config.archiveOutputFormat.extension}")
        if (tempArchiveFile.exists()) tempArchiveFile.delete()

        val usedEntryNames = HashSet<String>()
        val isEncryptedZip = (config.archiveOutputFormat == ArchiveOutputFormat.ZIP ||
            config.archiveOutputFormat == ArchiveOutputFormat.CBZ) &&
            config.archivePassword.isNotBlank()

        try {
            when {
                isEncryptedZip -> {
                    // 使用 Zip4j 生成 AES-256 加密的 ZIP / CBZ 归档包
                    val zipFile = ZipFile(tempArchiveFile, config.archivePassword.toCharArray())
                    val zipParams = ZipParameters().apply {
                        isEncryptFiles = true
                        encryptionMethod = EncryptionMethod.AES
                        aesKeyStrength = AesKeyStrength.KEY_STRENGTH_256
                        compressionMethod = if (config.archiveCompressionLevel == ArchiveCompressionLevel.STORE_ONLY) {
                            CompressionMethod.STORE
                        } else {
                            CompressionMethod.DEFLATE
                        }
                        compressionLevel = when (config.archiveCompressionLevel) {
                            ArchiveCompressionLevel.STORE_ONLY -> CompressionLevel.NO_COMPRESSION
                            ArchiveCompressionLevel.STANDARD -> CompressionLevel.NORMAL
                            ArchiveCompressionLevel.ULTRA -> CompressionLevel.ULTRA
                        }
                    }

                    val stagingDir = File(context.cacheDir, "zip4j_stage_${System.currentTimeMillis()}").apply {
                        mkdirs()
                    }
                    try {
                        items.forEachIndexed { index, item ->
                            ensureActive()
                            val prepared = prepareImageBytesForArchive(context, item, config, index)
                            if (prepared.result.isSuccess && prepared.bytes != null) {
                                val uniqueName = allocateUniqueEntryName(prepared.result.outputName, usedEntryNames)
                                val entryFile = File(stagingDir, uniqueName)
                                FileOutputStream(entryFile).use { it.write(prepared.bytes) }
                                zipFile.addFile(entryFile, zipParams)
                                entryFile.delete()

                                val updatedRes = prepared.result.copy(
                                    savedPathLabel = "AES加密归档: $archiveFileName/$uniqueName",
                                    packedIntoArchiveName = archiveFileName
                                )
                                results.add(updatedRes)
                                onProgress(index + 1, total, updatedRes)
                            } else {
                                results.add(prepared.result)
                                onProgress(index + 1, total, prepared.result)
                            }
                        }
                    } finally {
                        stagingDir.deleteRecursively()
                    }
                }

                config.archiveOutputFormat == ArchiveOutputFormat.ZIP ||
                    config.archiveOutputFormat == ArchiveOutputFormat.CBZ -> {
                    FileOutputStream(tempArchiveFile).use { rawFos ->
                        ZipOutputStream(BufferedOutputStream(rawFos)).use { zos ->
                            zos.setLevel(config.archiveCompressionLevel.zipLevel)
                            items.forEachIndexed { index, item ->
                                ensureActive()
                                val prepared = prepareImageBytesForArchive(context, item, config, index)
                                if (prepared.result.isSuccess && prepared.bytes != null) {
                                    val uniqueName = allocateUniqueEntryName(prepared.result.outputName, usedEntryNames)
                                    val entry = ZipEntry(uniqueName).apply {
                                        time = System.currentTimeMillis()
                                    }
                                    zos.putNextEntry(entry)
                                    zos.write(prepared.bytes)
                                    zos.closeEntry()
                                    val updatedRes = prepared.result.copy(
                                        savedPathLabel = "已打入: $archiveFileName/$uniqueName",
                                        packedIntoArchiveName = archiveFileName
                                    )
                                    results.add(updatedRes)
                                    onProgress(index + 1, total, updatedRes)
                                } else {
                                    results.add(prepared.result)
                                    onProgress(index + 1, total, prepared.result)
                                }
                            }
                            zos.finish()
                        }
                    }
                }

                config.archiveOutputFormat == ArchiveOutputFormat.SEVEN_Z -> {
                    SevenZOutputFile(tempArchiveFile).use { sevenZOut ->
                        items.forEachIndexed { index, item ->
                            ensureActive()
                            val prepared = prepareImageBytesForArchive(context, item, config, index)
                            if (prepared.result.isSuccess && prepared.bytes != null) {
                                val uniqueName = allocateUniqueEntryName(prepared.result.outputName, usedEntryNames)
                                val entry = SevenZArchiveEntry().apply {
                                    setName(uniqueName)
                                    setDirectory(false)
                                    setLastModifiedDate(Date())
                                    setSize(prepared.bytes.size.toLong())
                                }
                                sevenZOut.putArchiveEntry(entry)
                                sevenZOut.write(prepared.bytes)
                                sevenZOut.closeArchiveEntry()
                                val updatedRes = prepared.result.copy(
                                    savedPathLabel = "已打入 7Z: $archiveFileName/$uniqueName",
                                    packedIntoArchiveName = archiveFileName
                                )
                                results.add(updatedRes)
                                onProgress(index + 1, total, updatedRes)
                            } else {
                                results.add(prepared.result)
                                onProgress(index + 1, total, prepared.result)
                            }
                        }
                        sevenZOut.finish()
                    }
                }

                else -> {
                    FileOutputStream(tempArchiveFile).use { rawFos ->
                        val bufferedOut = BufferedOutputStream(rawFos)
                        val tarStream = when (config.archiveOutputFormat) {
                            ArchiveOutputFormat.TAR_GZ -> TarArchiveOutputStream(GzipCompressorOutputStream(bufferedOut))
                            ArchiveOutputFormat.TAR_XZ -> TarArchiveOutputStream(XZCompressorOutputStream(bufferedOut))
                            else -> TarArchiveOutputStream(bufferedOut)
                        }
                        tarStream.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX)
                        tarStream.use { tos ->
                            items.forEachIndexed { index, item ->
                                ensureActive()
                                val prepared = prepareImageBytesForArchive(context, item, config, index)
                                if (prepared.result.isSuccess && prepared.bytes != null) {
                                    val uniqueName = allocateUniqueEntryName(prepared.result.outputName, usedEntryNames)
                                    val tarEntry = TarArchiveEntry(uniqueName).apply {
                                        setSize(prepared.bytes.size.toLong())
                                        setModTime(Date())
                                    }
                                    tos.putArchiveEntry(tarEntry)
                                    tos.write(prepared.bytes)
                                    tos.closeArchiveEntry()
                                    val updatedRes = prepared.result.copy(
                                        savedPathLabel = "已打入归档: $archiveFileName/$uniqueName",
                                        packedIntoArchiveName = archiveFileName
                                    )
                                    results.add(updatedRes)
                                    onProgress(index + 1, total, updatedRes)
                                } else {
                                    results.add(prepared.result)
                                    onProgress(index + 1, total, prepared.result)
                                }
                            }
                            tos.finish()
                        }
                    }
                }
            }

            val archiveSize = tempArchiveFile.length()
            val (savedArchiveUri, archivePathLabel) = saveArchiveFileToTarget(
                context = context,
                sourceFile = tempArchiveFile,
                fileName = archiveFileName,
                mimeType = config.archiveOutputFormat.mimeType,
                customTreeUri = config.customTreeUri
            )

            val finalResults = results.map { res ->
                if (res.isSuccess) {
                    res.copy(savedPathLabel = "$archivePathLabel (${res.outputName})")
                } else {
                    res
                }
            }

            BatchExecutionReport(
                itemResults = finalResults,
                archiveSavedUri = savedArchiveUri,
                archiveFileName = archiveFileName,
                archiveSavedPathLabel = archivePathLabel,
                archiveTotalBytes = archiveSize,
                isArchiveEncrypted = isEncryptedZip
            )
        } finally {
            tempArchiveFile.delete()
        }
    }

    private data class PreparedArchiveEntry(
        val result: CompressionResult,
        val bytes: ByteArray?
    )

    private fun allocateUniqueEntryName(desiredName: String, used: MutableSet<String>): String {
        if (used.add(desiredName)) return desiredName
        val stem = desiredName.substringBeforeLast('.')
        val ext = desiredName.substringAfterLast('.', "jpg")
        var counter = 2
        while (true) {
            val candidate = "${stem}_$counter.$ext"
            if (used.add(candidate)) return candidate
            counter++
        }
    }

    private fun buildFormattedFileName(
        item: SelectedImageItem,
        config: CompressionConfig,
        sequenceIndex: Int,
        effectiveExtension: String
    ): String {
        val rawStem = item.displayName
            .substringBeforeLast('.')
            .replace(Regex("^(COMP_|OBF_B\d+_|OBF_|RESTORED_|ARC_)"), "")
            .ifBlank { "image_${sequenceIndex + 1}" }

        val indexStr = String.format(Locale.US, "%03d", sequenceIndex + 1)
        val dateStr = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val customPrefix = sanitizeFileName(config.customRenamePrefix.trim().ifBlank { "IMG" })

        val coreBase = when (config.renameTemplate) {
            RenameTemplate.KEEP_ORIGINAL -> sanitizeFileName(rawStem)
            RenameTemplate.PREFIX_INDEX -> "${customPrefix}_$indexStr"
            RenameTemplate.DATE_INDEX -> "${dateStr}_$indexStr"
        }

        val modePrefix = when (config.mode) {
            ProcessMode.COMPRESS_TRANSCODE -> if (config.renameTemplate == RenameTemplate.KEEP_ORIGINAL) "COMP_" else ""
            ProcessMode.OBFUSCATE_ENCRYPT -> {
                if (config.autoTagBlockSizeInName) {
                    "OBF_${config.blockGridSize.fileTag}_"
                } else {
                    "OBF_"
                }
            }
            ProcessMode.DEOBFUSCATE_RESTORE -> if (config.renameTemplate == RenameTemplate.KEEP_ORIGINAL) "RESTORED_" else ""
            ProcessMode.ARCHIVE_HUB, ProcessMode.ARCHIVE_READER -> ""
        }

        return "${modePrefix}${coreBase}.$effectiveExtension"
    }

    private fun prepareImageBytesForArchive(
        context: Context,
        item: SelectedImageItem,
        config: CompressionConfig,
        sequenceIndex: Int
    ): PreparedArchiveEntry {
        if (config.mode == ProcessMode.ARCHIVE_HUB) {
            return try {
                val rawBytes = context.contentResolver.openInputStream(item.uri)?.use { it.readBytes() }
                    ?: return PreparedArchiveEntry(
                        result = CompressionResult(
                            source = item,
                            isSuccess = false,
                            mode = config.mode,
                            errorMessage = "无法读取原图字节流"
                        ),
                        bytes = null
                    )
                val ext = item.displayName.substringAfterLast('.', "jpg").lowercase(Locale.ROOT)
                val outName = buildFormattedFileName(item, config, sequenceIndex, ext)
                PreparedArchiveEntry(
                    result = CompressionResult(
                        source = item,
                        isSuccess = true,
                        mode = config.mode,
                        outputUri = item.uri,
                        outputName = outName,
                        compressedSize = rawBytes.size.toLong(),
                        outputWidth = item.width,
                        outputHeight = item.height,
                        outputFormat = OutputFormat.PNG
                    ),
                    bytes = rawBytes
                )
            } catch (e: Exception) {
                PreparedArchiveEntry(
                    result = CompressionResult(
                        source = item,
                        isSuccess = false,
                        mode = config.mode,
                        errorMessage = e.localizedMessage ?: "读取图片失败"
                    ),
                    bytes = null
                )
            }
        }

        return encodeSingleImageInMemory(context, item, config, sequenceIndex, cachePreview = true)
    }

    private fun saveArchiveFileToTarget(
        context: Context,
        sourceFile: File,
        fileName: String,
        mimeType: String,
        customTreeUri: Uri?
    ): Pair<Uri, String> {
        if (customTreeUri != null) {
            val treeDir = DocumentFile.fromTreeUri(context, customTreeUri)
                ?: throw IllegalStateException("无法访问自定义目录")
            val finalName = if (treeDir.findFile(fileName) != null) {
                val stem = fileName.substringBefore('.')
                val ext = fileName.substringAfter('.')
                "${stem}_${System.currentTimeMillis() % 10000}.$ext"
            } else {
                fileName
            }
            val targetFile = treeDir.createFile(mimeType, finalName)
                ?: throw IllegalStateException("无法创建压缩包: $finalName")
            context.contentResolver.openOutputStream(targetFile.uri, "wt")?.use { out ->
                FileInputStream(sourceFile).use { input ->
                    input.copyTo(out)
                }
                out.flush()
            } ?: throw IllegalStateException("无法打开输出流")
            val dirName = treeDir.name ?: "自定义目录"
            return targetFile.uri to "$dirName/$finalName"
        }

        val resolver = context.contentResolver
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativePath = "${Environment.DIRECTORY_DOWNLOADS}/CompressedArchives"
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.RELATIVE_PATH, relativePath)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("无法在下载目录创建压缩包")

            resolver.openOutputStream(uri)?.use { out ->
                FileInputStream(sourceFile).use { input ->
                    input.copyTo(out)
                }
                out.flush()
            } ?: throw IllegalStateException("无法写入下载目录")

            val completeValues = ContentValues().apply {
                put(MediaStore.Downloads.IS_PENDING, 0)
            }
            resolver.update(uri, completeValues, null, null)
            return uri to "Download/CompressedArchives/$fileName"
        } else {
            @Suppress("DEPRECATION")
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val archiveDir = File(downloadsDir, "CompressedArchives").apply {
                if (!exists()) mkdirs()
            }
            val outFile = File(archiveDir, fileName)
            FileInputStream(sourceFile).use { input ->
                FileOutputStream(outFile).use { out ->
                    input.copyTo(out)
                    out.flush()
                }
            }
            return Uri.fromFile(outFile) to "Download/CompressedArchives/${outFile.name}"
        }
    }

    private fun exportRawImageDirectly(
        context: Context,
        item: SelectedImageItem,
        config: CompressionConfig,
        sequenceIndex: Int
    ): CompressionResult {
        return try {
            val rawBytes = context.contentResolver.openInputStream(item.uri)?.use { it.readBytes() }
                ?: return CompressionResult(
                    source = item,
                    isSuccess = false,
                    mode = ProcessMode.ARCHIVE_HUB,
                    errorMessage = "无法读取源文件"
                )

            val ext = item.displayName.substringAfterLast('.', "jpg").lowercase(Locale.ROOT)
            val outputFileName = buildFormattedFileName(item, config, sequenceIndex, ext)
            val mimeType = item.mimeType.ifBlank { guessMimeTypeFromName(outputFileName) }

            val (savedUri, locationDesc) = if (config.customTreeUri != null) {
                saveToCustomDocumentTree(
                    context = context,
                    treeUri = config.customTreeUri,
                    fileName = outputFileName,
                    mimeType = mimeType,
                    bytes = rawBytes
                )
            } else {
                saveToSystemGallery(
                    context = context,
                    fileName = outputFileName,
                    mimeType = mimeType,
                    bytes = rawBytes
                )
            }

            CompressionResult(
                source = item,
                isSuccess = true,
                mode = ProcessMode.ARCHIVE_HUB,
                outputUri = savedUri,
                outputName = outputFileName,
                compressedSize = rawBytes.size.toLong(),
                outputWidth = item.width,
                outputHeight = item.height,
                outputFormat = OutputFormat.PNG,
                savedPathLabel = locationDesc
            )
        } catch (e: Exception) {
            CompressionResult(
                source = item,
                isSuccess = false,
                mode = ProcessMode.ARCHIVE_HUB,
                errorMessage = e.localizedMessage ?: "导出失败"
            )
        }
    }

    private fun processSingleImageToSavedFile(
        context: Context,
        item: SelectedImageItem,
        config: CompressionConfig,
        sequenceIndex: Int
    ): CompressionResult {
        val prepared = encodeSingleImageInMemory(context, item, config, sequenceIndex, cachePreview = false)
        if (!prepared.result.isSuccess || prepared.bytes == null) {
            return prepared.result
        }

        return try {
            val effectiveFormat = prepared.result.outputFormat
            val outputFileName = prepared.result.outputName
            val (savedUri, locationDesc) = if (config.customTreeUri != null) {
                saveToCustomDocumentTree(
                    context = context,
                    treeUri = config.customTreeUri,
                    fileName = outputFileName,
                    mimeType = effectiveFormat.mimeType,
                    bytes = prepared.bytes
                )
            } else {
                saveToSystemGallery(
                    context = context,
                    fileName = outputFileName,
                    mimeType = effectiveFormat.mimeType,
                    bytes = prepared.bytes
                )
            }
            prepared.result.copy(
                outputUri = savedUri,
                savedPathLabel = locationDesc
            )
        } catch (e: Exception) {
            prepared.result.copy(
                isSuccess = false,
                errorMessage = e.localizedMessage ?: "写入失败"
            )
        }
    }

    private fun encodeSingleImageInMemory(
        context: Context,
        item: SelectedImageItem,
        config: CompressionConfig,
        sequenceIndex: Int,
        cachePreview: Boolean
    ): PreparedArchiveEntry {
        return try {
            val resolver = context.contentResolver
            val isObfuscationFlow = config.mode == ProcessMode.OBFUSCATE_ENCRYPT ||
                config.mode == ProcessMode.DEOBFUSCATE_RESTORE

            if (isObfuscationFlow && config.obfuscationKey.isBlank()) {
                return PreparedArchiveEntry(
                    result = CompressionResult(
                        source = item,
                        isSuccess = false,
                        mode = config.mode,
                        errorMessage = "请输入文字口令"
                    ),
                    bytes = null
                )
            }

            val maxTargetDim = if (config.mode == ProcessMode.DEOBFUSCATE_RESTORE) {
                null
            } else {
                config.resolutionOption.maxDimensionPx
            }

            val sampleSize = if (config.mode == ProcessMode.DEOBFUSCATE_RESTORE) {
                1
            } else {
                calculateInSampleSize(
                    srcWidth = item.width,
                    srcHeight = item.height,
                    maxDimension = maxTargetDim
                )
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
                inScaled = false
            }

            val rawBitmap = resolver.openInputStream(item.uri)?.use { input ->
                BitmapFactory.decodeStream(input, null, decodeOptions)
            } ?: return PreparedArchiveEntry(
                result = CompressionResult(
                    source = item,
                    isSuccess = false,
                    mode = config.mode,
                    errorMessage = "无法解码源图"
                ),
                bytes = null
            )

            val orientedBitmap = if (config.mode == ProcessMode.DEOBFUSCATE_RESTORE) {
                rawBitmap
            } else {
                val exifOrientation = resolver.openInputStream(item.uri)?.use { exifStream ->
                    runCatching {
                        val exif = ExifInterface(exifStream)
                        exif.getAttributeInt(
                            ExifInterface.TAG_ORIENTATION,
                            ExifInterface.ORIENTATION_NORMAL
                        )
                    }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
                } ?: ExifInterface.ORIENTATION_NORMAL

                applyExifOrientation(rawBitmap, exifOrientation).also {
                    if (it !== rawBitmap) rawBitmap.recycle()
                }
            }

            val scaledBitmap = if (config.mode == ProcessMode.DEOBFUSCATE_RESTORE) {
                orientedBitmap
            } else {
                scaleDownIfNeeded(orientedBitmap, maxTargetDim).also {
                    if (it !== orientedBitmap) orientedBitmap.recycle()
                }
            }

            val effectiveOutputFormat = when (config.mode) {
                ProcessMode.OBFUSCATE_ENCRYPT -> OutputFormat.PNG
                ProcessMode.DEOBFUSCATE_RESTORE -> config.format
                ProcessMode.COMPRESS_TRANSCODE -> config.format
                ProcessMode.ARCHIVE_HUB, ProcessMode.ARCHIVE_READER -> OutputFormat.PNG
            }

            // 还原模式下优先自动读取文件名中的粒度标记（如 B16），找不到则使用当前选中的粒度
            val effectiveGridSize = if (config.mode == ProcessMode.DEOBFUSCATE_RESTORE) {
                detectBlockGridFromItems(listOf(item)) ?: config.blockGridSize
            } else {
                config.blockGridSize
            }

            val processedBitmap = when (config.mode) {
                ProcessMode.OBFUSCATE_ENCRYPT -> {
                    transformImageBlocks(
                        source = scaledBitmap,
                        secretKey = config.obfuscationKey,
                        blockSize = effectiveGridSize.blockPx,
                        isEncrypt = true
                    ).also {
                        if (it !== scaledBitmap) scaledBitmap.recycle()
                    }
                }
                ProcessMode.DEOBFUSCATE_RESTORE -> {
                    transformImageBlocks(
                        source = scaledBitmap,
                        secretKey = config.obfuscationKey,
                        blockSize = effectiveGridSize.blockPx,
                        isEncrypt = false
                    ).also {
                        if (it !== scaledBitmap) scaledBitmap.recycle()
                    }
                }
                else -> scaledBitmap
            }

            val finalBitmap = if (effectiveOutputFormat == OutputFormat.JPEG && processedBitmap.hasAlpha()) {
                flattenAlphaOnWhite(processedBitmap).also {
                    if (it !== processedBitmap) processedBitmap.recycle()
                }
            } else {
                processedBitmap
            }

            val outWidth = finalBitmap.width
            val outHeight = finalBitmap.height

            var encodedBytes = ByteArrayOutputStream().use { buffer ->
                val compressFormat = resolveBitmapCompressFormat(effectiveOutputFormat)
                val effectiveQuality = when (effectiveOutputFormat) {
                    OutputFormat.JPEG, OutputFormat.WEBP_LOSSY -> config.quality.coerceIn(10, 100)
                    OutputFormat.WEBP_LOSSLESS, OutputFormat.PNG -> 100
                }
                val ok = finalBitmap.compress(compressFormat, effectiveQuality, buffer)
                finalBitmap.recycle()
                if (!ok) {
                    return PreparedArchiveEntry(
                        result = CompressionResult(
                            source = item,
                            isSuccess = false,
                            mode = config.mode,
                            errorMessage = "编码失败"
                        ),
                        bytes = null
                    )
                }
                buffer.toByteArray()
            }

            // 如果用户选择「保留 EXIF」且为 JPEG，则将安全拍摄参数（剔除定位后）写回文件字节
            if (!config.stripExifMetadata && effectiveOutputFormat == OutputFormat.JPEG) {
                encodedBytes = preserveSafeExifInJpegBytes(context, item.uri, encodedBytes)
            }

            val outputFileName = buildFormattedFileName(
                item = item,
                config = config,
                sequenceIndex = sequenceIndex,
                effectiveExtension = effectiveOutputFormat.extension
            )

            // 始终生成轻量缓存预览文件，方便点击卡片时在详情窗使用「拉帘对比 (Before/After Slider)」
            val previewUri = runCatching {
                val previewDir = File(context.cacheDir, "packed_previews").apply {
                    if (!exists()) mkdirs()
                }
                val previewFile = File(previewDir, "${System.currentTimeMillis()}_${sequenceIndex}_$outputFileName")
                FileOutputStream(previewFile).use { it.write(encodedBytes) }
                Uri.fromFile(previewFile)
            }.getOrNull()

            PreparedArchiveEntry(
                result = CompressionResult(
                    source = item,
                    isSuccess = true,
                    mode = config.mode,
                    outputUri = previewUri,
                    outputName = outputFileName,
                    compressedSize = encodedBytes.size.toLong(),
                    outputWidth = outWidth,
                    outputHeight = outHeight,
                    outputFormat = effectiveOutputFormat
                ),
                bytes = encodedBytes
            )
        } catch (e: Exception) {
            PreparedArchiveEntry(
                result = CompressionResult(
                    source = item,
                    isSuccess = false,
                    mode = config.mode,
                    errorMessage = e.localizedMessage ?: "处理出错"
                ),
                bytes = null
            )
        }
    }

    private fun preserveSafeExifInJpegBytes(
        context: Context,
        sourceUri: Uri,
        jpegBytes: ByteArray
    ): ByteArray {
        return runCatching {
            val tempFile = File(context.cacheDir, "exif_tmp_${System.currentTimeMillis()}.jpg")
            try {
                FileOutputStream(tempFile).use { it.write(jpegBytes) }
                val srcExif = context.contentResolver.openInputStream(sourceUri)?.use { ExifInterface(it) }
                    ?: return jpegBytes
                val dstExif = ExifInterface(tempFile)
                val safeTags = listOf(
                    ExifInterface.TAG_MAKE,
                    ExifInterface.TAG_MODEL,
                    ExifInterface.TAG_DATETIME,
                    ExifInterface.TAG_DATETIME_ORIGINAL,
                    ExifInterface.TAG_EXPOSURE_TIME,
                    ExifInterface.TAG_F_NUMBER,
                    ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY,
                    ExifInterface.TAG_FOCAL_LENGTH,
                    ExifInterface.TAG_WHITE_BALANCE
                )
                for (tag in safeTags) {
                    val v = srcExif.getAttribute(tag)
                    if (!v.isNullOrBlank()) {
                        dstExif.setAttribute(tag, v)
                    }
                }
                dstExif.saveAttributes()
                tempFile.readBytes()
            } finally {
                tempFile.delete()
            }
        }.getOrDefault(jpegBytes)
    }

    /**
     * 核心可逆色块混淆与无损还原算法
     */
    private fun transformImageBlocks(
        source: Bitmap,
        secretKey: String,
        blockSize: Int,
        isEncrypt: Boolean
    ): Bitmap {
        val width = source.width
        val height = source.height
        val totalPixels = width * height
        val srcPixels = IntArray(totalPixels)
        val dstPixels = IntArray(totalPixels)
        source.getPixels(srcPixels, 0, width, 0, 0, width, height)

        val bSize = blockSize.coerceIn(4, 128)
        val fullCols = width / bSize
        val fullRows = height / bSize
        val remW = width % bSize
        val remH = height % bSize

        val mainBlockCount = fullCols * fullRows
        if (mainBlockCount > 0) {
            val prng = KeySeededRandom(secretKey, "MAIN_${width}x${height}_$bSize")
            val perm = generatePermutation(mainBlockCount, prng)
            val orientations = IntArray(mainBlockCount) { prng.nextInt(8) }
            val dR = IntArray(mainBlockCount) { prng.nextByteMask() }
            val dG = IntArray(mainBlockCount) { prng.nextByteMask() }
            val dB = IntArray(mainBlockCount) { prng.nextByteMask() }

            for (srcIdx in 0 until mainBlockCount) {
                val dstIdx = perm[srcIdx]
                val orient = orientations[srcIdx]
                val rShift = dR[srcIdx]
                val gShift = dG[srcIdx]
                val bShift = dB[srcIdx]

                val srcCol = srcIdx % fullCols
                val srcRow = srcIdx / fullCols
                val dstCol = dstIdx % fullCols
                val dstRow = dstIdx / fullCols

                val srcStartX = srcCol * bSize
                val srcStartY = srcRow * bSize
                val dstStartX = dstCol * bSize
                val dstStartY = dstRow * bSize

                for (localY in 0 until bSize) {
                    for (localX in 0 until bSize) {
                        val (tx, ty) = transformSquareCoord(localX, localY, bSize, orient)
                        val origPos = (srcStartY + localY) * width + (srcStartX + localX)
                        val obfPos = (dstStartY + ty) * width + (dstStartX + tx)

                        if (isEncrypt) {
                            dstPixels[obfPos] = shiftPixelColor(srcPixels[origPos], rShift, gShift, bShift, true)
                        } else {
                            dstPixels[origPos] = shiftPixelColor(srcPixels[obfPos], rShift, gShift, bShift, false)
                        }
                    }
                }
            }
        }

        if (remW > 0 && fullRows > 0) {
            val prng = KeySeededRandom(secretKey, "RIGHT_${width}x${height}_$bSize")
            val perm = generatePermutation(fullRows, prng)
            val flipFlags = IntArray(fullRows) { prng.nextInt(4) }
            val dR = IntArray(fullRows) { prng.nextByteMask() }
            val dG = IntArray(fullRows) { prng.nextByteMask() }
            val dB = IntArray(fullRows) { prng.nextByteMask() }
            val startX = fullCols * bSize

            for (srcRow in 0 until fullRows) {
                val dstRow = perm[srcRow]
                val flip = flipFlags[srcRow]
                val rShift = dR[srcRow]
                val gShift = dG[srcRow]
                val bShift = dB[srcRow]

                val srcStartY = srcRow * bSize
                val dstStartY = dstRow * bSize

                for (localY in 0 until bSize) {
                    for (localX in 0 until remW) {
                        val tx = if ((flip and 1) != 0) (remW - 1 - localX) else localX
                        val ty = if ((flip and 2) != 0) (bSize - 1 - localY) else localY
                        val origPos = (srcStartY + localY) * width + (startX + localX)
                        val obfPos = (dstStartY + ty) * width + (startX + tx)

                        if (isEncrypt) {
                            dstPixels[obfPos] = shiftPixelColor(srcPixels[origPos], rShift, gShift, bShift, true)
                        } else {
                            dstPixels[origPos] = shiftPixelColor(srcPixels[obfPos], rShift, gShift, bShift, false)
                        }
                    }
                }
            }
        }

        if (remH > 0 && fullCols > 0) {
            val prng = KeySeededRandom(secretKey, "BOTTOM_${width}x${height}_$bSize")
            val perm = generatePermutation(fullCols, prng)
            val flipFlags = IntArray(fullCols) { prng.nextInt(4) }
            val dR = IntArray(fullCols) { prng.nextByteMask() }
            val dG = IntArray(fullCols) { prng.nextByteMask() }
            val dB = IntArray(fullCols) { prng.nextByteMask() }
            val startY = fullRows * bSize

            for (srcCol in 0 until fullCols) {
                val dstCol = perm[srcCol]
                val flip = flipFlags[srcCol]
                val rShift = dR[srcCol]
                val gShift = dG[srcCol]
                val bShift = dB[srcCol]

                val srcStartX = srcCol * bSize
                val dstStartX = dstCol * bSize

                for (localY in 0 until remH) {
                    for (localX in 0 until bSize) {
                        val tx = if ((flip and 1) != 0) (bSize - 1 - localX) else localX
                        val ty = if ((flip and 2) != 0) (remH - 1 - localY) else localY
                        val origPos = (startY + localY) * width + (srcStartX + localX)
                        val obfPos = (startY + ty) * width + (dstStartX + tx)

                        if (isEncrypt) {
                            dstPixels[obfPos] = shiftPixelColor(srcPixels[origPos], rShift, gShift, bShift, true)
                        } else {
                            dstPixels[origPos] = shiftPixelColor(srcPixels[obfPos], rShift, gShift, bShift, false)
                        }
                    }
                }
            }
        }

        if (remW > 0 && remH > 0) {
            val cornerCount = remW * remH
            val prng = KeySeededRandom(secretKey, "CORNER_${width}x${height}_$bSize")
            val perm = generatePermutation(cornerCount, prng)
            val rShift = prng.nextByteMask()
            val gShift = prng.nextByteMask()
            val bShift = prng.nextByteMask()
            val startX = fullCols * bSize
            val startY = fullRows * bSize

            for (idx in 0 until cornerCount) {
                val dstIdx = perm[idx]
                val origX = startX + (idx % remW)
                val origY = startY + (idx / remW)
                val obfX = startX + (dstIdx % remW)
                val obfY = startY + (dstIdx / remW)

                val origPos = origY * width + origX
                val obfPos = obfY * width + obfX

                if (isEncrypt) {
                    dstPixels[obfPos] = shiftPixelColor(srcPixels[origPos], rShift, gShift, bShift, true)
                } else {
                    dstPixels[origPos] = shiftPixelColor(srcPixels[obfPos], rShift, gShift, bShift, false)
                }
            }
        }

        val outBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        outBitmap.setPixels(dstPixels, 0, width, 0, 0, width, height)
        return outBitmap
    }

    private fun generatePermutation(count: Int, prng: KeySeededRandom): IntArray {
        val arr = IntArray(count) { it }
        for (i in count - 1 downTo 1) {
            val j = prng.nextInt(i + 1)
            val tmp = arr[i]
            arr[i] = arr[j]
            arr[j] = tmp
        }
        return arr
    }

    private fun transformSquareCoord(x: Int, y: Int, size: Int, orient: Int): Pair<Int, Int> {
        val last = size - 1
        return when (orient and 7) {
            0 -> x to y
            1 -> (last - y) to x
            2 -> (last - x) to (last - y)
            3 -> y to (last - x)
            4 -> (last - x) to y
            5 -> x to (last - y)
            6 -> y to x
            else -> (last - y) to (last - x)
        }
    }

    private fun shiftPixelColor(pixel: Int, dR: Int, dG: Int, dB: Int, isEncrypt: Boolean): Int {
        val r = (pixel shr 16) and 0xFF
        val g = (pixel shr 8) and 0xFF
        val b = pixel and 0xFF

        val nr: Int
        val ng: Int
        val nb: Int
        if (isEncrypt) {
            nr = (r + dR) and 0xFF
            ng = (g + dG) and 0xFF
            nb = (b + dB) and 0xFF
        } else {
            nr = (r - dR) and 0xFF
            ng = (g - dG) and 0xFF
            nb = (b - dB) and 0xFF
        }
        return (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
    }

    @Suppress("DEPRECATION")
    private fun resolveBitmapCompressFormat(format: OutputFormat): Bitmap.CompressFormat {
        return when (format) {
            OutputFormat.JPEG -> Bitmap.CompressFormat.JPEG
            OutputFormat.PNG -> Bitmap.CompressFormat.PNG
            OutputFormat.WEBP_LOSSY -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Bitmap.CompressFormat.WEBP_LOSSY
                } else {
                    Bitmap.CompressFormat.WEBP
                }
            }
            OutputFormat.WEBP_LOSSLESS -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Bitmap.CompressFormat.WEBP_LOSSLESS
                } else {
                    Bitmap.CompressFormat.WEBP
                }
            }
        }
    }

    private fun saveToCustomDocumentTree(
        context: Context,
        treeUri: Uri,
        fileName: String,
        mimeType: String,
        bytes: ByteArray
    ): Pair<Uri, String> {
        val treeDir = DocumentFile.fromTreeUri(context, treeUri)
            ?: throw IllegalStateException("无法访问自定义目录")

        val finalName = if (treeDir.findFile(fileName) != null) {
            val stem = fileName.substringBeforeLast('.')
            val ext = fileName.substringAfterLast('.')
            "${stem}_${System.currentTimeMillis() % 100000}.$ext"
        } else {
            fileName
        }

        val targetFile = treeDir.createFile(mimeType, finalName)
            ?: throw IllegalStateException("无法创建文件: $finalName")

        context.contentResolver.openOutputStream(targetFile.uri, "wt")?.use { output ->
            output.write(bytes)
            output.flush()
        } ?: throw IllegalStateException("无法写入文件")

        val dirName = treeDir.name ?: "自定义目录"
        return targetFile.uri to "$dirName/$finalName"
    }

    private fun saveToSystemGallery(
        context: Context,
        fileName: String,
        mimeType: String,
        bytes: ByteArray
    ): Pair<Uri, String> {
        val resolver = context.contentResolver
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativePath = "${Environment.DIRECTORY_PICTURES}/Compressed"
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, mimeType)
                put(MediaStore.Images.Media.RELATIVE_PATH, relativePath)
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("无法创建相册记录")

            resolver.openOutputStream(uri)?.use { out ->
                out.write(bytes)
                out.flush()
            } ?: throw IllegalStateException("无法写入相册")

            val completeValues = ContentValues().apply {
                put(MediaStore.Images.Media.IS_PENDING, 0)
            }
            resolver.update(uri, completeValues, null, null)
            return uri to "Pictures/Compressed/$fileName"
        } else {
            @Suppress("DEPRECATION")
            val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
            val compressedDir = File(picturesDir, "Compressed").apply {
                if (!exists()) mkdirs()
            }
            val outFile = File(compressedDir, fileName)
            FileOutputStream(outFile).use { out ->
                out.write(bytes)
                out.flush()
            }
            @Suppress("DEPRECATION")
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DATA, outFile.absolutePath)
                put(MediaStore.Images.Media.MIME_TYPE, mimeType)
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: Uri.fromFile(outFile)
            return uri to "Pictures/Compressed/${outFile.name}"
        }
    }

    private fun calculateInSampleSize(srcWidth: Int, srcHeight: Int, maxDimension: Int?): Int {
        if (srcWidth <= 0 || srcHeight <= 0) return 1
        val targetMax = maxDimension ?: 4096
        var inSampleSize = 1
        val longestSide = max(srcWidth, srcHeight)
        if (longestSide > targetMax) {
            val halfLongest = longestSide / 2
            while ((halfLongest / inSampleSize) >= targetMax) {
                inSampleSize *= 2
            }
        }
        return inSampleSize.coerceAtLeast(1)
    }

    private fun applyExifOrientation(bitmap: Bitmap, orientation: Int): Bitmap {
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.preScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.preScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> {
                matrix.postRotate(90f)
                matrix.preScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_TRANSVERSE -> {
                matrix.postRotate(270f)
                matrix.preScale(-1f, 1f)
            }
            else -> return bitmap
        }
        return runCatching {
            Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        }.getOrDefault(bitmap)
    }

    private fun scaleDownIfNeeded(bitmap: Bitmap, maxDimension: Int?): Bitmap {
        if (maxDimension == null || maxDimension <= 0) return bitmap
        val width = bitmap.width
        val height = bitmap.height
        val longest = max(width, height)
        if (longest <= maxDimension) return bitmap

        val ratio = maxDimension.toFloat() / longest.toFloat()
        val targetWidth = (width * ratio).roundToInt().coerceAtLeast(1)
        val targetHeight = (height * ratio).roundToInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
    }

    private fun flattenAlphaOnWhite(source: Bitmap): Bitmap {
        val result = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.drawColor(Color.WHITE)
        canvas.drawBitmap(source, 0f, 0f, null)
        return result
    }

    private fun guessMimeTypeFromName(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        return when (ext) {
            "png" -> "image/png"
            "webp" -> "image/webp"
            "heic", "heif" -> "image/heic"
            "bmp" -> "image/bmp"
            else -> "image/jpeg"
        }
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0L) return "0 KB"
        val kb = bytes / 1024.0
        return if (kb < 1024.0) {
            String.format(Locale.US, "%.1f KB", kb)
        } else {
            val mb = kb / 1024.0
            String.format(Locale.US, "%.2f MB", mb)
        }
    }
}
