package com.example.imagecompressor

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * 支持的目标编码/转码格式
 */
enum class OutputFormat(
    val label: String,
    val extension: String,
    val mimeType: String,
    val supportsQualitySlider: Boolean,
    val description: String
) {
    JPEG(
        label = "JPEG (有损压缩)",
        extension = "jpg",
        mimeType = "image/jpeg",
        supportsQualitySlider = true,
        description = "兼容性最好，适合照片体积大幅压缩（透明背景会自动填充白底）"
    ),
    WEBP_LOSSY(
        label = "WebP (有损高压缩)",
        extension = "webp",
        mimeType = "image/webp",
        supportsQualitySlider = true,
        description = "比同画质 JPEG 体积再减小约 25%~35%，支持透明通道"
    ),
    WEBP_LOSSLESS(
        label = "WebP (无损转码)",
        extension = "webp",
        mimeType = "image/webp",
        supportsQualitySlider = false,
        description = "100% 保留原始像素无损解码转码，体积通常小于 PNG"
    ),
    PNG(
        label = "PNG (无损解码转码)",
        extension = "png",
        mimeType = "image/png",
        supportsQualitySlider = false,
        description = "将任意格式图片解码并转码为无损 PNG 格式，保留完整透明通道与细节"
    )
}

/**
 * 分辨率限制选项（按最长边等比缩放）
 */
enum class ResolutionOption(val label: String, val maxDimensionPx: Int?) {
    ORIGINAL("原图尺寸", null),
    MAX_2560("2K (最长边 2560px)", 2560),
    MAX_1920("1080P (最长边 1920px)", 1920),
    MAX_1080("社交高清 (最长边 1080px)", 1080),
    MAX_720("小图轻量 (最长边 720px)", 720)
}

/**
 * 批量压缩与转码配置参数
 */
data class CompressionConfig(
    val format: OutputFormat = OutputFormat.JPEG,
    val quality: Int = 80,
    val resolutionOption: ResolutionOption = ResolutionOption.ORIGINAL,
    val customTreeUri: Uri? = null,
    val filePrefix: String = "OUT_"
)

/**
 * 待处理的单张原图元数据
 */
data class SelectedImageItem(
    val uri: Uri,
    val displayName: String,
    val originalSize: Long,
    val mimeType: String,
    val width: Int,
    val height: Int
)

/**
 * 单张图片压缩/解码转码后的结果
 */
data class CompressionResult(
    val source: SelectedImageItem,
    val isSuccess: Boolean,
    val outputUri: Uri? = null,
    val outputName: String = "",
    val compressedSize: Long = 0L,
    val outputWidth: Int = 0,
    val outputHeight: Int = 0,
    val outputFormat: OutputFormat = OutputFormat.JPEG,
    val savedPathLabel: String = "",
    val errorMessage: String? = null
)

/**
 * 核心图片批量解码、转码与压缩工具类
 */
object ImageCompressor {

    /**
     * 读取选中图片的元数据（文件名、原始字节大小、MIME 类型、原始宽高），不加载完整 Bitmap 到内存
     */
    suspend fun inspectImages(context: Context, uris: List<Uri>): List<SelectedImageItem> =
        withContext(Dispatchers.IO) {
            uris.mapNotNull { uri ->
                runCatching {
                    val resolver = context.contentResolver
                    var name = "image_${System.currentTimeMillis()}"
                    var size = 0L

                    resolver.query(uri, null, null, null, null)?.use { cursor ->
                        if (cursor.moveToFirst()) {
                            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                            if (nameIndex != -1 && !cursor.isNull(nameIndex)) {
                                name = cursor.getString(nameIndex)
                            }
                            if (sizeIndex != -1 && !cursor.isNull(sizeIndex)) {
                                size = cursor.getLong(sizeIndex)
                            }
                        }
                    }

                    if (size <= 0L) {
                        resolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                            size = afd.length.coerceAtLeast(0L)
                        }
                    }

                    val mimeType = resolver.getType(uri) ?: guessMimeTypeFromName(name)

                    val boundsOptions = BitmapFactory.Options().apply {
                        inJustDecodeBounds = true
                    }
                    resolver.openInputStream(uri)?.use { input ->
                        BitmapFactory.decodeStream(input, null, boundsOptions)
                    }

                    SelectedImageItem(
                        uri = uri,
                        displayName = name,
                        originalSize = size,
                        mimeType = mimeType,
                        width = boundsOptions.outWidth.coerceAtLeast(0),
                        height = boundsOptions.outHeight.coerceAtLeast(0)
                    )
                }.getOrNull()
            }
        }

    /**
     * 批量执行图片解码、分辨率缩放、格式转码与压缩，并保存到指定目录
     */
    suspend fun processBatch(
        context: Context,
        items: List<SelectedImageItem>,
        config: CompressionConfig,
        onProgress: (completedCount: Int, totalCount: Int, latestResult: CompressionResult) -> Unit
    ): List<CompressionResult> = withContext(Dispatchers.IO) {
        val results = ArrayList<CompressionResult>(items.size)
        val total = items.size

        items.forEachIndexed { index, item ->
            ensureActive()
            val result = processSingleImage(context, item, config, index)
            results.add(result)
            onProgress(index + 1, total, result)
        }
        results
    }

    /**
     * 处理单张图片的完整流水线：采样解码 -> EXIF 方向校正 -> 等比缩放 -> 目标格式编码 -> 写入目标目录
     */
    private fun processSingleImage(
        context: Context,
        item: SelectedImageItem,
        config: CompressionConfig,
        sequenceIndex: Int
    ): CompressionResult {
        return try {
            val resolver = context.contentResolver

            // 1. 计算采样率 (inSampleSize) 防止超大分辨率原图解码 OOM
            val maxTargetDim = config.resolutionOption.maxDimensionPx
            val sampleSize = calculateInSampleSize(
                srcWidth = item.width,
                srcHeight = item.height,
                maxDimension = maxTargetDim
            )

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }

            val rawBitmap = resolver.openInputStream(item.uri)?.use { input ->
                BitmapFactory.decodeStream(input, null, decodeOptions)
            } ?: return CompressionResult(
                source = item,
                isSuccess = false,
                errorMessage = "无法解码源图片流"
            )

            // 2. 读取 EXIF 信息并自动校正旋转/镜像角度
            val exifOrientation = resolver.openInputStream(item.uri)?.use { exifStream ->
                runCatching {
                    val exif = ExifInterface(exifStream)
                    exif.getAttributeInt(
                        ExifInterface.TAG_ORIENTATION,
                        ExifInterface.ORIENTATION_NORMAL
                    )
                }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL

            val orientedBitmap = applyExifOrientation(rawBitmap, exifOrientation)
            if (orientedBitmap !== rawBitmap) {
                rawBitmap.recycle()
            }

            // 3. 精确等比缩放到目标最长边限制
            val scaledBitmap = scaleDownIfNeeded(orientedBitmap, maxTargetDim)
            if (scaledBitmap !== orientedBitmap) {
                orientedBitmap.recycle()
            }

            // 4. 若目标格式为 JPEG 且源图带透明通道，先合成白色背景避免透明区域变黑
            val finalBitmap = if (config.format == OutputFormat.JPEG && scaledBitmap.hasAlpha()) {
                flattenAlphaOnWhite(scaledBitmap).also {
                    if (it !== scaledBitmap) scaledBitmap.recycle()
                }
            } else {
                scaledBitmap
            }

            val outWidth = finalBitmap.width
            val outHeight = finalBitmap.height

            // 5. 编码/转码到内存缓冲区
            val encodedBytes = ByteArrayOutputStream().use { buffer ->
                val compressFormat = resolveBitmapCompressFormat(config.format)
                val effectiveQuality = when (config.format) {
                    OutputFormat.JPEG, OutputFormat.WEBP_LOSSY -> config.quality.coerceIn(10, 100)
                    OutputFormat.WEBP_LOSSLESS, OutputFormat.PNG -> 100
                }
                val ok = finalBitmap.compress(compressFormat, effectiveQuality, buffer)
                finalBitmap.recycle()
                if (!ok) {
                    return CompressionResult(
                        source = item,
                        isSuccess = false,
                        errorMessage = "编码为 ${config.format.label} 失败"
                    )
                }
                buffer.toByteArray()
            }

            // 6. 生成输出文件名
            val baseName = item.displayName.substringBeforeLast('.').ifBlank { "image_$sequenceIndex" }
            val outputFileName = "${config.filePrefix}${baseName}.${config.format.extension}"

            // 7. 保存到用户所选自定义目录（SAF DocumentFile）或系统默认相册（MediaStore）
            val (savedUri, locationDesc) = if (config.customTreeUri != null) {
                saveToCustomDocumentTree(
                    context = context,
                    treeUri = config.customTreeUri,
                    fileName = outputFileName,
                    mimeType = config.format.mimeType,
                    bytes = encodedBytes
                )
            } else {
                saveToSystemGallery(
                    context = context,
                    fileName = outputFileName,
                    mimeType = config.format.mimeType,
                    bytes = encodedBytes
                )
            }

            CompressionResult(
                source = item,
                isSuccess = true,
                outputUri = savedUri,
                outputName = outputFileName,
                compressedSize = encodedBytes.size.toLong(),
                outputWidth = outWidth,
                outputHeight = outHeight,
                outputFormat = config.format,
                savedPathLabel = locationDesc
            )
        } catch (e: Exception) {
            CompressionResult(
                source = item,
                isSuccess = false,
                errorMessage = e.localizedMessage ?: "处理出错"
            )
        }
    }

    /**
     * 映射 OutputFormat 到 Android 原生 Bitmap.CompressFormat（兼容 API 26 - 34+）
     */
    @Suppress("DEPRECATION")
    private fun resolveBitmapCompressFormat(format: OutputFormat): Bitmap.CompressFormat {
        return when (format) {
            OutputFormat.JPEG -> Bitmap.CompressFormat.JPEG
            OutputFormat.PNG -> Bitmap.CompressFormat.PNG
            OutputFormat.WEBP_LOSSY -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Bitmap.CompressFormat.WEBP_LOSSY
                } else {
                    Bitmap.CompressFormat.WEBP
                }
            }
            OutputFormat.WEBP_LOSSLESS -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Bitmap.CompressFormat.WEBP_LOSSLESS
                } else {
                    Bitmap.CompressFormat.WEBP
                }
            }
        }
    }

    /**
     * 保存文件到用户通过 OpenDocumentTree 选择的自定义目录
     */
    private fun saveToCustomDocumentTree(
        context: Context,
        treeUri: Uri,
        fileName: String,
        mimeType: String,
        bytes: ByteArray
    ): Pair<Uri, String> {
        val treeDir = DocumentFile.fromTreeUri(context, treeUri)
            ?: throw IllegalStateException("无法访问所选自定义目录，请重新授权选择目录")

        // 如果同名文件已存在，自动追加时间戳避免覆盖失败
        val finalName = if (treeDir.findFile(fileName) != null) {
            val stem = fileName.substringBeforeLast('.')
            val ext = fileName.substringAfterLast('.')
            "${stem}_${System.currentTimeMillis() % 100000}.$ext"
        } else {
            fileName
        }

        val targetFile = treeDir.createFile(mimeType, finalName)
            ?: throw IllegalStateException("无法在所选目录创建文件: $finalName")

        context.contentResolver.openOutputStream(targetFile.uri, "wt")?.use { output ->
            output.write(bytes)
            output.flush()
        } ?: throw IllegalStateException("无法打开输出流写入文件")

        val dirName = treeDir.name ?: "自定义目录"
        return targetFile.uri to "自定义目录: $dirName/$finalName"
    }

    /**
     * 保存文件到系统相册 Pictures/Compressed 目录
     */
    private fun saveToSystemGallery(
        context: Context,
        fileName: String,
        mimeType: String,
        bytes: ByteArray
    ): Pair<Uri, String> {
        val resolver = context.contentResolver
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativePath = "${Environment.DIRECTORY_PICTURES}/Compressed"
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, mimeType)
                put(MediaStore.Images.Media.RELATIVE_PATH, relativePath)
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("无法创建系统相册 MediaStore 记录")

            resolver.openOutputStream(uri)?.use { out ->
                out.write(bytes)
                out.flush()
            } ?: throw IllegalStateException("无法写入系统相册输出流")

            val completeValues = ContentValues().apply {
                put(MediaStore.Images.Media.IS_PENDING, 0)
            }
            resolver.update(uri, completeValues, null, null)
            return uri to "系统相册: Pictures/Compressed/$fileName"
        } else {
            @Suppress("DEPRECATION")
            val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
            val compressedDir = File(picturesDir, "Compressed").apply {
                if (!exists()) mkdirs()
            }
            val outFile = File(compressedDir, fileName)
            FileOutputStream(outFile).use { out ->
                out.write(bytes)
                out.flush()
            }
            @Suppress("DEPRECATION")
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DATA, outFile.absolutePath)
                put(MediaStore.Images.Media.MIME_TYPE, mimeType)
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: Uri.fromFile(outFile)
            return uri to "系统相册: Pictures/Compressed/${outFile.name}"
        }
    }

    /**
     * 计算合理的采样率，避免解码超大分辨率图片导致内存溢出
     */
    private fun calculateInSampleSize(srcWidth: Int, srcHeight: Int, maxDimension: Int?): Int {
        if (srcWidth <= 0 || srcHeight <= 0) return 1
        val targetMax = maxDimension ?: 4096
        var inSampleSize = 1
        val longestSide = max(srcWidth, srcHeight)
        if (longestSide > targetMax) {
            val halfLongest = longestSide / 2
            while ((halfLongest / inSampleSize) >= targetMax) {
                inSampleSize *= 2
            }
        }
        return inSampleSize.coerceAtLeast(1)
    }

    /**
     * 根据 EXIF 方向标签旋转或翻转 Bitmap
     */
    private fun applyExifOrientation(bitmap: Bitmap, orientation: Int): Bitmap {
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.preScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.preScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> {
                matrix.postRotate(90f)
                matrix.preScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_TRANSVERSE -> {
                matrix.postRotate(270f)
                matrix.preScale(-1f, 1f)
            }
            else -> return bitmap
        }
        return runCatching {
            Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        }.getOrDefault(bitmap)
    }

    /**
     * 若图片最长边超过目标限制，按原图宽高比精确缩放
     */
    private fun scaleDownIfNeeded(bitmap: Bitmap, maxDimension: Int?): Bitmap {
        if (maxDimension == null || maxDimension <= 0) return bitmap
        val width = bitmap.width
        val height = bitmap.height
        val longest = max(width, height)
        if (longest <= maxDimension) return bitmap

        val ratio = maxDimension.toFloat() / longest.toFloat()
        val targetWidth = (width * ratio).roundToInt().coerceAtLeast(1)
        val targetHeight = (height * ratio).roundToInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
    }

    /**
     * 将带透明通道的 Bitmap 绘制在白色背景上（用于 PNG/WebP 转码为 JPEG 时防止黑底）
     */
    private fun flattenAlphaOnWhite(source: Bitmap): Bitmap {
        val result = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.drawColor(Color.WHITE)
        canvas.drawBitmap(source, 0f, 0f, null)
        return result
    }

    private fun guessMimeTypeFromName(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        return when (ext) {
            "png" -> "image/png"
            "webp" -> "image/webp"
            "heic", "heif" -> "image/heic"
            "bmp" -> "image/bmp"
            else -> "image/jpeg"
        }
    }

    /**
     * 格式化文件字节大小为可读文本 (B / KB / MB)
     */
    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0L) return "0 KB"
        val kb = bytes / 1024.0
        return if (kb < 1024.0) {
            String.format(Locale.US, "%.1f KB", kb)
        } else {
            val mb = kb / 1024.0
            String.format(Locale.US, "%.2f MB", mb)
        }
    }
}
