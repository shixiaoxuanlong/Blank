package com.example.imagecompressor

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.charset.Charset
import java.security.MessageDigest
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * 底部导航栏四大工作模式：
 * 1. COMPRESS_TRANSCODE：画质压缩、分辨率缩放与格式解码转码
 * 2. OBFUSCATE_ENCRYPT：输入文字口令，将图片混淆成无法识别的彩色色块（无损 PNG）
 * 3. DEOBFUSCATE_RESTORE：输入相同文字口令，将色块图 100% 像素级无损还原为原图
 * 4. ZIP_EXTRACT：接收外部“分享/打开方式”或本地选择的 .zip 压缩包，支持直接无损解压图片到目标目录，或一键送入其他模式处理
 */
enum class ProcessMode(
    val shortTitle: String,
    val fullTitle: String,
    val subtitle: String
) {
    COMPRESS_TRANSCODE(
        shortTitle = "压缩转码",
        fullTitle = "批量图片压缩与格式转码",
        subtitle = "调整画质百分比、限制最大尺寸或批量互转 JPEG / WebP / PNG"
    ),
    OBFUSCATE_ENCRYPT(
        shortTitle = "文字加密",
        fullTitle = "文字口令色块混淆加密",
        subtitle = "用一串文字将图片打散为彩色马赛克色块，自动保存为无损 PNG"
    ),
    DEOBFUSCATE_RESTORE(
        shortTitle = "文字还原",
        fullTitle = "文字口令无损解密还原",
        subtitle = "输入加密时的同一串文字，将混淆色块图 100% 像素级还原为原图"
    ),
    ZIP_EXTRACT(
        shortTitle = "ZIP 解压",
        fullTitle = "ZIP 压缩包图片提取与导出",
        subtitle = "支持从外部应用「分享 / 打开方式」传入 .zip，一键解压图片或转入加密/压缩"
    )
}

/**
 * 色块混淆粒度选项
 */
enum class BlockGridSize(val label: String, val shortLabel: String, val blockPx: Int) {
    BLOCK_8("细密 (8×8 px)", "8×8", 8),
    BLOCK_16("标准 (16×16 px)", "16×16", 16),
    BLOCK_32("大块 (32×32 px)", "32×32", 32),
    BLOCK_64("超大 (64×64 px)", "64×64", 64)
}

/**
 * 支持的目标编码/转码格式
 */
enum class OutputFormat(
    val label: String,
    val shortLabel: String,
    val extension: String,
    val mimeType: String,
    val supportsQualitySlider: Boolean,
    val description: String
) {
    JPEG(
        label = "JPEG (有损压缩)",
        shortLabel = "JPEG",
        extension = "jpg",
        mimeType = "image/jpeg",
        supportsQualitySlider = true,
        description = "兼容性最好，适合照片体积大幅瘦身（透明背景自动填充白底）"
    ),
    WEBP_LOSSY(
        label = "WebP (有损高压缩)",
        shortLabel = "WebP有损",
        extension = "webp",
        mimeType = "image/webp",
        supportsQualitySlider = true,
        description = "比同画质 JPEG 体积再小 25%~35%，支持透明通道"
    ),
    WEBP_LOSSLESS(
        label = "WebP (无损转码)",
        shortLabel = "WebP无损",
        extension = "webp",
        mimeType = "image/webp",
        supportsQualitySlider = false,
        description = "100% 保留原始像素无损解码转码，体积小于 PNG"
    ),
    PNG(
        label = "PNG (无损解码转码)",
        shortLabel = "PNG无损",
        extension = "png",
        mimeType = "image/png",
        supportsQualitySlider = false,
        description = "无损 PNG 格式，保留完整透明通道与每一个像素细节"
    )
}

/**
 * 分辨率限制选项（按最长边等比缩放）
 */
enum class ResolutionOption(val label: String, val maxDimensionPx: Int?) {
    ORIGINAL("原图尺寸", null),
    MAX_2560("2K (2560px)", 2560),
    MAX_1920("1080P (1920px)", 1920),
    MAX_1080("高清 (1080px)", 1080),
    MAX_720("轻量 (720px)", 720)
}

/**
 * 批量处理配置参数
 */
data class CompressionConfig(
    val mode: ProcessMode = ProcessMode.COMPRESS_TRANSCODE,
    val format: OutputFormat = OutputFormat.JPEG,
    val quality: Int = 80,
    val resolutionOption: ResolutionOption = ResolutionOption.ORIGINAL,
    val customTreeUri: Uri? = null,
    val obfuscationKey: String = "",
    val blockGridSize: BlockGridSize = BlockGridSize.BLOCK_16
)

/**
 * 待处理的单张原图元数据
 */
data class SelectedImageItem(
    val uri: Uri,
    val displayName: String,
    val originalSize: Long,
    val mimeType: String,
    val width: Int,
    val height: Int,
    val fromZipName: String? = null
)

/**
 * 单张图片处理后的结果
 */
data class CompressionResult(
    val source: SelectedImageItem,
    val isSuccess: Boolean,
    val mode: ProcessMode = ProcessMode.COMPRESS_TRANSCODE,
    val outputUri: Uri? = null,
    val outputName: String = "",
    val compressedSize: Long = 0L,
    val outputWidth: Int = 0,
    val outputHeight: Int = 0,
    val outputFormat: OutputFormat = OutputFormat.JPEG,
    val savedPathLabel: String = "",
    val errorMessage: String? = null
)

/**
 * 外部或本地 ZIP 导入结果汇总
 */
data class ZipImportSummary(
    val zipCount: Int,
    val extractedImages: List<SelectedImageItem>,
    val zipNames: List<String>
)

/**
 * 基于文字口令 (SHA-256 + SplitMix64) 的跨平台确定性伪随机数生成器
 */
private class KeySeededRandom(secretText: String, saltTag: String) {
    private var state: Long

    init {
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(secretText.toByteArray(Charsets.UTF_8))
        digest.update(0.toByte())
        digest.update(saltTag.toByteArray(Charsets.UTF_8))
        val hashBytes = digest.digest()
        val buf = ByteBuffer.wrap(hashBytes)
        var acc = 0L
        repeat(4) {
            acc = acc xor buf.long
        }
        state = if (acc == 0L) -0x61c8864680b583ebL else acc
    }

    fun nextLong(): Long {
        var z = (state + -0x61c8864680b583ebL).also { state = it }
        z = (z xor (z ushr 30)) * -0x40a7b892e31b1a47L
        z = (z xor (z ushr 27)) * -0x6b2fb644ecceee15L
        return z xor (z ushr 31)
    }

    fun nextInt(bound: Int): Int {
        if (bound <= 1) return 0
        return ((nextLong() ushr 1) % bound.toLong()).toInt()
    }

    fun nextByteMask(): Int = (nextLong() and 0xFFL).toInt()
}

/**
 * 核心图片批量解码、转码、压缩、文字色块混淆/还原与 ZIP 提取引擎
 */
object ImageCompressor {

    private val SUPPORTED_IMAGE_EXTENSIONS = setOf(
        "jpg", "jpeg", "png", "webp", "bmp", "heic", "heif"
    )

    /**
     * 判断某个 Uri 是否为 .zip 压缩包（通过 MIME 类型或文件名后缀判断）
     */
    fun isZipUri(context: Context, uri: Uri): Boolean {
        val mime = context.contentResolver.getType(uri)?.lowercase(Locale.ROOT) ?: ""
        if (mime.contains("zip") || mime.contains("compressed")) return true
        val displayName = queryDisplayName(context, uri).lowercase(Locale.ROOT)
        if (displayName.endsWith(".zip")) return true
        val pathSeg = uri.lastPathSegment?.lowercase(Locale.ROOT) ?: ""
        return pathSeg.endsWith(".zip")
    }

    /**
     * 从一个或多个 .zip 压缩包 Uri 中流式提取所有图片文件到应用缓存目录，并返回可预览、可处理的 SelectedImageItem 列表
     * 内置 UTF-8 与 GBK 编码兼容，防止中文文件名乱码，并防范 Zip Slip 路径穿越
     */
    suspend fun extractImagesFromZipUris(
        context: Context,
        zipUris: List<Uri>
    ): ZipImportSummary = withContext(Dispatchers.IO) {
        val cacheRoot = File(context.cacheDir, "zip_imports").apply {
            if (!exists()) mkdirs()
        }
        val extractedItems = mutableListOf<SelectedImageItem>()
        val zipNames = mutableListOf<String>()

        zipUris.forEachIndexed { zipIdx, zipUri ->
            ensureActive()
            val zipDisplayName = queryDisplayName(context, zipUri).ifBlank { "archive_${zipIdx + 1}.zip" }
            zipNames.add(zipDisplayName)

            val batchFolder = File(cacheRoot, "zip_${System.currentTimeMillis()}_$zipIdx").apply {
                mkdirs()
            }

            // 优先使用 UTF-8 读取 ZIP 条目，若遇到旧版 Windows/MT 管理器 GBK 编码压缩包则自动回退 GBK
            val extractedFromThisZip = tryExtractZipWithCharset(
                context = context,
                zipUri = zipUri,
                zipDisplayName = zipDisplayName,
                destFolder = batchFolder,
                charset = Charsets.UTF_8
            ) ?: tryExtractZipWithCharset(
                context = context,
                zipUri = zipUri,
                zipDisplayName = zipDisplayName,
                destFolder = batchFolder,
                charset = Charset.forName("GBK")
            ) ?: emptyList()

            extractedItems.addAll(extractedFromThisZip)
        }

        ZipImportSummary(
            zipCount = zipUris.size,
            extractedImages = extractedItems,
            zipNames = zipNames
        )
    }

    private fun tryExtractZipWithCharset(
        context: Context,
        zipUri: Uri,
        zipDisplayName: String,
        destFolder: File,
        charset: Charset
    ): List<SelectedImageItem>? {
        val items = mutableListOf<SelectedImageItem>()
        return try {
            context.contentResolver.openInputStream(zipUri)?.use { rawInput ->
                val zis = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    ZipInputStream(BufferedInputStream(rawInput), charset)
                } else {
                    ZipInputStream(BufferedInputStream(rawInput))
                }

                var entry: ZipEntry? = zis.nextEntry
                var fileCounter = 0
                while (entry != null) {
                    val currentEntry = entry
                    if (!currentEntry.isDirectory) {
                        val rawName = currentEntry.name.replace('\\', '/')
                        val simpleName = rawName.substringAfterLast('/')
                        val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)

                        // 忽略 macOS 隐藏元数据文件与非图片文件
                        if (!simpleName.startsWith("._") &&
                            !rawName.contains("__MACOSX/") &&
                            ext in SUPPORTED_IMAGE_EXTENSIONS
                        ) {
                            fileCounter++
                            val cleanedName = buildString {
                                for (ch in simpleName) {
                                    if (ch.isLetterOrDigit() || ch == '.' || ch == '_' || ch == '-') {
                                        append(ch)
                                    } else {
                                        append('_')
                                    }
                                }
                            }
                            val safeFileName = "${fileCounter}_$cleanedName"
                            val outFile = File(destFolder, safeFileName)

                            // Zip Slip 安全校验
                            if (outFile.canonicalPath.startsWith(destFolder.canonicalPath)) {
                                FileOutputStream(outFile).use { fos ->
                                    val buffer = ByteArray(16 * 1024)
                                    var len: Int
                                    while (zis.read(buffer).also { len = it } > 0) {
                                        fos.write(buffer, 0, len)
                                    }
                                    fos.flush()
                                }

                                val boundsOptions = BitmapFactory.Options().apply {
                                    inJustDecodeBounds = true
                                }
                                BitmapFactory.decodeFile(outFile.absolutePath, boundsOptions)

                                if (boundsOptions.outWidth > 0 && boundsOptions.outHeight > 0) {
                                    items.add(
                                        SelectedImageItem(
                                            uri = Uri.fromFile(outFile),
                                            displayName = simpleName,
                                            originalSize = outFile.length(),
                                            mimeType = guessMimeTypeFromName(simpleName),
                                            width = boundsOptions.outWidth,
                                            height = boundsOptions.outHeight,
                                            fromZipName = zipDisplayName
                                        )
                                    )
                                } else {
                                    outFile.delete()
                                }
                            }
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
            items
        } catch (e: IllegalArgumentException) {
            // 编码不匹配（如用 UTF-8 解 GBK 压缩包触发 MALFORMED）时返回 null 以便切换 GBK 重试
            null
        } catch (e: Exception) {
            items
        }
    }

    /**
     * 读取选中图片的元数据（文件名、原始字节大小、MIME 类型、原始宽高）
     */
    suspend fun inspectImages(context: Context, uris: List<Uri>): List<SelectedImageItem> =
        withContext(Dispatchers.IO) {
            uris.mapNotNull { uri ->
                runCatching {
                    val resolver = context.contentResolver
                    val name = queryDisplayName(context, uri).ifBlank {
                        "image_${System.currentTimeMillis()}.jpg"
                    }
                    var size = 0L

                    resolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                        if (cursor.moveToFirst()) {
                            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                            if (sizeIndex != -1 && !cursor.isNull(sizeIndex)) {
                                size = cursor.getLong(sizeIndex)
                            }
                        }
                    }

                    if (size <= 0L) {
                        resolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                            size = afd.length.coerceAtLeast(0L)
                        }
                    }

                    val mimeType = resolver.getType(uri) ?: guessMimeTypeFromName(name)

                    val boundsOptions = BitmapFactory.Options().apply {
                        inJustDecodeBounds = true
                    }
                    resolver.openInputStream(uri)?.use { input ->
                        BitmapFactory.decodeStream(input, null, boundsOptions)
                    }

                    SelectedImageItem(
                        uri = uri,
                        displayName = name,
                        originalSize = size,
                        mimeType = mimeType,
                        width = boundsOptions.outWidth.coerceAtLeast(0),
                        height = boundsOptions.outHeight.coerceAtLeast(0)
                    )
                }.getOrNull()
            }
        }

    private fun queryDisplayName(context: Context, uri: Uri): String {
        if (uri.scheme == "file") {
            return uri.lastPathSegment ?: ""
        }
        runCatching {
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx != -1 && !cursor.isNull(idx)) {
                        return cursor.getString(idx)
                    }
                }
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: ""
    }

    /**
     * 批量执行图片处理（压缩转码 / 文字色块混淆 / 文字无损还原 / ZIP 原图无损解压导出）
     */
    suspend fun processBatch(
        context: Context,
        items: List<SelectedImageItem>,
        config: CompressionConfig,
        onProgress: (completedCount: Int, totalCount: Int, latestResult: CompressionResult) -> Unit
    ): List<CompressionResult> = withContext(Dispatchers.IO) {
        val results = ArrayList<CompressionResult>(items.size)
        val total = items.size

        items.forEachIndexed { index, item ->
            ensureActive()
            val result = if (config.mode == ProcessMode.ZIP_EXTRACT) {
                exportRawImageDirectly(context, item, config, index)
            } else {
                processSingleImage(context, item, config, index)
            }
            results.add(result)
            onProgress(index + 1, total, result)
        }
        results
    }

    /**
     * 在「ZIP 解压」模式下，不对图片重新编码，直接将图片原始字节无损导出到目标目录
     */
    private fun exportRawImageDirectly(
        context: Context,
        item: SelectedImageItem,
        config: CompressionConfig,
        sequenceIndex: Int
    ): CompressionResult {
        return try {
            val rawBytes = context.contentResolver.openInputStream(item.uri)?.use { it.readBytes() }
                ?: return CompressionResult(
                    source = item,
                    isSuccess = false,
                    mode = ProcessMode.ZIP_EXTRACT,
                    errorMessage = "无法读取源文件字节流"
                )

            val outputFileName = item.displayName.ifBlank { "unzipped_${sequenceIndex + 1}.jpg" }
            val mimeType = item.mimeType.ifBlank { guessMimeTypeFromName(outputFileName) }

            val (savedUri, locationDesc) = if (config.customTreeUri != null) {
                saveToCustomDocumentTree(
                    context = context,
                    treeUri = config.customTreeUri,
                    fileName = outputFileName,
                    mimeType = mimeType,
                    bytes = rawBytes
                )
            } else {
                saveToSystemGallery(
                    context = context,
                    fileName = outputFileName,
                    mimeType = mimeType,
                    bytes = rawBytes
                )
            }

            CompressionResult(
                source = item,
                isSuccess = true,
                mode = ProcessMode.ZIP_EXTRACT,
                outputUri = savedUri,
                outputName = outputFileName,
                compressedSize = rawBytes.size.toLong(),
                outputWidth = item.width,
                outputHeight = item.height,
                outputFormat = OutputFormat.PNG,
                savedPathLabel = locationDesc
            )
        } catch (e: Exception) {
            CompressionResult(
                source = item,
                isSuccess = false,
                mode = ProcessMode.ZIP_EXTRACT,
                errorMessage = e.localizedMessage ?: "解压导出失败"
            )
        }
    }

    /**
     * 处理单张图片的完整流水线
     */
    private fun processSingleImage(
        context: Context,
        item: SelectedImageItem,
        config: CompressionConfig,
        sequenceIndex: Int
    ): CompressionResult {
        return try {
            val resolver = context.contentResolver
            val isObfuscationFlow = config.mode == ProcessMode.OBFUSCATE_ENCRYPT ||
                config.mode == ProcessMode.DEOBFUSCATE_RESTORE

            if (isObfuscationFlow && config.obfuscationKey.isBlank()) {
                return CompressionResult(
                    source = item,
                    isSuccess = false,
                    mode = config.mode,
                    errorMessage = "请输入用于加密混淆或解密还原的文字口令"
                )
            }

            val maxTargetDim = if (config.mode == ProcessMode.DEOBFUSCATE_RESTORE) {
                null
            } else {
                config.resolutionOption.maxDimensionPx
            }

            val sampleSize = if (config.mode == ProcessMode.DEOBFUSCATE_RESTORE) {
                1
            } else {
                calculateInSampleSize(
                    srcWidth = item.width,
                    srcHeight = item.height,
                    maxDimension = maxTargetDim
                )
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
                inScaled = false
            }

            val rawBitmap = resolver.openInputStream(item.uri)?.use { input ->
                BitmapFactory.decodeStream(input, null, decodeOptions)
            } ?: return CompressionResult(
                source = item,
                isSuccess = false,
                mode = config.mode,
                errorMessage = "无法解码源图片流"
            )

            val orientedBitmap = if (config.mode == ProcessMode.DEOBFUSCATE_RESTORE) {
                rawBitmap
            } else {
                val exifOrientation = resolver.openInputStream(item.uri)?.use { exifStream ->
                    runCatching {
                        val exif = ExifInterface(exifStream)
                        exif.getAttributeInt(
                            ExifInterface.TAG_ORIENTATION,
                            ExifInterface.ORIENTATION_NORMAL
                        )
                    }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
                } ?: ExifInterface.ORIENTATION_NORMAL

                applyExifOrientation(rawBitmap, exifOrientation).also {
                    if (it !== rawBitmap) rawBitmap.recycle()
                }
            }

            val scaledBitmap = if (config.mode == ProcessMode.DEOBFUSCATE_RESTORE) {
                orientedBitmap
            } else {
                scaleDownIfNeeded(orientedBitmap, maxTargetDim).also {
                    if (it !== orientedBitmap) orientedBitmap.recycle()
                }
            }

            val effectiveOutputFormat = when (config.mode) {
                ProcessMode.OBFUSCATE_ENCRYPT -> OutputFormat.PNG
                ProcessMode.DEOBFUSCATE_RESTORE -> config.format
                ProcessMode.COMPRESS_TRANSCODE -> config.format
                ProcessMode.ZIP_EXTRACT -> OutputFormat.PNG
            }

            val processedBitmap = when (config.mode) {
                ProcessMode.OBFUSCATE_ENCRYPT -> {
                    transformImageBlocks(
                        source = scaledBitmap,
                        secretKey = config.obfuscationKey,
                        blockSize = config.blockGridSize.blockPx,
                        isEncrypt = true
                    ).also {
                        if (it !== scaledBitmap) scaledBitmap.recycle()
                    }
                }
                ProcessMode.DEOBFUSCATE_RESTORE -> {
                    transformImageBlocks(
                        source = scaledBitmap,
                        secretKey = config.obfuscationKey,
                        blockSize = config.blockGridSize.blockPx,
                        isEncrypt = false
                    ).also {
                        if (it !== scaledBitmap) scaledBitmap.recycle()
                    }
                }
                else -> scaledBitmap
            }

            val finalBitmap = if (effectiveOutputFormat == OutputFormat.JPEG && processedBitmap.hasAlpha()) {
                flattenAlphaOnWhite(processedBitmap).also {
                    if (it !== processedBitmap) processedBitmap.recycle()
                }
            } else {
                processedBitmap
            }

            val outWidth = finalBitmap.width
            val outHeight = finalBitmap.height

            val encodedBytes = ByteArrayOutputStream().use { buffer ->
                val compressFormat = resolveBitmapCompressFormat(effectiveOutputFormat)
                val effectiveQuality = when (effectiveOutputFormat) {
                    OutputFormat.JPEG, OutputFormat.WEBP_LOSSY -> config.quality.coerceIn(10, 100)
                    OutputFormat.WEBP_LOSSLESS, OutputFormat.PNG -> 100
                }
                val ok = finalBitmap.compress(compressFormat, effectiveQuality, buffer)
                finalBitmap.recycle()
                if (!ok) {
                    return CompressionResult(
                        source = item,
                        isSuccess = false,
                        mode = config.mode,
                        errorMessage = "编码为 ${effectiveOutputFormat.label} 失败"
                    )
                }
                buffer.toByteArray()
            }

            val baseName = item.displayName.substringBeforeLast('.').ifBlank { "image_$sequenceIndex" }
            val modePrefix = when (config.mode) {
                ProcessMode.COMPRESS_TRANSCODE -> "COMP_"
                ProcessMode.OBFUSCATE_ENCRYPT -> "OBF_"
                ProcessMode.DEOBFUSCATE_RESTORE -> "RESTORED_"
                ProcessMode.ZIP_EXTRACT -> "UNZIP_"
            }
            val outputFileName = "${modePrefix}${baseName}.${effectiveOutputFormat.extension}"

            val (savedUri, locationDesc) = if (config.customTreeUri != null) {
                saveToCustomDocumentTree(
                    context = context,
                    treeUri = config.customTreeUri,
                    fileName = outputFileName,
                    mimeType = effectiveOutputFormat.mimeType,
                    bytes = encodedBytes
                )
            } else {
                saveToSystemGallery(
                    context = context,
                    fileName = outputFileName,
                    mimeType = effectiveOutputFormat.mimeType,
                    bytes = encodedBytes
                )
            }

            CompressionResult(
                source = item,
                isSuccess = true,
                mode = config.mode,
                outputUri = savedUri,
                outputName = outputFileName,
                compressedSize = encodedBytes.size.toLong(),
                outputWidth = outWidth,
                outputHeight = outHeight,
                outputFormat = effectiveOutputFormat,
                savedPathLabel = locationDesc
            )
        } catch (e: Exception) {
            CompressionResult(
                source = item,
                isSuccess = false,
                mode = config.mode,
                errorMessage = e.localizedMessage ?: "处理出错"
            )
        }
    }

    /**
     * 核心可逆色块混淆与无损还原算法
     */
    private fun transformImageBlocks(
        source: Bitmap,
        secretKey: String,
        blockSize: Int,
        isEncrypt: Boolean
    ): Bitmap {
        val width = source.width
        val height = source.height
        val totalPixels = width * height
        val srcPixels = IntArray(totalPixels)
        val dstPixels = IntArray(totalPixels)
        source.getPixels(srcPixels, 0, width, 0, 0, width, height)

        val bSize = blockSize.coerceIn(4, 128)
        val fullCols = width / bSize
        val fullRows = height / bSize
        val remW = width % bSize
        val remH = height % bSize

        // 区域 A：主网格色块
        val mainBlockCount = fullCols * fullRows
        if (mainBlockCount > 0) {
            val prng = KeySeededRandom(secretKey, "MAIN_${width}x${height}_$bSize")
            val perm = generatePermutation(mainBlockCount, prng)
            val orientations = IntArray(mainBlockCount) { prng.nextInt(8) }
            val dR = IntArray(mainBlockCount) { prng.nextByteMask() }
            val dG = IntArray(mainBlockCount) { prng.nextByteMask() }
            val dB = IntArray(mainBlockCount) { prng.nextByteMask() }

            for (srcIdx in 0 until mainBlockCount) {
                val dstIdx = perm[srcIdx]
                val orient = orientations[srcIdx]
                val rShift = dR[srcIdx]
                val gShift = dG[srcIdx]
                val bShift = dB[srcIdx]

                val srcCol = srcIdx % fullCols
                val srcRow = srcIdx / fullCols
                val dstCol = dstIdx % fullCols
                val dstRow = dstIdx / fullCols

                val srcStartX = srcCol * bSize
                val srcStartY = srcRow * bSize
                val dstStartX = dstCol * bSize
                val dstStartY = dstRow * bSize

                for (localY in 0 until bSize) {
                    for (localX in 0 until bSize) {
                        val (tx, ty) = transformSquareCoord(localX, localY, bSize, orient)
                        val origPos = (srcStartY + localY) * width + (srcStartX + localX)
                        val obfPos = (dstStartY + ty) * width + (dstStartX + tx)

                        if (isEncrypt) {
                            dstPixels[obfPos] = shiftPixelColor(srcPixels[origPos], rShift, gShift, bShift, true)
                        } else {
                            dstPixels[origPos] = shiftPixelColor(srcPixels[obfPos], rShift, gShift, bShift, false)
                        }
                    }
                }
            }
        }

        // 区域 B：右侧边缘余数色块
        if (remW > 0 && fullRows > 0) {
            val prng = KeySeededRandom(secretKey, "RIGHT_${width}x${height}_$bSize")
            val perm = generatePermutation(fullRows, prng)
            val flipFlags = IntArray(fullRows) { prng.nextInt(4) }
            val dR = IntArray(fullRows) { prng.nextByteMask() }
            val dG = IntArray(fullRows) { prng.nextByteMask() }
            val dB = IntArray(fullRows) { prng.nextByteMask() }
            val startX = fullCols * bSize

            for (srcRow in 0 until fullRows) {
                val dstRow = perm[srcRow]
                val flip = flipFlags[srcRow]
                val rShift = dR[srcRow]
                val gShift = dG[srcRow]
                val bShift = dB[srcRow]

                val srcStartY = srcRow * bSize
                val dstStartY = dstRow * bSize

                for (localY in 0 until bSize) {
                    for (localX in 0 until remW) {
                        val tx = if ((flip and 1) != 0) (remW - 1 - localX) else localX
                        val ty = if ((flip and 2) != 0) (bSize - 1 - localY) else localY
                        val origPos = (srcStartY + localY) * width + (startX + localX)
                        val obfPos = (dstStartY + ty) * width + (startX + tx)

                        if (isEncrypt) {
                            dstPixels[obfPos] = shiftPixelColor(srcPixels[origPos], rShift, gShift, bShift, true)
                        } else {
                            dstPixels[origPos] = shiftPixelColor(srcPixels[obfPos], rShift, gShift, bShift, false)
                        }
                    }
                }
            }
        }

        // 区域 C：底部边缘余数色块
        if (remH > 0 && fullCols > 0) {
            val prng = KeySeededRandom(secretKey, "BOTTOM_${width}x${height}_$bSize")
            val perm = generatePermutation(fullCols, prng)
            val flipFlags = IntArray(fullCols) { prng.nextInt(4) }
            val dR = IntArray(fullCols) { prng.nextByteMask() }
            val dG = IntArray(fullCols) { prng.nextByteMask() }
            val dB = IntArray(fullCols) { prng.nextByteMask() }
            val startY = fullRows * bSize

            for (srcCol in 0 until fullCols) {
                val dstCol = perm[srcCol]
                val flip = flipFlags[srcCol]
                val rShift = dR[srcCol]
                val gShift = dG[srcCol]
                val bShift = dB[srcCol]

                val srcStartX = srcCol * bSize
                val dstStartX = dstCol * bSize

                for (localY in 0 until remH) {
                    for (localX in 0 until bSize) {
                        val tx = if ((flip and 1) != 0) (bSize - 1 - localX) else localX
                        val ty = if ((flip and 2) != 0) (remH - 1 - localY) else localY
                        val origPos = (startY + localY) * width + (srcStartX + localX)
                        val obfPos = (startY + ty) * width + (dstStartX + tx)

                        if (isEncrypt) {
                            dstPixels[obfPos] = shiftPixelColor(srcPixels[origPos], rShift, gShift, bShift, true)
                        } else {
                            dstPixels[origPos] = shiftPixelColor(srcPixels[obfPos], rShift, gShift, bShift, false)
                        }
                    }
                }
            }
        }

        // 区域 D：右下角残余块
        if (remW > 0 && remH > 0) {
            val cornerCount = remW * remH
            val prng = KeySeededRandom(secretKey, "CORNER_${width}x${height}_$bSize")
            val perm = generatePermutation(cornerCount, prng)
            val rShift = prng.nextByteMask()
            val gShift = prng.nextByteMask()
            val bShift = prng.nextByteMask()
            val startX = fullCols * bSize
            val startY = fullRows * bSize

            for (idx in 0 until cornerCount) {
                val dstIdx = perm[idx]
                val origX = startX + (idx % remW)
                val origY = startY + (idx / remW)
                val obfX = startX + (dstIdx % remW)
                val obfY = startY + (dstIdx / remW)

                val origPos = origY * width + origX
                val obfPos = obfY * width + obfX

                if (isEncrypt) {
                    dstPixels[obfPos] = shiftPixelColor(srcPixels[origPos], rShift, gShift, bShift, true)
                } else {
                    dstPixels[origPos] = shiftPixelColor(srcPixels[obfPos], rShift, gShift, bShift, false)
                }
            }
        }

        val outBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        outBitmap.setPixels(dstPixels, 0, width, 0, 0, width, height)
        return outBitmap
    }

    private fun generatePermutation(count: Int, prng: KeySeededRandom): IntArray {
        val arr = IntArray(count) { it }
        for (i in count - 1 downTo 1) {
            val j = prng.nextInt(i + 1)
            val tmp = arr[i]
            arr[i] = arr[j]
            arr[j] = tmp
        }
        return arr
    }

    private fun transformSquareCoord(x: Int, y: Int, size: Int, orient: Int): Pair<Int, Int> {
        val last = size - 1
        return when (orient and 7) {
            0 -> x to y
            1 -> (last - y) to x
            2 -> (last - x) to (last - y)
            3 -> y to (last - x)
            4 -> (last - x) to y
            5 -> x to (last - y)
            6 -> y to x
            else -> (last - y) to (last - x)
        }
    }

    private fun shiftPixelColor(pixel: Int, dR: Int, dG: Int, dB: Int, isEncrypt: Boolean): Int {
        val r = (pixel shr 16) and 0xFF
        val g = (pixel shr 8) and 0xFF
        val b = pixel and 0xFF

        val nr: Int
        val ng: Int
        val nb: Int
        if (isEncrypt) {
            nr = (r + dR) and 0xFF
            ng = (g + dG) and 0xFF
            nb = (b + dB) and 0xFF
        } else {
            nr = (r - dR) and 0xFF
            ng = (g - dG) and 0xFF
            nb = (b - dB) and 0xFF
        }
        return (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
    }

    @Suppress("DEPRECATION")
    private fun resolveBitmapCompressFormat(format: OutputFormat): Bitmap.CompressFormat {
        return when (format) {
            OutputFormat.JPEG -> Bitmap.CompressFormat.JPEG
            OutputFormat.PNG -> Bitmap.CompressFormat.PNG
            OutputFormat.WEBP_LOSSY -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Bitmap.CompressFormat.WEBP_LOSSY
                } else {
                    Bitmap.CompressFormat.WEBP
                }
            }
            OutputFormat.WEBP_LOSSLESS -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Bitmap.CompressFormat.WEBP_LOSSLESS
                } else {
                    Bitmap.CompressFormat.WEBP
                }
            }
        }
    }

    private fun saveToCustomDocumentTree(
        context: Context,
        treeUri: Uri,
        fileName: String,
        mimeType: String,
        bytes: ByteArray
    ): Pair<Uri, String> {
        val treeDir = DocumentFile.fromTreeUri(context, treeUri)
            ?: throw IllegalStateException("无法访问所选自定义目录，请重新授权选择目录")

        val finalName = if (treeDir.findFile(fileName) != null) {
            val stem = fileName.substringBeforeLast('.')
            val ext = fileName.substringAfterLast('.')
            "${stem}_${System.currentTimeMillis() % 100000}.$ext"
        } else {
            fileName
        }

        val targetFile = treeDir.createFile(mimeType, finalName)
            ?: throw IllegalStateException("无法在所选目录创建文件: $finalName")

        context.contentResolver.openOutputStream(targetFile.uri, "wt")?.use { output ->
            output.write(bytes)
            output.flush()
        } ?: throw IllegalStateException("无法打开输出流写入文件")

        val dirName = treeDir.name ?: "自定义目录"
        return targetFile.uri to "$dirName/$finalName"
    }

    private fun saveToSystemGallery(
        context: Context,
        fileName: String,
        mimeType: String,
        bytes: ByteArray
    ): Pair<Uri, String> {
        val resolver = context.contentResolver
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativePath = "${Environment.DIRECTORY_PICTURES}/Compressed"
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, mimeType)
                put(MediaStore.Images.Media.RELATIVE_PATH, relativePath)
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("无法创建系统相册 MediaStore 记录")

            resolver.openOutputStream(uri)?.use { out ->
                out.write(bytes)
                out.flush()
            } ?: throw IllegalStateException("无法写入系统相册输出流")

            val completeValues = ContentValues().apply {
                put(MediaStore.Images.Media.IS_PENDING, 0)
            }
            resolver.update(uri, completeValues, null, null)
            return uri to "Pictures/Compressed/$fileName"
        } else {
            @Suppress("DEPRECATION")
            val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
            val compressedDir = File(picturesDir, "Compressed").apply {
                if (!exists()) mkdirs()
            }
            val outFile = File(compressedDir, fileName)
            FileOutputStream(outFile).use { out ->
                out.write(bytes)
                out.flush()
            }
            @Suppress("DEPRECATION")
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DATA, outFile.absolutePath)
                put(MediaStore.Images.Media.MIME_TYPE, mimeType)
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: Uri.fromFile(outFile)
            return uri to "Pictures/Compressed/${outFile.name}"
        }
    }

    private fun calculateInSampleSize(srcWidth: Int, srcHeight: Int, maxDimension: Int?): Int {
        if (srcWidth <= 0 || srcHeight <= 0) return 1
        val targetMax = maxDimension ?: 4096
        var inSampleSize = 1
        val longestSide = max(srcWidth, srcHeight)
        if (longestSide > targetMax) {
            val halfLongest = longestSide / 2
            while ((halfLongest / inSampleSize) >= targetMax) {
                inSampleSize *= 2
            }
        }
        return inSampleSize.coerceAtLeast(1)
    }

    private fun applyExifOrientation(bitmap: Bitmap, orientation: Int): Bitmap {
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.preScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.preScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> {
                matrix.postRotate(90f)
                matrix.preScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_TRANSVERSE -> {
                matrix.postRotate(270f)
                matrix.preScale(-1f, 1f)
            }
            else -> return bitmap
        }
        return runCatching {
            Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        }.getOrDefault(bitmap)
    }

    private fun scaleDownIfNeeded(bitmap: Bitmap, maxDimension: Int?): Bitmap {
        if (maxDimension == null || maxDimension <= 0) return bitmap
        val width = bitmap.width
        val height = bitmap.height
        val longest = max(width, height)
        if (longest <= maxDimension) return bitmap

        val ratio = maxDimension.toFloat() / longest.toFloat()
        val targetWidth = (width * ratio).roundToInt().coerceAtLeast(1)
        val targetHeight = (height * ratio).roundToInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
    }

    private fun flattenAlphaOnWhite(source: Bitmap): Bitmap {
        val result = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.drawColor(Color.WHITE)
        canvas.drawBitmap(source, 0f, 0f, null)
        return result
    }

    private fun guessMimeTypeFromName(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        return when (ext) {
            "png" -> "image/png"
            "webp" -> "image/webp"
            "heic", "heif" -> "image/heic"
            "bmp" -> "image/bmp"
            else -> "image/jpeg"
        }
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0L) return "0 KB"
        val kb = bytes / 1024.0
        return if (kb < 1024.0) {
            String.format(Locale.US, "%.1f KB", kb)
        } else {
            val mb = kb / 1024.0
            String.format(Locale.US, "%.2f MB", mb)
        }
    }
}
