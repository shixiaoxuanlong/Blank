package com.example.imagecompressor

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    BatchImageCompressorScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun BatchImageCompressorScreen() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // 批量选中的图片列表与对应的处理结果映射
    var selectedImages by remember { mutableStateOf<List<SelectedImageItem>>(emptyList()) }
    val compressionResults = remember { mutableStateMapOf<Uri, CompressionResult>() }

    // 压缩与转码参数状态
    var selectedFormat by remember { mutableStateOf(OutputFormat.JPEG) }
    var qualitySliderValue by remember { mutableFloatStateOf(80f) }
    var selectedResolution by remember { mutableStateOf(ResolutionOption.ORIGINAL) }

    // 自定义存储目录状态 (null 表示默认保存到系统相册 Pictures/Compressed)
    var customTreeUri by remember { mutableStateOf<Uri?>(null) }
    var customDirName by remember { mutableStateOf<String?>(null) }

    // 批量处理进度状态
    var isProcessing by remember { mutableStateOf(false) }
    var completedCount by remember { mutableIntStateOf(0) }
    var totalTaskCount by remember { mutableIntStateOf(0) }

    // 1. 注册系统 PhotoPicker 批量多选图片启动器
    val pickMultipleImagesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 50)
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            coroutineScope.launch {
                val inspected = ImageCompressor.inspectImages(context, uris)
                selectedImages = inspected
                compressionResults.clear()
                completedCount = 0
                totalTaskCount = inspected.size
            }
        }
    }

    // 2. 注册 SAF 目录选择器 (OpenDocumentTree) 用于自定义输出目录
    val pickOutputDirectoryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        if (treeUri != null) {
            runCatching {
                val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(treeUri, takeFlags)
            }
            customTreeUri = treeUri
            val docDir = DocumentFile.fromTreeUri(context, treeUri)
            customDirName = docDir?.name ?: treeUri.lastPathSegment ?: "已选自定义文件夹"
            Toast.makeText(context, "已设置保存目录：$customDirName", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "批量图片压缩与解码转码",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "支持多图批量处理 · 格式互转 · 自定义保存目录",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    if (selectedImages.isNotEmpty() && !isProcessing) {
                        IconButton(
                            onClick = {
                                selectedImages = emptyList()
                                compressionResults.clear()
                                completedCount = 0
                                totalTaskCount = 0
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteSweep,
                                contentDescription = "清空已选图片"
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainer
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 模块一：批量选图与输出目录设置
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerLow
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    pickMultipleImagesLauncher.launch(
                                        PickVisualMediaRequest(
                                            ActivityResultContracts.PickVisualMedia.ImageOnly
                                        )
                                    )
                                },
                                enabled = !isProcessing,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AddPhotoAlternate,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (selectedImages.isEmpty()) {
                                        "批量选择图片"
                                    } else {
                                        "重新选图 (${selectedImages.size}张)"
                                    }
                                )
                            }

                            FilledTonalButton(
                                onClick = { pickOutputDirectoryLauncher.launch(customTreeUri) },
                                enabled = !isProcessing,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FolderOpen,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("选择保存目录")
                            }
                        }

                        HorizontalDivider()

                        // 当前存储目录状态展示与重置
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "当前输出目录",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = if (customTreeUri != null) {
                                        "自定义文件夹：$customDirName"
                                    } else {
                                        "系统默认相册：Pictures/Compressed"
                                    },
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            if (customTreeUri != null && !isProcessing) {
                                OutlinedButton(
                                    onClick = {
                                        customTreeUri = null
                                        customDirName = null
                                    },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Restore,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("恢复默认", style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                    }
                }
            }

            // 模块二：目标格式转码、画质滑块与最大尺寸设置
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerLow
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Transform,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "目标输出格式（支持批量解码转码）",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            OutputFormat.entries.forEach { format ->
                                FilterChip(
                                    selected = selectedFormat == format,
                                    onClick = { if (!isProcessing) selectedFormat = format },
                                    label = { Text(format.label) },
                                    enabled = !isProcessing
                                )
                            }
                        }

                        Text(
                            text = selectedFormat.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        HorizontalDivider()

                        // 画质滑块（针对有损格式启用，无损格式展示提示）
                        if (selectedFormat.supportsQualitySlider) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "压缩画质百分比",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "${qualitySliderValue.roundToInt()}%",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Slider(
                                    value = qualitySliderValue,
                                    onValueChange = { qualitySliderValue = it },
                                    valueRange = 10f..100f,
                                    steps = 17,
                                    enabled = !isProcessing
                                )
                                Text(
                                    text = "建议设为 75%–85%，肉眼画质几乎无损且文件体积显著减小",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f))
                                    .padding(10.dp)
                            ) {
                                Text(
                                    text = "当前已选【${selectedFormat.label}】，将对所有选中图片执行 100% 像素级无损解码与重编码。",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }
                        }

                        HorizontalDivider()

                        // 最大分辨率缩放选项
                        Text(
                            text = "分辨率尺寸限制（按最长边等比缩放）",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            ResolutionOption.entries.forEach { option ->
                                FilterChip(
                                    selected = selectedResolution == option,
                                    onClick = { if (!isProcessing) selectedResolution = option },
                                    label = { Text(option.label) },
                                    enabled = !isProcessing
                                )
                            }
                        }
                    }
                }
            }

            // 模块三：开始执行按钮与实时进度反馈
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            if (selectedImages.isEmpty()) return@Button
                            isProcessing = true
                            completedCount = 0
                            totalTaskCount = selectedImages.size
                            compressionResults.clear()

                            val config = CompressionConfig(
                                format = selectedFormat,
                                quality = qualitySliderValue.roundToInt(),
                                resolutionOption = selectedResolution,
                                customTreeUri = customTreeUri
                            )

                            coroutineScope.launch {
                                val results = ImageCompressor.processBatch(
                                    context = context,
                                    items = selectedImages,
                                    config = config,
                                    onProgress = { done, total, latest ->
                                        completedCount = done
                                        totalTaskCount = total
                                        compressionResults[latest.source.uri] = latest
                                    }
                                )
                                isProcessing = false
                                val successCount = results.count { it.isSuccess }
                                Toast.makeText(
                                    context,
                                    "批量处理完成：成功 $successCount / ${results.size} 张",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        },
                        enabled = selectedImages.isNotEmpty() && !isProcessing,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = when {
                                isProcessing -> "正在批量解码转码 ($completedCount / $totalTaskCount)..."
                                selectedImages.isEmpty() -> "请先批量选择要处理的图片"
                                else -> "开始批量压缩 / 转码 (${selectedImages.size} 张)"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (isProcessing && totalTaskCount > 0) {
                        LinearProgressIndicator(
                            progress = { completedCount.toFloat() / totalTaskCount.toFloat() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                        )
                    }
                }
            }

            // 模块四：批量处理前后总体统计卡片
            if (compressionResults.isNotEmpty()) {
                item {
                    BatchSummaryBanner(
                        selectedImages = selectedImages,
                        resultsMap = compressionResults
                    )
                }
            }

            // 模块五：图片列表（或空状态提示）
            if (selectedImages.isEmpty()) {
                item {
                    EmptySelectionPlaceholder()
                }
            } else {
                items(
                    items = selectedImages,
                    key = { it.uri.toString() }
                ) { item ->
                    ImageComparisonItemCard(
                        item = item,
                        result = compressionResults[item.uri]
                    )
                }
            }
        }
    }
}

@Composable
private fun BatchSummaryBanner(
    selectedImages: List<SelectedImageItem>,
    resultsMap: Map<Uri, CompressionResult>
) {
    val successfulResults = selectedImages.mapNotNull { resultsMap[it.uri] }.filter { it.isSuccess }
    if (successfulResults.isEmpty()) return

    val totalOriginalBytes = successfulResults.sumOf { it.source.originalSize }
    val totalCompressedBytes = successfulResults.sumOf { it.compressedSize }
    val diffBytes = totalOriginalBytes - totalCompressedBytes
    val ratioPercent = if (totalOriginalBytes > 0) {
        (diffBytes.toDouble() / totalOriginalBytes.toDouble() * 100.0)
    } else {
        0.0
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "批量处理统计 (${successfulResults.size} / ${selectedImages.size} 张已完成)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "原始总大小：${ImageCompressor.formatFileSize(totalOriginalBytes)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                    text = "处理后总大小：${ImageCompressor.formatFileSize(totalCompressedBytes)}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
            val summaryText = if (diffBytes >= 0) {
                String.format(
                    Locale.US,
                    "共节省空间：%s (平均压缩率 -%.1f%%)",
                    ImageCompressor.formatFileSize(diffBytes),
                    ratioPercent
                )
            } else {
                String.format(
                    Locale.US,
                    "无损转码体积增加：+%s (+%.1f%%)",
                    ImageCompressor.formatFileSize(abs(diffBytes)),
                    abs(ratioPercent)
                )
            }
            Text(
                text = summaryText,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
private fun ImageComparisonItemCard(
    item: SelectedImageItem,
    result: CompressionResult?
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = item.uri,
                contentDescription = item.displayName,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = item.displayName,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                val srcFormatShort = item.mimeType.substringAfterLast('/').uppercase(Locale.ROOT)
                Text(
                    text = "原图：$srcFormatShort · ${item.width}×${item.height} · ${
                        ImageCompressor.formatFileSize(item.originalSize)
                    }",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (result != null) {
                    if (result.isSuccess) {
                        val deltaRatio = if (item.originalSize > 0) {
                            ((result.compressedSize - item.originalSize).toDouble() / item.originalSize.toDouble()) * 100.0
                        } else {
                            0.0
                        }
                        val ratioLabel = if (deltaRatio <= 0) {
                            String.format(Locale.US, "%.1f%%", deltaRatio)
                        } else {
                            String.format(Locale.US, "+%.1f%%", deltaRatio)
                        }
                        val badgeColor = if (deltaRatio <= 0) {
                            Color(0xFF2E7D32)
                        } else {
                            MaterialTheme.colorScheme.tertiary
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = badgeColor,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "转码后：${result.outputFormat.extension.uppercase(Locale.ROOT)} · " +
                                    "${result.outputWidth}×${result.outputHeight} · " +
                                    "${ImageCompressor.formatFileSize(result.compressedSize)} ($ratioLabel)",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = badgeColor
                            )
                        }

                        Text(
                            text = result.savedPathLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.ErrorOutline,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "失败：${result.errorMessage}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptySelectionPlaceholder() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 36.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.PhotoLibrary,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = MaterialTheme.colorScheme.outline
            )
            Text(
                text = "尚未选择图片",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "点击上方「批量选择图片」可一次勾选多张照片进行批量压缩与格式转码",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.outline
            )
        }
    }
}
