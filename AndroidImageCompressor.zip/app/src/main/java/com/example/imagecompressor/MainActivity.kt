package com.example.imagecompressor

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EnhancedEncryption
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.EnhancedEncryption
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.FolderZip
import androidx.compose.material.icons.outlined.LockOpen
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Transform
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.util.Consumer
import androidx.documentfile.provider.DocumentFile
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * 融合 Apple HIG 与小米澎湃 OS (HyperOS) 视觉规范的 Material 3 主题配色：
 * - 采用 HyperOS 标志性澎湃蓝 (#0D6EFD) 与 Apple 系统分组背景色 (#F4F6FA / #0F1116)
 * - 大圆角卡片 (24dp) 与同心内嵌圆角控件 (14dp)
 */
@Composable
fun HyperAppleMaterialTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = Color(0xFF3B82F6),
            onPrimary = Color.White,
            primaryContainer = Color(0xFF1E3A8A),
            onPrimaryContainer = Color(0xFFDBEAFE),
            secondary = Color(0xFF60A5FA),
            secondaryContainer = Color(0xFF1E293B),
            onSecondaryContainer = Color(0xFFE2E8F0),
            tertiary = Color(0xFF34D399),
            tertiaryContainer = Color(0xFF064E3B),
            onTertiaryContainer = Color(0xFFD1FAE5),
            background = Color(0xFF0F1116),
            surface = Color(0xFF0F1116),
            surfaceContainerLow = Color(0xFF181B22),
            surfaceContainer = Color(0xFF1E222B),
            surfaceContainerHigh = Color(0xFF262B36)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF0D6EFD),
            onPrimary = Color.White,
            primaryContainer = Color(0xFFE0ECFF),
            onPrimaryContainer = Color(0xFF002D6B),
            secondary = Color(0xFF475569),
            secondaryContainer = Color(0xFFEFF3F8),
            onSecondaryContainer = Color(0xFF1E293B),
            tertiary = Color(0xFF059669),
            tertiaryContainer = Color(0xFFD1FAE5),
            onTertiaryContainer = Color(0xFF064E3B),
            background = Color(0xFFF4F6FA),
            surface = Color(0xFFF4F6FA),
            surfaceContainerLow = Color(0xFFFFFFFF),
            surfaceContainer = Color(0xFFEEF1F6),
            surfaceContainerHigh = Color(0xFFE5E9F0)
        )
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}

/**
 * 遵循 Apple HIG Motion 与小米 HyperOS 阻尼弹簧物理反馈的按压缩放修饰符
 */
private fun Modifier.springPressScale(enabled: Boolean = true): Modifier = composed {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (enabled && isPressed) 0.96f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "HyperSpringPress"
    )
    this.graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}

class MainActivity : ComponentActivity() {

    private var incomingExternalIntent by mutableStateOf<Intent?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null && intent != null) {
            incomingExternalIntent = intent
        }

        addOnNewIntentListener(Consumer { newIntent ->
            incomingExternalIntent = newIntent
        })

        setContent {
            HyperAppleMaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    BatchImageCompressorScreen(
                        externalIntent = incomingExternalIntent,
                        onExternalIntentConsumed = { incomingExternalIntent = null }
                    )
                }
            }
        }
    }
}

/**
 * 从外部应用传入的 Intent (ACTION_VIEW / ACTION_SEND / ACTION_SEND_MULTIPLE) 中提取所有文件 Uri
 */
private fun extractUrisFromIntent(intent: Intent): List<Uri> {
    val uris = LinkedHashSet<Uri>()
    when (intent.action) {
        Intent.ACTION_VIEW -> {
            intent.data?.let { uris.add(it) }
        }
        Intent.ACTION_SEND -> {
            val streamUri: Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            }
            streamUri?.let { uris.add(it) }
            intent.data?.let { uris.add(it) }
        }
        Intent.ACTION_SEND_MULTIPLE -> {
            val streamList: java.util.ArrayList<Uri>? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
            }
            streamList?.forEach { uris.add(it) }
        }
    }
    intent.clipData?.let { clip ->
        for (i in 0 until clip.itemCount) {
            clip.getItemAt(i)?.uri?.let { uris.add(it) }
        }
    }
    return uris.toList()
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun BatchImageCompressorScreen(
    externalIntent: Intent?,
    onExternalIntentConsumed: () -> Unit
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val coroutineScope = rememberCoroutineScope()

    // 底部导航栏当前选中的工作空间
    var currentMode by remember { mutableStateOf(ProcessMode.COMPRESS_TRANSCODE) }
    var archiveSubMode by remember { mutableStateOf(ArchiveSubMode.PACK_TO_ARCHIVE) }

    // 批量选中的图片列表与对应的处理结果映射
    var selectedImages by remember { mutableStateOf<List<SelectedImageItem>>(emptyList()) }
    val compressionResults = remember { mutableStateMapOf<Uri, CompressionResult>() }
    var lastBatchReport by remember { mutableStateOf<BatchExecutionReport?>(null) }
    var lastImportedArchiveBanner by remember { mutableStateOf<String?>(null) }

    // 参数面板展开/收起状态（Apple HIG Disclosure 渐进展开规范）
    var isConfigExpanded by remember { mutableStateOf(true) }

    // 压缩与转码参数状态
    var selectedFormat by remember { mutableStateOf(OutputFormat.JPEG) }
    var qualitySliderValue by remember { mutableFloatStateOf(80f) }
    var selectedResolution by remember { mutableStateOf(ResolutionOption.ORIGINAL) }

    // 文字加密混淆与解密还原参数状态
    var obfuscationKeyText by remember { mutableStateOf("") }
    var selectedBlockGrid by remember { mutableStateOf(BlockGridSize.BLOCK_16) }

    // 直接将结果压入压缩包配置状态
    var packResultIntoArchive by remember { mutableStateOf(false) }
    var selectedArchiveFormat by remember { mutableStateOf(ArchiveOutputFormat.ZIP) }
    var selectedArchiveLevel by remember { mutableStateOf(ArchiveCompressionLevel.STANDARD) }
    var customArchiveName by remember { mutableStateOf("") }

    // 自定义存储目录状态
    var customTreeUri by remember { mutableStateOf<Uri?>(null) }
    var customDirName by remember { mutableStateOf<String?>(null) }

    // 批量处理进度状态
    var isProcessing by remember { mutableStateOf(false) }
    var completedCount by remember { mutableIntStateOf(0) }
    var totalTaskCount by remember { mutableIntStateOf(0) }

    // 响应外部应用“分享 (Share)”或“打开方式 (Open with)”传入的多格式压缩包 (.zip/.7z/.rar/.tar.gz/.xz/.cbz) 或图片
    LaunchedEffect(externalIntent) {
        val intentToHandle = externalIntent ?: return@LaunchedEffect
        val incomingUris = extractUrisFromIntent(intentToHandle)
        onExternalIntentConsumed()

        if (incomingUris.isNotEmpty()) {
            val archiveUris = incomingUris.filter { ImageCompressor.isArchiveUri(context, it) }
            val imageUris = incomingUris.filterNot { ImageCompressor.isArchiveUri(context, it) }

            val mergedList = mutableListOf<SelectedImageItem>()
            if (archiveUris.isNotEmpty()) {
                val summary = ImageCompressor.extractImagesFromArchiveUris(context, archiveUris)
                mergedList.addAll(summary.extractedImages)
                lastImportedArchiveBanner = "已从外部 ${summary.archiveNames.joinToString(", ")} 提取 ${summary.extractedImages.size} 张图片"
                currentMode = ProcessMode.ARCHIVE_HUB
                archiveSubMode = ArchiveSubMode.EXTRACT_FROM_ARCHIVE
                if (summary.errorNote != null && summary.extractedImages.isEmpty()) {
                    Toast.makeText(context, summary.errorNote, Toast.LENGTH_LONG).show()
                }
            }
            if (imageUris.isNotEmpty()) {
                mergedList.addAll(ImageCompressor.inspectImages(context, imageUris))
            }

            if (mergedList.isNotEmpty()) {
                selectedImages = mergedList
                compressionResults.clear()
                lastBatchReport = null
                completedCount = 0
                totalTaskCount = mergedList.size
                Toast.makeText(
                    context,
                    "已载入 ${mergedList.size} 张图片",
                    Toast.LENGTH_SHORT
                ).show()
            } else if (archiveUris.isNotEmpty()) {
                Toast.makeText(
                    context,
                    "所选压缩包内未找到支持的图片文件",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    // 1. 系统 PhotoPicker 批量多选图片启动器
    val pickMultipleImagesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 50)
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            coroutineScope.launch {
                val inspected = ImageCompressor.inspectImages(context, uris)
                selectedImages = inspected
                lastImportedArchiveBanner = null
                compressionResults.clear()
                lastBatchReport = null
                completedCount = 0
                totalTaskCount = inspected.size
            }
        }
    }

    // 2. 应用内选择多格式压缩包 (.zip / .7z / .rar / .tar / .gz / .bz2 / .xz / .cbz) 启动器
    val pickArchiveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            coroutineScope.launch {
                val summary = ImageCompressor.extractImagesFromArchiveUris(context, uris)
                if (summary.extractedImages.isNotEmpty()) {
                    selectedImages = summary.extractedImages
                    lastImportedArchiveBanner = "已从 ${summary.archiveNames.joinToString(", ")} 提取 ${summary.extractedImages.size} 张图片"
                    compressionResults.clear()
                    lastBatchReport = null
                    completedCount = 0
                    totalTaskCount = summary.extractedImages.size
                    Toast.makeText(
                        context,
                        "成功从压缩包提取 ${summary.extractedImages.size} 张图片",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    Toast.makeText(
                        context,
                        summary.errorNote ?: "所选压缩包中未找到可识别的图片",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    // 3. SAF 目录选择器 (OpenDocumentTree)
    val pickOutputDirectoryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        if (treeUri != null) {
            runCatching {
                val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(treeUri, takeFlags)
            }
            customTreeUri = treeUri
            val docDir = DocumentFile.fromTreeUri(context, treeUri)
            customDirName = docDir?.name ?: treeUri.lastPathSegment ?: "自定义目录"
            Toast.makeText(context, "输出目录已设为：$customDirName", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        topBar = {
            // 遵循 Apple HIG Toolbars 规范：左侧/标题区显示简洁的当前视图功能名（而非冗长应用名），右侧放置无边框系统符号操作按钮
            TopAppBar(
                title = {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = currentMode.fullTitle,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            if (selectedImages.isNotEmpty()) {
                                Badge(
                                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                                ) {
                                    Text(
                                        text = "${selectedImages.size}",
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = currentMode.subtitle,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                actions = {
                    // 右侧工具栏无边框图标按钮：更改输出目录 + 清空队列（Apple HIG Trailing Edge 规范）
                    IconButton(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            pickOutputDirectoryLauncher.launch(customTreeUri)
                        },
                        enabled = !isProcessing
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.FolderOpen,
                            contentDescription = "选择输出目录",
                            tint = if (customTreeUri != null) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.onSurface
                            }
                        )
                    }

                    if (selectedImages.isNotEmpty() && !isProcessing) {
                        IconButton(
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                selectedImages = emptyList()
                                compressionResults.clear()
                                lastBatchReport = null
                                lastImportedArchiveBanner = null
                                completedCount = 0
                                totalTaskCount = 0
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.DeleteSweep,
                                contentDescription = "清空队列"
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            Column {
                // 遵循 Apple HIG TabBar Attached Accessory 与小米 HyperOS 底部单手触控区规范：悬浮式执行坞
                AnimatedVisibility(
                    visible = selectedImages.isNotEmpty(),
                    enter = expandVertically(
                        animationSpec = spring(stiffness = Spring.StiffnessMediumLow)
                    ) + fadeIn(),
                    exit = shrinkVertically() + fadeOut()
                ) {
                    BottomFloatingExecutionDock(
                        currentMode = currentMode,
                        archiveSubMode = archiveSubMode,
                        packResultIntoArchive = packResultIntoArchive,
                        archiveFormat = selectedArchiveFormat,
                        selectedCount = selectedImages.size,
                        isProcessing = isProcessing,
                        completedCount = completedCount,
                        totalTaskCount = totalTaskCount,
                        obfuscationKeyText = obfuscationKeyText,
                        onStartClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            isProcessing = true
                            completedCount = 0
                            totalTaskCount = selectedImages.size
                            compressionResults.clear()
                            lastBatchReport = null

                            val config = CompressionConfig(
                                mode = currentMode,
                                archiveSubMode = archiveSubMode,
                                format = selectedFormat,
                                quality = qualitySliderValue.roundToInt(),
                                resolutionOption = selectedResolution,
                                customTreeUri = customTreeUri,
                                obfuscationKey = obfuscationKeyText,
                                blockGridSize = selectedBlockGrid,
                                packResultIntoArchive = packResultIntoArchive,
                                archiveOutputFormat = selectedArchiveFormat,
                                archiveCompressionLevel = selectedArchiveLevel,
                                customArchiveBaseName = customArchiveName
                            )

                            coroutineScope.launch {
                                val report = ImageCompressor.processBatch(
                                    context = context,
                                    items = selectedImages,
                                    config = config,
                                    onProgress = { done, total, latest ->
                                        completedCount = done
                                        totalTaskCount = total
                                        compressionResults[latest.source.uri] = latest
                                    }
                                )
                                lastBatchReport = report
                                isProcessing = false
                                val successCount = report.itemResults.count { it.isSuccess }
                                val toastMsg = if (report.archiveFileName != null) {
                                    "已将 $successCount 张图片打包为 ${report.archiveFileName}"
                                } else {
                                    "${currentMode.shortTitle}完成：成功 $successCount / ${report.itemResults.size} 张"
                                }
                                Toast.makeText(context, toastMsg, Toast.LENGTH_LONG).show()
                            }
                        }
                    )
                }

                // 底部四栏导航（遵循 Apple HIG Tab Bars 规范：选中态使用实心 Filled 图标，未选中态使用线性 Outlined 图标，配单词标签）
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
                    tonalElevation = 0.dp
                ) {
                    ProcessMode.entries.forEach { mode ->
                        val isSelected = currentMode == mode
                        val icon = when (mode) {
                            ProcessMode.COMPRESS_TRANSCODE -> if (isSelected) Icons.Filled.Transform else Icons.Outlined.Transform
                            ProcessMode.OBFUSCATE_ENCRYPT -> if (isSelected) Icons.Filled.EnhancedEncryption else Icons.Outlined.EnhancedEncryption
                            ProcessMode.DEOBFUSCATE_RESTORE -> if (isSelected) Icons.Filled.LockOpen else Icons.Outlined.LockOpen
                            ProcessMode.ARCHIVE_HUB -> if (isSelected) Icons.Filled.FolderZip else Icons.Outlined.FolderZip
                        }
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = {
                                if (!isProcessing && currentMode != mode) {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    currentMode = mode
                                    isConfigExpanded = true
                                    if (mode == ProcessMode.DEOBFUSCATE_RESTORE) {
                                        selectedFormat = OutputFormat.PNG
                                    }
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = mode.shortTitle
                                )
                            },
                            label = {
                                Text(
                                    text = mode.shortTitle,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 第一部分：小米 HyperOS 双胶囊源导入栏 + 目录状态条
            item {
                TopImportAndPathSection(
                    selectedCount = selectedImages.size,
                    customDirName = customDirName,
                    isDirectArchiveActive = (currentMode == ProcessMode.ARCHIVE_HUB && archiveSubMode == ArchiveSubMode.PACK_TO_ARCHIVE) ||
                        (currentMode != ProcessMode.ARCHIVE_HUB && packResultIntoArchive),
                    isProcessing = isProcessing,
                    lastImportedArchiveBanner = lastImportedArchiveBanner,
                    onPickImages = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        pickMultipleImagesLauncher.launch(
                            PickVisualMediaRequest(
                                ActivityResultContracts.PickVisualMedia.ImageOnly
                            )
                        )
                    },
                    onPickArchives = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        pickArchiveLauncher.launch(arrayOf("*/*"))
                    },
                    onPickDirectory = {
                        pickOutputDirectoryLauncher.launch(customTreeUri)
                    },
                    onResetDirectory = {
                        customTreeUri = null
                        customDirName = null
                    }
                )
            }

            // 第二部分：遵循 Apple HIG + 小米 HyperOS 24dp 超椭圆卡片规范的【当前工作台参数卡】
            item {
                CollapsibleModeWorkspaceCard(
                    currentMode = currentMode,
                    archiveSubMode = archiveSubMode,
                    onSelectArchiveSubMode = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        archiveSubMode = it
                    },
                    isExpanded = isConfigExpanded,
                    onToggleExpand = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        isConfigExpanded = !isConfigExpanded
                    },
                    isProcessing = isProcessing,
                    selectedFormat = selectedFormat,
                    onSelectFormat = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        selectedFormat = it
                    },
                    qualitySliderValue = qualitySliderValue,
                    onQualityChange = { qualitySliderValue = it },
                    selectedResolution = selectedResolution,
                    onSelectResolution = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        selectedResolution = it
                    },
                    obfuscationKeyText = obfuscationKeyText,
                    onKeyTextChange = { obfuscationKeyText = it },
                    selectedBlockGrid = selectedBlockGrid,
                    onSelectBlockGrid = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        selectedBlockGrid = it
                    },
                    packResultIntoArchive = packResultIntoArchive,
                    onTogglePackResultIntoArchive = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        packResultIntoArchive = it
                    },
                    selectedArchiveFormat = selectedArchiveFormat,
                    onSelectArchiveFormat = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        selectedArchiveFormat = it
                    },
                    selectedArchiveLevel = selectedArchiveLevel,
                    onSelectArchiveLevel = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        selectedArchiveLevel = it
                    },
                    customArchiveName = customArchiveName,
                    onCustomArchiveNameChange = { customArchiveName = it },
                    onSwitchMode = { targetMode ->
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        currentMode = targetMode
                        if (targetMode == ProcessMode.DEOBFUSCATE_RESTORE) {
                            selectedFormat = OutputFormat.PNG
                        }
                    }
                )
            }

            // 第三部分：批量处理完成后的结果汇总横幅（含压缩包生成结果展示）
            if (compressionResults.isNotEmpty() || lastBatchReport?.archiveFileName != null) {
                item {
                    BatchSummaryBanner(
                        selectedImages = selectedImages,
                        resultsMap = compressionResults,
                        batchReport = lastBatchReport
                    )
                }
            }

            // 第四部分：图片队列工作台列表（或留白充足的空状态卡片）
            if (selectedImages.isEmpty()) {
                item {
                    EmptyWorkbenchCard(
                        currentMode = currentMode,
                        onPickImages = {
                            pickMultipleImagesLauncher.launch(
                                PickVisualMediaRequest(
                                    ActivityResultContracts.PickVisualMedia.ImageOnly
                                )
                            )
                        },
                        onPickArchives = {
                            pickArchiveLauncher.launch(arrayOf("*/*"))
                        }
                    )
                }
            } else {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp, vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "图片队列 (${selectedImages.size})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        val totalOrigSize = selectedImages.sumOf { it.originalSize }
                        Text(
                            text = "原始总计 ${ImageCompressor.formatFileSize(totalOrigSize)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                items(
                    items = selectedImages,
                    key = { it.uri.toString() }
                ) { item ->
                    ImageComparisonItemCard(
                        item = item,
                        result = compressionResults[item.uri],
                        isProcessing = isProcessing,
                        onRemoveItem = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            selectedImages = selectedImages.filterNot { it.uri == item.uri }
                            compressionResults.remove(item.uri)
                        }
                    )
                }
            }
        }
    }
}

/**
 * Apple HIG + 小米 HyperOS 风格的分段胶囊控制器 (Segmented Control)
 */
@Composable
private fun <T> HyperSegmentedControl(
    items: List<T>,
    selectedItem: T,
    itemLabel: (T) -> String,
    enabled: Boolean = true,
    onItemSelected: (T) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items.forEach { item ->
                val isSelected = item == selectedItem
                val pillColor by animateColorAsState(
                    targetValue = if (isSelected) {
                        MaterialTheme.colorScheme.surfaceContainerLow
                    } else {
                        Color.Transparent
                    },
                    animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                    label = "SegmentPillColor"
                )
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = pillColor,
                    shadowElevation = if (isSelected) 2.dp else 0.dp,
                    modifier = Modifier
                        .weight(1f)
                        .springPressScale(enabled)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable(enabled = enabled) { onItemSelected(item) }
                ) {
                    Text(
                        text = itemLabel(item),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp)
                    )
                }
            }
        }
    }
}

/**
 * 顶部双胶囊导入按钮 + 紧凑型存储目录胶囊条（遵循 Concentric Corner Radii 同心圆角规范）
 */
@Composable
private fun TopImportAndPathSection(
    selectedCount: Int,
    customDirName: String?,
    isDirectArchiveActive: Boolean,
    isProcessing: Boolean,
    lastImportedArchiveBanner: String?,
    onPickImages: () -> Unit,
    onPickArchives: () -> Unit,
    onPickDirectory: () -> Unit,
    onResetDirectory: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onPickImages,
                enabled = !isProcessing,
                shape = RoundedCornerShape(16.dp),
                contentPadding = PaddingValues(vertical = 13.dp, horizontal = 14.dp),
                modifier = Modifier
                    .weight(1f)
                    .springPressScale(!isProcessing)
            ) {
                Icon(
                    imageVector = Icons.Default.AddPhotoAlternate,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (selectedCount == 0) "批量选图片" else "重选图片 ($selectedCount)",
                    fontWeight = FontWeight.SemiBold
                )
            }

            FilledTonalButton(
                onClick = onPickArchives,
                enabled = !isProcessing,
                shape = RoundedCornerShape(16.dp),
                contentPadding = PaddingValues(vertical = 13.dp, horizontal = 14.dp),
                modifier = Modifier
                    .weight(1f)
                    .springPressScale(!isProcessing)
            ) {
                Icon(
                    imageVector = Icons.Default.FolderZip,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "导入压缩包",
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // 存储路径状态胶囊条
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surfaceContainerLow,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .weight(1f)
                        .clickable(enabled = !isProcessing) { onPickDirectory() }
                ) {
                    Icon(
                        imageVector = Icons.Outlined.FolderOpen,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    val defaultPathText = if (isDirectArchiveActive) {
                        "默认目录：Download/CompressedArchives"
                    } else {
                        "默认相册：Pictures/Compressed"
                    }
                    Text(
                        text = if (customDirName != null) {
                            "输出至自定义目录：$customDirName"
                        } else {
                            defaultPathText
                        },
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (customDirName != null && !isProcessing) {
                        TextButton(
                            onClick = onResetDirectory,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Restore,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text("默认", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    TextButton(
                        onClick = onPickDirectory,
                        enabled = !isProcessing,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Text("切换目录", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        if (lastImportedArchiveBanner != null) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.tertiaryContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.FolderZip,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onTertiaryContainer,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = lastImportedArchiveBanner,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onTertiaryContainer
                    )
                }
            }
        }
    }
}

/**
 * 24dp 超椭圆圆角工作台参数卡片（支持跨模式 AnimatedContent 弹簧过渡与一键收起）
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CollapsibleModeWorkspaceCard(
    currentMode: ProcessMode,
    archiveSubMode: ArchiveSubMode,
    onSelectArchiveSubMode: (ArchiveSubMode) -> Unit,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    isProcessing: Boolean,
    selectedFormat: OutputFormat,
    onSelectFormat: (OutputFormat) -> Unit,
    qualitySliderValue: Float,
    onQualityChange: (Float) -> Unit,
    selectedResolution: ResolutionOption,
    onSelectResolution: (ResolutionOption) -> Unit,
    obfuscationKeyText: String,
    onKeyTextChange: (String) -> Unit,
    selectedBlockGrid: BlockGridSize,
    onSelectBlockGrid: (BlockGridSize) -> Unit,
    packResultIntoArchive: Boolean,
    onTogglePackResultIntoArchive: (Boolean) -> Unit,
    selectedArchiveFormat: ArchiveOutputFormat,
    onSelectArchiveFormat: (ArchiveOutputFormat) -> Unit,
    selectedArchiveLevel: ArchiveCompressionLevel,
    onSelectArchiveLevel: (ArchiveCompressionLevel) -> Unit,
    customArchiveName: String,
    onCustomArchiveNameChange: (String) -> Unit,
    onSwitchMode: (ProcessMode) -> Unit
) {
    ElevatedCard(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // 卡片顶部折叠栏
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleExpand() }
                    .padding(horizontal = 18.dp, vertical = 15.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "${currentMode.shortTitle}工作台参数",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        val summaryLine = when (currentMode) {
                            ProcessMode.COMPRESS_TRANSCODE -> {
                                val qText = if (selectedFormat.supportsQualitySlider) {
                                    "画质 ${qualitySliderValue.roundToInt()}%"
                                } else {
                                    "无损像素"
                                }
                                val packSuffix = if (packResultIntoArchive) {
                                    " · 直压 ${selectedArchiveFormat.shortLabel}"
                                } else {
                                    ""
                                }
                                "${selectedFormat.shortLabel} · $qText · ${selectedResolution.label}$packSuffix"
                            }
                            ProcessMode.OBFUSCATE_ENCRYPT -> {
                                val keyStatus = if (obfuscationKeyText.isBlank()) "待填口令" else "口令已就绪"
                                val packSuffix = if (packResultIntoArchive) {
                                    " · 直压 ${selectedArchiveFormat.shortLabel}"
                                } else {
                                    " · 无损 PNG"
                                }
                                "$keyStatus · 色块 ${selectedBlockGrid.shortLabel}$packSuffix"
                            }
                            ProcessMode.DEOBFUSCATE_RESTORE -> {
                                val keyStatus = if (obfuscationKeyText.isBlank()) "待填口令" else "口令已就绪"
                                "$keyStatus · 色块 ${selectedBlockGrid.shortLabel} · 导出 ${selectedFormat.shortLabel}"
                            }
                            ProcessMode.ARCHIVE_HUB -> {
                                if (archiveSubMode == ArchiveSubMode.PACK_TO_ARCHIVE) {
                                    "直接压入 ${selectedArchiveFormat.label} · ${selectedArchiveLevel.label}"
                                } else {
                                    "兼容 ZIP / 7Z / RAR / TAR.GZ / BZ2 / XZ / CBZ 解压"
                                }
                            }
                        }
                        Text(
                            text = summaryLine,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (isExpanded) "收起" else "展开",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically(
                    animationSpec = spring(stiffness = Spring.StiffnessMediumLow)
                ) + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                // 使用 AnimatedContent 实现底部导航栏切换时的平滑过渡动效
                AnimatedContent(
                    targetState = currentMode,
                    transitionSpec = {
                        fadeIn(animationSpec = tween(200)) togetherWith fadeOut(animationSpec = tween(150))
                    },
                    label = "ModeWorkspaceTransition"
                ) { targetMode ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 18.dp, end = 18.dp, bottom = 18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.surfaceContainerHigh)

                        when (targetMode) {
                            ProcessMode.COMPRESS_TRANSCODE -> {
                                Text(
                                    text = "目标图片格式",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.SemiBold
                                )
                                HyperSegmentedControl(
                                    items = OutputFormat.entries,
                                    selectedItem = selectedFormat,
                                    itemLabel = { it.shortLabel },
                                    enabled = !isProcessing,
                                    onItemSelected = onSelectFormat
                                )
                                Text(
                                    text = selectedFormat.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                if (selectedFormat.supportsQualitySlider) {
                                    Column {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "画质压缩比",
                                                style = MaterialTheme.typography.labelLarge,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Text(
                                                text = "${qualitySliderValue.roundToInt()}%",
                                                style = MaterialTheme.typography.labelLarge,
                                                color = MaterialTheme.colorScheme.primary,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Slider(
                                            value = qualitySliderValue,
                                            onValueChange = onQualityChange,
                                            valueRange = 10f..100f,
                                            steps = 17,
                                            enabled = !isProcessing
                                        )
                                    }
                                }

                                Text(
                                    text = "分辨率最长边限制",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.SemiBold
                                )
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    ResolutionOption.entries.forEach { option ->
                                        FilterChip(
                                            selected = selectedResolution == option,
                                            onClick = { if (!isProcessing) onSelectResolution(option) },
                                            label = { Text(option.label) },
                                            enabled = !isProcessing,
                                            shape = RoundedCornerShape(10.dp)
                                        )
                                    }
                                }

                                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceContainerHigh)

                                // 直接将压缩后图片打包进压缩包开关
                                DirectPackArchiveToggleSection(
                                    checked = packResultIntoArchive,
                                    onCheckedChange = onTogglePackResultIntoArchive,
                                    selectedArchiveFormat = selectedArchiveFormat,
                                    onSelectArchiveFormat = onSelectArchiveFormat,
                                    selectedArchiveLevel = selectedArchiveLevel,
                                    onSelectArchiveLevel = onSelectArchiveLevel,
                                    customArchiveName = customArchiveName,
                                    onCustomArchiveNameChange = onCustomArchiveNameChange,
                                    isProcessing = isProcessing
                                )
                            }

                            ProcessMode.OBFUSCATE_ENCRYPT, ProcessMode.DEOBFUSCATE_RESTORE -> {
                                val isEncrypt = targetMode == ProcessMode.OBFUSCATE_ENCRYPT
                                OutlinedTextField(
                                    value = obfuscationKeyText,
                                    onValueChange = onKeyTextChange,
                                    label = {
                                        Text(
                                            if (isEncrypt) "输入加密混淆口令文字" else "输入加密时的同一串文字口令"
                                        )
                                    },
                                    placeholder = { Text("任意中文、英文、数字或短句") },
                                    leadingIcon = {
                                        Icon(imageVector = Icons.Default.Key, contentDescription = null)
                                    },
                                    trailingIcon = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            if (obfuscationKeyText.isNotEmpty()) {
                                                IconButton(onClick = { onKeyTextChange("") }) {
                                                    Icon(
                                                        imageVector = Icons.Default.Clear,
                                                        contentDescription = "清空口令"
                                                    )
                                                }
                                            } else if (isEncrypt) {
                                                IconButton(
                                                    onClick = {
                                                        val randomPin = "口令" + Random.nextInt(100000, 999999)
                                                        onKeyTextChange(randomPin)
                                                    }
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Casino,
                                                        contentDescription = "随机生成口令"
                                                    )
                                                }
                                            }
                                        }
                                    },
                                    singleLine = true,
                                    enabled = !isProcessing,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.GridView,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "色块网格粒度（加密与还原须保持一致）",
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }

                                HyperSegmentedControl(
                                    items = BlockGridSize.entries,
                                    selectedItem = selectedBlockGrid,
                                    itemLabel = { it.shortLabel },
                                    enabled = !isProcessing,
                                    onItemSelected = onSelectBlockGrid
                                )

                                if (!isEncrypt) {
                                    Text(
                                        text = "还原后输出格式（推荐 PNG 无损）",
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    HyperSegmentedControl(
                                        items = OutputFormat.entries,
                                        selectedItem = selectedFormat,
                                        itemLabel = { it.shortLabel },
                                        enabled = !isProcessing,
                                        onItemSelected = onSelectFormat
                                    )
                                }

                                HorizontalDivider(color = MaterialTheme.colorScheme.surfaceContainerHigh)

                                DirectPackArchiveToggleSection(
                                    checked = packResultIntoArchive,
                                    onCheckedChange = onTogglePackResultIntoArchive,
                                    selectedArchiveFormat = selectedArchiveFormat,
                                    onSelectArchiveFormat = onSelectArchiveFormat,
                                    selectedArchiveLevel = selectedArchiveLevel,
                                    onSelectArchiveLevel = onSelectArchiveLevel,
                                    customArchiveName = customArchiveName,
                                    onCustomArchiveNameChange = onCustomArchiveNameChange,
                                    isProcessing = isProcessing
                                )
                            }

                            ProcessMode.ARCHIVE_HUB -> {
                                // Apple HIG Segmented Control 切换「图片打入压缩包」与「从压缩包解压图片」
                                HyperSegmentedControl(
                                    items = ArchiveSubMode.entries,
                                    selectedItem = archiveSubMode,
                                    itemLabel = { it.label },
                                    enabled = !isProcessing,
                                    onItemSelected = onSelectArchiveSubMode
                                )

                                Text(
                                    text = archiveSubMode.desc,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                if (archiveSubMode == ArchiveSubMode.PACK_TO_ARCHIVE) {
                                    ArchivePackParamsContent(
                                        selectedArchiveFormat = selectedArchiveFormat,
                                        onSelectArchiveFormat = onSelectArchiveFormat,
                                        selectedArchiveLevel = selectedArchiveLevel,
                                        onSelectArchiveLevel = onSelectArchiveLevel,
                                        customArchiveName = customArchiveName,
                                        onCustomArchiveNameChange = onCustomArchiveNameChange,
                                        isProcessing = isProcessing
                                    )
                                } else {
                                    Surface(
                                        shape = RoundedCornerShape(14.dp),
                                        color = MaterialTheme.colorScheme.secondaryContainer,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(12.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Text(
                                                text = "已兼容主流压缩格式：.zip · .7z · .rar · .cbz · .cbr · .tar · .tar.gz · .tar.bz2 · .tar.xz",
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSecondaryContainer
                                            )
                                            Text(
                                                text = "支持在 MT 管理器、文件管理或微信中通过「打开方式 / 分享」直接把压缩包发给本应用提取图片，也可将提取出的图片一键送往其他工作台：",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSecondaryContainer
                                            )
                                            FlowRow(
                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                verticalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                FilledTonalButton(
                                                    onClick = { onSwitchMode(ProcessMode.COMPRESS_TRANSCODE) },
                                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                                ) {
                                                    Text("转去压缩画质", style = MaterialTheme.typography.labelMedium)
                                                }
                                                FilledTonalButton(
                                                    onClick = { onSwitchMode(ProcessMode.OBFUSCATE_ENCRYPT) },
                                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                                ) {
                                                    Text("转去文字混淆", style = MaterialTheme.typography.labelMedium)
                                                }
                                                FilledTonalButton(
                                                    onClick = { onSwitchMode(ProcessMode.DEOBFUSCATE_RESTORE) },
                                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                                ) {
                                                    Text("转去口令还原", style = MaterialTheme.typography.labelMedium)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * 嵌入在压缩/混淆/还原模式中的「完成后直接压入压缩包」开关与折叠参数组件
 */
@Composable
private fun DirectPackArchiveToggleSection(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    selectedArchiveFormat: ArchiveOutputFormat,
    onSelectArchiveFormat: (ArchiveOutputFormat) -> Unit,
    selectedArchiveLevel: ArchiveCompressionLevel,
    onSelectArchiveLevel: (ArchiveCompressionLevel) -> Unit,
    customArchiveName: String,
    onCustomArchiveNameChange: (String) -> Unit,
    isProcessing: Boolean
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(enabled = !isProcessing) { onCheckedChange(!checked) },
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "处理后直接打包压入压缩包",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "开启后将所有处理结果直接封装进单个压缩包，不在相册散存单张图",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                enabled = !isProcessing
            )
        }

        AnimatedVisibility(
            visible = checked,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            ArchivePackParamsContent(
                selectedArchiveFormat = selectedArchiveFormat,
                onSelectArchiveFormat = onSelectArchiveFormat,
                selectedArchiveLevel = selectedArchiveLevel,
                onSelectArchiveLevel = onSelectArchiveLevel,
                customArchiveName = customArchiveName,
                onCustomArchiveNameChange = onCustomArchiveNameChange,
                isProcessing = isProcessing
            )
        }
    }
}

/**
 * 压缩包打包参数面板（格式选择：ZIP / CBZ / TAR.GZ / TAR + 压缩等级 + 自定义包名）
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ArchivePackParamsContent(
    selectedArchiveFormat: ArchiveOutputFormat,
    onSelectArchiveFormat: (ArchiveOutputFormat) -> Unit,
    selectedArchiveLevel: ArchiveCompressionLevel,
    onSelectArchiveLevel: (ArchiveCompressionLevel) -> Unit,
    customArchiveName: String,
    onCustomArchiveNameChange: (String) -> Unit,
    isProcessing: Boolean
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "目标压缩包格式",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold
        )
        HyperSegmentedControl(
            items = ArchiveOutputFormat.entries,
            selectedItem = selectedArchiveFormat,
            itemLabel = { it.shortLabel },
            enabled = !isProcessing,
            onItemSelected = onSelectArchiveFormat
        )
        Text(
            text = selectedArchiveFormat.description,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        if (selectedArchiveFormat == ArchiveOutputFormat.ZIP ||
            selectedArchiveFormat == ArchiveOutputFormat.CBZ
        ) {
            Text(
                text = "压缩包压缩率等级",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold
            )
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ArchiveCompressionLevel.entries.forEach { level ->
                    FilterChip(
                        selected = selectedArchiveLevel == level,
                        onClick = { if (!isProcessing) onSelectArchiveLevel(level) },
                        label = { Text(level.label) },
                        enabled = !isProcessing,
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }
        }

        OutlinedTextField(
            value = customArchiveName,
            onValueChange = onCustomArchiveNameChange,
            label = { Text("自定义压缩包名称（可选，留空自动按时间命名）") },
            placeholder = { Text("例如：旅行照片合集_2026") },
            leadingIcon = {
                Icon(imageVector = Icons.Default.Archive, contentDescription = null)
            },
            singleLine = true,
            enabled = !isProcessing,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/**
 * 底部悬浮执行坞（遵循 Apple HIG TabBar Accessory 与小米 HyperOS 底部触控热区规范）
 */
@Composable
private fun BottomFloatingExecutionDock(
    currentMode: ProcessMode,
    archiveSubMode: ArchiveSubMode,
    packResultIntoArchive: Boolean,
    archiveFormat: ArchiveOutputFormat,
    selectedCount: Int,
    isProcessing: Boolean,
    completedCount: Int,
    totalTaskCount: Int,
    obfuscationKeyText: String,
    onStartClick: () -> Unit
) {
    val requiresKey = currentMode == ProcessMode.OBFUSCATE_ENCRYPT ||
        currentMode == ProcessMode.DEOBFUSCATE_RESTORE
    val canStart = selectedCount > 0 && !isProcessing &&
        (!requiresKey || obfuscationKeyText.isNotBlank())

    Surface(
        color = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.96f),
        tonalElevation = 3.dp,
        shadowElevation = 8.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (isProcessing && totalTaskCount > 0) {
                LinearProgressIndicator(
                    progress = { completedCount.toFloat() / totalTaskCount.toFloat() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                )
            }

            Button(
                onClick = onStartClick,
                enabled = canStart,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .springPressScale(canStart)
            ) {
                val actionIcon = when {
                    currentMode == ProcessMode.ARCHIVE_HUB && archiveSubMode == ArchiveSubMode.PACK_TO_ARCHIVE -> Icons.Default.Archive
                    currentMode == ProcessMode.ARCHIVE_HUB && archiveSubMode == ArchiveSubMode.EXTRACT_FROM_ARCHIVE -> Icons.Default.Unarchive
                    packResultIntoArchive -> Icons.Default.Archive
                    else -> Icons.Default.PlayArrow
                }
                Icon(imageVector = actionIcon, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))

                val packSuffix = if (packResultIntoArchive && currentMode != ProcessMode.ARCHIVE_HUB) {
                    "并压入 .${archiveFormat.extension}"
                } else {
                    ""
                }

                val labelText = when {
                    isProcessing -> "正在执行${currentMode.shortTitle} ($completedCount / $totalTaskCount)..."
                    requiresKey && obfuscationKeyText.isBlank() -> "请先在上方输入文字口令"
                    currentMode == ProcessMode.COMPRESS_TRANSCODE -> "开始压缩 / 转码$packSuffix ($selectedCount 张)"
                    currentMode == ProcessMode.OBFUSCATE_ENCRYPT -> "开始混淆为色块$packSuffix ($selectedCount 张)"
                    currentMode == ProcessMode.DEOBFUSCATE_RESTORE -> "开始无损还原$packSuffix ($selectedCount 张)"
                    currentMode == ProcessMode.ARCHIVE_HUB && archiveSubMode == ArchiveSubMode.PACK_TO_ARCHIVE ->
                        "直接压入 .${archiveFormat.extension} 压缩包 ($selectedCount 张)"
                    else -> "直接无损解压全部图片 ($selectedCount 张)"
                }
                Text(
                    text = labelText,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun BatchSummaryBanner(
    selectedImages: List<SelectedImageItem>,
    resultsMap: Map<Uri, CompressionResult>,
    batchReport: BatchExecutionReport?
) {
    val successfulResults = selectedImages.mapNotNull { resultsMap[it.uri] }.filter { it.isSuccess }
    if (successfulResults.isEmpty()) return

    val totalOriginalBytes = successfulResults.sumOf { it.source.originalSize }
    val totalCompressedBytes = successfulResults.sumOf { it.compressedSize }
    val diffBytes = totalOriginalBytes - totalCompressedBytes
    val ratioPercent = if (totalOriginalBytes > 0) {
        (diffBytes.toDouble() / totalOriginalBytes.toDouble() * 100.0)
    } else {
        0.0
    }
    val mode = successfulResults.first().mode

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text(
                text = if (batchReport?.archiveFileName != null) {
                    "已打包生成压缩包：${batchReport.archiveFileName}"
                } else {
                    "${mode.shortTitle}已完成 (${successfulResults.size} / ${selectedImages.size} 张)"
                },
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "原始总大小：${ImageCompressor.formatFileSize(totalOriginalBytes)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                val outBytesToShow = if (batchReport != null && batchReport.archiveTotalBytes > 0L) {
                    batchReport.archiveTotalBytes
                } else {
                    totalCompressedBytes
                }
                Text(
                    text = "输出总大小：${ImageCompressor.formatFileSize(outBytesToShow)}",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }

            val footerNote = when {
                batchReport?.archiveSavedPathLabel != null ->
                    "归档保存位置：${batchReport.archiveSavedPathLabel}"
                mode == ProcessMode.OBFUSCATE_ENCRYPT ->
                    "已保存为无损 PNG 色块图，凭文字口令可随时 100% 还原"
                mode == ProcessMode.DEOBFUSCATE_RESTORE ->
                    "已按文字口令完成像素级逆向解混淆还原"
                mode == ProcessMode.ARCHIVE_HUB ->
                    "已将压缩包内图片原样无损导出到目标目录"
                else -> {
                    if (diffBytes >= 0) {
                        String.format(
                            Locale.US,
                            "累计节省：%s (-%.1f%%)",
                            ImageCompressor.formatFileSize(diffBytes),
                            ratioPercent
                        )
                    } else {
                        String.format(
                            Locale.US,
                            "无损转换体积变化：+%s (+%.1f%%)",
                            ImageCompressor.formatFileSize(abs(diffBytes)),
                            abs(ratioPercent)
                        )
                    }
                }
            }
            Text(
                text = footerNote,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

/**
 * 遵循小米 HyperOS 大圆角卡片规范的单张图片对比行
 */
@Composable
private fun ImageComparisonItemCard(
    item: SelectedImageItem,
    result: CompressionResult?,
    isProcessing: Boolean,
    onRemoveItem: () -> Unit
) {
    ElevatedCard(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 0.5.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 原图缩略图 (Concentric inner radius = 12dp)
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainer)
            ) {
                AsyncImage(
                    model = item.uri,
                    contentDescription = item.displayName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Surface(
                    color = Color.Black.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(bottomEnd = 6.dp),
                    modifier = Modifier.align(Alignment.TopStart)
                ) {
                    Text(
                        text = "原图",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                    )
                }
            }

            // 处理后结果缩略图（并排对比）
            if (result != null && result.isSuccess && result.outputUri != null) {
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainer)
                ) {
                    AsyncImage(
                        model = result.outputUri,
                        contentDescription = result.outputName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.88f),
                        shape = RoundedCornerShape(bottomEnd = 6.dp),
                        modifier = Modifier.align(Alignment.TopStart)
                    ) {
                        Text(
                            text = when {
                                result.packedIntoArchiveName != null -> "已入包"
                                result.mode == ProcessMode.OBFUSCATE_ENCRYPT -> "色块"
                                result.mode == ProcessMode.DEOBFUSCATE_RESTORE -> "还原"
                                else -> "结果"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = item.displayName,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (item.fromArchiveName != null) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer
                        ) {
                            Text(
                                text = "来自压缩包",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                            )
                        }
                    }
                }

                val srcFormatShort = item.mimeType.substringAfterLast('/').uppercase(Locale.ROOT)
                Text(
                    text = "$srcFormatShort · ${item.width}×${item.height} · ${
                        ImageCompressor.formatFileSize(item.originalSize)
                    }",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (result != null) {
                    if (result.isSuccess) {
                        val deltaRatio = if (item.originalSize > 0) {
                            ((result.compressedSize - item.originalSize).toDouble() / item.originalSize.toDouble()) * 100.0
                        } else {
                            0.0
                        }
                        val ratioLabel = if (deltaRatio <= 0) {
                            String.format(Locale.US, "%.1f%%", deltaRatio)
                        } else {
                            String.format(Locale.US, "+%.1f%%", deltaRatio)
                        }
                        val badgeColor = if (deltaRatio <= 0) {
                            Color(0xFF059669)
                        } else {
                            MaterialTheme.colorScheme.primary
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = badgeColor,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${result.outputFormat.extension.uppercase(Locale.ROOT)} · " +
                                    "${result.outputWidth}×${result.outputHeight} · " +
                                    "${ImageCompressor.formatFileSize(result.compressedSize)} ($ratioLabel)",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = badgeColor
                            )
                        }

                        Text(
                            text = result.savedPathLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.ErrorOutline,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = result.errorMessage ?: "处理失败",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }

            if (!isProcessing) {
                IconButton(
                    onClick = onRemoveItem,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "移除此图片",
                        tint = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

/**
 * 留白充足的 24dp 超椭圆空状态引导卡片
 */
@Composable
private fun EmptyWorkbenchCard(
    currentMode: ProcessMode,
    onPickImages: () -> Unit,
    onPickArchives: () -> Unit
) {
    ElevatedCard(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        ),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 0.5.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 34.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (currentMode == ProcessMode.ARCHIVE_HUB) {
                        Icons.Outlined.FolderZip
                    } else {
                        Icons.Outlined.PhotoLibrary
                    },
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(30.dp)
                )
            }

            Text(
                text = "当前工作台暂无图片",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "支持批量选取相册照片直接处理或压入压缩包；也可在 MT 管理器、文件管理、微信中对 .zip / .7z / .rar / .tar.gz / .xz / .cbz 选择「打开方式 / 分享」发给本应用",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FilledTonalButton(
                    onClick = onPickImages,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.springPressScale()
                ) {
                    Icon(
                        imageVector = Icons.Default.AddPhotoAlternate,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("选择相册图片")
                }
                FilledTonalButton(
                    onClick = onPickArchives,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.springPressScale()
                ) {
                    Icon(
                        imageVector = Icons.Default.FolderZip,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("导入多格式压缩包")
                }
            }
        }
    }
}
