package com.example.imagecompressor

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.EnhancedEncryption
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.EnhancedEncryption
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.FolderZip
import androidx.compose.material.icons.outlined.LockOpen
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Transform
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.VerticalDivider
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.util.Consumer
import androidx.documentfile.provider.DocumentFile
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * 标准 Material Design 3 & FlClash 缓动曲线与动画时长常量：
 * - Standard Easing: cubic-bezier(0.2, 0.0, 0.0, 1.0)
 * - Transition Duration: 280ms (Enter/Shared Axis), 220ms (Exit)
 */
private val FlClashStandardEasing = CubicBezierEasing(0.2f, 0.0f, 0.0f, 1.0f)
private const val TRANSITION_DURATION_MS = 280
private const val EXIT_DURATION_MS = 200

/**
 * FlClash 风格 Material Design 3 (Material You) 调色板：
 * - 支持 Android 12+ 系统壁纸动态取色 (Dynamic Color) 与经典 FlClash 靛青色阶切换
 * - 通过 Surface / SurfaceContainerLow / SurfaceContainerHigh 细微色阶与 1dp OutlineVariant 描边区分层次，摒弃厚重阴影
 */
@Composable
fun FlClashM3Theme(
    useDynamicColor: Boolean = true,
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val colorScheme = when {
        useDynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> darkColorScheme(
            primary = Color(0xFF8AB4F8),
            onPrimary = Color(0xFF002E6B),
            primaryContainer = Color(0xFF1E3A5F),
            onPrimaryContainer = Color(0xFFD3E3FD),
            secondary = Color(0xFFBCC7DC),
            secondaryContainer = Color(0xFF283141),
            onSecondaryContainer = Color(0xFFD8E3F8),
            tertiary = Color(0xFF81C995),
            tertiaryContainer = Color(0xFF0F5223),
            onTertiaryContainer = Color(0xFFCEEAD6),
            background = Color(0xFF111318),
            surface = Color(0xFF111318),
            surfaceContainerLow = Color(0xFF191C22),
            surfaceContainer = Color(0xFF1E2229),
            surfaceContainerHigh = Color(0xFF282C35),
            outlineVariant = Color(0xFF333842)
        )
        else -> lightColorScheme(
            primary = Color(0xFF1A73E8),
            onPrimary = Color.White,
            primaryContainer = Color(0xFFD3E3FD),
            onPrimaryContainer = Color(0xFF041E49),
            secondary = Color(0xFF535F70),
            secondaryContainer = Color(0xFFD7E3F7),
            onSecondaryContainer = Color(0xFF101C2B),
            tertiary = Color(0xFF188038),
            tertiaryContainer = Color(0xFFCEEAD6),
            onTertiaryContainer = Color(0xFF072711),
            background = Color(0xFFF8FAFD),
            surface = Color(0xFFF8FAFD),
            surfaceContainerLow = Color(0xFFFFFFFF),
            surfaceContainer = Color(0xFFF0F4F9),
            surfaceContainerHigh = Color(0xFFE6ECF5),
            outlineVariant = Color(0xFFDADCE0)
        )
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}

/**
 * 微交互修饰符：提供柔和 M3 水波纹与 0.98f 按压缩放反馈（使用 cubic-bezier(0.2, 0, 0, 1)）
 */
private fun Modifier.flClashInteractive(
    enabled: Boolean = true,
    shape: Shape = RoundedCornerShape(18.dp),
    onClick: () -> Unit
): Modifier = composed {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (enabled && isPressed) 0.98f else 1f,
        animationSpec = tween(durationMillis = 150, easing = FlClashStandardEasing),
        label = "FlClashMicroScale"
    )
    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clip(shape)
        .clickable(
            interactionSource = interactionSource,
            indication = LocalIndication.current,
            enabled = enabled,
            onClick = onClick
        )
}

/**
 * 绑定外部 InteractionSource 的 0.98f 缩放修饰符（用于 Button / FilledTonalButton）
 */
@Composable
private fun Modifier.flClashButtonScale(
    interactionSource: MutableInteractionSource,
    enabled: Boolean = true
): Modifier {
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (enabled && isPressed) 0.98f else 1f,
        animationSpec = tween(durationMillis = 150, easing = FlClashStandardEasing),
        label = "FlClashBtnScale"
    )
    return this.graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}

/**
 * FlClash 标志性 18dp 圆角 + 1dp 细边框 + 零阴影色阶容器卡片
 */
@Composable
private fun FlClashSurfaceCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 18.dp,
    containerColor: Color = MaterialTheme.colorScheme.surfaceContainerLow,
    borderColor: Color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f),
    content: @Composable () -> Unit
) {
    OutlinedCard(
        shape = RoundedCornerShape(cornerRadius),
        colors = CardDefaults.outlinedCardColors(containerColor = containerColor),
        border = BorderStroke(1.dp, borderColor),
        elevation = CardDefaults.outlinedCardElevation(defaultElevation = 0.dp),
        modifier = modifier
    ) {
        content()
    }
}

class MainActivity : ComponentActivity() {

    private var incomingExternalIntent by mutableStateOf<Intent?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null && intent != null) {
            incomingExternalIntent = intent
        }

        addOnNewIntentListener(Consumer { newIntent ->
            incomingExternalIntent = newIntent
        })

        setContent {
            var useDynamicColor by remember { mutableStateOf(true) }
            FlClashM3Theme(useDynamicColor = useDynamicColor) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    FlClashAdaptiveDashboardApp(
                        externalIntent = incomingExternalIntent,
                        onExternalIntentConsumed = { incomingExternalIntent = null },
                        useDynamicColor = useDynamicColor,
                        onToggleDynamicColor = { useDynamicColor = !useDynamicColor }
                    )
                }
            }
        }
    }
}

/**
 * 从外部应用传入的 Intent (ACTION_VIEW / ACTION_SEND / ACTION_SEND_MULTIPLE) 中提取所有文件 Uri
 */
private fun extractUrisFromIntent(intent: Intent): List<Uri> {
    val uris = LinkedHashSet<Uri>()
    when (intent.action) {
        Intent.ACTION_VIEW -> {
            intent.data?.let { uris.add(it) }
        }
        Intent.ACTION_SEND -> {
            val streamUri: Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            }
            streamUri?.let { uris.add(it) }
            intent.data?.let { uris.add(it) }
        }
        Intent.ACTION_SEND_MULTIPLE -> {
            val streamList: java.util.ArrayList<Uri>? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
            }
            streamList?.forEach { uris.add(it) }
        }
    }
    intent.clipData?.let { clip ->
        for (i in 0 until clip.itemCount) {
            clip.getItemAt(i)?.uri?.let { uris.add(it) }
        }
    }
    return uris.toList()
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun FlClashAdaptiveDashboardApp(
    externalIntent: Intent?,
    onExternalIntentConsumed: () -> Unit,
    useDynamicColor: Boolean,
    onToggleDynamicColor: () -> Unit
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val coroutineScope = rememberCoroutineScope()

    // 顶层工作空间状态
    var currentMode by remember { mutableStateOf(ProcessMode.COMPRESS_TRANSCODE) }
    var archiveSubMode by remember { mutableStateOf(ArchiveSubMode.PACK_TO_ARCHIVE) }

    // 图片队列与处理结果映射
    var selectedImages by remember { mutableStateOf<List<SelectedImageItem>>(emptyList()) }
    val compressionResults = remember { mutableStateMapOf<Uri, CompressionResult>() }
    var lastBatchReport by remember { mutableStateOf<BatchExecutionReport?>(null) }
    var lastImportedArchiveBanner by remember { mutableStateOf<String?>(null) }

    // Container Transform 卡片详情检视状态（点击任意图片卡片无缝展开为详情视图，关闭时收缩回原卡片）
    var inspectedItem by remember { mutableStateOf<SelectedImageItem?>(null) }

    // 参数面板展开状态
    var isConfigExpanded by remember { mutableStateOf(true) }

    // 压缩与转码参数
    var selectedFormat by remember { mutableStateOf(OutputFormat.JPEG) }
    var qualitySliderValue by remember { mutableFloatStateOf(80f) }
    var selectedResolution by remember { mutableStateOf(ResolutionOption.ORIGINAL) }

    // 文字加密混淆与还原参数
    var obfuscationKeyText by remember { mutableStateOf("") }
    var selectedBlockGrid by remember { mutableStateOf(BlockGridSize.BLOCK_16) }

    // 直接将结果压入压缩包配置
    var packResultIntoArchive by remember { mutableStateOf(false) }
    var selectedArchiveFormat by remember { mutableStateOf(ArchiveOutputFormat.ZIP) }
    var selectedArchiveLevel by remember { mutableStateOf(ArchiveCompressionLevel.STANDARD) }
    var customArchiveName by remember { mutableStateOf("") }

    // 自定义存储目录状态
    var customTreeUri by remember { mutableStateOf<Uri?>(null) }
    var customDirName by remember { mutableStateOf<String?>(null) }

    // 批量执行进度
    var isProcessing by remember { mutableStateOf(false) }
    var completedCount by remember { mutableIntStateOf(0) }
    var totalTaskCount by remember { mutableIntStateOf(0) }

    // 响应外部应用“分享 (Share)”或“打开方式 (Open with)”传入的多格式压缩包或图片
    LaunchedEffect(externalIntent) {
        val intentToHandle = externalIntent ?: return@LaunchedEffect
        val incomingUris = extractUrisFromIntent(intentToHandle)
        onExternalIntentConsumed()

        if (incomingUris.isNotEmpty()) {
            val archiveUris = incomingUris.filter { ImageCompressor.isArchiveUri(context, it) }
            val imageUris = incomingUris.filterNot { ImageCompressor.isArchiveUri(context, it) }

            val mergedList = mutableListOf<SelectedImageItem>()
            if (archiveUris.isNotEmpty()) {
                val summary = ImageCompressor.extractImagesFromArchiveUris(context, archiveUris)
                mergedList.addAll(summary.extractedImages)
                lastImportedArchiveBanner = "已从 ${summary.archiveNames.joinToString(", ")} 提取 ${summary.extractedImages.size} 张图片"
                currentMode = ProcessMode.ARCHIVE_HUB
                archiveSubMode = ArchiveSubMode.EXTRACT_FROM_ARCHIVE
                if (summary.errorNote != null && summary.extractedImages.isEmpty()) {
                    Toast.makeText(context, summary.errorNote, Toast.LENGTH_LONG).show()
                }
            }
            if (imageUris.isNotEmpty()) {
                mergedList.addAll(ImageCompressor.inspectImages(context, imageUris))
            }

            if (mergedList.isNotEmpty()) {
                selectedImages = mergedList
                compressionResults.clear()
                lastBatchReport = null
                completedCount = 0
                totalTaskCount = mergedList.size
                Toast.makeText(context, "已载入 ${mergedList.size} 张图片", Toast.LENGTH_SHORT).show()
            } else if (archiveUris.isNotEmpty()) {
                Toast.makeText(context, "所选压缩包内未找到支持的图片文件", Toast.LENGTH_LONG).show()
            }
        }
    }

    // 1. 系统 PhotoPicker 批量选图启动器
    val pickMultipleImagesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 50)
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            coroutineScope.launch {
                val inspected = ImageCompressor.inspectImages(context, uris)
                selectedImages = inspected
                lastImportedArchiveBanner = null
                compressionResults.clear()
                lastBatchReport = null
                completedCount = 0
                totalTaskCount = inspected.size
            }
        }
    }

    // 2. 多格式压缩包选择启动器
    val pickArchiveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            coroutineScope.launch {
                val summary = ImageCompressor.extractImagesFromArchiveUris(context, uris)
                if (summary.extractedImages.isNotEmpty()) {
                    selectedImages = summary.extractedImages
                    lastImportedArchiveBanner = "已从 ${summary.archiveNames.joinToString(", ")} 提取 ${summary.extractedImages.size} 张图片"
                    compressionResults.clear()
                    lastBatchReport = null
                    completedCount = 0
                    totalTaskCount = summary.extractedImages.size
                    Toast.makeText(context, "成功提取 ${summary.extractedImages.size} 张图片", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(
                        context,
                        summary.errorNote ?: "所选压缩包中未找到可识别的图片",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    // 3. SAF 目录选择器
    val pickOutputDirectoryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        if (treeUri != null) {
            runCatching {
                val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(treeUri, takeFlags)
            }
            customTreeUri = treeUri
            val docDir = DocumentFile.fromTreeUri(context, treeUri)
            customDirName = docDir?.name ?: treeUri.lastPathSegment ?: "自定义目录"
            Toast.makeText(context, "输出目录已设为：$customDirName", Toast.LENGTH_SHORT).show()
        }
    }

    // 触发批量处理的统一回调
    val triggerBatchExecution: () -> Unit = {
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        isProcessing = true
        completedCount = 0
        totalTaskCount = selectedImages.size
        compressionResults.clear()
        lastBatchReport = null

        val config = CompressionConfig(
            mode = currentMode,
            archiveSubMode = archiveSubMode,
            format = selectedFormat,
            quality = qualitySliderValue.roundToInt(),
            resolutionOption = selectedResolution,
            customTreeUri = customTreeUri,
            obfuscationKey = obfuscationKeyText,
            blockGridSize = selectedBlockGrid,
            packResultIntoArchive = packResultIntoArchive,
            archiveOutputFormat = selectedArchiveFormat,
            archiveCompressionLevel = selectedArchiveLevel,
            customArchiveBaseName = customArchiveName
        )

        coroutineScope.launch {
            val report = ImageCompressor.processBatch(
                context = context,
                items = selectedImages,
                config = config,
                onProgress = { done, total, latest ->
                    completedCount = done
                    totalTaskCount = total
                    compressionResults[latest.source.uri] = latest
                }
            )
            lastBatchReport = report
            isProcessing = false
            val successCount = report.itemResults.count { it.isSuccess }
            val toastMsg = if (report.archiveFileName != null) {
                "已将 $successCount 张图片打包为 ${report.archiveFileName}"
            } else {
                "${currentMode.shortTitle}完成：成功 $successCount / ${report.itemResults.size} 张"
            }
            Toast.makeText(context, toastMsg, Toast.LENGTH_LONG).show()
        }
    }

    // 当打开详情检视模态层时，背景主界面应用柔和亚克力/云母模糊过渡 (Acrylic / Mica Blur)
    val backgroundBlurRadius by animateDpAsState(
        targetValue = if (inspectedItem != null) 14.dp else 0.dp,
        animationSpec = tween(durationMillis = TRANSITION_DURATION_MS, easing = FlClashStandardEasing),
        label = "AcrylicBackdropBlur"
    )

    // 响应式自适应布局：自动根据窗口宽度切换 Desktop/Tablet (NavigationRail) 与 Mobile (NavigationBar)
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth >= 600.dp

        Box(modifier = Modifier.fillMaxSize()) {
            // 主界面层
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .then(
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && backgroundBlurRadius > 0.dp) {
                            Modifier.blur(backgroundBlurRadius)
                        } else {
                            Modifier
                        }
                    )
            ) {
                // 桌面端 / 平板端 / 横屏：左侧 M3 NavigationRail + 1dp 细分割线
                if (isWideScreen) {
                    FlClashNavigationRail(
                        currentMode = currentMode,
                        selectedCount = selectedImages.size,
                        isProcessing = isProcessing,
                        onSelectMode = { mode ->
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            currentMode = mode
                            if (mode == ProcessMode.DEOBFUSCATE_RESTORE) {
                                selectedFormat = OutputFormat.PNG
                            }
                        }
                    )
                    VerticalDivider(
                        thickness = 1.dp,
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                    )
                }

                // 主工作区 Scaffold
                Scaffold(
                    modifier = Modifier.weight(1f),
                    containerColor = MaterialTheme.colorScheme.background,
                    topBar = {
                        FlClashTopBar(
                            currentMode = currentMode,
                            selectedCount = selectedImages.size,
                            customTreeUri = customTreeUri,
                            useDynamicColor = useDynamicColor,
                            isProcessing = isProcessing,
                            onToggleDynamicColor = {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onToggleDynamicColor()
                            },
                            onPickDirectory = {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                pickOutputDirectoryLauncher.launch(customTreeUri)
                            },
                            onClearQueue = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                selectedImages = emptyList()
                                compressionResults.clear()
                                lastBatchReport = null
                                lastImportedArchiveBanner = null
                                completedCount = 0
                                totalTaskCount = 0
                            }
                        )
                    },
                    bottomBar = {
                        Column {
                            // 悬浮亚克力执行栏（Sticky Acrylic Action Dock）
                            AnimatedVisibility(
                                visible = selectedImages.isNotEmpty(),
                                enter = expandVertically(
                                    animationSpec = tween(TRANSITION_DURATION_MS, easing = FlClashStandardEasing)
                                ) + fadeIn(tween(TRANSITION_DURATION_MS, easing = FlClashStandardEasing)),
                                exit = shrinkVertically(
                                    animationSpec = tween(EXIT_DURATION_MS, easing = FlClashStandardEasing)
                                ) + fadeOut(tween(EXIT_DURATION_MS, easing = FlClashStandardEasing))
                            ) {
                                FlClashAcrylicActionDock(
                                    currentMode = currentMode,
                                    archiveSubMode = archiveSubMode,
                                    packResultIntoArchive = packResultIntoArchive,
                                    archiveFormat = selectedArchiveFormat,
                                    selectedCount = selectedImages.size,
                                    isProcessing = isProcessing,
                                    completedCount = completedCount,
                                    totalTaskCount = totalTaskCount,
                                    obfuscationKeyText = obfuscationKeyText,
                                    onStartClick = triggerBatchExecution
                                )
                            }

                            // 移动端竖屏：底部 M3 NavigationBar
                            if (!isWideScreen) {
                                HorizontalDivider(
                                    thickness = 1.dp,
                                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                )
                                NavigationBar(
                                    containerColor = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.94f),
                                    tonalElevation = 0.dp
                                ) {
                                    ProcessMode.entries.forEach { mode ->
                                        val isSelected = currentMode == mode
                                        val icon = when (mode) {
                                            ProcessMode.COMPRESS_TRANSCODE -> if (isSelected) Icons.Filled.Transform else Icons.Outlined.Transform
                                            ProcessMode.OBFUSCATE_ENCRYPT -> if (isSelected) Icons.Filled.EnhancedEncryption else Icons.Outlined.EnhancedEncryption
                                            ProcessMode.DEOBFUSCATE_RESTORE -> if (isSelected) Icons.Filled.LockOpen else Icons.Outlined.LockOpen
                                            ProcessMode.ARCHIVE_HUB -> if (isSelected) Icons.Filled.FolderZip else Icons.Outlined.FolderZip
                                        }
                                        NavigationBarItem(
                                            selected = isSelected,
                                            onClick = {
                                                if (!isProcessing && currentMode != mode) {
                                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                    currentMode = mode
                                                    if (mode == ProcessMode.DEOBFUSCATE_RESTORE) {
                                                        selectedFormat = OutputFormat.PNG
                                                    }
                                                }
                                            },
                                            icon = { Icon(imageVector = icon, contentDescription = mode.shortTitle) },
                                            label = {
                                                Text(
                                                    text = mode.shortTitle,
                                                    style = MaterialTheme.typography.labelMedium,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                                )
                                            },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                                indicatorColor = MaterialTheme.colorScheme.primaryContainer
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                ) { innerPadding ->
                    // ====== 顶层页面切换：实现平滑的 Shared Axis Transition（水平位移 + 渐隐渐显，严格使用 cubic-bezier(0.2, 0, 0, 1)） ======
                    AnimatedContent(
                        targetState = currentMode,
                        transitionSpec = {
                            val isForward = targetState.ordinal >= initialState.ordinal
                            val slideOffset: (Int) -> Int = { fullWidth ->
                                if (isForward) (fullWidth * 0.14f).roundToInt() else -(fullWidth * 0.14f).roundToInt()
                            }
                            val exitOffset: (Int) -> Int = { fullWidth ->
                                if (isForward) -(fullWidth * 0.14f).roundToInt() else (fullWidth * 0.14f).roundToInt()
                            }
                            (slideInHorizontally(
                                animationSpec = tween(TRANSITION_DURATION_MS, easing = FlClashStandardEasing),
                                initialOffsetX = slideOffset
                            ) + fadeIn(
                                animationSpec = tween(TRANSITION_DURATION_MS, easing = FlClashStandardEasing)
                            )).togetherWith(
                                slideOutHorizontally(
                                    animationSpec = tween(EXIT_DURATION_MS, easing = FlClashStandardEasing),
                                    targetOffsetX = exitOffset
                                ) + fadeOut(
                                    animationSpec = tween(150, easing = FlClashStandardEasing)
                                )
                            ).using(SizeTransform(clip = false))
                        },
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding),
                        label = "FlClashSharedAxisPageTransition"
                    ) { pageMode ->
                        // 根据屏幕宽度自适应单栏或双栏仪表盘布局
                        if (isWideScreen) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 20.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.spacedBy(18.dp)
                            ) {
                                // 左栏：仪表盘指标卡 + 当前工作空间配置卡
                                LazyColumn(
                                    modifier = Modifier.weight(0.46f),
                                    verticalArrangement = Arrangement.spacedBy(14.dp),
                                    contentPadding = PaddingValues(bottom = 20.dp)
                                ) {
                                    item {
                                        FlClashDashboardMetricsRow(
                                            pageMode = pageMode,
                                            selectedImages = selectedImages,
                                            resultsMap = compressionResults,
                                            customDirName = customDirName,
                                            isDirectArchiveActive = (pageMode == ProcessMode.ARCHIVE_HUB && archiveSubMode == ArchiveSubMode.PACK_TO_ARCHIVE) ||
                                                (pageMode != ProcessMode.ARCHIVE_HUB && packResultIntoArchive),
                                            isProcessing = isProcessing,
                                            lastImportedArchiveBanner = lastImportedArchiveBanner,
                                            onPickImages = {
                                                pickMultipleImagesLauncher.launch(
                                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                )
                                            },
                                            onPickArchives = {
                                                pickArchiveLauncher.launch(arrayOf("*/*"))
                                            },
                                            onPickDirectory = {
                                                pickOutputDirectoryLauncher.launch(customTreeUri)
                                            },
                                            onResetDirectory = {
                                                customTreeUri = null
                                                customDirName = null
                                            }
                                        )
                                    }

                                    item {
                                        FlClashWorkspaceConfigCard(
                                            currentMode = pageMode,
                                            archiveSubMode = archiveSubMode,
                                            onSelectArchiveSubMode = { archiveSubMode = it },
                                            isExpanded = isConfigExpanded,
                                            onToggleExpand = { isConfigExpanded = !isConfigExpanded },
                                            isProcessing = isProcessing,
                                            selectedFormat = selectedFormat,
                                            onSelectFormat = { selectedFormat = it },
                                            qualitySliderValue = qualitySliderValue,
                                            onQualityChange = { qualitySliderValue = it },
                                            selectedResolution = selectedResolution,
                                            onSelectResolution = { selectedResolution = it },
                                            obfuscationKeyText = obfuscationKeyText,
                                            onKeyTextChange = { obfuscationKeyText = it },
                                            selectedBlockGrid = selectedBlockGrid,
                                            onSelectBlockGrid = { selectedBlockGrid = it },
                                            packResultIntoArchive = packResultIntoArchive,
                                            onTogglePackResultIntoArchive = { packResultIntoArchive = it },
                                            selectedArchiveFormat = selectedArchiveFormat,
                                            onSelectArchiveFormat = { selectedArchiveFormat = it },
                                            selectedArchiveLevel = selectedArchiveLevel,
                                            onSelectArchiveLevel = { selectedArchiveLevel = it },
                                            customArchiveName = customArchiveName,
                                            onCustomArchiveNameChange = { customArchiveName = it },
                                            onSwitchMode = { targetMode ->
                                                currentMode = targetMode
                                                if (targetMode == ProcessMode.DEOBFUSCATE_RESTORE) {
                                                    selectedFormat = OutputFormat.PNG
                                                }
                                            }
                                        )
                                    }
                                }

                                // 右栏：处理统计与图片队列卡片列表
                                LazyColumn(
                                    modifier = Modifier.weight(0.54f),
                                    verticalArrangement = Arrangement.spacedBy(12.dp),
                                    contentPadding = PaddingValues(bottom = 20.dp)
                                ) {
                                    if (compressionResults.isNotEmpty() || lastBatchReport?.archiveFileName != null) {
                                        item {
                                            BatchSummaryBanner(
                                                selectedImages = selectedImages,
                                                resultsMap = compressionResults,
                                                batchReport = lastBatchReport
                                            )
                                        }
                                    }

                                    if (selectedImages.isEmpty()) {
                                        item {
                                            EmptyWorkbenchCard(
                                                currentMode = pageMode,
                                                onPickImages = {
                                                    pickMultipleImagesLauncher.launch(
                                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                    )
                                                },
                                                onPickArchives = {
                                                    pickArchiveLauncher.launch(arrayOf("*/*"))
                                                }
                                            )
                                        }
                                    } else {
                                        items(
                                            items = selectedImages,
                                            key = { it.uri.toString() }
                                        ) { item ->
                                            ImageComparisonItemCard(
                                                item = item,
                                                result = compressionResults[item.uri],
                                                isProcessing = isProcessing,
                                                onCardClick = { inspectedItem = item },
                                                onRemoveItem = {
                                                    selectedImages = selectedImages.filterNot { it.uri == item.uri }
                                                    compressionResults.remove(item.uri)
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        } else {
                            // 手机竖屏自适应单栏分组卡片仪表盘
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                item {
                                    FlClashDashboardMetricsRow(
                                        pageMode = pageMode,
                                        selectedImages = selectedImages,
                                        resultsMap = compressionResults,
                                        customDirName = customDirName,
                                        isDirectArchiveActive = (pageMode == ProcessMode.ARCHIVE_HUB && archiveSubMode == ArchiveSubMode.PACK_TO_ARCHIVE) ||
                                            (pageMode != ProcessMode.ARCHIVE_HUB && packResultIntoArchive),
                                        isProcessing = isProcessing,
                                        lastImportedArchiveBanner = lastImportedArchiveBanner,
                                        onPickImages = {
                                            pickMultipleImagesLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        },
                                        onPickArchives = {
                                            pickArchiveLauncher.launch(arrayOf("*/*"))
                                        },
                                        onPickDirectory = {
                                            pickOutputDirectoryLauncher.launch(customTreeUri)
                                        },
                                        onResetDirectory = {
                                            customTreeUri = null
                                            customDirName = null
                                        }
                                    )
                                }

                                item {
                                    FlClashWorkspaceConfigCard(
                                        currentMode = pageMode,
                                        archiveSubMode = archiveSubMode,
                                        onSelectArchiveSubMode = { archiveSubMode = it },
                                        isExpanded = isConfigExpanded,
                                        onToggleExpand = { isConfigExpanded = !isConfigExpanded },
                                        isProcessing = isProcessing,
                                        selectedFormat = selectedFormat,
                                        onSelectFormat = { selectedFormat = it },
                                        qualitySliderValue = qualitySliderValue,
                                        onQualityChange = { qualitySliderValue = it },
                                        selectedResolution = selectedResolution,
                                        onSelectResolution = { selectedResolution = it },
                                        obfuscationKeyText = obfuscationKeyText,
                                        onKeyTextChange = { obfuscationKeyText = it },
                                        selectedBlockGrid = selectedBlockGrid,
                                        onSelectBlockGrid = { selectedBlockGrid = it },
                                        packResultIntoArchive = packResultIntoArchive,
                                        onTogglePackResultIntoArchive = { packResultIntoArchive = it },
                                        selectedArchiveFormat = selectedArchiveFormat,
                                        onSelectArchiveFormat = { selectedArchiveFormat = it },
                                        selectedArchiveLevel = selectedArchiveLevel,
                                        onSelectArchiveLevel = { selectedArchiveLevel = it },
                                        customArchiveName = customArchiveName,
                                        onCustomArchiveNameChange = { customArchiveName = it },
                                        onSwitchMode = { targetMode ->
                                            currentMode = targetMode
                                            if (targetMode == ProcessMode.DEOBFUSCATE_RESTORE) {
                                                selectedFormat = OutputFormat.PNG
                                            }
                                        }
                                    )
                                }

                                if (compressionResults.isNotEmpty() || lastBatchReport?.archiveFileName != null) {
                                    item {
                                        BatchSummaryBanner(
                                            selectedImages = selectedImages,
                                            resultsMap = compressionResults,
                                            batchReport = lastBatchReport
                                        )
                                    }
                                }

                                if (selectedImages.isEmpty()) {
                                    item {
                                        EmptyWorkbenchCard(
                                            currentMode = pageMode,
                                            onPickImages = {
                                                pickMultipleImagesLauncher.launch(
                                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                )
                                            },
                                            onPickArchives = {
                                                pickArchiveLauncher.launch(arrayOf("*/*"))
                                            }
                                        )
                                    }
                                } else {
                                    item {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 4.dp, vertical = 2.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "图片队列 (点击卡片可展开详情检视)",
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Text(
                                                text = "${selectedImages.size} 项",
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.primary,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }

                                    items(
                                        items = selectedImages,
                                        key = { it.uri.toString() }
                                    ) { item ->
                                        ImageComparisonItemCard(
                                            item = item,
                                            result = compressionResults[item.uri],
                                            isProcessing = isProcessing,
                                            onCardClick = { inspectedItem = item },
                                            onRemoveItem = {
                                                selectedImages = selectedImages.filterNot { it.uri == item.uri }
                                                compressionResults.remove(item.uri)
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ====== Container Transform 模态详情视图（点击图片卡片无缝展开为详情视图，关闭时平滑收缩回卡片） ======
            AnimatedVisibility(
                visible = inspectedItem != null,
                enter = fadeIn(animationSpec = tween(TRANSITION_DURATION_MS, easing = FlClashStandardEasing)) +
                    scaleIn(
                        initialScale = 0.88f,
                        animationSpec = tween(TRANSITION_DURATION_MS, easing = FlClashStandardEasing)
                    ),
                exit = fadeOut(animationSpec = tween(EXIT_DURATION_MS, easing = FlClashStandardEasing)) +
                    scaleOut(
                        targetScale = 0.88f,
                        animationSpec = tween(EXIT_DURATION_MS, easing = FlClashStandardEasing)
                    )
            ) {
                val activeItem = inspectedItem
                if (activeItem != null) {
                    ImageDetailContainerTransformModal(
                        item = activeItem,
                        result = compressionResults[activeItem.uri],
                        onDismiss = { inspectedItem = null },
                        onRemove = {
                            selectedImages = selectedImages.filterNot { it.uri == activeItem.uri }
                            compressionResults.remove(activeItem.uri)
                            inspectedItem = null
                        }
                    )
                }
            }
        }
    }
}

/**
 * 桌面/平板端左侧 M3 NavigationRail（对标 FlClash 侧边胶囊导航栏）
 */
@Composable
private fun FlClashNavigationRail(
    currentMode: ProcessMode,
    selectedCount: Int,
    isProcessing: Boolean,
    onSelectMode: (ProcessMode) -> Unit
) {
    NavigationRail(
        containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
        header = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 12.dp, bottom = 8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(44.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Dashboard,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
                if (selectedCount > 0) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Badge(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ) {
                        Text("$selectedCount", modifier = Modifier.padding(horizontal = 4.dp))
                    }
                }
            }
        },
        modifier = Modifier.fillMaxHeight()
    ) {
        Spacer(modifier = Modifier.height(8.dp))
        ProcessMode.entries.forEach { mode ->
            val isSelected = currentMode == mode
            val icon = when (mode) {
                ProcessMode.COMPRESS_TRANSCODE -> if (isSelected) Icons.Filled.Transform else Icons.Outlined.Transform
                ProcessMode.OBFUSCATE_ENCRYPT -> if (isSelected) Icons.Filled.EnhancedEncryption else Icons.Outlined.EnhancedEncryption
                ProcessMode.DEOBFUSCATE_RESTORE -> if (isSelected) Icons.Filled.LockOpen else Icons.Outlined.LockOpen
                ProcessMode.ARCHIVE_HUB -> if (isSelected) Icons.Filled.FolderZip else Icons.Outlined.FolderZip
            }
            NavigationRailItem(
                selected = isSelected,
                onClick = { if (!isProcessing) onSelectMode(mode) },
                icon = { Icon(imageVector = icon, contentDescription = mode.shortTitle) },
                label = {
                    Text(
                        text = mode.shortTitle,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    selectedTextColor = MaterialTheme.colorScheme.primary,
                    indicatorColor = MaterialTheme.colorScheme.primaryContainer
                ),
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }
    }
}

/**
 * 顶部状态工具栏（遵循 M3 Typography 层级：titleMedium + labelMedium，提供动态取色切换、目录选择与清空按钮）
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FlClashTopBar(
    currentMode: ProcessMode,
    selectedCount: Int,
    customTreeUri: Uri?,
    useDynamicColor: Boolean,
    isProcessing: Boolean,
    onToggleDynamicColor: () -> Unit,
    onPickDirectory: () -> Unit,
    onClearQueue: () -> Unit
) {
    Column {
        TopAppBar(
            title = {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = currentMode.fullTitle,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                        ) {
                            Text(
                                text = currentMode.shortTitle,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = currentMode.subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            },
            actions = {
                // Material You 动态壁纸取色 / FlClash 经典靛蓝主题切换按钮
                IconButton(onClick = onToggleDynamicColor) {
                    Icon(
                        imageVector = if (useDynamicColor) Icons.Default.AutoAwesome else Icons.Outlined.Palette,
                        contentDescription = "切换 Material You 动态取色",
                        tint = if (useDynamicColor) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                }

                // 选择输出目录按钮
                IconButton(
                    onClick = onPickDirectory,
                    enabled = !isProcessing
                ) {
                    Icon(
                        imageVector = Icons.Outlined.FolderOpen,
                        contentDescription = "更改输出目录",
                        tint = if (customTreeUri != null) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                }

                // 清空队列按钮
                if (selectedCount > 0 && !isProcessing) {
                    IconButton(onClick = onClearQueue) {
                        Icon(
                            imageVector = Icons.Outlined.DeleteSweep,
                            contentDescription = "清空队列",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.background
            )
        )
        HorizontalDivider(
            thickness = 1.dp,
            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
        )
    }
}

/**
 * FlClash 风格仪表盘概览区（包含 headlineMedium 数字指标卡 + 0.98f 缩放快捷导入卡 + 路径胶囊条）
 */
@Composable
private fun FlClashDashboardMetricsRow(
    pageMode: ProcessMode,
    selectedImages: List<SelectedImageItem>,
    resultsMap: Map<Uri, CompressionResult>,
    customDirName: String?,
    isDirectArchiveActive: Boolean,
    isProcessing: Boolean,
    lastImportedArchiveBanner: String?,
    onPickImages: () -> Unit,
    onPickArchives: () -> Unit,
    onPickDirectory: () -> Unit,
    onResetDirectory: () -> Unit
) {
    val totalOrigBytes = selectedImages.sumOf { it.originalSize }
    val doneCount = selectedImages.count { resultsMap[it.uri]?.isSuccess == true }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // 仪表盘双指标状态卡（遵循 headlineMedium + titleMedium + bodyMedium 排版规范）
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            FlClashSurfaceCard(
                modifier = Modifier
                    .weight(1f)
                    .flClashInteractive(enabled = !isProcessing, onClick = onPickImages)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "已选图片队列",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Text(
                        text = "${selectedImages.size}",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (selectedImages.isEmpty()) {
                            "点击批量选择相册照片"
                        } else {
                            "总计 ${ImageCompressor.formatFileSize(totalOrigBytes)} · 已完成 $doneCount"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            FlClashSurfaceCard(
                modifier = Modifier
                    .weight(1f)
                    .flClashInteractive(enabled = !isProcessing, onClick = onPickArchives)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "多格式归档导入",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Icon(
                            imageVector = Icons.Default.FolderZip,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Text(
                        text = "ZIP / 7Z / RAR",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                    Text(
                        text = "支持 TAR.GZ · XZ · CBZ 导入",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        // 18dp 细边框存储路径状态栏
        FlClashSurfaceCard(
            cornerRadius = 16.dp,
            containerColor = MaterialTheme.colorScheme.surfaceContainer,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .weight(1f)
                        .clickable(enabled = !isProcessing) { onPickDirectory() }
                ) {
                    Icon(
                        imageVector = Icons.Outlined.FolderOpen,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    val defaultPathText = if (isDirectArchiveActive) {
                        "默认目录：Download/CompressedArchives"
                    } else {
                        "默认相册：Pictures/Compressed"
                    }
                    Text(
                        text = if (customDirName != null) {
                            "输出目录：$customDirName"
                        } else {
                            defaultPathText
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (customDirName != null && !isProcessing) {
                        TextButton(
                            onClick = onResetDirectory,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Restore,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text("重置", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                    TextButton(
                        onClick = onPickDirectory,
                        enabled = !isProcessing,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Text(
                            text = if (pageMode == ProcessMode.ARCHIVE_HUB) "更改位置" else "切换目录",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        if (lastImportedArchiveBanner != null) {
            FlClashSurfaceCard(
                cornerRadius = 16.dp,
                containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.75f),
                borderColor = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.4f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.FolderZip,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onTertiaryContainer,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = lastImportedArchiveBanner,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onTertiaryContainer
                    )
                }
            }
        }
    }
}

/**
 * FlClash 风格分段选择器 (Tonal Segmented Pill Row with 0.98f scale micro-interaction)
 */
@Composable
private fun <T> FlClashSegmentedRow(
    items: List<T>,
    selectedItem: T,
    itemLabel: (T) -> String,
    enabled: Boolean = true,
    onItemSelected: (T) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items.forEach { item ->
                val isSelected = item == selectedItem
                val pillColor by animateColorAsState(
                    targetValue = if (isSelected) {
                        MaterialTheme.colorScheme.primaryContainer
                    } else {
                        Color.Transparent
                    },
                    animationSpec = tween(durationMillis = 220, easing = FlClashStandardEasing),
                    label = "FlClashSegmentColor"
                )
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = pillColor,
                    border = if (isSelected) {
                        BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f))
                    } else {
                        null
                    },
                    modifier = Modifier
                        .weight(1f)
                        .flClashInteractive(
                            enabled = enabled,
                            shape = RoundedCornerShape(10.dp),
                            onClick = { onItemSelected(item) }
                        )
                ) {
                    Text(
                        text = itemLabel(item),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) {
                            MaterialTheme.colorScheme.onPrimaryContainer
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(vertical = 9.dp, horizontal = 6.dp)
                    )
                }
            }
        }
    }
}

/**
 * FlClash 风格 18dp 细边框工作空间参数卡片
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FlClashWorkspaceConfigCard(
    currentMode: ProcessMode,
    archiveSubMode: ArchiveSubMode,
    onSelectArchiveSubMode: (ArchiveSubMode) -> Unit,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    isProcessing: Boolean,
    selectedFormat: OutputFormat,
    onSelectFormat: (OutputFormat) -> Unit,
    qualitySliderValue: Float,
    onQualityChange: (Float) -> Unit,
    selectedResolution: ResolutionOption,
    onSelectResolution: (ResolutionOption) -> Unit,
    obfuscationKeyText: String,
    onKeyTextChange: (String) -> Unit,
    selectedBlockGrid: BlockGridSize,
    onSelectBlockGrid: (BlockGridSize) -> Unit,
    packResultIntoArchive: Boolean,
    onTogglePackResultIntoArchive: (Boolean) -> Unit,
    selectedArchiveFormat: ArchiveOutputFormat,
    onSelectArchiveFormat: (ArchiveOutputFormat) -> Unit,
    selectedArchiveLevel: ArchiveCompressionLevel,
    onSelectArchiveLevel: (ArchiveCompressionLevel) -> Unit,
    customArchiveName: String,
    onCustomArchiveNameChange: (String) -> Unit,
    onSwitchMode: (ProcessMode) -> Unit
) {
    FlClashSurfaceCard(
        cornerRadius = 18.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // 卡片头部
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleExpand() }
                    .padding(horizontal = 18.dp, vertical = 15.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "${currentMode.shortTitle}引擎配置",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        val summaryLine = when (currentMode) {
                            ProcessMode.COMPRESS_TRANSCODE -> {
                                val qText = if (selectedFormat.supportsQualitySlider) {
                                    "画质 ${qualitySliderValue.roundToInt()}%"
                                } else {
                                    "无损像素"
                                }
                                val packSuffix = if (packResultIntoArchive) {
                                    " · 直压 ${selectedArchiveFormat.shortLabel}"
                                } else {
                                    ""
                                }
                                "${selectedFormat.shortLabel} · $qText · ${selectedResolution.label}$packSuffix"
                            }
                            ProcessMode.OBFUSCATE_ENCRYPT -> {
                                val keyStatus = if (obfuscationKeyText.isBlank()) "待填口令" else "口令已配置"
                                val packSuffix = if (packResultIntoArchive) {
                                    " · 直压 ${selectedArchiveFormat.shortLabel}"
                                } else {
                                    " · 无损 PNG"
                                }
                                "$keyStatus · 色块 ${selectedBlockGrid.shortLabel}$packSuffix"
                            }
                            ProcessMode.DEOBFUSCATE_RESTORE -> {
                                val keyStatus = if (obfuscationKeyText.isBlank()) "待填口令" else "口令已配置"
                                "$keyStatus · 色块 ${selectedBlockGrid.shortLabel} · 导出 ${selectedFormat.shortLabel}"
                            }
                            ProcessMode.ARCHIVE_HUB -> {
                                if (archiveSubMode == ArchiveSubMode.PACK_TO_ARCHIVE) {
                                    "打包格式：${selectedArchiveFormat.shortLabel} · ${selectedArchiveLevel.label}"
                                } else {
                                    "多格式流式提取：ZIP / 7Z / RAR / TAR.GZ / XZ / CBZ"
                                }
                            }
                        }
                        Text(
                            text = summaryLine,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (isExpanded) "收起配置" else "展开配置",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically(
                    animationSpec = tween(TRANSITION_DURATION_MS, easing = FlClashStandardEasing)
                ) + fadeIn(tween(TRANSITION_DURATION_MS, easing = FlClashStandardEasing)),
                exit = shrinkVertically(
                    animationSpec = tween(EXIT_DURATION_MS, easing = FlClashStandardEasing)
                ) + fadeOut(tween(EXIT_DURATION_MS, easing = FlClashStandardEasing))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 18.dp, end = 18.dp, bottom = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    HorizontalDivider(
                        thickness = 1.dp,
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                    )

                    when (currentMode) {
                        ProcessMode.COMPRESS_TRANSCODE -> {
                            Text(
                                text = "目标编码格式",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            FlClashSegmentedRow(
                                items = OutputFormat.entries,
                                selectedItem = selectedFormat,
                                itemLabel = { it.shortLabel },
                                enabled = !isProcessing,
                                onItemSelected = onSelectFormat
                            )
                            Text(
                                text = selectedFormat.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            if (selectedFormat.supportsQualitySlider) {
                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "画质压缩百分比",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "${qualitySliderValue.roundToInt()}%",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Slider(
                                        value = qualitySliderValue,
                                        onValueChange = onQualityChange,
                                        valueRange = 10f..100f,
                                        steps = 17,
                                        enabled = !isProcessing
                                    )
                                }
                            }

                            Text(
                                text = "分辨率最长边缩放",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                ResolutionOption.entries.forEach { option ->
                                    FilterChip(
                                        selected = selectedResolution == option,
                                        onClick = { if (!isProcessing) onSelectResolution(option) },
                                        label = { Text(option.label) },
                                        enabled = !isProcessing,
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                }
                            }

                            HorizontalDivider(
                                thickness = 1.dp,
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                            )

                            DirectPackArchiveToggleSection(
                                checked = packResultIntoArchive,
                                onCheckedChange = onTogglePackResultIntoArchive,
                                selectedArchiveFormat = selectedArchiveFormat,
                                onSelectArchiveFormat = onSelectArchiveFormat,
                                selectedArchiveLevel = selectedArchiveLevel,
                                onSelectArchiveLevel = onSelectArchiveLevel,
                                customArchiveName = customArchiveName,
                                onCustomArchiveNameChange = onCustomArchiveNameChange,
                                isProcessing = isProcessing
                            )
                        }

                        ProcessMode.OBFUSCATE_ENCRYPT, ProcessMode.DEOBFUSCATE_RESTORE -> {
                            val isEncrypt = currentMode == ProcessMode.OBFUSCATE_ENCRYPT
                            OutlinedTextField(
                                value = obfuscationKeyText,
                                onValueChange = onKeyTextChange,
                                label = {
                                    Text(
                                        if (isEncrypt) "输入加密混淆口令文字" else "输入加密时的同一串文字口令"
                                    )
                                },
                                placeholder = { Text("支持任意中英文、数字或短句") },
                                leadingIcon = {
                                    Icon(imageVector = Icons.Default.Key, contentDescription = null)
                                },
                                trailingIcon = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (obfuscationKeyText.isNotEmpty()) {
                                            IconButton(onClick = { onKeyTextChange("") }) {
                                                Icon(
                                                    imageVector = Icons.Default.Clear,
                                                    contentDescription = "清空口令"
                                                )
                                            }
                                        } else if (isEncrypt) {
                                            IconButton(
                                                onClick = {
                                                    val randomPin = "KEY_" + Random.nextInt(100000, 999999)
                                                    onKeyTextChange(randomPin)
                                                }
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Casino,
                                                    contentDescription = "随机生成口令"
                                                )
                                            }
                                        }
                                    }
                                },
                                singleLine = true,
                                enabled = !isProcessing,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.GridView,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "色块网格粒度（加密与还原须保持一致）",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            FlClashSegmentedRow(
                                items = BlockGridSize.entries,
                                selectedItem = selectedBlockGrid,
                                itemLabel = { it.shortLabel },
                                enabled = !isProcessing,
                                onItemSelected = onSelectBlockGrid
                            )

                            if (!isEncrypt) {
                                Text(
                                    text = "还原后导出格式（推荐 PNG 无损）",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                FlClashSegmentedRow(
                                    items = OutputFormat.entries,
                                    selectedItem = selectedFormat,
                                    itemLabel = { it.shortLabel },
                                    enabled = !isProcessing,
                                    onItemSelected = onSelectFormat
                                )
                            }

                            HorizontalDivider(
                                thickness = 1.dp,
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                            )

                            DirectPackArchiveToggleSection(
                                checked = packResultIntoArchive,
                                onCheckedChange = onTogglePackResultIntoArchive,
                                selectedArchiveFormat = selectedArchiveFormat,
                                onSelectArchiveFormat = onSelectArchiveFormat,
                                selectedArchiveLevel = selectedArchiveLevel,
                                onSelectArchiveLevel = onSelectArchiveLevel,
                                customArchiveName = customArchiveName,
                                onCustomArchiveNameChange = onCustomArchiveNameChange,
                                isProcessing = isProcessing
                            )
                        }

                        ProcessMode.ARCHIVE_HUB -> {
                            FlClashSegmentedRow(
                                items = ArchiveSubMode.entries,
                                selectedItem = archiveSubMode,
                                itemLabel = { it.label },
                                enabled = !isProcessing,
                                onItemSelected = onSelectArchiveSubMode
                            )

                            Text(
                                text = archiveSubMode.desc,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            if (archiveSubMode == ArchiveSubMode.PACK_TO_ARCHIVE) {
                                ArchivePackParamsContent(
                                    selectedArchiveFormat = selectedArchiveFormat,
                                    onSelectArchiveFormat = onSelectArchiveFormat,
                                    selectedArchiveLevel = selectedArchiveLevel,
                                    onSelectArchiveLevel = onSelectArchiveLevel,
                                    customArchiveName = customArchiveName,
                                    onCustomArchiveNameChange = onCustomArchiveNameChange,
                                    isProcessing = isProcessing
                                )
                            } else {
                                FlClashSurfaceCard(
                                    cornerRadius = 14.dp,
                                    containerColor = MaterialTheme.colorScheme.surfaceContainer,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = "支持解压格式：.zip · .7z · .rar · .cbz · .cbr · .tar · .tar.gz · .tar.bz2 · .tar.xz",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "在 MT 管理器、系统文件管理或微信中对任意压缩包选择「打开方式 / 分享」并点选本应用，即可自动流式提取图片。提取后也可一键送往其他工作台：",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        FlowRow(
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            FilledTonalButton(
                                                onClick = { onSwitchMode(ProcessMode.COMPRESS_TRANSCODE) },
                                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                            ) {
                                                Text("转去压缩画质", style = MaterialTheme.typography.labelMedium)
                                            }
                                            FilledTonalButton(
                                                onClick = { onSwitchMode(ProcessMode.OBFUSCATE_ENCRYPT) },
                                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                            ) {
                                                Text("转去文字混淆", style = MaterialTheme.typography.labelMedium)
                                            }
                                            FilledTonalButton(
                                                onClick = { onSwitchMode(ProcessMode.DEOBFUSCATE_RESTORE) },
                                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                            ) {
                                                Text("转去口令还原", style = MaterialTheme.typography.labelMedium)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DirectPackArchiveToggleSection(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    selectedArchiveFormat: ArchiveOutputFormat,
    onSelectArchiveFormat: (ArchiveOutputFormat) -> Unit,
    selectedArchiveLevel: ArchiveCompressionLevel,
    onSelectArchiveLevel: (ArchiveCompressionLevel) -> Unit,
    customArchiveName: String,
    onCustomArchiveNameChange: (String) -> Unit,
    isProcessing: Boolean
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .clickable(enabled = !isProcessing) { onCheckedChange(!checked) }
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "处理后直接打包压入压缩包",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "开启后将所有处理结果直接封装进单个压缩包，不在相册散存单张图",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                enabled = !isProcessing
            )
        }

        AnimatedVisibility(
            visible = checked,
            enter = expandVertically(
                animationSpec = tween(TRANSITION_DURATION_MS, easing = FlClashStandardEasing)
            ) + fadeIn(tween(TRANSITION_DURATION_MS, easing = FlClashStandardEasing)),
            exit = shrinkVertically(
                animationSpec = tween(EXIT_DURATION_MS, easing = FlClashStandardEasing)
            ) + fadeOut(tween(EXIT_DURATION_MS, easing = FlClashStandardEasing))
        ) {
            ArchivePackParamsContent(
                selectedArchiveFormat = selectedArchiveFormat,
                onSelectArchiveFormat = onSelectArchiveFormat,
                selectedArchiveLevel = selectedArchiveLevel,
                onSelectArchiveLevel = onSelectArchiveLevel,
                customArchiveName = customArchiveName,
                onCustomArchiveNameChange = onCustomArchiveNameChange,
                isProcessing = isProcessing
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ArchivePackParamsContent(
    selectedArchiveFormat: ArchiveOutputFormat,
    onSelectArchiveFormat: (ArchiveOutputFormat) -> Unit,
    selectedArchiveLevel: ArchiveCompressionLevel,
    onSelectArchiveLevel: (ArchiveCompressionLevel) -> Unit,
    customArchiveName: String,
    onCustomArchiveNameChange: (String) -> Unit,
    isProcessing: Boolean
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "目标压缩包格式",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold
        )
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            ArchiveOutputFormat.entries.forEach { format ->
                FilterChip(
                    selected = selectedArchiveFormat == format,
                    onClick = { if (!isProcessing) onSelectArchiveFormat(format) },
                    label = { Text(format.shortLabel) },
                    enabled = !isProcessing,
                    shape = RoundedCornerShape(10.dp)
                )
            }
        }
        Text(
            text = selectedArchiveFormat.description,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        if (selectedArchiveFormat == ArchiveOutputFormat.ZIP ||
            selectedArchiveFormat == ArchiveOutputFormat.CBZ
        ) {
            Text(
                text = "ZIP 压缩率等级",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold
            )
            FlClashSegmentedRow(
                items = ArchiveCompressionLevel.entries,
                selectedItem = selectedArchiveLevel,
                itemLabel = { it.label },
                enabled = !isProcessing,
                onItemSelected = onSelectArchiveLevel
            )
        }

        OutlinedTextField(
            value = customArchiveName,
            onValueChange = onCustomArchiveNameChange,
            label = { Text("自定义压缩包名称（可选，留空自动按时间命名）") },
            placeholder = { Text("例如：Photos_Archive_2026") },
            leadingIcon = {
                Icon(imageVector = Icons.Default.Archive, contentDescription = null)
            },
            singleLine = true,
            enabled = !isProcessing,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/**
 * 亚克力/云母半透明悬浮执行栏（Acrylic / Mica Floating Dock，带 0.98f 微缩放按钮反馈）
 */
@Composable
private fun FlClashAcrylicActionDock(
    currentMode: ProcessMode,
    archiveSubMode: ArchiveSubMode,
    packResultIntoArchive: Boolean,
    archiveFormat: ArchiveOutputFormat,
    selectedCount: Int,
    isProcessing: Boolean,
    completedCount: Int,
    totalTaskCount: Int,
    obfuscationKeyText: String,
    onStartClick: () -> Unit
) {
    val requiresKey = currentMode == ProcessMode.OBFUSCATE_ENCRYPT ||
        currentMode == ProcessMode.DEOBFUSCATE_RESTORE
    val canStart = selectedCount > 0 && !isProcessing &&
        (!requiresKey || obfuscationKeyText.isNotBlank())
    val btnInteractionSource = remember { MutableInteractionSource() }

    Surface(
        color = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.90f),
        tonalElevation = 0.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 1.dp,
                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
                )
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (isProcessing && totalTaskCount > 0) {
                LinearProgressIndicator(
                    progress = { completedCount.toFloat() / totalTaskCount.toFloat() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                )
            }

            Button(
                onClick = onStartClick,
                enabled = canStart,
                interactionSource = btnInteractionSource,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .flClashButtonScale(btnInteractionSource, canStart)
            ) {
                val actionIcon = when {
                    currentMode == ProcessMode.ARCHIVE_HUB && archiveSubMode == ArchiveSubMode.PACK_TO_ARCHIVE -> Icons.Default.Archive
                    currentMode == ProcessMode.ARCHIVE_HUB && archiveSubMode == ArchiveSubMode.EXTRACT_FROM_ARCHIVE -> Icons.Default.Unarchive
                    packResultIntoArchive -> Icons.Default.Archive
                    else -> Icons.Default.PlayArrow
                }
                Icon(imageVector = actionIcon, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))

                val packSuffix = if (packResultIntoArchive && currentMode != ProcessMode.ARCHIVE_HUB) {
                    "并压入 .${archiveFormat.extension}"
                } else {
                    ""
                }

                val labelText = when {
                    isProcessing -> "正在执行${currentMode.shortTitle} ($completedCount / $totalTaskCount)..."
                    requiresKey && obfuscationKeyText.isBlank() -> "请先在配置卡中输入文字口令"
                    currentMode == ProcessMode.COMPRESS_TRANSCODE -> "开始压缩 / 转码$packSuffix ($selectedCount 张)"
                    currentMode == ProcessMode.OBFUSCATE_ENCRYPT -> "开始混淆为色块$packSuffix ($selectedCount 张)"
                    currentMode == ProcessMode.DEOBFUSCATE_RESTORE -> "开始无损还原$packSuffix ($selectedCount 张)"
                    currentMode == ProcessMode.ARCHIVE_HUB && archiveSubMode == ArchiveSubMode.PACK_TO_ARCHIVE ->
                        "直接压入 .${archiveFormat.extension} 压缩包 ($selectedCount 张)"
                    else -> "直接无损解压全部图片 ($selectedCount 张)"
                }
                Text(
                    text = labelText,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun BatchSummaryBanner(
    selectedImages: List<SelectedImageItem>,
    resultsMap: Map<Uri, CompressionResult>,
    batchReport: BatchExecutionReport?
) {
    val successfulResults = selectedImages.mapNotNull { resultsMap[it.uri] }.filter { it.isSuccess }
    if (successfulResults.isEmpty()) return

    val totalOriginalBytes = successfulResults.sumOf { it.source.originalSize }
    val totalCompressedBytes = successfulResults.sumOf { it.compressedSize }
    val diffBytes = totalOriginalBytes - totalCompressedBytes
    val ratioPercent = if (totalOriginalBytes > 0) {
        (diffBytes.toDouble() / totalOriginalBytes.toDouble() * 100.0)
    } else {
        0.0
    }
    val mode = successfulResults.first().mode

    FlClashSurfaceCard(
        cornerRadius = 18.dp,
        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
        borderColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = if (batchReport?.archiveFileName != null) {
                    "已生成归档包：${batchReport.archiveFileName}"
                } else {
                    "${mode.shortTitle}批处理完成 (${successfulResults.size} / ${selectedImages.size})"
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "原始总计：${ImageCompressor.formatFileSize(totalOriginalBytes)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                val outBytesToShow = if (batchReport != null && batchReport.archiveTotalBytes > 0L) {
                    batchReport.archiveTotalBytes
                } else {
                    totalCompressedBytes
                }
                Text(
                    text = "输出总计：${ImageCompressor.formatFileSize(outBytesToShow)}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }

            val footerNote = when {
                batchReport?.archiveSavedPathLabel != null ->
                    "归档保存位置：${batchReport.archiveSavedPathLabel}"
                mode == ProcessMode.OBFUSCATE_ENCRYPT ->
                    "已输出为无损 PNG 色块图，凭文字口令可随时 100% 还原"
                mode == ProcessMode.DEOBFUSCATE_RESTORE ->
                    "已按文字口令完成像素级逆向解混淆还原"
                mode == ProcessMode.ARCHIVE_HUB ->
                    "已将压缩包内图片原样无损导出到目标目录"
                else -> {
                    if (diffBytes >= 0) {
                        String.format(
                            Locale.US,
                            "累计节省：%s (-%.1f%%)",
                            ImageCompressor.formatFileSize(diffBytes),
                            ratioPercent
                        )
                    } else {
                        String.format(
                            Locale.US,
                            "无损转换体积变化：+%s (+%.1f%%)",
                            ImageCompressor.formatFileSize(abs(diffBytes)),
                            abs(ratioPercent)
                        )
                    }
                }
            }
            Text(
                text = footerNote,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

/**
 * 18dp 细边框交互式图片列表项卡片（支持 0.98f 按压缩放，点击触发 Container Transform 展开详情视图）
 */
@Composable
private fun ImageComparisonItemCard(
    item: SelectedImageItem,
    result: CompressionResult?,
    isProcessing: Boolean,
    onCardClick: () -> Unit,
    onRemoveItem: () -> Unit
) {
    FlClashSurfaceCard(
        cornerRadius = 18.dp,
        modifier = Modifier
            .fillMaxWidth()
            .flClashInteractive(
                enabled = true,
                shape = RoundedCornerShape(18.dp),
                onClick = onCardClick
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 原图缩略图
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainer)
            ) {
                AsyncImage(
                    model = item.uri,
                    contentDescription = item.displayName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Surface(
                    color = Color.Black.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(bottomEnd = 6.dp),
                    modifier = Modifier.align(Alignment.TopStart)
                ) {
                    Text(
                        text = "原图",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                    )
                }
            }

            // 处理后结果缩略图
            if (result != null && result.isSuccess && result.outputUri != null) {
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainer)
                ) {
                    AsyncImage(
                        model = result.outputUri,
                        contentDescription = result.outputName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.88f),
                        shape = RoundedCornerShape(bottomEnd = 6.dp),
                        modifier = Modifier.align(Alignment.TopStart)
                    ) {
                        Text(
                            text = when {
                                result.packedIntoArchiveName != null -> "已入包"
                                result.mode == ProcessMode.OBFUSCATE_ENCRYPT -> "色块"
                                result.mode == ProcessMode.DEOBFUSCATE_RESTORE -> "还原"
                                else -> "结果"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = item.displayName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (item.fromArchiveName != null) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer
                        ) {
                            Text(
                                text = "来自归档",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                            )
                        }
                    }
                }

                val srcFormatShort = item.mimeType.substringAfterLast('/').uppercase(Locale.ROOT)
                Text(
                    text = "$srcFormatShort · ${item.width}×${item.height} · ${
                        ImageCompressor.formatFileSize(item.originalSize)
                    }",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (result != null) {
                    if (result.isSuccess) {
                        val deltaRatio = if (item.originalSize > 0) {
                            ((result.compressedSize - item.originalSize).toDouble() / item.originalSize.toDouble()) * 100.0
                        } else {
                            0.0
                        }
                        val ratioLabel = if (deltaRatio <= 0) {
                            String.format(Locale.US, "%.1f%%", deltaRatio)
                        } else {
                            String.format(Locale.US, "+%.1f%%", deltaRatio)
                        }
                        val badgeColor = if (deltaRatio <= 0) {
                            MaterialTheme.colorScheme.tertiary
                        } else {
                            MaterialTheme.colorScheme.primary
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = badgeColor,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${result.outputFormat.extension.uppercase(Locale.ROOT)} · " +
                                    "${result.outputWidth}×${result.outputHeight} · " +
                                    "${ImageCompressor.formatFileSize(result.compressedSize)} ($ratioLabel)",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = badgeColor
                            )
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.ErrorOutline,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = result.errorMessage ?: "处理失败",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }

            Icon(
                imageVector = Icons.Default.ZoomIn,
                contentDescription = "展开详情",
                tint = MaterialTheme.colorScheme.outline,
                modifier = Modifier.size(18.dp)
            )

            if (!isProcessing) {
                IconButton(
                    onClick = onRemoveItem,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "移除此图片",
                        tint = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

/**
 * Container Transform 卡片展开详情检视模态层（点击任意图片卡片后无缝展开，显示大图对比与完整参数）
 */
@Composable
private fun ImageDetailContainerTransformModal(
    item: SelectedImageItem,
    result: CompressionResult?,
    onDismiss: () -> Unit,
    onRemove: () -> Unit
) {
    BackHandler(onBack = onDismiss)

    var showProcessedPreview by remember { mutableStateOf(result?.outputUri != null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.48f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismiss
            )
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        FlClashSurfaceCard(
            cornerRadius = 20.dp,
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.96f),
            borderColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f),
            modifier = Modifier
                .widthIn(max = 560.dp)
                .fillMaxWidth()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {}
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 顶部标题与关闭按钮
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.displayName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = item.fromArchiveName?.let { "来源归档包：$it" } ?: "来源：本地相册选择",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "关闭详情")
                    }
                }

                // 若已有处理后图片，提供“原图 / 处理后结果”分段切换预览
                if (result != null && result.isSuccess && result.outputUri != null) {
                    FlClashSegmentedRow(
                        items = listOf(false, true),
                        selectedItem = showProcessedPreview,
                        itemLabel = { isAfter -> if (isAfter) "处理后预览 (${result.outputName})" else "原始图像预览" },
                        onItemSelected = { showProcessedPreview = it }
                    )
                }

                // 大图检视容器
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainer)
                        .border(
                            1.dp,
                            MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                            RoundedCornerShape(16.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    val previewUri = if (showProcessedPreview && result?.outputUri != null) {
                        result.outputUri
                    } else {
                        item.uri
                    }
                    AsyncImage(
                        model = previewUri,
                        contentDescription = item.displayName,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp)
                    )
                }

                // 详细元数据参数对比表
                FlClashSurfaceCard(
                    cornerRadius = 14.dp,
                    containerColor = MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "原始规格",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "${item.mimeType.substringAfterLast('/').uppercase(Locale.ROOT)} · ${item.width}×${item.height} · ${
                                    ImageCompressor.formatFileSize(item.originalSize)
                                }",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        if (result != null && result.isSuccess) {
                            HorizontalDivider(
                                thickness = 1.dp,
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "输出规格",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "${result.outputFormat.extension.uppercase(Locale.ROOT)} · ${result.outputWidth}×${result.outputHeight} · ${
                                        ImageCompressor.formatFileSize(result.compressedSize)
                                    }",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Text(
                                text = "输出路径：${result.savedPathLabel}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // 底部操作行
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FilledTonalButton(
                        onClick = onRemove,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("从队列移除")
                    }
                    Button(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("收起详情")
                    }
                }
            }
        }
    }
}

/**
 * 18dp 细边框空状态引导卡片
 */
@Composable
private fun EmptyWorkbenchCard(
    currentMode: ProcessMode,
    onPickImages: () -> Unit,
    onPickArchives: () -> Unit
) {
    FlClashSurfaceCard(
        cornerRadius = 20.dp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 34.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                modifier = Modifier.size(64.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (currentMode == ProcessMode.ARCHIVE_HUB) {
                            Icons.Outlined.FolderZip
                        } else {
                            Icons.Outlined.PhotoLibrary
                        },
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }

            Text(
                text = "当前工作台暂无图片",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "支持批量选取相册照片直接处理或压入压缩包；也可在 MT 管理器、文件管理、微信中对 .zip / .7z / .rar / .tar.gz / .xz / .cbz 选择「打开方式 / 分享」发给本应用",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                val imgBtnInteraction = remember { MutableInteractionSource() }
                val zipBtnInteraction = remember { MutableInteractionSource() }
                FilledTonalButton(
                    onClick = onPickImages,
                    interactionSource = imgBtnInteraction,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.flClashButtonScale(imgBtnInteraction)
                ) {
                    Icon(
                        imageVector = Icons.Default.AddPhotoAlternate,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("选择相册图片")
                }
                FilledTonalButton(
                    onClick = onPickArchives,
                    interactionSource = zipBtnInteraction,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.flClashButtonScale(zipBtnInteraction)
                ) {
                    Icon(
                        imageVector = Icons.Default.FolderZip,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("导入多格式压缩包")
                }
            }
        }
    }
}
