package com.example.imagecompressor

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.EnhancedEncryption
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.util.Consumer
import androidx.documentfile.provider.DocumentFile
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.random.Random

class MainActivity : ComponentActivity() {

    private var incomingExternalIntent by mutableStateOf<Intent?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null && intent != null) {
            incomingExternalIntent = intent
        }

        // 监听应用在后台时通过“打开方式”或“分享”再次传入的新 Intent
        addOnNewIntentListener(Consumer { newIntent ->
            incomingExternalIntent = newIntent
        })

        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    BatchImageCompressorScreen(
                        externalIntent = incomingExternalIntent,
                        onExternalIntentConsumed = { incomingExternalIntent = null }
                    )
                }
            }
        }
    }
}

/**
 * 从外部应用传入的 Intent (ACTION_VIEW / ACTION_SEND / ACTION_SEND_MULTIPLE) 中提取所有文件 Uri
 */
private fun extractUrisFromIntent(intent: Intent): List<Uri> {
    val uris = LinkedHashSet<Uri>()
    when (intent.action) {
        Intent.ACTION_VIEW -> {
            intent.data?.let { uris.add(it) }
        }
        Intent.ACTION_SEND -> {
            val streamUri: Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            }
            streamUri?.let { uris.add(it) }
            intent.data?.let { uris.add(it) }
        }
        Intent.ACTION_SEND_MULTIPLE -> {
            val streamList: java.util.ArrayList<Uri>? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
            }
            streamList?.forEach { uris.add(it) }
        }
    }
    intent.clipData?.let { clip ->
        for (i in 0 until clip.itemCount) {
            clip.getItemAt(i)?.uri?.let { uris.add(it) }
        }
    }
    return uris.toList()
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun BatchImageCompressorScreen(
    externalIntent: Intent?,
    onExternalIntentConsumed: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // 底部导航栏当前选中的工作模式
    var currentMode by remember { mutableStateOf(ProcessMode.COMPRESS_TRANSCODE) }

    // 批量选中的图片列表与对应的处理结果映射
    var selectedImages by remember { mutableStateOf<List<SelectedImageItem>>(emptyList()) }
    val compressionResults = remember { mutableStateMapOf<Uri, CompressionResult>() }
    var lastImportedZipBanner by remember { mutableStateOf<String?>(null) }

    // 参数面板展开/收起状态（收起后释放更大空间给图片列表，界面清爽不拥挤）
    var isConfigExpanded by remember { mutableStateOf(true) }

    // 压缩与转码参数状态
    var selectedFormat by remember { mutableStateOf(OutputFormat.JPEG) }
    var qualitySliderValue by remember { mutableFloatStateOf(80f) }
    var selectedResolution by remember { mutableStateOf(ResolutionOption.ORIGINAL) }

    // 文字加密混淆与解密还原参数状态
    var obfuscationKeyText by remember { mutableStateOf("") }
    var selectedBlockGrid by remember { mutableStateOf(BlockGridSize.BLOCK_16) }

    // 自定义存储目录状态 (null 表示默认保存到系统相册 Pictures/Compressed)
    var customTreeUri by remember { mutableStateOf<Uri?>(null) }
    var customDirName by remember { mutableStateOf<String?>(null) }

    // 批量处理进度状态
    var isProcessing by remember { mutableStateOf(false) }
    var completedCount by remember { mutableIntStateOf(0) }
    var totalTaskCount by remember { mutableIntStateOf(0) }

    // 统一处理外部“分享 (Share)”或“打开方式 (Open with)”传入的 .zip 压缩包或图片
    LaunchedEffect(externalIntent) {
        val intentToHandle = externalIntent ?: return@LaunchedEffect
        val incomingUris = extractUrisFromIntent(intentToHandle)
        onExternalIntentConsumed()

        if (incomingUris.isNotEmpty()) {
            val zipUris = incomingUris.filter { ImageCompressor.isZipUri(context, it) }
            val imageUris = incomingUris.filterNot { ImageCompressor.isZipUri(context, it) }

            val mergedList = mutableListOf<SelectedImageItem>()
            if (zipUris.isNotEmpty()) {
                val zipSummary = ImageCompressor.extractImagesFromZipUris(context, zipUris)
                mergedList.addAll(zipSummary.extractedImages)
                lastImportedZipBanner = "已从外部传入的 ${zipSummary.zipNames.joinToString(", ")} 中提取 ${zipSummary.extractedImages.size} 张图片"
                // 当外部直接用“打开方式/分享”传入 .zip 时，自动切到 ZIP 解压页签方便用户选择直接导出或转入其他模式
                currentMode = ProcessMode.ZIP_EXTRACT
            }
            if (imageUris.isNotEmpty()) {
                mergedList.addAll(ImageCompressor.inspectImages(context, imageUris))
            }

            if (mergedList.isNotEmpty()) {
                selectedImages = mergedList
                compressionResults.clear()
                completedCount = 0
                totalTaskCount = mergedList.size
                Toast.makeText(
                    context,
                    "已成功载入 ${mergedList.size} 张图片",
                    Toast.LENGTH_SHORT
                ).show()
            } else if (zipUris.isNotEmpty()) {
                Toast.makeText(
                    context,
                    "所选 ZIP 压缩包内未找到支持的图片文件",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    // 1. 系统 PhotoPicker 批量多选图片启动器
    val pickMultipleImagesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 50)
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            coroutineScope.launch {
                val inspected = ImageCompressor.inspectImages(context, uris)
                selectedImages = inspected
                lastImportedZipBanner = null
                compressionResults.clear()
                completedCount = 0
                totalTaskCount = inspected.size
            }
        }
    }

    // 2. 应用内选择本地 .zip 压缩包启动器
    val pickZipArchiveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            coroutineScope.launch {
                val zipSummary = ImageCompressor.extractImagesFromZipUris(context, uris)
                if (zipSummary.extractedImages.isNotEmpty()) {
                    selectedImages = zipSummary.extractedImages
                    lastImportedZipBanner = "已从 ${zipSummary.zipNames.joinToString(", ")} 提取 ${zipSummary.extractedImages.size} 张图片"
                    compressionResults.clear()
                    completedCount = 0
                    totalTaskCount = zipSummary.extractedImages.size
                    Toast.makeText(
                        context,
                        "从 ZIP 中提取了 ${zipSummary.extractedImages.size} 张图片",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    Toast.makeText(
                        context,
                        "所选文件中未找到可识别的图片",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    // 3. SAF 目录选择器 (OpenDocumentTree) 用于自定义输出目录
    val pickOutputDirectoryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        if (treeUri != null) {
            runCatching {
                val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(treeUri, takeFlags)
            }
            customTreeUri = treeUri
            val docDir = DocumentFile.fromTreeUri(context, treeUri)
            customDirName = docDir?.name ?: treeUri.lastPathSegment ?: "自定义文件夹"
            Toast.makeText(context, "保存目录已设为：$customDirName", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = currentMode.fullTitle,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            if (selectedImages.isNotEmpty()) {
                                Badge(
                                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                                ) {
                                    Text(
                                        text = "${selectedImages.size}张",
                                        modifier = Modifier.padding(horizontal = 4.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = currentMode.subtitle,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                actions = {
                    if (selectedImages.isNotEmpty() && !isProcessing) {
                        IconButton(
                            onClick = {
                                selectedImages = emptyList()
                                compressionResults.clear()
                                lastImportedZipBanner = null
                                completedCount = 0
                                totalTaskCount = 0
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteSweep,
                                contentDescription = "清空图片列表"
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            Column {
                // 底部固定悬浮执行栏（仅当已选择图片时浮现，避免在列表里到处翻找开始按钮）
                if (selectedImages.isNotEmpty()) {
                    BottomExecutionBar(
                        currentMode = currentMode,
                        selectedCount = selectedImages.size,
                        isProcessing = isProcessing,
                        completedCount = completedCount,
                        totalTaskCount = totalTaskCount,
                        obfuscationKeyText = obfuscationKeyText,
                        onStartClick = {
                            isProcessing = true
                            completedCount = 0
                            totalTaskCount = selectedImages.size
                            compressionResults.clear()

                            val config = CompressionConfig(
                                mode = currentMode,
                                format = selectedFormat,
                                quality = qualitySliderValue.roundToInt(),
                                resolutionOption = selectedResolution,
                                customTreeUri = customTreeUri,
                                obfuscationKey = obfuscationKeyText,
                                blockGridSize = selectedBlockGrid
                            )

                            coroutineScope.launch {
                                val results = ImageCompressor.processBatch(
                                    context = context,
                                    items = selectedImages,
                                    config = config,
                                    onProgress = { done, total, latest ->
                                        completedCount = done
                                        totalTaskCount = total
                                        compressionResults[latest.source.uri] = latest
                                    }
                                )
                                isProcessing = false
                                val successCount = results.count { it.isSuccess }
                                Toast.makeText(
                                    context,
                                    "${currentMode.shortTitle}完成：成功 $successCount / ${results.size} 张",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    )
                }

                // 底部四栏工作模式导航栏 (Material 3 NavigationBar)
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surfaceContainer
                ) {
                    ProcessMode.entries.forEach { mode ->
                        val icon = when (mode) {
                            ProcessMode.COMPRESS_TRANSCODE -> Icons.Default.Transform
                            ProcessMode.OBFUSCATE_ENCRYPT -> Icons.Default.EnhancedEncryption
                            ProcessMode.DEOBFUSCATE_RESTORE -> Icons.Default.LockOpen
                            ProcessMode.ZIP_EXTRACT -> Icons.Default.FolderZip
                        }
                        NavigationBarItem(
                            selected = currentMode == mode,
                            onClick = {
                                if (!isProcessing) {
                                    currentMode = mode
                                    isConfigExpanded = true
                                    if (mode == ProcessMode.DEOBFUSCATE_RESTORE) {
                                        selectedFormat = OutputFormat.PNG
                                    }
                                }
                            },
                            icon = { Icon(imageVector = icon, contentDescription = mode.shortTitle) },
                            label = {
                                Text(
                                    text = mode.shortTitle,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = if (currentMode == mode) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 第一部分：清爽的顶部图片导入与存储路径胶囊区
            item {
                TopQuickActionSection(
                    selectedCount = selectedImages.size,
                    customDirName = customDirName,
                    isProcessing = isProcessing,
                    lastImportedZipBanner = lastImportedZipBanner,
                    onPickImages = {
                        pickMultipleImagesLauncher.launch(
                            PickVisualMediaRequest(
                                ActivityResultContracts.PickVisualMedia.ImageOnly
                            )
                        )
                    },
                    onPickZip = {
                        pickZipArchiveLauncher.launch(
                            arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")
                        )
                    },
                    onPickDirectory = {
                        pickOutputDirectoryLauncher.launch(customTreeUri)
                    },
                    onResetDirectory = {
                        customTreeUri = null
                        customDirName = null
                    }
                )
            }

            // 第二部分：当前底栏模式专属的可折叠参数卡片（不同模式界面完全独立，绝不混堆）
            item {
                CollapsibleModeConfigCard(
                    currentMode = currentMode,
                    isExpanded = isConfigExpanded,
                    onToggleExpand = { isConfigExpanded = !isConfigExpanded },
                    isProcessing = isProcessing,
                    selectedFormat = selectedFormat,
                    onSelectFormat = { selectedFormat = it },
                    qualitySliderValue = qualitySliderValue,
                    onQualityChange = { qualitySliderValue = it },
                    selectedResolution = selectedResolution,
                    onSelectResolution = { selectedResolution = it },
                    obfuscationKeyText = obfuscationKeyText,
                    onKeyTextChange = { obfuscationKeyText = it },
                    selectedBlockGrid = selectedBlockGrid,
                    onSelectBlockGrid = { selectedBlockGrid = it },
                    onSwitchMode = { targetMode ->
                        currentMode = targetMode
                        if (targetMode == ProcessMode.DEOBFUSCATE_RESTORE) {
                            selectedFormat = OutputFormat.PNG
                        }
                    }
                )
            }

            // 第三部分：处理完成后的统计横幅
            if (compressionResults.isNotEmpty()) {
                item {
                    BatchSummaryBanner(
                        selectedImages = selectedImages,
                        resultsMap = compressionResults
                    )
                }
            }

            // 第四部分：图片工作台列表（带列表头或空状态引导）
            if (selectedImages.isEmpty()) {
                item {
                    EmptyWorkbenchCard(
                        currentMode = currentMode,
                        onPickImages = {
                            pickMultipleImagesLauncher.launch(
                                PickVisualMediaRequest(
                                    ActivityResultContracts.PickVisualMedia.ImageOnly
                                )
                            )
                        },
                        onPickZip = {
                            pickZipArchiveLauncher.launch(
                                arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")
                            )
                        }
                    )
                }
            } else {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp, bottom = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "待处理图片队列 (${selectedImages.size})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        val totalOrigSize = selectedImages.sumOf { it.originalSize }
                        Text(
                            text = "总计 ${ImageCompressor.formatFileSize(totalOrigSize)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                items(
                    items = selectedImages,
                    key = { it.uri.toString() }
                ) { item ->
                    ImageComparisonItemCard(
                        item = item,
                        result = compressionResults[item.uri],
                        isProcessing = isProcessing,
                        onRemoveItem = {
                            selectedImages = selectedImages.filterNot { it.uri == item.uri }
                            compressionResults.remove(item.uri)
                        }
                    )
                }
            }
        }
    }
}

/**
 * 顶部快捷导入按钮 + 紧凑型存储目录胶囊栏
 */
@Composable
private fun TopQuickActionSection(
    selectedCount: Int,
    customDirName: String?,
    isProcessing: Boolean,
    lastImportedZipBanner: String?,
    onPickImages: () -> Unit,
    onPickZip: () -> Unit,
    onPickDirectory: () -> Unit,
    onResetDirectory: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onPickImages,
                enabled = !isProcessing,
                shape = RoundedCornerShape(14.dp),
                contentPadding = PaddingValues(vertical = 12.dp, horizontal = 14.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Default.AddPhotoAlternate,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (selectedCount == 0) "选择相册图片" else "重选图片 ($selectedCount)",
                    fontWeight = FontWeight.SemiBold
                )
            }

            FilledTonalButton(
                onClick = onPickZip,
                enabled = !isProcessing,
                shape = RoundedCornerShape(14.dp),
                contentPadding = PaddingValues(vertical = 12.dp, horizontal = 14.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Default.FolderZip,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "导入 ZIP 压缩包",
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // 紧凑型输出目录状态胶囊条
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .weight(1f)
                        .clickable(enabled = !isProcessing) { onPickDirectory() }
                ) {
                    Icon(
                        imageVector = Icons.Default.FolderOpen,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (customDirName != null) {
                                "保存至自定义目录：$customDirName"
                            } else {
                                "保存至系统相册：Pictures/Compressed"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (customDirName != null && !isProcessing) {
                        TextButton(
                            onClick = onResetDirectory,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Restore,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text("默认", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    TextButton(
                        onClick = onPickDirectory,
                        enabled = !isProcessing,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                        modifier = Modifier.height(28.dp)
                    ) {
                        Text("更改目录", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        // 若刚刚从外部或本地导入了 ZIP 压缩包，展示清爽的提示条
        if (lastImportedZipBanner != null) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.tertiaryContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.FolderZip,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onTertiaryContainer,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = lastImportedZipBanner,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onTertiaryContainer
                    )
                }
            }
        }
    }
}

/**
 * 可折叠的当前模式专属参数配置卡片（随底栏 Tab 切换，每次只展示当前模式需要的控件）
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CollapsibleModeConfigCard(
    currentMode: ProcessMode,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    isProcessing: Boolean,
    selectedFormat: OutputFormat,
    onSelectFormat: (OutputFormat) -> Unit,
    qualitySliderValue: Float,
    onQualityChange: (Float) -> Unit,
    selectedResolution: ResolutionOption,
    onSelectResolution: (ResolutionOption) -> Unit,
    obfuscationKeyText: String,
    onKeyTextChange: (String) -> Unit,
    selectedBlockGrid: BlockGridSize,
    onSelectBlockGrid: (BlockGridSize) -> Unit,
    onSwitchMode: (ProcessMode) -> Unit
) {
    ElevatedCard(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // 卡片头部：支持点击展开或收起参数区
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleExpand() }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "${currentMode.shortTitle}参数设置",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        val summaryLine = when (currentMode) {
                            ProcessMode.COMPRESS_TRANSCODE -> {
                                val qText = if (selectedFormat.supportsQualitySlider) {
                                    "画质 ${qualitySliderValue.roundToInt()}%"
                                } else {
                                    "无损像素"
                                }
                                "${selectedFormat.shortLabel} · $qText · ${selectedResolution.label}"
                            }
                            ProcessMode.OBFUSCATE_ENCRYPT -> {
                                val keyStatus = if (obfuscationKeyText.isBlank()) "未填口令" else "口令已设"
                                "$keyStatus · 色块 ${selectedBlockGrid.shortLabel} · 自动无损 PNG"
                            }
                            ProcessMode.DEOBFUSCATE_RESTORE -> {
                                val keyStatus = if (obfuscationKeyText.isBlank()) "未填口令" else "口令已设"
                                "$keyStatus · 色块 ${selectedBlockGrid.shortLabel} · 导出 ${selectedFormat.shortLabel}"
                            }
                            ProcessMode.ZIP_EXTRACT -> {
                                "支持外部「分享/打开方式」传入 ZIP 或直接无损解压图片"
                            }
                        }
                        Text(
                            text = summaryLine,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (isExpanded) "收起参数" else "展开参数",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp, bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    HorizontalDivider()

                    when (currentMode) {
                        ProcessMode.COMPRESS_TRANSCODE -> {
                            Text(
                                text = "目标导出格式",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                OutputFormat.entries.forEach { format ->
                                    FilterChip(
                                        selected = selectedFormat == format,
                                        onClick = { if (!isProcessing) onSelectFormat(format) },
                                        label = { Text(format.label) },
                                        enabled = !isProcessing
                                    )
                                }
                            }
                            Text(
                                text = selectedFormat.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            if (selectedFormat.supportsQualitySlider) {
                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "压缩画质",
                                            style = MaterialTheme.typography.labelLarge,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = "${qualitySliderValue.roundToInt()}%",
                                            style = MaterialTheme.typography.labelLarge,
                                            color = MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Slider(
                                        value = qualitySliderValue,
                                        onValueChange = onQualityChange,
                                        valueRange = 10f..100f,
                                        steps = 17,
                                        enabled = !isProcessing
                                    )
                                }
                            }

                            Text(
                                text = "最大尺寸限制（等比缩放）",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                ResolutionOption.entries.forEach { option ->
                                    FilterChip(
                                        selected = selectedResolution == option,
                                        onClick = { if (!isProcessing) onSelectResolution(option) },
                                        label = { Text(option.label) },
                                        enabled = !isProcessing
                                    )
                                }
                            }
                        }

                        ProcessMode.OBFUSCATE_ENCRYPT, ProcessMode.DEOBFUSCATE_RESTORE -> {
                            val isEncrypt = currentMode == ProcessMode.OBFUSCATE_ENCRYPT
                            OutlinedTextField(
                                value = obfuscationKeyText,
                                onValueChange = onKeyTextChange,
                                label = {
                                    Text(
                                        if (isEncrypt) "输入加密文字口令" else "输入加密时的同一串文字口令"
                                    )
                                },
                                placeholder = { Text("支持任意中文、英文、数字或句子") },
                                leadingIcon = {
                                    Icon(imageVector = Icons.Default.Key, contentDescription = null)
                                },
                                trailingIcon = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (obfuscationKeyText.isNotEmpty()) {
                                            IconButton(onClick = { onKeyTextChange("") }) {
                                                Icon(
                                                    imageVector = Icons.Default.Clear,
                                                    contentDescription = "清空口令"
                                                )
                                            }
                                        } else if (isEncrypt) {
                                            IconButton(
                                                onClick = {
                                                    val randomPin = "密钥" + Random.nextInt(100000, 999999)
                                                    onKeyTextChange(randomPin)
                                                }
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Casino,
                                                    contentDescription = "随机生成口令"
                                                )
                                            }
                                        }
                                    }
                                },
                                singleLine = true,
                                enabled = !isProcessing,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.GridView,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "色块网格粒度（加密与还原须保持一致）",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                BlockGridSize.entries.forEach { grid ->
                                    FilterChip(
                                        selected = selectedBlockGrid == grid,
                                        onClick = { if (!isProcessing) onSelectBlockGrid(grid) },
                                        label = { Text(grid.label) },
                                        enabled = !isProcessing
                                    )
                                }
                            }

                            if (!isEncrypt) {
                                Text(
                                    text = "还原后导出格式（默认无损 PNG）",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.SemiBold
                                )
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    OutputFormat.entries.forEach { format ->
                                        FilterChip(
                                            selected = selectedFormat == format,
                                            onClick = { if (!isProcessing) onSelectFormat(format) },
                                            label = { Text(format.shortLabel) },
                                            enabled = !isProcessing
                                        )
                                    }
                                }
                            }
                        }

                        ProcessMode.ZIP_EXTRACT -> {
                            Text(
                                text = "外部应用联动说明：你可以在 MT 管理器、系统文件管理、微信或浏览器中长按任意 .zip 压缩包，选择「打开方式」或「分享」并点选本应用，系统会自动提取压缩包内的全部图片。",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Text(
                                text = "提取后的图片除了直接点击下方按钮原样解压保存到目录外，也可一键转入其他工作台：",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold
                            )

                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                FilledTonalButton(
                                    onClick = { onSwitchMode(ProcessMode.COMPRESS_TRANSCODE) },
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text("去批量压缩/转码", style = MaterialTheme.typography.labelMedium)
                                }
                                FilledTonalButton(
                                    onClick = { onSwitchMode(ProcessMode.OBFUSCATE_ENCRYPT) },
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text("去文字混淆加密", style = MaterialTheme.typography.labelMedium)
                                }
                                FilledTonalButton(
                                    onClick = { onSwitchMode(ProcessMode.DEOBFUSCATE_RESTORE) },
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text("去文字解密还原", style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * 底部固定悬浮执行栏（始终贴合在底部导航栏上方，操作触手可及）
 */
@Composable
private fun BottomExecutionBar(
    currentMode: ProcessMode,
    selectedCount: Int,
    isProcessing: Boolean,
    completedCount: Int,
    totalTaskCount: Int,
    obfuscationKeyText: String,
    onStartClick: () -> Unit
) {
    val requiresKey = currentMode == ProcessMode.OBFUSCATE_ENCRYPT ||
        currentMode == ProcessMode.DEOBFUSCATE_RESTORE
    val canStart = selectedCount > 0 && !isProcessing &&
        (!requiresKey || obfuscationKeyText.isNotBlank())

    Surface(
        tonalElevation = 4.dp,
        shadowElevation = 6.dp,
        color = MaterialTheme.colorScheme.surfaceContainerLow
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (isProcessing && totalTaskCount > 0) {
                LinearProgressIndicator(
                    progress = { completedCount.toFloat() / totalTaskCount.toFloat() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                )
            }

            Button(
                onClick = onStartClick,
                enabled = canStart,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                val labelText = when {
                    isProcessing -> "正在执行${currentMode.shortTitle} ($completedCount / $totalTaskCount)..."
                    requiresKey && obfuscationKeyText.isBlank() -> "请先在参数卡片中输入文字口令"
                    currentMode == ProcessMode.COMPRESS_TRANSCODE -> "开始批量压缩 / 转码 ($selectedCount 张)"
                    currentMode == ProcessMode.OBFUSCATE_ENCRYPT -> "开始混淆成彩色色块 ($selectedCount 张)"
                    currentMode == ProcessMode.DEOBFUSCATE_RESTORE -> "开始无损还原原图 ($selectedCount 张)"
                    ProcessMode.ZIP_EXTRACT == currentMode -> "直接解压保存全部图片 ($selectedCount 张)"
                    else -> "开始处理 ($selectedCount 张)"
                }
                Text(
                    text = labelText,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun BatchSummaryBanner(
    selectedImages: List<SelectedImageItem>,
    resultsMap: Map<Uri, CompressionResult>
) {
    val successfulResults = selectedImages.mapNotNull { resultsMap[it.uri] }.filter { it.isSuccess }
    if (successfulResults.isEmpty()) return

    val totalOriginalBytes = successfulResults.sumOf { it.source.originalSize }
    val totalCompressedBytes = successfulResults.sumOf { it.compressedSize }
    val diffBytes = totalOriginalBytes - totalCompressedBytes
    val ratioPercent = if (totalOriginalBytes > 0) {
        (diffBytes.toDouble() / totalOriginalBytes.toDouble() * 100.0)
    } else {
        0.0
    }
    val mode = successfulResults.first().mode

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = "${mode.shortTitle}已完成 (${successfulResults.size} / ${selectedImages.size} 张)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "处理前：${ImageCompressor.formatFileSize(totalOriginalBytes)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                    text = "处理后：${ImageCompressor.formatFileSize(totalCompressedBytes)}",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
            val footerNote = when (mode) {
                ProcessMode.OBFUSCATE_ENCRYPT -> "已保存为无损 PNG 色块图，凭文字口令可随时 100% 还原"
                ProcessMode.DEOBFUSCATE_RESTORE -> "已按文字口令完成像素级逆向解混淆还原"
                ProcessMode.ZIP_EXTRACT -> "已将 ZIP 包内图片原样无损导出到目标目录"
                ProcessMode.COMPRESS_TRANSCODE -> {
                    if (diffBytes >= 0) {
                        String.format(
                            Locale.US,
                            "累计节省：%s (-%.1f%%)",
                            ImageCompressor.formatFileSize(diffBytes),
                            ratioPercent
                        )
                    } else {
                        String.format(
                            Locale.US,
                            "无损转码体积增加：+%s (+%.1f%%)",
                            ImageCompressor.formatFileSize(abs(diffBytes)),
                            abs(ratioPercent)
                        )
                    }
                }
            }
            Text(
                text = footerNote,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

/**
 * 现代留白风格的单张图片对比卡片
 */
@Composable
private fun ImageComparisonItemCard(
    item: SelectedImageItem,
    result: CompressionResult?,
    isProcessing: Boolean,
    onRemoveItem: () -> Unit
) {
    OutlinedCard(
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 原图缩略图
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                AsyncImage(
                    model = item.uri,
                    contentDescription = item.displayName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Surface(
                    color = Color.Black.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(bottomEnd = 6.dp),
                    modifier = Modifier.align(Alignment.TopStart)
                ) {
                    Text(
                        text = "原图",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                    )
                }
            }

            // 处理后结果缩略图（并排直观对比）
            if (result != null && result.isSuccess && result.outputUri != null) {
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    AsyncImage(
                        model = result.outputUri,
                        contentDescription = result.outputName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                        shape = RoundedCornerShape(bottomEnd = 6.dp),
                        modifier = Modifier.align(Alignment.TopStart)
                    ) {
                        Text(
                            text = when (result.mode) {
                                ProcessMode.OBFUSCATE_ENCRYPT -> "色块"
                                ProcessMode.DEOBFUSCATE_RESTORE -> "还原"
                                else -> "结果"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = item.displayName,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (item.fromZipName != null) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer
                        ) {
                            Text(
                                text = "来自ZIP",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                }

                val srcFormatShort = item.mimeType.substringAfterLast('/').uppercase(Locale.ROOT)
                Text(
                    text = "$srcFormatShort · ${item.width}×${item.height} · ${
                        ImageCompressor.formatFileSize(item.originalSize)
                    }",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (result != null) {
                    if (result.isSuccess) {
                        val deltaRatio = if (item.originalSize > 0) {
                            ((result.compressedSize - item.originalSize).toDouble() / item.originalSize.toDouble()) * 100.0
                        } else {
                            0.0
                        }
                        val ratioLabel = if (deltaRatio <= 0) {
                            String.format(Locale.US, "%.1f%%", deltaRatio)
                        } else {
                            String.format(Locale.US, "+%.1f%%", deltaRatio)
                        }
                        val badgeColor = if (deltaRatio <= 0) {
                            Color(0xFF2E7D32)
                        } else {
                            MaterialTheme.colorScheme.primary
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = badgeColor,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${result.outputFormat.extension.uppercase(Locale.ROOT)} · " +
                                    "${result.outputWidth}×${result.outputHeight} · " +
                                    "${ImageCompressor.formatFileSize(result.compressedSize)} ($ratioLabel)",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = badgeColor
                            )
                        }

                        Text(
                            text = result.savedPathLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.ErrorOutline,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = result.errorMessage ?: "处理失败",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }

            if (!isProcessing) {
                IconButton(
                    onClick = onRemoveItem,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "移除此图片",
                        tint = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

/**
 * 留白充足的空状态引导卡片
 */
@Composable
private fun EmptyWorkbenchCard(
    currentMode: ProcessMode,
    onPickImages: () -> Unit,
    onPickZip: () -> Unit
) {
    OutlinedCard(
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 36.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (currentMode == ProcessMode.ZIP_EXTRACT) {
                        Icons.Default.FolderZip
                    } else {
                        Icons.Default.PhotoLibrary
                    },
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(32.dp)
                )
            }

            Text(
                text = "当前工作台还没有图片",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "你可以从相册批量选择图片，或者在 MT 管理器、文件管理、微信中将 .zip 压缩包通过「打开方式 / 分享」发送给本应用自动载入",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FilledTonalButton(onClick = onPickImages) {
                    Icon(
                        imageVector = Icons.Default.AddPhotoAlternate,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("从相册选图")
                }
                FilledTonalButton(onClick = onPickZip) {
                    Icon(
                        imageVector = Icons.Default.FolderZip,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("选择本地 ZIP")
                }
            }
        }
    }
}
