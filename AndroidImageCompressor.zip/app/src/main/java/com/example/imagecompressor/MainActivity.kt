package com.example.imagecompressor

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.EnhancedEncryption
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Password
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.EnhancedEncryption
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.FolderZip
import androidx.compose.material.icons.outlined.LockOpen
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Transform
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.VerticalDivider
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.core.util.Consumer
import androidx.documentfile.provider.DocumentFile
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * FlClash 物理果冻弹簧常量 + Apple Liquid Glass 液态玻璃二级展开动效参数
 */
private const val JELLY_DAMPING = 0.44f
private const val PAGE_SPRING_DAMPING = 0.58f
private const val JELLY_STIFFNESS = 350f

/**
 * Apple 液态玻璃二级弹出菜单枚举：
 * 点击任意一级按钮后，以果冻弹簧展开对应的第二层液态玻璃面板；点击任意空白区域自动缩回按钮本身
 */
private enum class LiquidGlassLayer2Menu {
    NONE,
    FORMAT_PICKER,           // 输出格式二级面板
    QUALITY_SLIDER,          // 画质百分比二级面板
    PRIVACY_AND_RENAME,      // EXIF 隐私抹除与批量重命名二级面板
    DIRECT_ARCHIVE_PACK,     // 直接压入压缩包与加密密码二级面板
    OBFUSCATION_KEY,         // 加密/还原文字口令二级面板
    BLOCK_GRID_PICKER,       // 色块粒度与文件名标记二级面板
    ARCHIVE_SUBMODE,         // 归档打包/解压模式二级面板
    ARCHIVE_FORMAT_LEVEL,    // 归档格式与压缩等级二级面板
    ARCHIVE_PASSWORD_NAMING, // 归档加密密码与包名二级面板
    FAB_QUICK_HUB,           // 右下角液态玻璃快捷菜单（选图/导入包/打开阅读器/分享/清空）
    READER_CONTROL_PANEL     // 阅读器液态玻璃二级控制面板（条漫/翻页、密码解锁、口令实时还原）
}

@Composable
fun FlClashM3Theme(
    useDynamicColor: Boolean = true,
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val colorScheme = when {
        useDynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> darkColorScheme(
            primary = Color(0xFF8AB4F8),
            onPrimary = Color(0xFF002E6B),
            primaryContainer = Color(0xFF1E3A5F),
            onPrimaryContainer = Color(0xFFD3E3FD),
            secondary = Color(0xFFBCC7DC),
            secondaryContainer = Color(0xFF283141),
            onSecondaryContainer = Color(0xFFD8E3F8),
            tertiary = Color(0xFF81C995),
            tertiaryContainer = Color(0xFF0F5223),
            onTertiaryContainer = Color(0xFFCEEAD6),
            background = Color(0xFF0F1116),
            surface = Color(0xFF0F1116),
            surfaceContainerLow = Color(0xFF171A21),
            surfaceContainer = Color(0xFF1D212A),
            surfaceContainerHigh = Color(0xFF262B36),
            outlineVariant = Color(0xFF343A46)
        )
        else -> lightColorScheme(
            primary = Color(0xFF1A73E8),
            onPrimary = Color.White,
            primaryContainer = Color(0xFFD3E3FD),
            onPrimaryContainer = Color(0xFF041E49),
            secondary = Color(0xFF535F70),
            secondaryContainer = Color(0xFFD7E3F7),
            onSecondaryContainer = Color(0xFF101C2B),
            tertiary = Color(0xFF188038),
            tertiaryContainer = Color(0xFFCEEAD6),
            onTertiaryContainer = Color(0xFF072711),
            background = Color(0xFFF5F7FB),
            surface = Color(0xFFF5F7FB),
            surfaceContainerLow = Color(0xFFFFFFFF),
            surfaceContainer = Color(0xFFEEF2F8),
            surfaceContainerHigh = Color(0xFFE2E8F2),
            outlineVariant = Color(0xFFD5DCE6)
        )
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}

/**
 * FlClash 果冻按压回弹修饰符
 */
private fun Modifier.flClashJellyClick(
    enabled: Boolean = true,
    pressScale: Float = 0.90f,
    shape: Shape = RoundedCornerShape(18.dp),
    onClick: () -> Unit
): Modifier = composed {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (enabled && isPressed) pressScale else 1f,
        animationSpec = spring(
            dampingRatio = if (isPressed) 0.6f else 0.40f,
            stiffness = if (isPressed) 650f else 330f
        ),
        label = "JellyClickScale"
    )
    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clip(shape)
        .clickable(
            interactionSource = interactionSource,
            indication = LocalIndication.current,
            enabled = enabled,
            onClick = onClick
        )
}

/**
 * Apple Liquid Glass 液态玻璃表面卡片（半透明高光折射描边 + 柔和通透底色）
 */
@Composable
private fun LiquidGlassSurfaceCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 22.dp,
    isHighlighted: Boolean = false,
    containerColor: Color = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.92f),
    content: @Composable () -> Unit
) {
    val primaryColor = MaterialTheme.colorScheme.primary
    val outlineColor = MaterialTheme.colorScheme.outlineVariant
    val glassBorderBrush = remember(isHighlighted, primaryColor, outlineColor) {
        if (isHighlighted) {
            Brush.linearGradient(
                colors = listOf(
                    primaryColor.copy(alpha = 0.85f),
                    Color.White.copy(alpha = 0.55f),
                    primaryColor.copy(alpha = 0.45f)
                )
            )
        } else {
            Brush.linearGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.35f),
                    outlineColor.copy(alpha = 0.55f),
                    outlineColor.copy(alpha = 0.30f)
                )
            )
        }
    }

    OutlinedCard(
        shape = RoundedCornerShape(cornerRadius),
        colors = CardDefaults.outlinedCardColors(containerColor = containerColor),
        border = BorderStroke(if (isHighlighted) 1.5.dp else 1.dp, glassBorderBrush),
        elevation = CardDefaults.outlinedCardElevation(defaultElevation = 0.dp),
        modifier = modifier
    ) {
        content()
    }
}

/**
 * 一级液态玻璃胶囊按钮（点击后 Q 弹展开第二层液态玻璃面板，激活时带有玻璃高光与膨胀效果）
 */
@Composable
private fun LiquidGlassTriggerTile(
    icon: ImageVector,
    title: String,
    valueText: String,
    isActive: Boolean,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val activeScale by animateFloatAsState(
        targetValue = if (isActive) 1.03f else 1f,
        animationSpec = spring(dampingRatio = JELLY_DAMPING, stiffness = JELLY_STIFFNESS),
        label = "TriggerTileActiveScale"
    )

    val bgColor by animateColorAsState(
        targetValue = if (isActive) {
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.92f)
        } else {
            MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.90f)
        },
        animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = JELLY_STIFFNESS),
        label = "TriggerTileBgColor"
    )

    LiquidGlassSurfaceCard(
        cornerRadius = 18.dp,
        isHighlighted = isActive,
        containerColor = bgColor,
        modifier = modifier
            .graphicsLayer {
                scaleX = activeScale
                scaleY = activeScale
            }
            .flClashJellyClick(
                enabled = enabled,
                pressScale = 0.90f,
                shape = RoundedCornerShape(18.dp),
                onClick = onClick
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isActive) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.75f)
                },
                modifier = Modifier.size(34.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = if (isActive) {
                            MaterialTheme.colorScheme.onPrimary
                        } else {
                            MaterialTheme.colorScheme.onPrimaryContainer
                        },
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = valueText,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (isActive) {
                        MaterialTheme.colorScheme.onPrimaryContainer
                    } else {
                        MaterialTheme.colorScheme.onSurface
                    },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Icon(
                imageVector = if (isActive) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                contentDescription = null,
                tint = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

class MainActivity : ComponentActivity() {

    private var incomingExternalIntent by mutableStateOf<Intent?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null && intent != null) {
            incomingExternalIntent = intent
        }

        addOnNewIntentListener(Consumer { newIntent ->
            incomingExternalIntent = newIntent
        })

        setContent {
            var useDynamicColor by remember { mutableStateOf(true) }
            FlClashM3Theme(useDynamicColor = useDynamicColor) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    FlClashAdaptiveDashboardApp(
                        externalIntent = incomingExternalIntent,
                        onExternalIntentConsumed = { incomingExternalIntent = null },
                        useDynamicColor = useDynamicColor,
                        onToggleDynamicColor = { useDynamicColor = !useDynamicColor }
                    )
                }
            }
        }
    }
}

private fun extractUrisFromIntent(intent: Intent): List<Uri> {
    val uris = LinkedHashSet<Uri>()
    when (intent.action) {
        Intent.ACTION_VIEW -> {
            intent.data?.let { uris.add(it) }
        }
        Intent.ACTION_SEND -> {
            val streamUri: Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            }
            streamUri?.let { uris.add(it) }
            intent.data?.let { uris.add(it) }
        }
        Intent.ACTION_SEND_MULTIPLE -> {
            val streamList: java.util.ArrayList<Uri>? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
            }
            streamList?.forEach { uris.add(it) }
        }
    }
    intent.clipData?.let { clip ->
        for (i in 0 until clip.itemCount) {
            clip.getItemAt(i)?.uri?.let { uris.add(it) }
        }
    }
    return uris.toList()
}

@OptIn(
    ExperimentalMaterial3Api::class,
    ExperimentalLayoutApi::class,
    ExperimentalFoundationApi::class,
    ExperimentalAnimationApi::class
)
@Composable
fun FlClashAdaptiveDashboardApp(
    externalIntent: Intent?,
    onExternalIntentConsumed: () -> Unit,
    useDynamicColor: Boolean,
    onToggleDynamicColor: () -> Unit
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val coroutineScope = rememberCoroutineScope()

    // 五大工作空间左右滑页 Pager（压缩 · 混淆 · 还原 · 归档 · 阅读）
    val pagerState = rememberPagerState(
        initialPage = 0,
        pageCount = { ProcessMode.entries.size }
    )
    var pagerScrollJob by remember { mutableStateOf<Job?>(null) }
    val currentMode = ProcessMode.entries[pagerState.currentPage]

    // 当前展开的第二层 Apple 液态玻璃弹出面板（点击空白区域即置为 NONE 缩回按钮）
    var activeLayer2Menu by remember { mutableStateOf(LiquidGlassLayer2Menu.NONE) }

    var archiveSubMode by remember { mutableStateOf(ArchiveSubMode.PACK_TO_ARCHIVE) }

    // 图片队列与处理结果映射
    var selectedImages by remember { mutableStateOf<List<SelectedImageItem>>(emptyList()) }
    val compressionResults = remember { mutableStateMapOf<Uri, CompressionResult>() }
    var lastBatchReport by remember { mutableStateOf<BatchExecutionReport?>(null) }
    var lastImportedArchiveBanner by remember { mutableStateOf<String?>(null) }

    // 详情弹窗状态（支持 Before/After 拉帘对比）
    var inspectedItem by remember { mutableStateOf<SelectedImageItem?>(null) }

    // 1. 压缩与转码参数
    var selectedFormat by remember { mutableStateOf(OutputFormat.JPEG) }
    var qualitySliderValue by remember { mutableFloatStateOf(80f) }
    var selectedResolution by remember { mutableStateOf(ResolutionOption.ORIGINAL) }

    // 2. EXIF 隐私抹除与批量重命名参数
    var stripExifMetadata by remember { mutableStateOf(true) }
    var selectedRenameTemplate by remember { mutableStateOf(RenameTemplate.KEEP_ORIGINAL) }
    var customRenamePrefix by remember { mutableStateOf("IMG") }

    // 3. 文字加密混淆与无损还原参数（含自动粒度标记与识别）
    var obfuscationKeyText by remember { mutableStateOf("") }
    var selectedBlockGrid by remember { mutableStateOf(BlockGridSize.BLOCK_16) }
    var autoTagBlockSizeInName by remember { mutableStateOf(true) }

    // 4. 直接压入压缩包与 AES-256 密码配置
    var packResultIntoArchive by remember { mutableStateOf(false) }
    var selectedArchiveFormat by remember { mutableStateOf(ArchiveOutputFormat.ZIP) }
    var selectedArchiveLevel by remember { mutableStateOf(ArchiveCompressionLevel.STANDARD) }
    var archivePassword by remember { mutableStateOf("") }
    var customArchiveName by remember { mutableStateOf("") }

    // 5. 加密压缩包导入密码解锁弹窗状态
    var pendingPasswordArchiveUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var pendingPasswordArchiveNames by remember { mutableStateOf("") }
    var unlockPasswordInput by remember { mutableStateOf("") }
    var unlockPasswordError by remember { mutableStateOf<String?>(null) }
    var jumpToReaderAfterUnlock by remember { mutableStateOf(false) }

    // 6. 归档阅读器与解压进度专属状态
    var readerLayoutMode by remember { mutableStateOf(ReaderLayoutMode.VERTICAL_STRIP) }
    var isImmersiveReader by remember { mutableStateOf(false) }
    var readerLiveDecryptEnabled by remember { mutableStateOf(false) }
    val readerDecryptedUriCache = remember { mutableStateMapOf<Uri, Uri>() }
    var isExtractingArchive by remember { mutableStateOf(false) }
    var extractDoneCount by remember { mutableIntStateOf(0) }
    var extractTotalCount by remember { mutableIntStateOf(0) }
    var extractCurrentFile by remember { mutableStateOf("") }

    // 自定义存储目录状态
    var customTreeUri by remember { mutableStateOf<Uri?>(null) }
    var customDirName by remember { mutableStateOf<String?>(null) }

    // 批量执行进度与可取消任务句柄（允许随时中断批处理或解压任务，且后台运行时不锁死浏览与切页）
    var isProcessing by remember { mutableStateOf(false) }
    var completedCount by remember { mutableIntStateOf(0) }
    var totalTaskCount by remember { mutableIntStateOf(0) }
    var activeTaskJob by remember { mutableStateOf<Job?>(null) }

    val cancelRunningTask: () -> Unit = {
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        activeTaskJob?.cancel()
        activeTaskJob = null
        isProcessing = false
        isExtractingArchive = false
        Toast.makeText(context, "已取消当前任务（已完成结果已保留）", Toast.LENGTH_SHORT).show()
    }

    // 当载入新图片时，若文件名带有 OBF_B8/B16/B32/B64 标记，自动同步还原粒度
    val applyAutoDetectedGrid: (List<SelectedImageItem>) -> Unit = { items ->
        ImageCompressor.detectBlockGridFromItems(items)?.let { detected ->
            selectedBlockGrid = detected
        }
    }

    // 动画跳转工作台（任务后台执行时仍允许自由切换页面与查看阅读器，不再锁死界面）
    val animateToMode: (ProcessMode) -> Unit = { targetMode ->
        activeLayer2Menu = LiquidGlassLayer2Menu.NONE
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        if (targetMode == ProcessMode.DEOBFUSCATE_RESTORE) {
            selectedFormat = OutputFormat.PNG
            applyAutoDetectedGrid(selectedImages)
        }
        pagerScrollJob?.cancel()
        pagerScrollJob = coroutineScope.launch {
            pagerState.animateScrollToPage(
                page = targetMode.ordinal,
                animationSpec = spring(
                    dampingRatio = PAGE_SPRING_DAMPING,
                    stiffness = JELLY_STIFFNESS
                )
            )
        }
    }

    // 统一处理压缩包导入（含加密检测、主线程节流实时解压进度条、随时取消与密码弹窗）
    val handleArchiveImport: (List<Uri>, String, Boolean) -> Unit = { uris, pwd, openInReader ->
        activeTaskJob?.cancel()
        activeTaskJob = coroutineScope.launch {
            if (openInReader && currentMode != ProcessMode.ARCHIVE_READER) {
                animateToMode(ProcessMode.ARCHIVE_READER)
            }
            isExtractingArchive = true
            extractDoneCount = 0
            extractTotalCount = 0
            extractCurrentFile = ""
            try {
                val summary = ImageCompressor.extractImagesFromArchiveUris(
                    context = context,
                    archiveUris = uris,
                    password = pwd
                ) { done, total, currentName ->
                    coroutineScope.launch(Dispatchers.Main.immediate) {
                        extractDoneCount = done
                        extractTotalCount = total
                        extractCurrentFile = currentName
                    }
                }
                isExtractingArchive = false

                if (summary.needsPassword) {
                    pendingPasswordArchiveUris = summary.pendingUris
                    pendingPasswordArchiveNames = summary.archiveNames.joinToString(", ")
                    unlockPasswordError = if (summary.wrongPassword) "密码不正确，请重新输入" else null
                    jumpToReaderAfterUnlock = openInReader
                } else if (summary.extractedImages.isNotEmpty()) {
                    pendingPasswordArchiveUris = emptyList()
                    unlockPasswordError = null
                    selectedImages = summary.extractedImages
                    applyAutoDetectedGrid(summary.extractedImages)
                    lastImportedArchiveBanner = "${summary.archiveNames.joinToString(", ")} · ${summary.extractedImages.size} 张"
                    compressionResults.clear()
                    readerDecryptedUriCache.clear()
                    lastBatchReport = null
                    completedCount = 0
                    totalTaskCount = summary.extractedImages.size
                    if (openInReader) {
                        animateToMode(ProcessMode.ARCHIVE_READER)
                    }
                    Toast.makeText(context, "已载入 ${summary.extractedImages.size} 张图片", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(
                        context,
                        summary.errorNote ?: "压缩包内未找到支持的图片",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (_: CancellationException) {
                isExtractingArchive = false
            } finally {
                isExtractingArchive = false
            }
        }
    }

    // 响应外部应用「打开方式 / 分享」传入的压缩包或图片
    LaunchedEffect(externalIntent) {
        val intentToHandle = externalIntent ?: return@LaunchedEffect
        val incomingUris = extractUrisFromIntent(intentToHandle)
        onExternalIntentConsumed()

        if (incomingUris.isNotEmpty()) {
            val archiveUris = incomingUris.filter { ImageCompressor.isArchiveUri(context, it) }
            val imageUris = incomingUris.filterNot { ImageCompressor.isArchiveUri(context, it) }

            if (archiveUris.isNotEmpty() && imageUris.isEmpty()) {
                // 外部传入压缩包时直接提取并进入「阅读」页，支持带密码压缩包解锁
                handleArchiveImport(archiveUris, archivePassword, true)
            } else {
                val mergedList = mutableListOf<SelectedImageItem>()
                if (archiveUris.isNotEmpty()) {
                    isExtractingArchive = true
                    extractDoneCount = 0
                    extractTotalCount = 0
                    extractCurrentFile = ""
                    val summary = ImageCompressor.extractImagesFromArchiveUris(
                        context = context,
                        archiveUris = archiveUris,
                        password = archivePassword
                    ) { done, total, currentName ->
                        extractDoneCount = done
                        extractTotalCount = total
                        extractCurrentFile = currentName
                    }
                    isExtractingArchive = false
                    if (summary.needsPassword) {
                        pendingPasswordArchiveUris = summary.pendingUris
                        pendingPasswordArchiveNames = summary.archiveNames.joinToString(", ")
                        jumpToReaderAfterUnlock = true
                    }
                    mergedList.addAll(summary.extractedImages)
                }
                if (imageUris.isNotEmpty()) {
                    mergedList.addAll(ImageCompressor.inspectImages(context, imageUris))
                }
                if (mergedList.isNotEmpty()) {
                    selectedImages = mergedList
                    applyAutoDetectedGrid(mergedList)
                    compressionResults.clear()
                    readerDecryptedUriCache.clear()
                    lastBatchReport = null
                    completedCount = 0
                    totalTaskCount = mergedList.size
                }
            }
        }
    }

    // 阅读器开启「口令实时还原预览」时，后台自动解混淆当前队列图片
    LaunchedEffect(readerLiveDecryptEnabled, obfuscationKeyText, selectedImages, selectedBlockGrid) {
        if (readerLiveDecryptEnabled && obfuscationKeyText.isNotBlank()) {
            for (item in selectedImages) {
                if (!readerDecryptedUriCache.containsKey(item.uri)) {
                    val decUri = ImageCompressor.decryptImageForReaderPreview(
                        context = context,
                        item = item,
                        secretKey = obfuscationKeyText,
                        fallbackGridSize = selectedBlockGrid
                    )
                    if (decUri != null) {
                        readerDecryptedUriCache[item.uri] = decUri
                    }
                }
            }
        }
    }

    // 1. 相册选图启动器
    val pickMultipleImagesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 50)
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            coroutineScope.launch {
                val inspected = ImageCompressor.inspectImages(context, uris)
                selectedImages = inspected
                applyAutoDetectedGrid(inspected)
                lastImportedArchiveBanner = null
                compressionResults.clear()
                readerDecryptedUriCache.clear()
                lastBatchReport = null
                completedCount = 0
                totalTaskCount = inspected.size
            }
        }
    }

    // 2. 压缩包导入启动器（工作台通用）
    var openArchiveInReaderFlag by remember { mutableStateOf(false) }
    val pickArchiveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            handleArchiveImport(uris, archivePassword, openArchiveInReaderFlag)
        }
    }

    // 3. SAF 目录选择器
    val pickOutputDirectoryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        if (treeUri != null) {
            runCatching {
                val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(treeUri, takeFlags)
            }
            customTreeUri = treeUri
            val docDir = DocumentFile.fromTreeUri(context, treeUri)
            customDirName = docDir?.name ?: treeUri.lastPathSegment ?: "自定义目录"
            Toast.makeText(context, "保存目录：$customDirName", Toast.LENGTH_SHORT).show()
        }
    }

    // 批量执行入口
    val triggerBatchExecution: () -> Unit = {
        activeLayer2Menu = LiquidGlassLayer2Menu.NONE
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        isProcessing = true
        completedCount = 0
        totalTaskCount = selectedImages.size
        compressionResults.clear()
        lastBatchReport = null

        val config = CompressionConfig(
            mode = currentMode,
            archiveSubMode = archiveSubMode,
            format = selectedFormat,
            quality = qualitySliderValue.roundToInt(),
            resolutionOption = selectedResolution,
            stripExifMetadata = stripExifMetadata,
            renameTemplate = selectedRenameTemplate,
            customRenamePrefix = customRenamePrefix,
            customTreeUri = customTreeUri,
            obfuscationKey = obfuscationKeyText,
            blockGridSize = selectedBlockGrid,
            autoTagBlockSizeInName = autoTagBlockSizeInName,
            packResultIntoArchive = packResultIntoArchive,
            archiveOutputFormat = selectedArchiveFormat,
            archiveCompressionLevel = selectedArchiveLevel,
            archivePassword = archivePassword,
            customArchiveBaseName = customArchiveName
        )

        activeTaskJob?.cancel()
        activeTaskJob = coroutineScope.launch {
            try {
                val report = ImageCompressor.processBatch(
                    context = context,
                    items = selectedImages,
                    config = config,
                    onProgress = { done, total, latest ->
                        coroutineScope.launch(Dispatchers.Main.immediate) {
                            completedCount = done
                            totalTaskCount = total
                            compressionResults[latest.source.uri] = latest
                        }
                    }
                )
                lastBatchReport = report
                isProcessing = false
                val successCount = report.itemResults.count { it.isSuccess }
                val toastMsg = if (report.archiveFileName != null) {
                    "已打包 ${report.archiveFileName} ($successCount 张)"
                } else {
                    "已完成 $successCount / ${report.itemResults.size} 张"
                }
                Toast.makeText(context, toastMsg, Toast.LENGTH_SHORT).show()
            } catch (_: CancellationException) {
                isProcessing = false
            } finally {
                isProcessing = false
                activeTaskJob = null
            }
        }
    }

    // 阅读器单页一键落盘保存到系统相册/自定义目录（支持直接保存口令实时解混淆后的高清图）
    val saveSingleReaderPage: (SelectedImageItem) -> Unit = { item ->
        val decryptedUri = if (readerLiveDecryptEnabled) readerDecryptedUriCache[item.uri] else null
        val uriToSave = decryptedUri ?: item.uri
        coroutineScope.launch {
            val saved = ImageCompressor.saveReaderPageToGallery(
                context = context,
                sourceUri = uriToSave,
                originalDisplayName = item.displayName,
                isDecryptedPreview = decryptedUri != null,
                customTreeUri = customTreeUri
            )
            if (saved != null) {
                Toast.makeText(context, "已保存至 ${saved.second}", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "保存单页失败", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // 一键分享当前处理结果
    val shareLatestOutputs: () -> Unit = {
        val archiveUri = lastBatchReport?.archiveSavedUri
        if (archiveUri != null) {
            ImageCompressor.shareOutputUris(
                context = context,
                uris = listOf(archiveUri),
                mimeType = selectedArchiveFormat.mimeType,
                chooserTitle = "分享归档压缩包"
            )
        } else {
            val outUris = selectedImages.mapNotNull { compressionResults[it.uri]?.outputUri }
            val fallbackUris = if (outUris.isNotEmpty()) outUris else selectedImages.map { it.uri }
            ImageCompressor.shareOutputUris(
                context = context,
                uris = fallbackUris,
                mimeType = "image/*",
                chooserTitle = "分享图片"
            )
        }
    }

    // 当二级液态玻璃面板或大图详情弹窗打开时，底层背景自动呈现 Apple 毛玻璃景深模糊
    val hasModalOrLayer2 = inspectedItem != null ||
        activeLayer2Menu != LiquidGlassLayer2Menu.NONE ||
        pendingPasswordArchiveUris.isNotEmpty()

    // 性能优化：移除逐帧变化的 animateDpAsState(blur)，改为静态半径触发，彻底消除二级液态玻璃弹出瞬间 GPU 每帧重建 RenderEffect 纹理导致的掉帧
    val continuousPagePositionProvider: () -> Float = {
        pagerState.currentPage + pagerState.currentPageOffsetFraction
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth >= 600.dp

        Box(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .then(
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && hasModalOrLayer2) {
                            Modifier.blur(12.dp)
                        } else {
                            Modifier
                        }
                    )
            ) {
                if (isWideScreen && !isImmersiveReader) {
                    FlClashNavigationRail(
                        currentMode = currentMode,
                        selectedCount = selectedImages.size,
                        isProcessing = isProcessing,
                        onSelectMode = animateToMode
                    )
                    VerticalDivider(
                        thickness = 1.dp,
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                    )
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        containerColor = MaterialTheme.colorScheme.background,
                        topBar = {
                            if (!isImmersiveReader) {
                                FlClashTopBar(
                                    currentMode = currentMode,
                                    selectedCount = selectedImages.size,
                                    customTreeUri = customTreeUri,
                                    useDynamicColor = useDynamicColor,
                                    isProcessing = isProcessing,
                                    onToggleDynamicColor = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        onToggleDynamicColor()
                                    },
                                    onPickDirectory = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        pickOutputDirectoryLauncher.launch(customTreeUri)
                                    },
                                    onClearQueue = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        selectedImages = emptyList()
                                        compressionResults.clear()
                                        readerDecryptedUriCache.clear()
                                        lastBatchReport = null
                                        lastImportedArchiveBanner = null
                                        completedCount = 0
                                        totalTaskCount = 0
                                    }
                                )
                            }
                        }
                    ) { innerPadding ->
                        HorizontalPager(
                            state = pagerState,
                            userScrollEnabled = !isImmersiveReader,
                            beyondBoundsPageCount = 1,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(if (isImmersiveReader) PaddingValues(0.dp) else innerPadding)
                        ) { pageIndex ->
                            val pageMode = ProcessMode.entries[pageIndex]

                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .graphicsLayer {
                                        // 性能优化：在绘制阶段（graphicsLayer）直接读取 currentPageOffsetFraction，滑动时 0 次组件重组
                                        val pageOffset = ((pagerState.currentPage - pageIndex) + pagerState.currentPageOffsetFraction)
                                        val absOffset = abs(pageOffset).coerceIn(0f, 1f)
                                        val pageScale = 1f - (absOffset * 0.08f)
                                        val pageAlpha = 1f - (absOffset * 0.28f)
                                        scaleX = pageScale
                                        scaleY = pageScale
                                        alpha = pageAlpha
                                    }
                            ) {
                                if (pageMode == ProcessMode.ARCHIVE_READER) {
                                    // ====== 独立压缩包图片阅读器工作空间 ======
                                    FlClashArchiveImageReaderView(
                                        images = selectedImages,
                                        decryptedUriMap = readerDecryptedUriCache,
                                        liveDecryptEnabled = readerLiveDecryptEnabled,
                                        readerLayoutMode = readerLayoutMode,
                                        isImmersive = isImmersiveReader,
                                        archiveBanner = lastImportedArchiveBanner,
                                        hasArchivePassword = archivePassword.isNotBlank(),
                                        isExtracting = isExtractingArchive,
                                        extractDoneCount = extractDoneCount,
                                        extractTotalCount = extractTotalCount,
                                        extractCurrentFile = extractCurrentFile,
                                        onCancelExtract = cancelRunningTask,
                                        onToggleImmersive = { isImmersiveReader = !isImmersiveReader },
                                        onToggleLayoutMode = {
                                            readerLayoutMode = if (readerLayoutMode == ReaderLayoutMode.VERTICAL_STRIP) {
                                                ReaderLayoutMode.HORIZONTAL_PAGER
                                            } else {
                                                ReaderLayoutMode.VERTICAL_STRIP
                                            }
                                        },
                                        onOpenReaderLayer2Menu = {
                                            activeLayer2Menu = LiquidGlassLayer2Menu.READER_CONTROL_PANEL
                                        },
                                        onPickArchiveToRead = {
                                            openArchiveInReaderFlag = true
                                            pickArchiveLauncher.launch(arrayOf("*/*"))
                                        },
                                        onPickImagesToRead = {
                                            pickMultipleImagesLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        },
                                        onSaveSingleImage = saveSingleReaderPage,
                                        onShareSingleImage = { item ->
                                            val uriToShare = if (readerLiveDecryptEnabled) {
                                                readerDecryptedUriCache[item.uri] ?: item.uri
                                            } else {
                                                item.uri
                                            }
                                            ImageCompressor.shareOutputUris(
                                                context = context,
                                                uris = listOf(uriToShare),
                                                mimeType = item.mimeType,
                                                chooserTitle = item.displayName
                                            )
                                        }
                                    )
                                } else {
                                    // ====== 压缩 / 混淆 / 还原 / 归档 四大处理工作空间 ======
                                    LazyColumn(
                                        modifier = Modifier.fillMaxSize(),
                                        contentPadding = PaddingValues(
                                            start = 16.dp,
                                            end = 16.dp,
                                            top = 12.dp,
                                            bottom = 152.dp
                                        ),
                                        verticalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        // 1. FlClash 2x2 Bento 仪表盘卡片
                                        item {
                                            FlClashBentoDashboardGrid(
                                                pageMode = pageMode,
                                                selectedImages = selectedImages,
                                                resultsMap = compressionResults,
                                                selectedFormat = selectedFormat,
                                                quality = qualitySliderValue.roundToInt(),
                                                selectedBlockGrid = selectedBlockGrid,
                                                selectedArchiveFormat = selectedArchiveFormat,
                                                customDirName = customDirName,
                                                isDirectArchiveActive = (pageMode == ProcessMode.ARCHIVE_HUB && archiveSubMode == ArchiveSubMode.PACK_TO_ARCHIVE) ||
                                                    (pageMode != ProcessMode.ARCHIVE_HUB && packResultIntoArchive),
                                                isProcessing = isProcessing,
                                                lastImportedArchiveBanner = lastImportedArchiveBanner,
                                                onPickImages = {
                                                    pickMultipleImagesLauncher.launch(
                                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                    )
                                                },
                                                onPickArchives = {
                                                    openArchiveInReaderFlag = false
                                                    pickArchiveLauncher.launch(arrayOf("*/*"))
                                                },
                                                onOpenReader = {
                                                    animateToMode(ProcessMode.ARCHIVE_READER)
                                                },
                                                onPickDirectory = {
                                                    pickOutputDirectoryLauncher.launch(customTreeUri)
                                                },
                                                onResetDirectory = {
                                                    customTreeUri = null
                                                    customDirName = null
                                                }
                                            )
                                        }

                                        // 2. 一级液态玻璃参数按钮矩阵（点击任意胶囊按钮展开第二层液态玻璃面板，整齐不堆叠）
                                        item {
                                            FlClashLiquidGlassTriggerMatrix(
                                                pageMode = pageMode,
                                                activeMenu = activeLayer2Menu,
                                                isProcessing = isProcessing,
                                                selectedFormat = selectedFormat,
                                                quality = qualitySliderValue.roundToInt(),
                                                selectedResolution = selectedResolution,
                                                stripExifMetadata = stripExifMetadata,
                                                selectedRenameTemplate = selectedRenameTemplate,
                                                obfuscationKeyText = obfuscationKeyText,
                                                selectedBlockGrid = selectedBlockGrid,
                                                autoTagBlockSizeInName = autoTagBlockSizeInName,
                                                packResultIntoArchive = packResultIntoArchive,
                                                archiveSubMode = archiveSubMode,
                                                selectedArchiveFormat = selectedArchiveFormat,
                                                selectedArchiveLevel = selectedArchiveLevel,
                                                archivePassword = archivePassword,
                                                onOpenMenu = { menu ->
                                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                    activeLayer2Menu = if (activeLayer2Menu == menu) {
                                                        LiquidGlassLayer2Menu.NONE
                                                    } else {
                                                        menu
                                                    }
                                                }
                                            )
                                        }

                                        // 3. 批处理完成统计与一键分享接力横幅
                                        if (compressionResults.isNotEmpty() || lastBatchReport?.archiveFileName != null) {
                                            item {
                                                BatchSummaryBanner(
                                                    selectedImages = selectedImages,
                                                    resultsMap = compressionResults,
                                                    batchReport = lastBatchReport,
                                                    onShareClick = shareLatestOutputs
                                                )
                                            }
                                        }

                                        // 4. 待处理图片队列
                                        if (selectedImages.isEmpty()) {
                                            item {
                                                EmptyWorkbenchCard(
                                                    currentMode = pageMode,
                                                    isExtracting = isExtractingArchive,
                                                    extractDoneCount = extractDoneCount,
                                                    extractTotalCount = extractTotalCount,
                                                    extractCurrentFile = extractCurrentFile,
                                                    onCancelExtract = cancelRunningTask,
                                                    onPickImages = {
                                                        pickMultipleImagesLauncher.launch(
                                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                        )
                                                    },
                                                    onPickArchives = {
                                                        openArchiveInReaderFlag = false
                                                        pickArchiveLauncher.launch(arrayOf("*/*"))
                                                    }
                                                )
                                            }
                                        } else {
                                            item {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 4.dp, vertical = 2.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = "队列 (${selectedImages.size})",
                                                        style = MaterialTheme.typography.titleSmall,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Text(
                                                        text = "点击卡片拉帘对比",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.primary
                                                    )
                                                }
                                            }

                                            items(
                                                items = selectedImages,
                                                key = { it.uri.toString() }
                                            ) { item ->
                                                ImageComparisonItemCard(
                                                    item = item,
                                                    result = compressionResults[item.uri],
                                                    isProcessing = isProcessing,
                                                    onCardClick = { inspectedItem = item },
                                                    onRemoveItem = {
                                                        selectedImages = selectedImages.filterNot { it.uri == item.uri }
                                                        compressionResults.remove(item.uri)
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // ====== 底部：右下角液态玻璃双层启动按钮 + 悬浮果冻胶囊导航栏 ======
                    if (!isImmersiveReader) {
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            horizontalAlignment = Alignment.End,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (currentMode != ProcessMode.ARCHIVE_READER) {
                                FlClashLiquidGlassFloatingBarActions(
                                    currentMode = currentMode,
                                    archiveSubMode = archiveSubMode,
                                    packResultIntoArchive = packResultIntoArchive,
                                    archiveFormat = selectedArchiveFormat,
                                    selectedCount = selectedImages.size,
                                    isProcessing = isProcessing || isExtractingArchive,
                                    completedCount = if (isExtractingArchive) extractDoneCount else completedCount,
                                    totalTaskCount = if (isExtractingArchive) extractTotalCount else totalTaskCount,
                                    obfuscationKeyText = obfuscationKeyText,
                                    isQuickHubExpanded = activeLayer2Menu == LiquidGlassLayer2Menu.FAB_QUICK_HUB,
                                    onToggleQuickHub = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        activeLayer2Menu = if (activeLayer2Menu == LiquidGlassLayer2Menu.FAB_QUICK_HUB) {
                                            LiquidGlassLayer2Menu.NONE
                                        } else {
                                            LiquidGlassLayer2Menu.FAB_QUICK_HUB
                                        }
                                    },
                                    onMissingKeyOpenSheet = {
                                        activeLayer2Menu = LiquidGlassLayer2Menu.OBFUSCATION_KEY
                                    },
                                    onStartClick = triggerBatchExecution,
                                    onCancelClick = cancelRunningTask
                                )
                            }

                            if (!isWideScreen) {
                                FlClashFloatingLiquidDockBar(
                                    continuousPagePositionProvider = continuousPagePositionProvider,
                                    currentMode = currentMode,
                                    isProcessing = isProcessing,
                                    onSelectMode = animateToMode
                                )
                            }
                        }
                    }
                }
            }

            // ====== Apple 液态玻璃第二层弹出面板（点击任意空白处自动缩回按钮） ======
            LiquidGlassLayer2PopoverHost(
                activeMenu = activeLayer2Menu,
                onDismiss = {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    activeLayer2Menu = LiquidGlassLayer2Menu.NONE
                },
                selectedFormat = selectedFormat,
                onSelectFormat = { selectedFormat = it },
                qualitySliderValue = qualitySliderValue,
                onQualityChange = { qualitySliderValue = it },
                selectedResolution = selectedResolution,
                onSelectResolution = { selectedResolution = it },
                stripExifMetadata = stripExifMetadata,
                onToggleStripExif = { stripExifMetadata = it },
                selectedRenameTemplate = selectedRenameTemplate,
                onSelectRenameTemplate = { selectedRenameTemplate = it },
                customRenamePrefix = customRenamePrefix,
                onCustomRenamePrefixChange = { customRenamePrefix = it },
                obfuscationKeyText = obfuscationKeyText,
                onKeyTextChange = { obfuscationKeyText = it },
                selectedBlockGrid = selectedBlockGrid,
                onSelectBlockGrid = { selectedBlockGrid = it },
                autoTagBlockSizeInName = autoTagBlockSizeInName,
                onToggleAutoTagBlock = { autoTagBlockSizeInName = it },
                packResultIntoArchive = packResultIntoArchive,
                onTogglePackResultIntoArchive = { packResultIntoArchive = it },
                archiveSubMode = archiveSubMode,
                onSelectArchiveSubMode = { archiveSubMode = it },
                selectedArchiveFormat = selectedArchiveFormat,
                onSelectArchiveFormat = { selectedArchiveFormat = it },
                selectedArchiveLevel = selectedArchiveLevel,
                onSelectArchiveLevel = { selectedArchiveLevel = it },
                archivePassword = archivePassword,
                onArchivePasswordChange = { archivePassword = it },
                customArchiveName = customArchiveName,
                onCustomArchiveNameChange = { customArchiveName = it },
                readerLayoutMode = readerLayoutMode,
                onSelectReaderLayoutMode = { readerLayoutMode = it },
                readerLiveDecryptEnabled = readerLiveDecryptEnabled,
                onToggleReaderLiveDecrypt = { readerLiveDecryptEnabled = it },
                hasOutputsToShare = compressionResults.isNotEmpty() || lastBatchReport?.archiveSavedUri != null || selectedImages.isNotEmpty(),
                onQuickPickImages = {
                    activeLayer2Menu = LiquidGlassLayer2Menu.NONE
                    pickMultipleImagesLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                onQuickImportArchive = {
                    activeLayer2Menu = LiquidGlassLayer2Menu.NONE
                    openArchiveInReaderFlag = false
                    pickArchiveLauncher.launch(arrayOf("*/*"))
                },
                onQuickOpenArchiveInReader = {
                    activeLayer2Menu = LiquidGlassLayer2Menu.NONE
                    openArchiveInReaderFlag = true
                    pickArchiveLauncher.launch(arrayOf("*/*"))
                },
                onQuickShareOutputs = {
                    activeLayer2Menu = LiquidGlassLayer2Menu.NONE
                    shareLatestOutputs()
                },
                onQuickPickDirectory = {
                    activeLayer2Menu = LiquidGlassLayer2Menu.NONE
                    pickOutputDirectoryLauncher.launch(customTreeUri)
                },
                onQuickClearQueue = {
                    activeLayer2Menu = LiquidGlassLayer2Menu.NONE
                    selectedImages = emptyList()
                    compressionResults.clear()
                    readerDecryptedUriCache.clear()
                    lastBatchReport = null
                },
                onSwitchMode = animateToMode
            )

            // ====== 加密压缩包密码解锁液态玻璃弹窗 ======
            AnimatedVisibility(
                visible = pendingPasswordArchiveUris.isNotEmpty(),
                enter = fadeIn(spring(stiffness = JELLY_STIFFNESS)) +
                    scaleIn(initialScale = 0.76f, animationSpec = spring(dampingRatio = JELLY_DAMPING, stiffness = JELLY_STIFFNESS)),
                exit = fadeOut(spring(stiffness = JELLY_STIFFNESS)) +
                    scaleOut(targetScale = 0.78f, animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = 420f))
            ) {
                ArchivePasswordUnlockModal(
                    archiveNames = pendingPasswordArchiveNames,
                    passwordInput = unlockPasswordInput,
                    errorText = unlockPasswordError,
                    onPasswordChange = {
                        unlockPasswordInput = it
                        unlockPasswordError = null
                    },
                    onDismiss = {
                        pendingPasswordArchiveUris = emptyList()
                        unlockPasswordError = null
                    },
                    onConfirmUnlock = {
                        if (unlockPasswordInput.isBlank()) {
                            unlockPasswordError = "请输入压缩包密码"
                        } else {
                            archivePassword = unlockPasswordInput
                            handleArchiveImport(
                                pendingPasswordArchiveUris,
                                unlockPasswordInput,
                                jumpToReaderAfterUnlock
                            )
                        }
                    }
                )
            }

            // ====== Container Transform 卡片展开大图详情视图（含拉帘对比 Before/After Slider） ======
            AnimatedVisibility(
                visible = inspectedItem != null,
                enter = fadeIn(animationSpec = spring(stiffness = JELLY_STIFFNESS)) +
                    scaleIn(
                        initialScale = 0.78f,
                        animationSpec = spring(
                            dampingRatio = JELLY_DAMPING,
                            stiffness = JELLY_STIFFNESS
                        )
                    ),
                exit = fadeOut(animationSpec = spring(stiffness = JELLY_STIFFNESS)) +
                    scaleOut(
                        targetScale = 0.80f,
                        animationSpec = spring(
                            dampingRatio = PAGE_SPRING_DAMPING,
                            stiffness = 450f
                        )
                    )
            ) {
                val activeItem = inspectedItem
                if (activeItem != null) {
                    ImageDetailContainerTransformModal(
                        item = activeItem,
                        result = compressionResults[activeItem.uri],
                        onDismiss = { inspectedItem = null },
                        onShare = {
                            val targetUri = compressionResults[activeItem.uri]?.outputUri ?: activeItem.uri
                            ImageCompressor.shareOutputUris(
                                context = context,
                                uris = listOf(targetUri),
                                mimeType = "image/*",
                                chooserTitle = activeItem.displayName
                            )
                        },
                        onRemove = {
                            selectedImages = selectedImages.filterNot { it.uri == activeItem.uri }
                            compressionResults.remove(activeItem.uri)
                            inspectedItem = null
                        }
                    )
                }
            }
        }
    }
}

/**
 * 一级液态玻璃参数按钮矩阵：
 * 将原本堆叠在卡片里的多行选项收纳为整齐的 2x2 液态玻璃胶囊按钮，点击任意按钮以果冻弹簧展开对应的二级玻璃菜单
 */
@Composable
private fun FlClashLiquidGlassTriggerMatrix(
    pageMode: ProcessMode,
    activeMenu: LiquidGlassLayer2Menu,
    isProcessing: Boolean,
    selectedFormat: OutputFormat,
    quality: Int,
    selectedResolution: ResolutionOption,
    stripExifMetadata: Boolean,
    selectedRenameTemplate: RenameTemplate,
    obfuscationKeyText: String,
    selectedBlockGrid: BlockGridSize,
    autoTagBlockSizeInName: Boolean,
    packResultIntoArchive: Boolean,
    archiveSubMode: ArchiveSubMode,
    selectedArchiveFormat: ArchiveOutputFormat,
    selectedArchiveLevel: ArchiveCompressionLevel,
    archivePassword: String,
    onOpenMenu: (LiquidGlassLayer2Menu) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        when (pageMode) {
            ProcessMode.COMPRESS_TRANSCODE -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    LiquidGlassTriggerTile(
                        icon = Icons.Default.Transform,
                        title = "输出格式",
                        valueText = selectedFormat.shortLabel,
                        isActive = activeMenu == LiquidGlassLayer2Menu.FORMAT_PICKER,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.FORMAT_PICKER) }
                    )
                    LiquidGlassTriggerTile(
                        icon = Icons.Default.Tune,
                        title = "画质与尺寸",
                        valueText = if (selectedFormat.supportsQualitySlider) {
                            "$quality% · ${selectedResolution.label}"
                        } else {
                            "无损 · ${selectedResolution.label}"
                        },
                        isActive = activeMenu == LiquidGlassLayer2Menu.QUALITY_SLIDER,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.QUALITY_SLIDER) }
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    LiquidGlassTriggerTile(
                        icon = Icons.Default.PrivacyTip,
                        title = "隐私与命名",
                        valueText = "${if (stripExifMetadata) "抹除EXIF" else "保留EXIF"} · ${selectedRenameTemplate.shortLabel}",
                        isActive = activeMenu == LiquidGlassLayer2Menu.PRIVACY_AND_RENAME,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.PRIVACY_AND_RENAME) }
                    )
                    LiquidGlassTriggerTile(
                        icon = Icons.Default.Archive,
                        title = "直压归档",
                        valueText = if (packResultIntoArchive) {
                            "${selectedArchiveFormat.shortLabel}${if (archivePassword.isNotBlank()) " · 加密" else ""}"
                        } else {
                            "不打包 (单图)"
                        },
                        isActive = activeMenu == LiquidGlassLayer2Menu.DIRECT_ARCHIVE_PACK,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.DIRECT_ARCHIVE_PACK) }
                    )
                }
            }

            ProcessMode.OBFUSCATE_ENCRYPT, ProcessMode.DEOBFUSCATE_RESTORE -> {
                val isEncrypt = pageMode == ProcessMode.OBFUSCATE_ENCRYPT
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    LiquidGlassTriggerTile(
                        icon = Icons.Default.Key,
                        title = if (isEncrypt) "加密口令" else "还原口令",
                        valueText = if (obfuscationKeyText.isBlank()) "点击输入口令" else "已设 (${obfuscationKeyText.length}位)",
                        isActive = activeMenu == LiquidGlassLayer2Menu.OBFUSCATION_KEY,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.OBFUSCATION_KEY) }
                    )
                    LiquidGlassTriggerTile(
                        icon = Icons.Default.GridView,
                        title = "色块粒度",
                        valueText = "${selectedBlockGrid.shortLabel}${if (autoTagBlockSizeInName) " · 自动标记" else ""}",
                        isActive = activeMenu == LiquidGlassLayer2Menu.BLOCK_GRID_PICKER,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.BLOCK_GRID_PICKER) }
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    LiquidGlassTriggerTile(
                        icon = Icons.Default.DriveFileRenameOutline,
                        title = "命名与格式",
                        valueText = "${selectedRenameTemplate.shortLabel} · ${if (isEncrypt) "PNG" else selectedFormat.shortLabel}",
                        isActive = activeMenu == LiquidGlassLayer2Menu.PRIVACY_AND_RENAME,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.PRIVACY_AND_RENAME) }
                    )
                    LiquidGlassTriggerTile(
                        icon = Icons.Default.Lock,
                        title = "直压加密包",
                        valueText = if (packResultIntoArchive) {
                            "${selectedArchiveFormat.shortLabel}${if (archivePassword.isNotBlank()) " · 密码保护" else ""}"
                        } else {
                            "不打包 (单图)"
                        },
                        isActive = activeMenu == LiquidGlassLayer2Menu.DIRECT_ARCHIVE_PACK,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.DIRECT_ARCHIVE_PACK) }
                    )
                }
            }

            ProcessMode.ARCHIVE_HUB -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    LiquidGlassTriggerTile(
                        icon = if (archiveSubMode == ArchiveSubMode.PACK_TO_ARCHIVE) Icons.Default.Archive else Icons.Default.Unarchive,
                        title = "归档动作",
                        valueText = archiveSubMode.label,
                        isActive = activeMenu == LiquidGlassLayer2Menu.ARCHIVE_SUBMODE,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.ARCHIVE_SUBMODE) }
                    )
                    LiquidGlassTriggerTile(
                        icon = Icons.Default.FolderZip,
                        title = "格式与等级",
                        valueText = "${selectedArchiveFormat.shortLabel} · ${selectedArchiveLevel.label}",
                        isActive = activeMenu == LiquidGlassLayer2Menu.ARCHIVE_FORMAT_LEVEL,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.ARCHIVE_FORMAT_LEVEL) }
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    LiquidGlassTriggerTile(
                        icon = Icons.Default.Password,
                        title = "压缩包密码",
                        valueText = if (archivePassword.isBlank()) "无密码 (点击设置)" else "AES 密码已设",
                        isActive = activeMenu == LiquidGlassLayer2Menu.ARCHIVE_PASSWORD_NAMING,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.ARCHIVE_PASSWORD_NAMING) }
                    )
                    LiquidGlassTriggerTile(
                        icon = Icons.Default.DriveFileRenameOutline,
                        title = "包内重命名",
                        valueText = selectedRenameTemplate.shortLabel,
                        isActive = activeMenu == LiquidGlassLayer2Menu.PRIVACY_AND_RENAME,
                        enabled = !isProcessing,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenMenu(LiquidGlassLayer2Menu.PRIVACY_AND_RENAME) }
                    )
                }
            }

            ProcessMode.ARCHIVE_READER -> Unit
        }
    }
}

/**
 * Apple 液态玻璃第二层弹出菜单宿主：
 * - 点击一级按钮时，面板以 0.44f 低阻尼果冻弹簧放大弹出
 * - 点击面板外部的任意空白区域（透明模糊遮罩层），面板自动平滑缩回按钮本身
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun LiquidGlassLayer2PopoverHost(
    activeMenu: LiquidGlassLayer2Menu,
    onDismiss: () -> Unit,
    selectedFormat: OutputFormat,
    onSelectFormat: (OutputFormat) -> Unit,
    qualitySliderValue: Float,
    onQualityChange: (Float) -> Unit,
    selectedResolution: ResolutionOption,
    onSelectResolution: (ResolutionOption) -> Unit,
    stripExifMetadata: Boolean,
    onToggleStripExif: (Boolean) -> Unit,
    selectedRenameTemplate: RenameTemplate,
    onSelectRenameTemplate: (RenameTemplate) -> Unit,
    customRenamePrefix: String,
    onCustomRenamePrefixChange: (String) -> Unit,
    obfuscationKeyText: String,
    onKeyTextChange: (String) -> Unit,
    selectedBlockGrid: BlockGridSize,
    onSelectBlockGrid: (BlockGridSize) -> Unit,
    autoTagBlockSizeInName: Boolean,
    onToggleAutoTagBlock: (Boolean) -> Unit,
    packResultIntoArchive: Boolean,
    onTogglePackResultIntoArchive: (Boolean) -> Unit,
    archiveSubMode: ArchiveSubMode,
    onSelectArchiveSubMode: (ArchiveSubMode) -> Unit,
    selectedArchiveFormat: ArchiveOutputFormat,
    onSelectArchiveFormat: (ArchiveOutputFormat) -> Unit,
    selectedArchiveLevel: ArchiveCompressionLevel,
    onSelectArchiveLevel: (ArchiveCompressionLevel) -> Unit,
    archivePassword: String,
    onArchivePasswordChange: (String) -> Unit,
    customArchiveName: String,
    onCustomArchiveNameChange: (String) -> Unit,
    readerLayoutMode: ReaderLayoutMode,
    onSelectReaderLayoutMode: (ReaderLayoutMode) -> Unit,
    readerLiveDecryptEnabled: Boolean,
    onToggleReaderLiveDecrypt: (Boolean) -> Unit,
    hasOutputsToShare: Boolean,
    onQuickPickImages: () -> Unit,
    onQuickImportArchive: () -> Unit,
    onQuickOpenArchiveInReader: () -> Unit,
    onQuickShareOutputs: () -> Unit,
    onQuickPickDirectory: () -> Unit,
    onQuickClearQueue: () -> Unit,
    onSwitchMode: (ProcessMode) -> Unit
) {
    val isFabMenu = activeMenu == LiquidGlassLayer2Menu.FAB_QUICK_HUB
    val origin = if (isFabMenu) TransformOrigin(0.9f, 0.9f) else TransformOrigin(0.5f, 0.35f)

    AnimatedVisibility(
        visible = activeMenu != LiquidGlassLayer2Menu.NONE,
        enter = fadeIn(animationSpec = spring(stiffness = JELLY_STIFFNESS)) +
            scaleIn(
                initialScale = 0.68f,
                transformOrigin = origin,
                animationSpec = spring(dampingRatio = JELLY_DAMPING, stiffness = JELLY_STIFFNESS)
            ),
        exit = fadeOut(animationSpec = spring(stiffness = 460f)) +
            scaleOut(
                targetScale = 0.68f,
                transformOrigin = origin,
                animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = 460f)
            )
    ) {
        BackHandler(onBack = onDismiss)

        // 全屏空白区域点击拦截层：点击任意空白处立即将二级菜单缩回一级按钮
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.28f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss
                )
                .padding(horizontal = 20.dp, vertical = 88.dp),
            contentAlignment = if (isFabMenu) Alignment.BottomEnd else Alignment.Center
        ) {
            LiquidGlassSurfaceCard(
                cornerRadius = 26.dp,
                isHighlighted = true,
                containerColor = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.96f),
                modifier = Modifier
                    .widthIn(max = if (isFabMenu) 290.dp else 480.dp)
                    .fillMaxWidth()
                    .shadow(
                        elevation = 16.dp,
                        shape = RoundedCornerShape(26.dp),
                        ambientColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.25f),
                        spotColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.30f)
                    )
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {}
                    )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    when (activeMenu) {
                        LiquidGlassLayer2Menu.FORMAT_PICKER -> {
                            Layer2Header("选择输出格式", "点击空白处自动收起", onDismiss)
                            FlClashSegmentedRow(
                                items = OutputFormat.entries,
                                selectedItem = selectedFormat,
                                itemLabel = { it.shortLabel },
                                onItemSelected = {
                                    onSelectFormat(it)
                                    onDismiss()
                                }
                            )
                            Text(
                                text = selectedFormat.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        LiquidGlassLayer2Menu.QUALITY_SLIDER -> {
                            Layer2Header("画质与尺寸缩放", "点击空白处自动收起", onDismiss)
                            if (selectedFormat.supportsQualitySlider) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("输出画质", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        "${qualitySliderValue.roundToInt()}%",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Slider(
                                    value = qualitySliderValue,
                                    onValueChange = onQualityChange,
                                    valueRange = 10f..100f,
                                    steps = 17
                                )
                            }
                            Text("最长边尺寸限制", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            FlClashSegmentedRow(
                                items = ResolutionOption.entries,
                                selectedItem = selectedResolution,
                                itemLabel = { it.label },
                                onItemSelected = onSelectResolution
                            )
                        }

                        LiquidGlassLayer2Menu.PRIVACY_AND_RENAME -> {
                            Layer2Header("隐私抹除与批量命名", "点击空白处自动收起", onDismiss)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onToggleStripExif(!stripExifMetadata) }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("抹除 EXIF 拍摄与定位隐私", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                    Text("清除 GPS 经纬度与设备信息", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(checked = stripExifMetadata, onCheckedChange = onToggleStripExif)
                            }

                            HorizontalDivider(thickness = 1.dp, color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                            Text("批量重命名模板", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            FlClashSegmentedRow(
                                items = RenameTemplate.entries,
                                selectedItem = selectedRenameTemplate,
                                itemLabel = { it.shortLabel },
                                onItemSelected = onSelectRenameTemplate
                            )

                            if (selectedRenameTemplate == RenameTemplate.PREFIX_INDEX) {
                                OutlinedTextField(
                                    value = customRenamePrefix,
                                    onValueChange = onCustomRenamePrefixChange,
                                    label = { Text("自定义前缀") },
                                    placeholder = { Text("例如：Manga") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            Text("还原导出格式", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            FlClashSegmentedRow(
                                items = OutputFormat.entries,
                                selectedItem = selectedFormat,
                                itemLabel = { it.shortLabel },
                                onItemSelected = onSelectFormat
                            )
                        }

                        LiquidGlassLayer2Menu.DIRECT_ARCHIVE_PACK -> {
                            Layer2Header("直接打入压缩包", "支持 AES-256 加密", onDismiss)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onTogglePackResultIntoArchive(!packResultIntoArchive) }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("处理后直接压入单个压缩包", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                    Text("不在相册散存单张图", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(checked = packResultIntoArchive, onCheckedChange = onTogglePackResultIntoArchive)
                            }

                            if (packResultIntoArchive) {
                                ArchivePackConfigControls(
                                    selectedArchiveFormat = selectedArchiveFormat,
                                    onSelectArchiveFormat = onSelectArchiveFormat,
                                    selectedArchiveLevel = selectedArchiveLevel,
                                    onSelectArchiveLevel = onSelectArchiveLevel,
                                    archivePassword = archivePassword,
                                    onArchivePasswordChange = onArchivePasswordChange,
                                    customArchiveName = customArchiveName,
                                    onCustomArchiveNameChange = onCustomArchiveNameChange
                                )
                            }
                        }

                        LiquidGlassLayer2Menu.OBFUSCATION_KEY -> {
                            Layer2Header("设置文字加密/还原口令", "相同口令可 100% 无损还原", onDismiss)
                            OutlinedTextField(
                                value = obfuscationKeyText,
                                onValueChange = onKeyTextChange,
                                label = { Text("文字口令") },
                                placeholder = { Text("输入任意文字、数字或短句") },
                                leadingIcon = { Icon(Icons.Default.Key, contentDescription = null) },
                                trailingIcon = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        if (obfuscationKeyText.isNotEmpty()) {
                                            IconButton(onClick = { onKeyTextChange("") }) {
                                                Icon(Icons.Default.Clear, contentDescription = "清空")
                                            }
                                        }
                                        IconButton(
                                            onClick = {
                                                onKeyTextChange("KEY_" + Random.nextInt(100000, 999999))
                                            }
                                        ) {
                                            Icon(Icons.Default.Casino, contentDescription = "随机生成")
                                        }
                                    }
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        LiquidGlassLayer2Menu.BLOCK_GRID_PICKER -> {
                            Layer2Header("色块粒度与自动标记", "点击空白处自动收起", onDismiss)
                            FlClashSegmentedRow(
                                items = BlockGridSize.entries,
                                selectedItem = selectedBlockGrid,
                                itemLabel = { it.shortLabel },
                                onItemSelected = onSelectBlockGrid
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onToggleAutoTagBlock(!autoTagBlockSizeInName) }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("文件名自动标记粒度 (如 OBF_B16_)", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                    Text("还原时自动识别粒度，无需手选", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(checked = autoTagBlockSizeInName, onCheckedChange = onToggleAutoTagBlock)
                            }
                        }

                        LiquidGlassLayer2Menu.ARCHIVE_SUBMODE -> {
                            Layer2Header("归档工作模式", "点击空白处自动收起", onDismiss)
                            FlClashSegmentedRow(
                                items = ArchiveSubMode.entries,
                                selectedItem = archiveSubMode,
                                itemLabel = { it.label },
                                onItemSelected = {
                                    onSelectArchiveSubMode(it)
                                    onDismiss()
                                }
                            )
                            if (archiveSubMode == ArchiveSubMode.EXTRACT_FROM_ARCHIVE) {
                                Text("提取图片后一键流转：", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FilledTonalButton(
                                        onClick = { onSwitchMode(ProcessMode.COMPRESS_TRANSCODE) },
                                        modifier = Modifier.weight(1f)
                                    ) { Text("去压缩") }
                                    FilledTonalButton(
                                        onClick = { onSwitchMode(ProcessMode.OBFUSCATE_ENCRYPT) },
                                        modifier = Modifier.weight(1f)
                                    ) { Text("去混淆") }
                                    FilledTonalButton(
                                        onClick = { onSwitchMode(ProcessMode.ARCHIVE_READER) },
                                        modifier = Modifier.weight(1f)
                                    ) { Text("去阅读") }
                                }
                            }
                        }

                        LiquidGlassLayer2Menu.ARCHIVE_FORMAT_LEVEL -> {
                            Layer2Header("归档格式与压缩率", "点击空白处自动收起", onDismiss)
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                ArchiveOutputFormat.entries.forEach { format ->
                                    FilterChip(
                                        selected = selectedArchiveFormat == format,
                                        onClick = { onSelectArchiveFormat(format) },
                                        label = { Text(format.shortLabel) },
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                }
                            }
                            if (selectedArchiveFormat == ArchiveOutputFormat.ZIP ||
                                selectedArchiveFormat == ArchiveOutputFormat.CBZ
                            ) {
                                Text("压缩率等级", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                FlClashSegmentedRow(
                                    items = ArchiveCompressionLevel.entries,
                                    selectedItem = selectedArchiveLevel,
                                    itemLabel = { it.label },
                                    onItemSelected = onSelectArchiveLevel
                                )
                            }
                        }

                        LiquidGlassLayer2Menu.ARCHIVE_PASSWORD_NAMING -> {
                            Layer2Header("归档密码与包名", "支持 ZIP/CBZ AES-256 加密及 7Z/RAR 解锁", onDismiss)
                            OutlinedTextField(
                                value = archivePassword,
                                onValueChange = onArchivePasswordChange,
                                label = { Text("压缩包密码（打包加密 / 解压解锁通用）") },
                                placeholder = { Text("留空则不设密码") },
                                leadingIcon = { Icon(Icons.Default.Password, contentDescription = null) },
                                trailingIcon = {
                                    if (archivePassword.isNotEmpty()) {
                                        IconButton(onClick = { onArchivePasswordChange("") }) {
                                            Icon(Icons.Default.Clear, contentDescription = "清除")
                                        }
                                    }
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = customArchiveName,
                                onValueChange = onCustomArchiveNameChange,
                                label = { Text("归档包名称（选填）") },
                                placeholder = { Text("留空自动按时间命名") },
                                leadingIcon = { Icon(Icons.Default.Archive, contentDescription = null) },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        LiquidGlassLayer2Menu.FAB_QUICK_HUB -> {
                            Layer2Header("快捷操作中心", "点击空白处自动缩回按钮", onDismiss)
                            LiquidGlassMenuActionRow(
                                icon = Icons.Default.AddPhotoAlternate,
                                title = "从相册选择图片",
                                onClick = onQuickPickImages
                            )
                            LiquidGlassMenuActionRow(
                                icon = Icons.Default.FolderZip,
                                title = "导入压缩包 (支持密码)",
                                onClick = onQuickImportArchive
                            )
                            LiquidGlassMenuActionRow(
                                icon = Icons.Default.AutoStories,
                                title = "打开压缩包阅读器",
                                onClick = onQuickOpenArchiveInReader
                            )
                            if (hasOutputsToShare) {
                                LiquidGlassMenuActionRow(
                                    icon = Icons.Default.Share,
                                    title = "一键向外分享结果",
                                    onClick = onQuickShareOutputs
                                )
                            }
                            LiquidGlassMenuActionRow(
                                icon = Icons.Outlined.FolderOpen,
                                title = "更改输出保存目录",
                                onClick = onQuickPickDirectory
                            )
                            if (hasOutputsToShare) {
                                LiquidGlassMenuActionRow(
                                    icon = Icons.Outlined.DeleteSweep,
                                    title = "清空当前队列",
                                    onClick = onQuickClearQueue
                                )
                            }
                        }

                        LiquidGlassLayer2Menu.READER_CONTROL_PANEL -> {
                            Layer2Header("阅读器液态玻璃控制", "点击空白处收起", onDismiss)
                            Text("翻页阅读模式", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            FlClashSegmentedRow(
                                items = ReaderLayoutMode.entries,
                                selectedItem = readerLayoutMode,
                                itemLabel = { it.label },
                                onItemSelected = onSelectReaderLayoutMode
                            )

                            OutlinedTextField(
                                value = archivePassword,
                                onValueChange = onArchivePasswordChange,
                                label = { Text("加密压缩包解锁密码") },
                                placeholder = { Text("若压缩包有密码请在此输入") },
                                leadingIcon = { Icon(Icons.Default.Password, contentDescription = null) },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            HorizontalDivider(thickness = 1.dp, color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onToggleReaderLiveDecrypt(!readerLiveDecryptEnabled) }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("口令实时还原色块图", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                    Text("阅读被色块混淆的图集时自动解密显示", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(checked = readerLiveDecryptEnabled, onCheckedChange = onToggleReaderLiveDecrypt)
                            }

                            if (readerLiveDecryptEnabled) {
                                OutlinedTextField(
                                    value = obfuscationKeyText,
                                    onValueChange = onKeyTextChange,
                                    label = { Text("色块还原口令") },
                                    placeholder = { Text("输入加密时的文字口令") },
                                    leadingIcon = { Icon(Icons.Default.Key, contentDescription = null) },
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }

                        LiquidGlassLayer2Menu.NONE -> Unit
                    }
                }
            }
        }
    }
}

@Composable
private fun Layer2Header(
    title: String,
    subtitle: String,
    onClose: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
        }
        IconButton(onClick = onClose, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Close, contentDescription = "收起", modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun LiquidGlassMenuActionRow(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .flClashJellyClick(
                pressScale = 0.92f,
                shape = RoundedCornerShape(14.dp),
                onClick = onClick
            )
            .background(MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.85f))
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp)
        )
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ArchivePackConfigControls(
    selectedArchiveFormat: ArchiveOutputFormat,
    onSelectArchiveFormat: (ArchiveOutputFormat) -> Unit,
    selectedArchiveLevel: ArchiveCompressionLevel,
    onSelectArchiveLevel: (ArchiveCompressionLevel) -> Unit,
    archivePassword: String,
    onArchivePasswordChange: (String) -> Unit,
    customArchiveName: String,
    onCustomArchiveNameChange: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            ArchiveOutputFormat.entries.forEach { format ->
                FilterChip(
                    selected = selectedArchiveFormat == format,
                    onClick = { onSelectArchiveFormat(format) },
                    label = { Text(format.shortLabel) },
                    shape = RoundedCornerShape(10.dp)
                )
            }
        }
        if (selectedArchiveFormat == ArchiveOutputFormat.ZIP ||
            selectedArchiveFormat == ArchiveOutputFormat.CBZ
        ) {
            FlClashSegmentedRow(
                items = ArchiveCompressionLevel.entries,
                selectedItem = selectedArchiveLevel,
                itemLabel = { it.label },
                onItemSelected = onSelectArchiveLevel
            )
            OutlinedTextField(
                value = archivePassword,
                onValueChange = onArchivePasswordChange,
                label = { Text("AES-256 归档密码（选填）") },
                placeholder = { Text("留空则不加密") },
                leadingIcon = { Icon(Icons.Default.Password, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
        }
        OutlinedTextField(
            value = customArchiveName,
            onValueChange = onCustomArchiveNameChange,
            label = { Text("归档包名称（选填）") },
            placeholder = { Text("留空按时间命名") },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/**
 * 独立压缩包图片阅读器视图（支持加密压缩包密码解锁、条漫连读 / 左右翻页、手势双指缩放、实时色块解密阅读）
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FlClashArchiveImageReaderView(
    images: List<SelectedImageItem>,
    decryptedUriMap: Map<Uri, Uri>,
    liveDecryptEnabled: Boolean,
    readerLayoutMode: ReaderLayoutMode,
    isImmersive: Boolean,
    archiveBanner: String?,
    hasArchivePassword: Boolean,
    isExtracting: Boolean,
    extractDoneCount: Int,
    extractTotalCount: Int,
    extractCurrentFile: String,
    onCancelExtract: () -> Unit,
    onToggleImmersive: () -> Unit,
    onToggleLayoutMode: () -> Unit,
    onOpenReaderLayer2Menu: () -> Unit,
    onPickArchiveToRead: () -> Unit,
    onPickImagesToRead: () -> Unit,
    onSaveSingleImage: (SelectedImageItem) -> Unit,
    onShareSingleImage: (SelectedImageItem) -> Unit
) {
    val context = LocalContext.current
    val extractProgressTarget = if (extractTotalCount > 0) {
        (extractDoneCount.toFloat() / extractTotalCount.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }
    val animatedExtractProgress by animateFloatAsState(
        targetValue = extractProgressTarget,
        animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = JELLY_STIFFNESS),
        label = "ReaderExtractProgress"
    )

    if (images.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            LiquidGlassSurfaceCard(
                cornerRadius = 24.dp,
                isHighlighted = isExtracting,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(64.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (isExtracting) Icons.Default.Unarchive else Icons.Default.AutoStories,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(30.dp)
                            )
                        }
                    }
                    Text(
                        text = if (isExtracting) "正在解压压缩包..." else "压缩包图片阅读器",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    if (isExtracting) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = when {
                                        extractTotalCount > 0 -> "已解压 $extractDoneCount / $extractTotalCount 张"
                                        extractDoneCount > 0 -> "已解压 $extractDoneCount 张"
                                        else -> "正在读取压缩包索引..."
                                    },
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                if (extractTotalCount > 0) {
                                    Text(
                                        text = "${(animatedExtractProgress * 100).roundToInt()}%",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                            if (extractTotalCount > 0) {
                                LinearProgressIndicator(
                                    progress = { animatedExtractProgress },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp)),
                                    color = MaterialTheme.colorScheme.primary,
                                    trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                                )
                            } else {
                                LinearProgressIndicator(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp)),
                                    color = MaterialTheme.colorScheme.primary,
                                    trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                                )
                            }
                            if (extractCurrentFile.isNotBlank()) {
                                Text(
                                    text = extractCurrentFile,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            FilledTonalButton(
                                onClick = onCancelExtract,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("取消解压")
                            }
                        }
                    } else {
                        Text(
                            text = "直接阅读 .zip · .cbz · .7z · .rar · .tar.gz 内的图片，自动检测并支持输入压缩包密码解锁",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = onPickArchiveToRead,
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Default.FolderZip, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("打开压缩包")
                            }
                            FilledTonalButton(
                                onClick = onPickImagesToRead,
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("选择图片")
                            }
                        }
                    }
                }
            }
        }
        return
    }

    val listState = rememberLazyListState()
    val readerPagerState = rememberPagerState(
        initialPage = 0,
        pageCount = { images.size }
    )
    val coroutineScope = rememberCoroutineScope()

    // 自动书签键值：按当前压缩包文件名或首图归属包名记忆上次阅读位置
    val archiveBookmarkKey = remember(archiveBanner, images.firstOrNull()?.uri) {
        archiveBanner?.substringBefore(" · ")?.trim()?.takeIf { it.isNotBlank() }
            ?: images.firstOrNull()?.fromArchiveName
            ?: images.firstOrNull()?.displayName
            ?: ""
    }

    val currentPageIndex = if (readerLayoutMode == ReaderLayoutMode.VERTICAL_STRIP) {
        listState.firstVisibleItemIndex.coerceIn(0, (images.size - 1).coerceAtLeast(0))
    } else {
        readerPagerState.currentPage.coerceIn(0, (images.size - 1).coerceAtLeast(0))
    }

    // 打开压缩包时自动恢复到上次阅读页码
    var hasRestoredBookmarkForKey by remember(archiveBookmarkKey, images.size) { mutableStateOf(false) }
    LaunchedEffect(archiveBookmarkKey, images.size) {
        if (!hasRestoredBookmarkForKey && archiveBookmarkKey.isNotBlank() && images.size > 1) {
            hasRestoredBookmarkForKey = true
            val savedPage = ImageCompressor.getReaderBookmark(context, archiveBookmarkKey)
            if (savedPage in 1 until images.size) {
                listState.scrollToItem(savedPage)
                readerPagerState.scrollToPage(savedPage)
                Toast.makeText(
                    context,
                    "已恢复至上次阅读位置：第 ${savedPage + 1} / ${images.size} 页",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    // 翻页/滑动时自动保存当前阅读页码书签
    LaunchedEffect(currentPageIndex, archiveBookmarkKey) {
        if (hasRestoredBookmarkForKey && archiveBookmarkKey.isNotBlank() && images.size > 1) {
            ImageCompressor.saveReaderBookmark(context, archiveBookmarkKey, currentPageIndex)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (readerLayoutMode == ReaderLayoutMode.VERTICAL_STRIP) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(
                    top = if (isImmersive) 0.dp else 64.dp,
                    bottom = if (isImmersive) 64.dp else 148.dp
                ),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                itemsIndexed(
                    items = images,
                    key = { _, item -> item.uri.toString() }
                ) { idx, item ->
                    val displayUri = if (liveDecryptEnabled) {
                        decryptedUriMap[item.uri] ?: item.uri
                    } else {
                        item.uri
                    }
                    ReaderZoomablePageItem(
                        uri = displayUri,
                        pageLabel = "${idx + 1} / ${images.size} · ${item.displayName}",
                        isVerticalMode = true,
                        onTapPage = onToggleImmersive,
                        onSavePage = { onSaveSingleImage(item) },
                        onSharePage = { onShareSingleImage(item) }
                    )
                }
            }
        } else {
            HorizontalPager(
                state = readerPagerState,
                beyondBoundsPageCount = 1,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(
                        top = if (isImmersive) 0.dp else 58.dp,
                        bottom = if (isImmersive) 0.dp else 90.dp
                    )
            ) { idx ->
                val item = images[idx]
                val displayUri = if (liveDecryptEnabled) {
                    decryptedUriMap[item.uri] ?: item.uri
                } else {
                    item.uri
                }
                ReaderZoomablePageItem(
                    uri = displayUri,
                    pageLabel = "${idx + 1} / ${images.size} · ${item.displayName}",
                    isVerticalMode = false,
                    onTapPage = onToggleImmersive,
                    onSavePage = { onSaveSingleImage(item) },
                    onSharePage = { onShareSingleImage(item) }
                )
            }
        }

        // 顶部液态玻璃阅读器悬浮控制条
        LiquidGlassSurfaceCard(
            cornerRadius = 20.dp,
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.90f),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Text(
                            text = "${currentPageIndex + 1} / ${images.size}",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    Text(
                        text = archiveBanner ?: images[currentPageIndex].displayName,
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        modifier = Modifier.flClashJellyClick(
                            pressScale = 0.88f,
                            shape = RoundedCornerShape(10.dp),
                            onClick = onToggleLayoutMode
                        )
                    ) {
                        Text(
                            text = readerLayoutMode.label,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                        )
                    }

                    IconButton(onClick = onPickArchiveToRead, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = Icons.Default.FolderZip,
                            contentDescription = "打开其他压缩包",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(onClick = onOpenReaderLayer2Menu, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = if (hasArchivePassword || liveDecryptEnabled) Icons.Default.Key else Icons.Default.Tune,
                            contentDescription = "阅读设置与密码",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(onClick = onToggleImmersive, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = if (isImmersive) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                            contentDescription = "全屏阅读",
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
            AnimatedVisibility(visible = isExtracting) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 12.dp, end = 12.dp, bottom = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = when {
                                extractTotalCount > 0 -> "正在解压 ($extractDoneCount/$extractTotalCount) · $extractCurrentFile"
                                extractDoneCount > 0 -> "正在解压 ($extractDoneCount 张) · $extractCurrentFile"
                                else -> "正在解析压缩包条目..."
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        if (extractTotalCount > 0) {
                            Text(
                                text = "${(animatedExtractProgress * 100).roundToInt()}%",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    if (extractTotalCount > 0) {
                        LinearProgressIndicator(
                            progress = { animatedExtractProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                        )
                    } else {
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                        )
                    }
                }
            }
        }

        if (isImmersive && images.size > 1) {
            LiquidGlassSurfaceCard(
                cornerRadius = 20.dp,
                containerColor = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.90f),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("${currentPageIndex + 1}", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Slider(
                        value = currentPageIndex.toFloat(),
                        onValueChange = { target ->
                            val targetIdx = target.roundToInt().coerceIn(0, images.size - 1)
                            coroutineScope.launch {
                                if (readerLayoutMode == ReaderLayoutMode.VERTICAL_STRIP) {
                                    listState.scrollToItem(targetIdx)
                                } else {
                                    readerPagerState.scrollToPage(targetIdx)
                                }
                            }
                        },
                        valueRange = 0f..(images.size - 1).toFloat(),
                        modifier = Modifier.weight(1f)
                    )
                    Text("${images.size}", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

@Composable
private fun ReaderZoomablePageItem(
    uri: Uri,
    pageLabel: String,
    isVerticalMode: Boolean,
    onTapPage: () -> Unit,
    onSavePage: () -> Unit,
    onSharePage: () -> Unit
) {
    var scale by remember(uri) { mutableFloatStateOf(1f) }
    var offsetX by remember(uri) { mutableFloatStateOf(0f) }
    var offsetY by remember(uri) { mutableFloatStateOf(0f) }

    val animatedScale by animateFloatAsState(
        targetValue = scale,
        animationSpec = spring(dampingRatio = JELLY_DAMPING, stiffness = JELLY_STIFFNESS),
        label = "ReaderPageZoom"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (isVerticalMode) Modifier else Modifier.fillMaxHeight())
            .clip(RoundedCornerShape(if (isVerticalMode) 8.dp else 14.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerLow)
            .pointerInput(uri) {
                detectTapGestures(
                    onDoubleTap = {
                        if (scale > 1.05f) {
                            scale = 1f
                            offsetX = 0f
                            offsetY = 0f
                        } else {
                            scale = 2.2f
                        }
                    },
                    onTap = { onTapPage() }
                )
            }
            .then(
                if (!isVerticalMode || scale > 1.01f) {
                    Modifier.pointerInput(uri) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(1f, 3.5f)
                            if (scale > 1.01f) {
                                offsetX += pan.x
                                offsetY += pan.y
                            } else {
                                offsetX = 0f
                                offsetY = 0f
                            }
                        }
                    }
                } else {
                    Modifier
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = uri,
            contentDescription = pageLabel,
            contentScale = if (isVerticalMode) ContentScale.FillWidth else ContentScale.Fit,
            modifier = Modifier
                .fillMaxWidth()
                .graphicsLayer {
                    scaleX = animatedScale
                    scaleY = animatedScale
                    translationX = offsetX
                    translationY = offsetY
                }
        )

        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color.Black.copy(alpha = 0.52f)
            ) {
                Text(
                    text = pageLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
            Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.52f),
                modifier = Modifier
                    .size(28.dp)
                    .clickable { onSavePage() }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = "保存此页到相册",
                        tint = Color.White,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }
            Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.52f),
                modifier = Modifier
                    .size(28.dp)
                    .clickable { onSharePage() }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "分享此页",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

/**
 * 加密压缩包密码解锁液态玻璃弹窗
 */
@Composable
private fun ArchivePasswordUnlockModal(
    archiveNames: String,
    passwordInput: String,
    errorText: String?,
    onPasswordChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onConfirmUnlock: () -> Unit
) {
    var passwordVisible by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismiss
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        LiquidGlassSurfaceCard(
            cornerRadius = 26.dp,
            isHighlighted = true,
            modifier = Modifier
                .widthIn(max = 420.dp)
                .fillMaxWidth()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {}
                )
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "压缩包受密码保护",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = archiveNames,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                OutlinedTextField(
                    value = passwordInput,
                    onValueChange = onPasswordChange,
                    label = { Text("输入压缩包密码") },
                    singleLine = true,
                    isError = errorText != null,
                    visualTransformation = if (passwordVisible) {
                        VisualTransformation.None
                    } else {
                        PasswordVisualTransformation()
                    },
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = "切换密码可见"
                            )
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorText != null) {
                    Text(
                        text = errorText,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FilledTonalButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("取消")
                    }
                    Button(
                        onClick = onConfirmUnlock,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("解锁并打开")
                    }
                }
            }
        }
    }
}

/**
 * 右下角液态玻璃双层启动按钮组：
 * 左侧为圆形液态玻璃二级菜单触发钮（点击弹出第二层菜单，点击空白处缩回），右侧为 FlClash 主启动胶囊
 */
@OptIn(ExperimentalAnimationApi::class)
@Composable
private fun FlClashLiquidGlassFloatingBarActions(
    currentMode: ProcessMode,
    archiveSubMode: ArchiveSubMode,
    packResultIntoArchive: Boolean,
    archiveFormat: ArchiveOutputFormat,
    selectedCount: Int,
    isProcessing: Boolean,
    completedCount: Int,
    totalTaskCount: Int,
    obfuscationKeyText: String,
    isQuickHubExpanded: Boolean,
    onToggleQuickHub: () -> Unit,
    onMissingKeyOpenSheet: () -> Unit,
    onStartClick: () -> Unit,
    onCancelClick: () -> Unit
) {
    val requiresKey = currentMode == ProcessMode.OBFUSCATE_ENCRYPT ||
        currentMode == ProcessMode.DEOBFUSCATE_RESTORE
    val missingKey = requiresKey && obfuscationKeyText.isBlank()

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        val hubRotation by animateFloatAsState(
            targetValue = if (isQuickHubExpanded) 45f else 0f,
            animationSpec = spring(dampingRatio = JELLY_DAMPING, stiffness = JELLY_STIFFNESS),
            label = "QuickHubRotate"
        )
        LiquidGlassSurfaceCard(
            cornerRadius = 22.dp,
            isHighlighted = isQuickHubExpanded,
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.94f),
            modifier = Modifier
                .size(46.dp)
                .shadow(
                    elevation = 8.dp,
                    shape = CircleShape,
                    ambientColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                    spotColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)
                )
                .flClashJellyClick(
                    enabled = true,
                    pressScale = 0.85f,
                    shape = CircleShape,
                    onClick = onToggleQuickHub
                )
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "展开二级快捷菜单",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .size(22.dp)
                        .graphicsLayer { rotationZ = hubRotation }
                )
            }
        }

        val containerColor by animateColorAsState(
            targetValue = when {
                isProcessing -> MaterialTheme.colorScheme.tertiaryContainer
                selectedCount == 0 -> MaterialTheme.colorScheme.secondaryContainer
                missingKey -> MaterialTheme.colorScheme.errorContainer
                else -> MaterialTheme.colorScheme.primary
            },
            animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = JELLY_STIFFNESS),
            label = "RunFabColor"
        )

        val contentColor = when {
            isProcessing -> MaterialTheme.colorScheme.onTertiaryContainer
            selectedCount == 0 -> MaterialTheme.colorScheme.onSecondaryContainer
            missingKey -> MaterialTheme.colorScheme.onErrorContainer
            else -> MaterialTheme.colorScheme.onPrimary
        }

        Box(
            modifier = Modifier
                .shadow(
                    elevation = 8.dp,
                    shape = RoundedCornerShape(22.dp),
                    ambientColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.25f),
                    spotColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.30f)
                )
                .flClashJellyClick(
                    enabled = true,
                    pressScale = 0.88f,
                    shape = RoundedCornerShape(22.dp),
                    onClick = {
                        when {
                            isProcessing -> onCancelClick()
                            selectedCount == 0 -> onToggleQuickHub()
                            missingKey -> onMissingKeyOpenSheet()
                            else -> onStartClick()
                        }
                    }
                )
                .background(containerColor)
                .border(
                    width = 1.dp,
                    color = Color.White.copy(alpha = 0.35f),
                    shape = RoundedCornerShape(22.dp)
                )
                .padding(horizontal = 18.dp, vertical = 12.dp)
        ) {
            AnimatedContent(
                targetState = Triple(currentMode, selectedCount, isProcessing),
                transitionSpec = {
                    (scaleIn(
                        initialScale = 0.85f,
                        animationSpec = spring(dampingRatio = JELLY_DAMPING, stiffness = JELLY_STIFFNESS)
                    ) + fadeIn()).togetherWith(
                        scaleOut(targetScale = 0.85f) + fadeOut()
                    )
                },
                label = "FlClashFabTextMorph"
            ) { (mode, count, running) ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val icon = when {
                        running -> Icons.Default.Close
                        count == 0 -> Icons.Default.AddPhotoAlternate
                        missingKey -> Icons.Default.Key
                        mode == ProcessMode.ARCHIVE_HUB && archiveSubMode == ArchiveSubMode.PACK_TO_ARCHIVE -> Icons.Default.Archive
                        mode == ProcessMode.ARCHIVE_HUB && archiveSubMode == ArchiveSubMode.EXTRACT_FROM_ARCHIVE -> Icons.Default.Unarchive
                        packResultIntoArchive -> Icons.Default.Archive
                        else -> Icons.Default.PlayArrow
                    }
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = contentColor,
                        modifier = Modifier.size(19.dp)
                    )

                    val text = when {
                        running -> if (totalTaskCount > 0) "$completedCount / $totalTaskCount · 取消" else "执行中 · 点击取消"
                        count == 0 -> "添加图片 / 压缩包"
                        missingKey -> "设置口令"
                        mode == ProcessMode.COMPRESS_TRANSCODE ->
                            if (packResultIntoArchive) "压缩打包 ($count)" else "开始压缩 ($count)"
                        mode == ProcessMode.OBFUSCATE_ENCRYPT ->
                            if (packResultIntoArchive) "混淆打包 ($count)" else "开始混淆 ($count)"
                        mode == ProcessMode.DEOBFUSCATE_RESTORE ->
                            if (packResultIntoArchive) "还原打包 ($count)" else "开始还原 ($count)"
                        mode == ProcessMode.ARCHIVE_HUB && archiveSubMode == ArchiveSubMode.PACK_TO_ARCHIVE ->
                            "打包 .${archiveFormat.extension} ($count)"
                        else -> "导出 ($count)"
                    }

                    Text(
                        text = text,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = contentColor
                    )
                }
            }
        }
    }
}

/**
 * 底部悬浮果冻胶囊导航栏 (5个页签：压缩 · 混淆 · 还原 · 归档 · 阅读)
 * 支持手指按住底栏直接左右拖动滑块切换 + 点击果冻过冲回弹 + 全屏滑页实时联动
 */
@Composable
private fun FlClashFloatingLiquidDockBar(
    continuousPagePositionProvider: () -> Float,
    currentMode: ProcessMode,
    isProcessing: Boolean,
    onSelectMode: (ProcessMode) -> Unit
) {
    val tabCount = ProcessMode.entries.size
    val continuousPagePosition = continuousPagePositionProvider()
    var barWidthPx by remember { mutableIntStateOf(0) }
    var isDraggingBar by remember { mutableStateOf(false) }
    var dragFractionPosition by remember { mutableFloatStateOf(continuousPagePosition) }
    var pressedTabIndex by remember { mutableIntStateOf(-1) }

    val targetFraction = if (isDraggingBar) {
        dragFractionPosition.coerceIn(0f, (tabCount - 1).toFloat())
    } else {
        continuousPagePosition.coerceIn(0f, (tabCount - 1).toFloat())
    }

    val animatedTabPosition by animateFloatAsState(
        targetValue = targetFraction,
        animationSpec = spring(
            dampingRatio = if (isDraggingBar) 0.72f else JELLY_DAMPING,
            stiffness = if (isDraggingBar) 650f else 330f
        ),
        label = "FloatingDockJellyPosition"
    )

    val dockScale by animateFloatAsState(
        targetValue = if (isDraggingBar || pressedTabIndex != -1) 1.025f else 1f,
        animationSpec = spring(dampingRatio = 0.42f, stiffness = 360f),
        label = "FloatingDockOuterScale"
    )

    val motionDelta = abs(targetFraction - animatedTabPosition).coerceIn(0f, 1f)
    val pillStretchX = 1f + (motionDelta * 0.34f)
    val pillSquishY = 1f - (motionDelta * 0.14f)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .graphicsLayer {
                scaleX = dockScale
                scaleY = dockScale
            }
            .shadow(
                elevation = 10.dp,
                shape = RoundedCornerShape(28.dp),
                ambientColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                spotColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
            )
            .clip(RoundedCornerShape(28.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.94f))
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.40f),
                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)
                    )
                ),
                shape = RoundedCornerShape(28.dp)
            )
            .onSizeChanged { barWidthPx = it.width }
            .pointerInput(barWidthPx) {
                if (barWidthPx <= 0) return@pointerInput
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val startFrac = ((down.position.x / barWidthPx.toFloat()) * tabCount - 0.5f)
                        .coerceIn(0f, (tabCount - 1).toFloat())
                    var currentFrac = startFrac
                    var hasDragged = false
                    var lastTriggeredIdx = ((down.position.x / barWidthPx.toFloat()) * tabCount)
                        .toInt()
                        .coerceIn(0, tabCount - 1)
                    pressedTabIndex = lastTriggeredIdx

                    do {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull() ?: break
                        if (change.pressed) {
                            val dx = abs(change.position.x - down.position.x)
                            if (dx > 5f) {
                                hasDragged = true
                                isDraggingBar = true
                            }
                            if (hasDragged) {
                                change.consume()
                                currentFrac = ((change.position.x / barWidthPx.toFloat()) * tabCount - 0.5f)
                                    .coerceIn(0f, (tabCount - 1).toFloat())
                                dragFractionPosition = currentFrac
                                val hoveredIdx = ((change.position.x / barWidthPx.toFloat()) * tabCount)
                                    .toInt()
                                    .coerceIn(0, tabCount - 1)
                                pressedTabIndex = hoveredIdx
                                if (hoveredIdx != lastTriggeredIdx) {
                                    lastTriggeredIdx = hoveredIdx
                                    onSelectMode(ProcessMode.entries[hoveredIdx])
                                }
                            }
                        }
                    } while (event.changes.any { it.pressed })

                    pressedTabIndex = -1
                    if (hasDragged) {
                        isDraggingBar = false
                        val finalIdx = currentFrac.roundToInt().coerceIn(0, tabCount - 1)
                        onSelectMode(ProcessMode.entries[finalIdx])
                    } else {
                        val tappedIdx = ((down.position.x / barWidthPx.toFloat()) * tabCount)
                            .toInt()
                            .coerceIn(0, tabCount - 1)
                        onSelectMode(ProcessMode.entries[tappedIdx])
                    }
                }
            }
    ) {
        val tabWidthPx = if (barWidthPx > 0) barWidthPx / tabCount else 0
        val tabWidthDp = with(LocalDensity.current) { tabWidthPx.toDp() }

        if (tabWidthPx > 0) {
            val offsetXPx = (animatedTabPosition * tabWidthPx).roundToInt()
            Box(
                modifier = Modifier
                    .offset { IntOffset(x = offsetXPx, y = 0) }
                    .width(tabWidthDp)
                    .fillMaxHeight()
                    .padding(horizontal = 4.dp, vertical = 6.dp)
                    .graphicsLayer {
                        scaleX = pillStretchX
                        scaleY = pillSquishY
                    }
                    .clip(RoundedCornerShape(22.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .border(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.45f),
                        shape = RoundedCornerShape(22.dp)
                    )
            )
        }

        Row(modifier = Modifier.fillMaxSize()) {
            ProcessMode.entries.forEachIndexed { index, mode ->
                val distance = abs(animatedTabPosition - index).coerceIn(0f, 1f)
                val isSelected = distance < 0.45f
                val isFingerPressing = pressedTabIndex == index

                val iconScale by animateFloatAsState(
                    targetValue = when {
                        isFingerPressing -> 0.84f
                        isSelected -> 1.16f
                        else -> 0.94f
                    },
                    animationSpec = spring(dampingRatio = 0.40f, stiffness = 380f),
                    label = "DockIconBounceScale"
                )

                val iconLiftY by animateFloatAsState(
                    targetValue = if (isSelected) -3.5f else 0f,
                    animationSpec = spring(dampingRatio = 0.42f, stiffness = 360f),
                    label = "DockIconBounceLift"
                )

                val icon = when (mode) {
                    ProcessMode.COMPRESS_TRANSCODE -> if (isSelected) Icons.Filled.Transform else Icons.Outlined.Transform
                    ProcessMode.OBFUSCATE_ENCRYPT -> if (isSelected) Icons.Filled.EnhancedEncryption else Icons.Outlined.EnhancedEncryption
                    ProcessMode.DEOBFUSCATE_RESTORE -> if (isSelected) Icons.Filled.LockOpen else Icons.Outlined.LockOpen
                    ProcessMode.ARCHIVE_HUB -> if (isSelected) Icons.Filled.FolderZip else Icons.Outlined.FolderZip
                    ProcessMode.ARCHIVE_READER -> if (isSelected) Icons.Filled.AutoStories else Icons.Outlined.AutoStories
                }

                val contentColor = if (isSelected) {
                    MaterialTheme.colorScheme.onPrimaryContainer
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = mode.shortTitle,
                        tint = contentColor,
                        modifier = Modifier
                            .size(21.dp)
                            .graphicsLayer {
                                scaleX = iconScale
                                scaleY = iconScale
                                translationY = iconLiftY
                            }
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = mode.shortTitle,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = contentColor
                    )
                }
            }
        }
    }
}

/**
 * FlClash 仪表盘 2x2 Bento 状态卡片组
 */
@Composable
private fun FlClashBentoDashboardGrid(
    pageMode: ProcessMode,
    selectedImages: List<SelectedImageItem>,
    resultsMap: Map<Uri, CompressionResult>,
    selectedFormat: OutputFormat,
    quality: Int,
    selectedBlockGrid: BlockGridSize,
    selectedArchiveFormat: ArchiveOutputFormat,
    customDirName: String?,
    isDirectArchiveActive: Boolean,
    isProcessing: Boolean,
    lastImportedArchiveBanner: String?,
    onPickImages: () -> Unit,
    onPickArchives: () -> Unit,
    onOpenReader: () -> Unit,
    onPickDirectory: () -> Unit,
    onResetDirectory: () -> Unit
) {
    val totalOrigBytes = selectedImages.sumOf { it.originalSize }
    val doneCount = selectedImages.count { resultsMap[it.uri]?.isSuccess == true }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            LiquidGlassSurfaceCard(
                cornerRadius = 18.dp,
                modifier = Modifier
                    .weight(1f)
                    .flClashJellyClick(enabled = !isProcessing, onClick = onPickImages)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (selectedImages.isNotEmpty()) Color(0xFF22C55E) else MaterialTheme.colorScheme.outline
                                    )
                            )
                            Text("图片队列", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = "${selectedImages.size} 张",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (selectedImages.isEmpty()) {
                            "点击选图"
                        } else {
                            "${ImageCompressor.formatFileSize(totalOrigBytes)} · 完成 $doneCount"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            LiquidGlassSurfaceCard(
                cornerRadius = 18.dp,
                modifier = Modifier
                    .weight(1f)
                    .flClashJellyClick(enabled = !isProcessing, onClick = onPickArchives)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("归档导入", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Icon(
                            imageVector = Icons.Default.FolderZip,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = "导入压缩包",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "支持密码 · ZIP/7Z/RAR",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            LiquidGlassSurfaceCard(
                cornerRadius = 18.dp,
                modifier = Modifier
                    .weight(1f)
                    .flClashJellyClick(enabled = !isProcessing, onClick = onOpenReader)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("图集阅读器", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Icon(
                            imageVector = Icons.Default.AutoStories,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = if (selectedImages.isNotEmpty()) "阅读 (${selectedImages.size}页)" else "归档直读",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "条漫连读 · 口令实时预览",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            LiquidGlassSurfaceCard(
                cornerRadius = 18.dp,
                modifier = Modifier
                    .weight(1f)
                    .flClashJellyClick(enabled = !isProcessing, onClick = onPickDirectory)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("保存位置", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (customDirName != null && !isProcessing) {
                            Icon(
                                imageVector = Icons.Default.Restore,
                                contentDescription = "重置",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .size(16.dp)
                                    .clickable { onResetDirectory() }
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Outlined.FolderOpen,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Text(
                        text = customDirName ?: if (isDirectArchiveActive) "Download" else "系统相册",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = if (customDirName != null) "自定义目录" else "点击更改",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

/**
 * Q 弹果冻分段选择器
 */
@Composable
private fun <T> FlClashSegmentedRow(
    items: List<T>,
    selectedItem: T,
    itemLabel: (T) -> String,
    enabled: Boolean = true,
    onItemSelected: (T) -> Unit
) {
    val selectedIndex = items.indexOf(selectedItem).coerceAtLeast(0)
    var rowWidthPx by remember { mutableIntStateOf(0) }

    val animatedIndex by animateFloatAsState(
        targetValue = selectedIndex.toFloat(),
        animationSpec = spring(
            dampingRatio = JELLY_DAMPING,
            stiffness = 380f
        ),
        label = "SegmentJellyOffset"
    )

    val stretchDelta = abs(selectedIndex.toFloat() - animatedIndex).coerceIn(0f, 1f)
    val pillScaleX = 1f + (stretchDelta * 0.25f)
    val pillScaleY = 1f - (stretchDelta * 0.12f)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(42.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceContainer)
            .border(
                1.dp,
                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f),
                RoundedCornerShape(14.dp)
            )
            .onSizeChanged { rowWidthPx = it.width }
    ) {
        val itemWidthPx = if (rowWidthPx > 0 && items.isNotEmpty()) rowWidthPx / items.size else 0
        val itemWidthDp = with(LocalDensity.current) { itemWidthPx.toDp() }

        if (itemWidthPx > 0) {
            val offsetXPx = (animatedIndex * itemWidthPx).roundToInt()
            Box(
                modifier = Modifier
                    .offset { IntOffset(x = offsetXPx, y = 0) }
                    .width(itemWidthDp)
                    .fillMaxHeight()
                    .padding(3.dp)
                    .graphicsLayer {
                        scaleX = pillScaleX
                        scaleY = pillScaleY
                    }
                    .clip(RoundedCornerShape(11.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.35f),
                        RoundedCornerShape(11.dp)
                    )
            )
        }

        Row(modifier = Modifier.fillMaxSize()) {
            items.forEach { item ->
                val isSelected = item == selectedItem
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .flClashJellyClick(
                            enabled = enabled,
                            pressScale = 0.88f,
                            shape = RoundedCornerShape(11.dp),
                            onClick = { onItemSelected(item) }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = itemLabel(item),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) {
                            MaterialTheme.colorScheme.onPrimaryContainer
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                }
            }
        }
    }
}

/**
 * 桌面/平板端左侧 M3 NavigationRail
 */
@Composable
private fun FlClashNavigationRail(
    currentMode: ProcessMode,
    selectedCount: Int,
    isProcessing: Boolean,
    onSelectMode: (ProcessMode) -> Unit
) {
    NavigationRail(
        containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
        header = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 12.dp, bottom = 8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(44.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Dashboard,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
                if (selectedCount > 0) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Badge(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ) {
                        Text("$selectedCount", modifier = Modifier.padding(horizontal = 4.dp))
                    }
                }
            }
        },
        modifier = Modifier.fillMaxHeight()
    ) {
        Spacer(modifier = Modifier.height(8.dp))
        ProcessMode.entries.forEach { mode ->
            val isSelected = currentMode == mode
            val icon = when (mode) {
                ProcessMode.COMPRESS_TRANSCODE -> if (isSelected) Icons.Filled.Transform else Icons.Outlined.Transform
                ProcessMode.OBFUSCATE_ENCRYPT -> if (isSelected) Icons.Filled.EnhancedEncryption else Icons.Outlined.EnhancedEncryption
                ProcessMode.DEOBFUSCATE_RESTORE -> if (isSelected) Icons.Filled.LockOpen else Icons.Outlined.LockOpen
                ProcessMode.ARCHIVE_HUB -> if (isSelected) Icons.Filled.FolderZip else Icons.Outlined.FolderZip
                ProcessMode.ARCHIVE_READER -> if (isSelected) Icons.Filled.AutoStories else Icons.Outlined.AutoStories
            }
            NavigationRailItem(
                selected = isSelected,
                onClick = { onSelectMode(mode) },
                icon = { Icon(imageVector = icon, contentDescription = mode.shortTitle) },
                label = {
                    Text(
                        text = mode.shortTitle,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    selectedTextColor = MaterialTheme.colorScheme.primary,
                    indicatorColor = MaterialTheme.colorScheme.primaryContainer
                ),
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }
    }
}

/**
 * 极简顶栏
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FlClashTopBar(
    currentMode: ProcessMode,
    selectedCount: Int,
    customTreeUri: Uri?,
    useDynamicColor: Boolean,
    isProcessing: Boolean,
    onToggleDynamicColor: () -> Unit,
    onPickDirectory: () -> Unit,
    onClearQueue: () -> Unit
) {
    Column {
        TopAppBar(
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = currentMode.fullTitle,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                    ) {
                        Text(
                            text = currentMode.shortTitle,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                        )
                    }
                }
            },
            actions = {
                IconButton(onClick = onToggleDynamicColor) {
                    Icon(
                        imageVector = if (useDynamicColor) Icons.Default.AutoAwesome else Icons.Outlined.Palette,
                        contentDescription = "动态取色",
                        tint = if (useDynamicColor) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                }

                IconButton(
                    onClick = onPickDirectory,
                    enabled = !isProcessing
                ) {
                    Icon(
                        imageVector = Icons.Outlined.FolderOpen,
                        contentDescription = "输出目录",
                        tint = if (customTreeUri != null) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                }

                if (selectedCount > 0 && !isProcessing) {
                    IconButton(onClick = onClearQueue) {
                        Icon(
                            imageVector = Icons.Outlined.DeleteSweep,
                            contentDescription = "清空队列",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.background
            )
        )
        HorizontalDivider(
            thickness = 1.dp,
            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
        )
    }
}

/**
 * 批处理完成统计与一键分享接力卡片
 */
@Composable
private fun BatchSummaryBanner(
    selectedImages: List<SelectedImageItem>,
    resultsMap: Map<Uri, CompressionResult>,
    batchReport: BatchExecutionReport?,
    onShareClick: () -> Unit
) {
    val successfulResults = selectedImages.mapNotNull { resultsMap[it.uri] }.filter { it.isSuccess }
    if (successfulResults.isEmpty()) return

    val totalOriginalBytes = successfulResults.sumOf { it.source.originalSize }
    val totalCompressedBytes = successfulResults.sumOf { it.compressedSize }
    val diffBytes = totalOriginalBytes - totalCompressedBytes
    val ratioPercent = if (totalOriginalBytes > 0) {
        (diffBytes.toDouble() / totalOriginalBytes.toDouble() * 100.0)
    } else {
        0.0
    }
    val mode = successfulResults.first().mode

    LiquidGlassSurfaceCard(
        cornerRadius = 18.dp,
        isHighlighted = true,
        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = if (batchReport?.archiveFileName != null) {
                        "已打包：${batchReport.archiveFileName}${if (batchReport.isArchiveEncrypted) " (AES加密)" else ""}"
                    } else {
                        "${mode.shortTitle}完成 (${successfulResults.size}/${selectedImages.size})"
                    },
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )

                val outBytesToShow = if (batchReport != null && batchReport.archiveTotalBytes > 0L) {
                    batchReport.archiveTotalBytes
                } else {
                    totalCompressedBytes
                }
                Text(
                    text = "${ImageCompressor.formatFileSize(totalOriginalBytes)} → ${ImageCompressor.formatFileSize(outBytesToShow)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )

                val footerNote = when {
                    batchReport?.archiveSavedPathLabel != null ->
                        batchReport.archiveSavedPathLabel
                    diffBytes >= 0 ->
                        String.format(Locale.US, "已省 %s (-%.1f%%)", ImageCompressor.formatFileSize(diffBytes), ratioPercent)
                    else ->
                        String.format(Locale.US, "无损转换 +%s", ImageCompressor.formatFileSize(abs(diffBytes)))
                }
                Text(
                    text = footerNote,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Button(
                onClick = onShareClick,
                shape = RoundedCornerShape(14.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Icon(Icons.Default.Share, contentDescription = "分享", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("分享", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

/**
 * 18dp 液态玻璃图片列表卡片
 */
@Composable
private fun ImageComparisonItemCard(
    item: SelectedImageItem,
    result: CompressionResult?,
    isProcessing: Boolean,
    onCardClick: () -> Unit,
    onRemoveItem: () -> Unit
) {
    LiquidGlassSurfaceCard(
        cornerRadius = 18.dp,
        modifier = Modifier
            .fillMaxWidth()
            .flClashJellyClick(
                enabled = true,
                pressScale = 0.93f,
                shape = RoundedCornerShape(18.dp),
                onClick = onCardClick
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val context = LocalContext.current
            val sourceThumbRequest = remember(item.uri) {
                ImageRequest.Builder(context)
                    .data(item.uri)
                    .size(180, 180)
                    .crossfade(false)
                    .build()
            }
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainer)
            ) {
                AsyncImage(
                    model = sourceThumbRequest,
                    contentDescription = item.displayName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Surface(
                    color = Color.Black.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(bottomEnd = 6.dp),
                    modifier = Modifier.align(Alignment.TopStart)
                ) {
                    Text(
                        text = "原图",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                    )
                }
            }

            if (result != null && result.isSuccess && result.outputUri != null) {
                val outThumbRequest = remember(result.outputUri) {
                    ImageRequest.Builder(context)
                        .data(result.outputUri)
                        .size(180, 180)
                        .crossfade(false)
                        .build()
                }
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainer)
                ) {
                    AsyncImage(
                        model = outThumbRequest,
                        contentDescription = result.outputName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Surface(
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.88f),
                        shape = RoundedCornerShape(bottomEnd = 6.dp),
                        modifier = Modifier.align(Alignment.TopStart)
                    ) {
                        Text(
                            text = when {
                                result.packedIntoArchiveName != null -> "已入包"
                                result.mode == ProcessMode.OBFUSCATE_ENCRYPT -> "色块"
                                result.mode == ProcessMode.DEOBFUSCATE_RESTORE -> "还原"
                                else -> "结果"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text(
                    text = item.displayName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                val srcFormatShort = item.mimeType.substringAfterLast('/').uppercase(Locale.ROOT)
                Text(
                    text = "$srcFormatShort · ${item.width}×${item.height} · ${ImageCompressor.formatFileSize(item.originalSize)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (result != null) {
                    if (result.isSuccess) {
                        val deltaRatio = if (item.originalSize > 0) {
                            ((result.compressedSize - item.originalSize).toDouble() / item.originalSize.toDouble()) * 100.0
                        } else {
                            0.0
                        }
                        val ratioLabel = if (deltaRatio <= 0) {
                            String.format(Locale.US, "%.1f%%", deltaRatio)
                        } else {
                            String.format(Locale.US, "+%.1f%%", deltaRatio)
                        }
                        val badgeColor = if (deltaRatio <= 0) {
                            MaterialTheme.colorScheme.tertiary
                        } else {
                            MaterialTheme.colorScheme.primary
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = badgeColor,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${result.outputName} · ${ImageCompressor.formatFileSize(result.compressedSize)} ($ratioLabel)",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = badgeColor,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.ErrorOutline,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = result.errorMessage ?: "失败",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }

            Icon(
                imageVector = Icons.Default.Compare,
                contentDescription = "拉帘对比",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )

            if (!isProcessing) {
                IconButton(
                    onClick = onRemoveItem,
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "移除",
                        tint = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

/**
 * Container Transform 卡片展开大图详情视图（内置交互式拉帘对比 Before/After Split Slider + 一键分享）
 */
@Composable
private fun ImageDetailContainerTransformModal(
    item: SelectedImageItem,
    result: CompressionResult?,
    onDismiss: () -> Unit,
    onShare: () -> Unit,
    onRemove: () -> Unit
) {
    BackHandler(onBack = onDismiss)

    val hasProcessedImage = result != null && result.isSuccess && result.outputUri != null
    var useSplitCurtain by remember(hasProcessedImage) { mutableStateOf(hasProcessedImage) }
    var splitFraction by remember { mutableFloatStateOf(0.5f) }
    var previewContainerWidthPx by remember { mutableIntStateOf(0) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.50f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismiss
            )
            .padding(18.dp),
        contentAlignment = Alignment.Center
    ) {
        LiquidGlassSurfaceCard(
            cornerRadius = 24.dp,
            isHighlighted = true,
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.96f),
            modifier = Modifier
                .widthIn(max = 560.dp)
                .fillMaxWidth()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {}
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.displayName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = if (hasProcessedImage) "左右拖动分割线实时对比原图与处理结果" else "${item.width}×${item.height} · ${ImageCompressor.formatFileSize(item.originalSize)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(onClick = onShare) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = "分享", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "关闭")
                    }
                }

                if (hasProcessedImage) {
                    FlClashSegmentedRow(
                        items = listOf(true, false),
                        selectedItem = useSplitCurtain,
                        itemLabel = { isSplit -> if (isSplit) "拉帘对比 (左右拖动)" else "处理后单图" },
                        onItemSelected = { useSplitCurtain = it }
                    )
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainer)
                        .border(
                            1.dp,
                            MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                            RoundedCornerShape(16.dp)
                        )
                        .onSizeChanged { previewContainerWidthPx = it.width }
                        .then(
                            if (hasProcessedImage && useSplitCurtain) {
                                Modifier.pointerInput(previewContainerWidthPx) {
                                    if (previewContainerWidthPx <= 0) return@pointerInput
                                    detectHorizontalDragGestures { change, _ ->
                                        change.consume()
                                        splitFraction = (change.position.x / previewContainerWidthPx.toFloat())
                                            .coerceIn(0.05f, 0.95f)
                                    }
                                }
                            } else {
                                Modifier
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (hasProcessedImage && useSplitCurtain && result?.outputUri != null) {
                        AsyncImage(
                            model = result.outputUri,
                            contentDescription = "处理后",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(6.dp)
                        )

                        AsyncImage(
                            model = item.uri,
                            contentDescription = "原图",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(6.dp)
                                .drawWithContent {
                                    clipRect(right = size.width * splitFraction) {
                                        this@drawWithContent.drawContent()
                                    }
                                }
                        )

                        val dividerOffsetDp = with(LocalDensity.current) {
                            ((previewContainerWidthPx * splitFraction).roundToInt()).toDp()
                        }
                        Box(
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .offset(x = dividerOffsetDp - 1.dp)
                                .width(2.dp)
                                .fillMaxHeight()
                                .background(Color.White)
                        )
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary,
                            border = BorderStroke(2.dp, Color.White),
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .offset(x = dividerOffsetDp - 16.dp)
                                .size(32.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.SwapHoriz,
                                    contentDescription = "拖动对比",
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color.Black.copy(alpha = 0.6f),
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(8.dp)
                        ) {
                            Text(
                                text = "原图 (${ImageCompressor.formatFileSize(item.originalSize)})",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(8.dp)
                        ) {
                            Text(
                                text = "处理后 (${ImageCompressor.formatFileSize(result.compressedSize)})",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    } else {
                        val singleUri = if (hasProcessedImage && result?.outputUri != null) {
                            result.outputUri
                        } else {
                            item.uri
                        }
                        AsyncImage(
                            model = singleUri,
                            contentDescription = item.displayName,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(8.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FilledTonalButton(
                        onClick = onRemove,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("移除")
                    }
                    Button(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("完成")
                    }
                }
            }
        }
    }
}

/**
 * 极简空状态引导卡片
 */
@Composable
private fun EmptyWorkbenchCard(
    currentMode: ProcessMode,
    isExtracting: Boolean = false,
    extractDoneCount: Int = 0,
    extractTotalCount: Int = 0,
    extractCurrentFile: String = "",
    onCancelExtract: () -> Unit = {},
    onPickImages: () -> Unit,
    onPickArchives: () -> Unit
) {
    val extractProgressTarget = if (extractTotalCount > 0) {
        (extractDoneCount.toFloat() / extractTotalCount.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }
    val animatedExtractProgress by animateFloatAsState(
        targetValue = extractProgressTarget,
        animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = JELLY_STIFFNESS),
        label = "WorkbenchExtractProgress"
    )

    LiquidGlassSurfaceCard(
        cornerRadius = 20.dp,
        isHighlighted = isExtracting,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                modifier = Modifier.size(56.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (isExtracting) {
                            Icons.Default.Unarchive
                        } else if (currentMode == ProcessMode.ARCHIVE_HUB) {
                            Icons.Outlined.FolderZip
                        } else {
                            Icons.Outlined.PhotoLibrary
                        },
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            Text(
                text = if (isExtracting) "正在解压压缩包..." else "暂无待处理图片",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            if (isExtracting) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = when {
                                extractTotalCount > 0 -> "已解压 $extractDoneCount / $extractTotalCount 张"
                                extractDoneCount > 0 -> "已解压 $extractDoneCount 张"
                                else -> "正在读取压缩包索引..."
                            },
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        if (extractTotalCount > 0) {
                            Text(
                                text = "${(animatedExtractProgress * 100).roundToInt()}%",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    if (extractTotalCount > 0) {
                        LinearProgressIndicator(
                            progress = { animatedExtractProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                        )
                    } else {
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                        )
                    }
                    if (extractCurrentFile.isNotBlank()) {
                        Text(
                            text = extractCurrentFile,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    FilledTonalButton(
                        onClick = onCancelExtract,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("取消解压")
                    }
                }
            } else {
                Text(
                    text = "点击上方液态玻璃按钮展开二级配置，点击空白处自动缩回",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    FilledTonalButton(
                        onClick = onPickImages,
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("选择图片")
                    }
                    FilledTonalButton(
                        onClick = onPickArchives,
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FolderZip,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("导入压缩包")
                    }
                }
            }
        }
    }
}
