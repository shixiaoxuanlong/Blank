package com.example.imagecompressor

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Password
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.FolderZip
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.VerticalDivider
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.core.util.Consumer
import androidx.documentfile.provider.DocumentFile
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * FlClash 物理果冻弹簧常量 + Apple Liquid Glass 液态玻璃二级展开动效参数
 */
private const val JELLY_DAMPING = 0.44f
private const val PAGE_SPRING_DAMPING = 0.58f
private const val JELLY_STIFFNESS = 350f

/**
 * Apple 液态玻璃二级弹出菜单枚举：
 * 点击任意一级按钮后，以果冻弹簧从按钮所在象限展开对应的第二层液态玻璃面板；点击任意空白区域自动缩回按钮本身
 */
private enum class LiquidGlassLayer2Menu {
    NONE,
    PASSWORD_BOOK_PANEL,   // 左上：解压密码与常用密码本二级面板
    RENAME_TEMPLATE_PANEL, // 右上：存相册批量重命名二级面板
    QUEUE_SORT_PANEL,      // 左下：图片列表排序与筛选二级面板
    READER_PRESET_PANEL,   // 右下：阅读模式（条漫/单页/双页跨页）与音量键翻页二级面板
    FAB_QUICK_HUB,         // 右下角液态玻璃快捷菜单（导入压缩包/打开阅读器/一键存相册/一键分享/清空）
    READER_CONTROL_PANEL   // 阅读器右上角液态玻璃二级控制面板
}

@Composable
fun FlClashM3Theme(
    useDynamicColor: Boolean = true,
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val colorScheme = when {
        useDynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> darkColorScheme(
            primary = Color(0xFF8AB4F8),
            onPrimary = Color(0xFF002E6B),
            primaryContainer = Color(0xFF1E3A5F),
            onPrimaryContainer = Color(0xFFD3E3FD),
            secondary = Color(0xFFBCC7DC),
            secondaryContainer = Color(0xFF283141),
            onSecondaryContainer = Color(0xFFD8E3F8),
            tertiary = Color(0xFF81C995),
            tertiaryContainer = Color(0xFF0F5223),
            onTertiaryContainer = Color(0xFFCEEAD6),
            background = Color(0xFF0F1116),
            surface = Color(0xFF0F1116),
            surfaceContainerLow = Color(0xFF171A21),
            surfaceContainer = Color(0xFF1D212A),
            surfaceContainerHigh = Color(0xFF262B36),
            outlineVariant = Color(0xFF343A46)
        )
        else -> lightColorScheme(
            primary = Color(0xFF1A73E8),
            onPrimary = Color.White,
            primaryContainer = Color(0xFFD3E3FD),
            onPrimaryContainer = Color(0xFF041E49),
            secondary = Color(0xFF535F70),
            secondaryContainer = Color(0xFFD7E3F7),
            onSecondaryContainer = Color(0xFF101C2B),
            tertiary = Color(0xFF188038),
            tertiaryContainer = Color(0xFFCEEAD6),
            onTertiaryContainer = Color(0xFF072711),
            background = Color(0xFFF5F7FB),
            surface = Color(0xFFF5F7FB),
            surfaceContainerLow = Color(0xFFFFFFFF),
            surfaceContainer = Color(0xFFEEF2F8),
            surfaceContainerHigh = Color(0xFFE2E8F2),
            outlineVariant = Color(0xFFD5DCE6)
        )
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}

/**
 * FlClash 果冻按压回弹修饰符
 */
private fun Modifier.flClashJellyClick(
    enabled: Boolean = true,
    pressScale: Float = 0.90f,
    shape: Shape = RoundedCornerShape(18.dp),
    onClick: () -> Unit
): Modifier = composed {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (enabled && isPressed) pressScale else 1f,
        animationSpec = spring(
            dampingRatio = if (isPressed) 0.6f else 0.40f,
            stiffness = if (isPressed) 650f else 330f
        ),
        label = "JellyClickScale"
    )
    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clip(shape)
        .clickable(
            interactionSource = interactionSource,
            indication = LocalIndication.current,
            enabled = enabled,
            onClick = onClick
        )
}

/**
 * Apple Liquid Glass 液态玻璃表面卡片（半透明高光折射描边 + 柔和通透底色）
 */
@Composable
private fun LiquidGlassSurfaceCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 22.dp,
    isHighlighted: Boolean = false,
    containerColor: Color = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.92f),
    content: @Composable () -> Unit
) {
    val primaryColor = MaterialTheme.colorScheme.primary
    val outlineColor = MaterialTheme.colorScheme.outlineVariant
    val glassBorderBrush = remember(isHighlighted, primaryColor, outlineColor) {
        if (isHighlighted) {
            Brush.linearGradient(
                colors = listOf(
                    primaryColor.copy(alpha = 0.85f),
                    Color.White.copy(alpha = 0.55f),
                    primaryColor.copy(alpha = 0.45f)
                )
            )
        } else {
            Brush.linearGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.35f),
                    outlineColor.copy(alpha = 0.55f),
                    outlineColor.copy(alpha = 0.30f)
                )
            )
        }
    }

    OutlinedCard(
        shape = RoundedCornerShape(cornerRadius),
        colors = CardDefaults.outlinedCardColors(containerColor = containerColor),
        border = BorderStroke(if (isHighlighted) 1.5.dp else 1.dp, glassBorderBrush),
        elevation = CardDefaults.outlinedCardElevation(defaultElevation = 0.dp),
        modifier = modifier
    ) {
        content()
    }
}

/**
 * 一级液态玻璃胶囊按钮（点击后 Q 弹展开第二层液态玻璃面板，点击空白处缩回）
 */
@Composable
private fun LiquidGlassTriggerTile(
    icon: ImageVector,
    title: String,
    valueText: String,
    isActive: Boolean,
    enabled: Boolean = true,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val activeScale by animateFloatAsState(
        targetValue = if (isActive) 1.03f else 1f,
        animationSpec = spring(dampingRatio = JELLY_DAMPING, stiffness = JELLY_STIFFNESS),
        label = "TriggerTileActiveScale"
    )

    val bgColor by animateColorAsState(
        targetValue = if (isActive) {
            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.92f)
        } else {
            MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.90f)
        },
        animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = JELLY_STIFFNESS),
        label = "TriggerTileBgColor"
    )

    LiquidGlassSurfaceCard(
        cornerRadius = 18.dp,
        isHighlighted = isActive,
        containerColor = bgColor,
        modifier = modifier
            .graphicsLayer {
                scaleX = activeScale
                scaleY = activeScale
            }
            .flClashJellyClick(
                enabled = enabled,
                pressScale = 0.90f,
                shape = RoundedCornerShape(18.dp),
                onClick = onClick
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isActive) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.75f)
                },
                modifier = Modifier.size(34.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = if (isActive) {
                            MaterialTheme.colorScheme.onPrimary
                        } else {
                            MaterialTheme.colorScheme.onPrimaryContainer
                        },
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = valueText,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (isActive) {
                        MaterialTheme.colorScheme.onPrimaryContainer
                    } else {
                        MaterialTheme.colorScheme.onSurface
                    },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Icon(
                imageVector = if (isActive) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                contentDescription = null,
                tint = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

class MainActivity : ComponentActivity() {

    private var incomingExternalIntent by mutableStateOf<Intent?>(null)
    private var interceptVolumeKeysForReader by mutableStateOf(false)
    private var volumePageStepSignal by mutableIntStateOf(0)
    private var volumePageDirection by mutableIntStateOf(0)

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (interceptVolumeKeysForReader &&
            (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || event.keyCode == KeyEvent.KEYCODE_VOLUME_UP)
        ) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                volumePageDirection = if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) 1 else -1
                volumePageStepSignal++
            }
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null && intent != null) {
            incomingExternalIntent = intent
        }

        addOnNewIntentListener(Consumer { newIntent ->
            incomingExternalIntent = newIntent
        })

        setContent {
            var useDynamicColor by remember { mutableStateOf(true) }
            FlClashM3Theme(useDynamicColor = useDynamicColor) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    FlClashArchiveExtractorReaderApp(
                        externalIntent = incomingExternalIntent,
                        onExternalIntentConsumed = { incomingExternalIntent = null },
                        useDynamicColor = useDynamicColor,
                        onToggleDynamicColor = { useDynamicColor = !useDynamicColor },
                        volumePageStepSignal = volumePageStepSignal,
                        volumePageDirection = volumePageDirection,
                        onUpdateVolumeKeyIntercept = { interceptVolumeKeysForReader = it }
                    )
                }
            }
        }
    }
}

private fun extractUrisFromIntent(intent: Intent): List<Uri> {
    val uris = LinkedHashSet<Uri>()
    when (intent.action) {
        Intent.ACTION_VIEW -> {
            intent.data?.let { uris.add(it) }
        }
        Intent.ACTION_SEND -> {
            val streamUri: Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            }
            streamUri?.let { uris.add(it) }
            intent.data?.let { uris.add(it) }
        }
        Intent.ACTION_SEND_MULTIPLE -> {
            val streamList: java.util.ArrayList<Uri>? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
            }
            streamList?.forEach { uris.add(it) }
        }
    }
    intent.clipData?.let { clip ->
        for (i in 0 until clip.itemCount) {
            clip.getItemAt(i)?.uri?.let { uris.add(it) }
        }
    }
    return uris.toList()
}

@OptIn(
    ExperimentalMaterial3Api::class,
    ExperimentalLayoutApi::class,
    ExperimentalFoundationApi::class,
    ExperimentalAnimationApi::class
)
@Composable
fun FlClashArchiveExtractorReaderApp(
    externalIntent: Intent?,
    onExternalIntentConsumed: () -> Unit,
    useDynamicColor: Boolean,
    onToggleDynamicColor: () -> Unit,
    volumePageStepSignal: Int = 0,
    volumePageDirection: Int = 0,
    onUpdateVolumeKeyIntercept: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val coroutineScope = rememberCoroutineScope()

    // 两大核心工作空间左右滑页 Pager（解压 · 阅读）
    val pagerState = rememberPagerState(
        initialPage = 0,
        pageCount = { ProcessMode.entries.size }
    )
    var pagerScrollJob by remember { mutableStateOf<Job?>(null) }
    val currentMode = ProcessMode.entries[pagerState.currentPage]

    // 当前展开的第二层 Apple 液态玻璃弹出面板（点击空白区域即置为 NONE 缩回按钮）
    var activeLayer2Menu by remember { mutableStateOf(LiquidGlassLayer2Menu.NONE) }

    // 解压出的图片队列与存相册结果映射
    var selectedImages by remember { mutableStateOf<List<SelectedImageItem>>(emptyList()) }
    val exportResults = remember { mutableStateMapOf<Uri, ExportSaveResult>() }
    var lastExportReport by remember { mutableStateOf<BatchExportReport?>(null) }
    var lastImportedArchiveBanner by remember { mutableStateOf<String?>(null) }

    // 大图详情预览弹窗状态
    var inspectedItem by remember { mutableStateOf<SelectedImageItem?>(null) }

    // 1. 常用密码本与默认解压密码状态
    var archivePassword by remember { mutableStateOf("") }
    var savedArchivePasswords by remember {
        mutableStateOf(ImageCompressor.getSavedArchivePasswords(context))
    }

    // 2. 加密压缩包导入密码解锁弹窗状态
    var pendingPasswordArchiveUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var pendingPasswordArchiveNames by remember { mutableStateOf("") }
    var unlockPasswordInput by remember { mutableStateOf("") }
    var unlockPasswordError by remember { mutableStateOf<String?>(null) }
    var jumpToReaderAfterUnlock by remember { mutableStateOf(false) }

    // 3. 批量存相册重命名与自定义目录状态
    var selectedRenameTemplate by remember { mutableStateOf(RenameTemplate.KEEP_ORIGINAL) }
    var customRenamePrefix by remember { mutableStateOf("IMG") }
    var customTreeUri by remember { mutableStateOf<Uri?>(null) }
    var customDirName by remember { mutableStateOf<String?>(null) }

    // 4. 归档阅读器、音量键翻页与队列排序筛选状态
    var readerLayoutMode by remember { mutableStateOf(ReaderLayoutMode.VERTICAL_STRIP) }
    var isImmersiveReader by remember { mutableStateOf(false) }
    var readerVolumeKeyPaging by remember { mutableStateOf(true) }
    var queueSortOrder by remember { mutableStateOf(QueueSortOrder.NAME_ASC) }
    var showOnlyUnsaved by remember { mutableStateOf(false) }

    // 5. 实时解压进度与批量存相册进度状态
    var isExtractingArchive by remember { mutableStateOf(false) }
    var extractDoneCount by remember { mutableIntStateOf(0) }
    var extractTotalCount by remember { mutableIntStateOf(0) }
    var extractCurrentFile by remember { mutableStateOf("") }

    var isSavingBatch by remember { mutableStateOf(false) }
    var completedCount by remember { mutableIntStateOf(0) }
    var totalTaskCount by remember { mutableIntStateOf(0) }
    var activeTaskJob by remember { mutableStateOf<Job?>(null) }

    val displayedQueueImages = remember(
        selectedImages,
        queueSortOrder,
        showOnlyUnsaved,
        exportResults.size
    ) {
        val sorted = ImageCompressor.sortImageQueue(selectedImages, queueSortOrder)
        if (showOnlyUnsaved && exportResults.isNotEmpty()) {
            sorted.filter { exportResults[it.uri]?.isSuccess != true }
        } else {
            sorted
        }
    }

    // 仅当处于「阅读」页、已有图片且未打开二级弹窗时，启用音量上下键翻页拦截
    LaunchedEffect(
        currentMode,
        readerVolumeKeyPaging,
        selectedImages.isNotEmpty(),
        activeLayer2Menu,
        pendingPasswordArchiveUris.isEmpty()
    ) {
        val shouldIntercept = currentMode == ProcessMode.ARCHIVE_READER &&
            readerVolumeKeyPaging &&
            selectedImages.isNotEmpty() &&
            activeLayer2Menu == LiquidGlassLayer2Menu.NONE &&
            pendingPasswordArchiveUris.isEmpty()
        onUpdateVolumeKeyIntercept(shouldIntercept)
    }

    val cancelRunningTask: () -> Unit = {
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        activeTaskJob?.cancel()
        activeTaskJob = null
        isSavingBatch = false
        isExtractingArchive = false
        Toast.makeText(context, "已取消当前任务（已完成项已保留）", Toast.LENGTH_SHORT).show()
    }

    // 动画跳转工作台
    val animateToMode: (ProcessMode) -> Unit = { targetMode ->
        activeLayer2Menu = LiquidGlassLayer2Menu.NONE
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        pagerScrollJob?.cancel()
        pagerScrollJob = coroutineScope.launch {
            pagerState.animateScrollToPage(
                page = targetMode.ordinal,
                animationSpec = spring(
                    dampingRatio = PAGE_SPRING_DAMPING,
                    stiffness = JELLY_STIFFNESS
                )
            )
        }
    }

    // 统一处理压缩包解压导入（含加密检测、主线程节流实时解压进度条、随时取消与密码弹窗）
    val handleArchiveImport: (List<Uri>, String, Boolean) -> Unit = { uris, pwd, openInReader ->
        activeTaskJob?.cancel()
        activeTaskJob = coroutineScope.launch {
            if (openInReader && currentMode != ProcessMode.ARCHIVE_READER) {
                animateToMode(ProcessMode.ARCHIVE_READER)
            }
            isExtractingArchive = true
            extractDoneCount = 0
            extractTotalCount = 0
            extractCurrentFile = ""
            try {
                val summary = ImageCompressor.extractImagesFromArchiveUris(
                    context = context,
                    archiveUris = uris,
                    password = pwd
                ) { done, total, currentName ->
                    coroutineScope.launch(Dispatchers.Main.immediate) {
                        extractDoneCount = done
                        extractTotalCount = total
                        extractCurrentFile = currentName
                    }
                }
                isExtractingArchive = false

                if (summary.needsPassword) {
                    pendingPasswordArchiveUris = summary.pendingUris
                    pendingPasswordArchiveNames = summary.archiveNames.joinToString(", ")
                    unlockPasswordError = if (summary.wrongPassword) "密码不正确，请重新输入" else null
                    jumpToReaderAfterUnlock = openInReader
                } else if (summary.extractedImages.isNotEmpty()) {
                    if (pwd.isNotBlank()) {
                        savedArchivePasswords = ImageCompressor.saveArchivePasswordToHistory(context, pwd)
                    }
                    pendingPasswordArchiveUris = emptyList()
                    unlockPasswordError = null
                    selectedImages = ImageCompressor.sortImageQueue(summary.extractedImages, queueSortOrder)
                    lastImportedArchiveBanner = "${summary.archiveNames.joinToString(", ")} · ${summary.extractedImages.size} 张"
                    exportResults.clear()
                    lastExportReport = null
                    completedCount = 0
                    totalTaskCount = summary.extractedImages.size
                    if (openInReader) {
                        animateToMode(ProcessMode.ARCHIVE_READER)
                    }
                    Toast.makeText(context, "已解压载入 ${summary.extractedImages.size} 张图片", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(
                        context,
                        summary.errorNote ?: "压缩包内未找到支持的图片",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (_: CancellationException) {
                isExtractingArchive = false
            } finally {
                isExtractingArchive = false
            }
        }
    }

    // 响应外部应用「打开方式 / 分享导入」传入的压缩包或图片
    LaunchedEffect(externalIntent) {
        val intentToHandle = externalIntent ?: return@LaunchedEffect
        val incomingUris = extractUrisFromIntent(intentToHandle)
        onExternalIntentConsumed()

        if (incomingUris.isNotEmpty()) {
            val archiveUris = incomingUris.filter { ImageCompressor.isArchiveUri(context, it) }
            val imageUris = incomingUris.filterNot { ImageCompressor.isArchiveUri(context, it) }

            if (archiveUris.isNotEmpty() && imageUris.isEmpty()) {
                // 外部传入压缩包时直接提取并进入「阅读」页，支持带密码压缩包解锁
                handleArchiveImport(archiveUris, archivePassword, true)
            } else {
                val mergedList = mutableListOf<SelectedImageItem>()
                if (archiveUris.isNotEmpty()) {
                    isExtractingArchive = true
                    extractDoneCount = 0
                    extractTotalCount = 0
                    extractCurrentFile = ""
                    val summary = ImageCompressor.extractImagesFromArchiveUris(
                        context = context,
                        archiveUris = archiveUris,
                        password = archivePassword
                    ) { done, total, currentName ->
                        coroutineScope.launch(Dispatchers.Main.immediate) {
                            extractDoneCount = done
                            extractTotalCount = total
                            extractCurrentFile = currentName
                        }
                    }
                    isExtractingArchive = false
                    if (summary.needsPassword) {
                        pendingPasswordArchiveUris = summary.pendingUris
                        pendingPasswordArchiveNames = summary.archiveNames.joinToString(", ")
                        jumpToReaderAfterUnlock = true
                    }
                    mergedList.addAll(summary.extractedImages)
                }
                if (imageUris.isNotEmpty()) {
                    mergedList.addAll(ImageCompressor.inspectImages(context, imageUris))
                }
                if (mergedList.isNotEmpty()) {
                    selectedImages = ImageCompressor.sortImageQueue(mergedList, queueSortOrder)
                    exportResults.clear()
                    lastExportReport = null
                    completedCount = 0
                    totalTaskCount = mergedList.size
                }
            }
        }
    }

    // 1. 压缩包导入启动器
    var openArchiveInReaderFlag by remember { mutableStateOf(false) }
    val pickArchiveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            handleArchiveImport(uris, archivePassword, openArchiveInReaderFlag)
        }
    }

    // 2. 相册选图启动器（供阅读器直接选图阅读）
    val pickMultipleImagesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 50)
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            coroutineScope.launch {
                val inspected = ImageCompressor.inspectImages(context, uris)
                selectedImages = ImageCompressor.sortImageQueue(inspected, queueSortOrder)
                lastImportedArchiveBanner = "相册图片 · ${inspected.size} 张"
                exportResults.clear()
                lastExportReport = null
                completedCount = 0
                totalTaskCount = inspected.size
            }
        }
    }

    // 3. SAF 自定义保存目录选择器
    val pickOutputDirectoryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        if (treeUri != null) {
            runCatching {
                val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(treeUri, takeFlags)
            }
            customTreeUri = treeUri
            val docDir = DocumentFile.fromTreeUri(context, treeUri)
            customDirName = docDir?.name ?: treeUri.lastPathSegment ?: "自定义目录"
            Toast.makeText(context, "存相册目录：$customDirName", Toast.LENGTH_SHORT).show()
        }
    }

    // 一键批量存相册入口
    val triggerBatchSaveToGallery: () -> Unit = {
        if (selectedImages.isNotEmpty()) {
            activeLayer2Menu = LiquidGlassLayer2Menu.NONE
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            isSavingBatch = true
            completedCount = 0
            totalTaskCount = selectedImages.size
            exportResults.clear()
            lastExportReport = null

            val config = GalleryExportConfig(
                renameTemplate = selectedRenameTemplate,
                customRenamePrefix = customRenamePrefix,
                customTreeUri = customTreeUri
            )

            activeTaskJob?.cancel()
            activeTaskJob = coroutineScope.launch {
                try {
                    val report = ImageCompressor.saveBatchToGallery(
                        context = context,
                        items = selectedImages,
                        config = config,
                        onProgress = { done, total, latest ->
                            coroutineScope.launch(Dispatchers.Main.immediate) {
                                completedCount = done
                                totalTaskCount = total
                                exportResults[latest.source.uri] = latest
                            }
                        }
                    )
                    lastExportReport = report
                    isSavingBatch = false
                    val successCount = report.itemResults.count { it.isSuccess }
                    Toast.makeText(
                        context,
                        "已存相册 $successCount / ${report.itemResults.size} 张 (${report.targetFolderLabel})",
                        Toast.LENGTH_SHORT
                    ).show()
                } catch (_: CancellationException) {
                    isSavingBatch = false
                } finally {
                    isSavingBatch = false
                    activeTaskJob = null
                }
            }
        }
    }

    // 单张图片一键保存到系统相册/自定义目录（供阅读器单页与列表卡片单张保存调用）
    val saveSingleImageItemToGallery: (SelectedImageItem) -> Unit = { item ->
        coroutineScope.launch {
            val saved = ImageCompressor.saveSingleImageToGallery(
                context = context,
                sourceUri = item.uri,
                originalDisplayName = item.displayName,
                customTreeUri = customTreeUri
            )
            if (saved != null) {
                exportResults[item.uri] = ExportSaveResult(
                    source = item,
                    isSuccess = true,
                    savedUri = saved.first,
                    savedName = saved.second.substringAfterLast('/'),
                    savedSize = item.originalSize,
                    savedPathLabel = saved.second
                )
                Toast.makeText(context, "已存入相册：${saved.second}", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "保存图片失败", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // 一键分享全部解压图片
    val shareAllExtractedImages: () -> Unit = {
        val savedUris = selectedImages.mapNotNull { exportResults[it.uri]?.savedUri }
        val targetUris = if (savedUris.isNotEmpty()) savedUris else selectedImages.map { it.uri }
        ImageCompressor.shareOutputUris(
            context = context,
            uris = targetUris,
            mimeType = "image/*",
            chooserTitle = "分享解压图片 (${targetUris.size}张)"
        )
    }

    val hasModalOrLayer2 = inspectedItem != null ||
        activeLayer2Menu != LiquidGlassLayer2Menu.NONE ||
        pendingPasswordArchiveUris.isNotEmpty()

    val continuousPagePositionProvider: () -> Float = {
        pagerState.currentPage + pagerState.currentPageOffsetFraction
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth >= 600.dp

        Box(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .then(
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && hasModalOrLayer2) {
                            Modifier.blur(12.dp)
                        } else {
                            Modifier
                        }
                    )
            ) {
                if (isWideScreen && !isImmersiveReader) {
                    FlClashNavigationRail(
                        currentMode = currentMode,
                        selectedCount = selectedImages.size,
                        onSelectMode = animateToMode
                    )
                    VerticalDivider(
                        thickness = 1.dp,
                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                    )
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        containerColor = MaterialTheme.colorScheme.background,
                        topBar = {
                            if (!isImmersiveReader) {
                                FlClashTopBar(
                                    currentMode = currentMode,
                                    selectedCount = selectedImages.size,
                                    customTreeUri = customTreeUri,
                                    useDynamicColor = useDynamicColor,
                                    isBusy = isSavingBatch || isExtractingArchive,
                                    onToggleDynamicColor = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        onToggleDynamicColor()
                                    },
                                    onPickDirectory = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        pickOutputDirectoryLauncher.launch(customTreeUri)
                                    },
                                    onShareAll = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        shareAllExtractedImages()
                                    },
                                    onClearQueue = {
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        selectedImages = emptyList()
                                        exportResults.clear()
                                        lastExportReport = null
                                        lastImportedArchiveBanner = null
                                        completedCount = 0
                                        totalTaskCount = 0
                                    }
                                )
                            }
                        }
                    ) { innerPadding ->
                        HorizontalPager(
                            state = pagerState,
                            userScrollEnabled = !isImmersiveReader,
                            beyondBoundsPageCount = 1,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(if (isImmersiveReader) PaddingValues(0.dp) else innerPadding)
                        ) { pageIndex ->
                            val pageMode = ProcessMode.entries[pageIndex]

                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .graphicsLayer {
                                        val pageOffset = ((pagerState.currentPage - pageIndex) + pagerState.currentPageOffsetFraction)
                                        val absOffset = abs(pageOffset).coerceIn(0f, 1f)
                                        val pageScale = 1f - (absOffset * 0.08f)
                                        val pageAlpha = 1f - (absOffset * 0.28f)
                                        scaleX = pageScale
                                        scaleY = pageScale
                                        alpha = pageAlpha
                                    }
                            ) {
                                if (pageMode == ProcessMode.ARCHIVE_READER) {
                                    // ====== 页签 2：独立归档图片阅读器 ======
                                    FlClashArchiveImageReaderView(
                                        images = displayedQueueImages,
                                        readerLayoutMode = readerLayoutMode,
                                        isImmersive = isImmersiveReader,
                                        archiveBanner = lastImportedArchiveBanner,
                                        hasArchivePassword = archivePassword.isNotBlank(),
                                        isExtracting = isExtractingArchive,
                                        extractDoneCount = extractDoneCount,
                                        extractTotalCount = extractTotalCount,
                                        extractCurrentFile = extractCurrentFile,
                                        volumePageStepSignal = volumePageStepSignal,
                                        volumePageDirection = volumePageDirection,
                                        onCancelExtract = cancelRunningTask,
                                        onToggleImmersive = { isImmersiveReader = !isImmersiveReader },
                                        onToggleLayoutMode = {
                                            val modes = ReaderLayoutMode.entries
                                            val nextIdx = (modes.indexOf(readerLayoutMode) + 1) % modes.size
                                            readerLayoutMode = modes[nextIdx]
                                        },
                                        onOpenReaderLayer2Menu = {
                                            activeLayer2Menu = LiquidGlassLayer2Menu.READER_CONTROL_PANEL
                                        },
                                        onPickArchiveToRead = {
                                            openArchiveInReaderFlag = true
                                            pickArchiveLauncher.launch(arrayOf("*/*"))
                                        },
                                        onPickImagesToRead = {
                                            pickMultipleImagesLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        },
                                        onSaveSingleImage = saveSingleImageItemToGallery,
                                        onShareSingleImage = { item ->
                                            ImageCompressor.shareOutputUris(
                                                context = context,
                                                uris = listOf(exportResults[item.uri]?.savedUri ?: item.uri),
                                                mimeType = item.mimeType,
                                                chooserTitle = item.displayName
                                            )
                                        }
                                    )
                                } else {
                                    // ====== 页签 1：压缩包解压工作台（解压进度条、常用密码、一键存相册、一键分享） ======
                                    LazyColumn(
                                        modifier = Modifier.fillMaxSize(),
                                        contentPadding = PaddingValues(
                                            start = 16.dp,
                                            end = 16.dp,
                                            top = 12.dp,
                                            bottom = 152.dp
                                        ),
                                        verticalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        // 1. FlClash 2x2 Bento 仪表盘卡片（导入压缩包 · 进入阅读器 · 一键存相册/分享 · 保存位置）
                                        item {
                                            FlClashExtractorBentoDashboardGrid(
                                                selectedImages = selectedImages,
                                                exportResultsMap = exportResults,
                                                readerLayoutMode = readerLayoutMode,
                                                customDirName = customDirName,
                                                lastImportedArchiveBanner = lastImportedArchiveBanner,
                                                onPickArchives = {
                                                    openArchiveInReaderFlag = false
                                                    pickArchiveLauncher.launch(arrayOf("*/*"))
                                                },
                                                onOpenReader = {
                                                    animateToMode(ProcessMode.ARCHIVE_READER)
                                                },
                                                onSaveAllToGallery = triggerBatchSaveToGallery,
                                                onShareAll = shareAllExtractedImages,
                                                onPickDirectory = {
                                                    pickOutputDirectoryLauncher.launch(customTreeUri)
                                                },
                                                onResetDirectory = {
                                                    customTreeUri = null
                                                    customDirName = null
                                                }
                                            )
                                        }

                                        // 2. 一级液态玻璃参数按钮矩阵（点击任意胶囊按钮从对应象限弹出二级液态玻璃菜单，点击空白处缩回）
                                        item {
                                            FlClashExtractorLiquidGlassMatrix(
                                                activeMenu = activeLayer2Menu,
                                                archivePassword = archivePassword,
                                                savedPasswordCount = savedArchivePasswords.size,
                                                selectedRenameTemplate = selectedRenameTemplate,
                                                queueSortOrder = queueSortOrder,
                                                readerLayoutMode = readerLayoutMode,
                                                readerVolumeKeyPaging = readerVolumeKeyPaging,
                                                onOpenMenu = { menu ->
                                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                    activeLayer2Menu = if (activeLayer2Menu == menu) {
                                                        LiquidGlassLayer2Menu.NONE
                                                    } else {
                                                        menu
                                                    }
                                                }
                                            )
                                        }

                                        // 3. 实时解压进度条横幅（当已有列表且正在导入新压缩包时展示）
                                        if (isExtractingArchive && selectedImages.isNotEmpty()) {
                                            item {
                                                ExtractionProgressCard(
                                                    extractDoneCount = extractDoneCount,
                                                    extractTotalCount = extractTotalCount,
                                                    extractCurrentFile = extractCurrentFile,
                                                    onCancelExtract = cancelRunningTask
                                                )
                                            }
                                        }

                                        // 4. 批量存相册完成横幅（含一键分享）
                                        if (exportResults.isNotEmpty()) {
                                            item {
                                                BatchExportSummaryBanner(
                                                    selectedImages = selectedImages,
                                                    resultsMap = exportResults,
                                                    exportReport = lastExportReport,
                                                    onShareClick = shareAllExtractedImages
                                                )
                                            }
                                        }

                                        // 5. 解压图片队列或空状态引导卡片（含解压进度条）
                                        if (selectedImages.isEmpty()) {
                                            item {
                                                EmptyExtractorWorkbenchCard(
                                                    isExtracting = isExtractingArchive,
                                                    extractDoneCount = extractDoneCount,
                                                    extractTotalCount = extractTotalCount,
                                                    extractCurrentFile = extractCurrentFile,
                                                    onCancelExtract = cancelRunningTask,
                                                    onPickArchives = {
                                                        openArchiveInReaderFlag = false
                                                        pickArchiveLauncher.launch(arrayOf("*/*"))
                                                    },
                                                    onPickArchivesAndRead = {
                                                        openArchiveInReaderFlag = true
                                                        pickArchiveLauncher.launch(arrayOf("*/*"))
                                                    }
                                                )
                                            }
                                        } else {
                                            item {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 4.dp, vertical = 2.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = "已解压图片 (${displayedQueueImages.size}/${selectedImages.size})",
                                                        style = MaterialTheme.typography.titleSmall,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                    ) {
                                                        if (exportResults.isNotEmpty()) {
                                                            Surface(
                                                                shape = RoundedCornerShape(10.dp),
                                                                color = if (showOnlyUnsaved) {
                                                                    MaterialTheme.colorScheme.primaryContainer
                                                                } else {
                                                                    MaterialTheme.colorScheme.surfaceContainerHigh
                                                                },
                                                                modifier = Modifier.flClashJellyClick(
                                                                    pressScale = 0.88f,
                                                                    shape = RoundedCornerShape(10.dp),
                                                                    onClick = {
                                                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                                        showOnlyUnsaved = !showOnlyUnsaved
                                                                    }
                                                                )
                                                            ) {
                                                                Row(
                                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                                    verticalAlignment = Alignment.CenterVertically,
                                                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                                ) {
                                                                    Icon(
                                                                        imageVector = Icons.Default.FilterAlt,
                                                                        contentDescription = null,
                                                                        tint = MaterialTheme.colorScheme.primary,
                                                                        modifier = Modifier.size(13.dp)
                                                                    )
                                                                    Text(
                                                                        text = if (showOnlyUnsaved) "仅未存相册" else "全部图片",
                                                                        style = MaterialTheme.typography.labelSmall,
                                                                        fontWeight = FontWeight.Bold,
                                                                        color = if (showOnlyUnsaved) {
                                                                            MaterialTheme.colorScheme.onPrimaryContainer
                                                                        } else {
                                                                            MaterialTheme.colorScheme.onSurfaceVariant
                                                                        }
                                                                    )
                                                                }
                                                            }
                                                        }

                                                        Surface(
                                                            shape = RoundedCornerShape(10.dp),
                                                            color = MaterialTheme.colorScheme.secondaryContainer,
                                                            modifier = Modifier.flClashJellyClick(
                                                                pressScale = 0.88f,
                                                                shape = RoundedCornerShape(10.dp),
                                                                onClick = {
                                                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                                    val orders = QueueSortOrder.entries
                                                                    val nextOrder = orders[(orders.indexOf(queueSortOrder) + 1) % orders.size]
                                                                    queueSortOrder = nextOrder
                                                                    selectedImages = ImageCompressor.sortImageQueue(selectedImages, nextOrder)
                                                                }
                                                            )
                                                        ) {
                                                            Row(
                                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                                verticalAlignment = Alignment.CenterVertically,
                                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                            ) {
                                                                Icon(
                                                                    imageVector = Icons.Default.Sort,
                                                                    contentDescription = null,
                                                                    tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                                                    modifier = Modifier.size(13.dp)
                                                                )
                                                                Text(
                                                                    text = queueSortOrder.label,
                                                                    style = MaterialTheme.typography.labelSmall,
                                                                    fontWeight = FontWeight.Bold,
                                                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                            }

                                            items(
                                                items = displayedQueueImages,
                                                key = { it.uri.toString() }
                                            ) { item ->
                                                ExtractedImageItemCard(
                                                    item = item,
                                                    exportResult = exportResults[item.uri],
                                                    modifier = Modifier.animateItemPlacement(
                                                        animationSpec = spring(
                                                            dampingRatio = JELLY_DAMPING,
                                                            stiffness = JELLY_STIFFNESS
                                                        )
                                                    ),
                                                    onCardClick = { inspectedItem = item },
                                                    onSaveSingleClick = { saveSingleImageItemToGallery(item) },
                                                    onShareSingleClick = {
                                                        ImageCompressor.shareOutputUris(
                                                            context = context,
                                                            uris = listOf(exportResults[item.uri]?.savedUri ?: item.uri),
                                                            mimeType = item.mimeType,
                                                            chooserTitle = item.displayName
                                                        )
                                                    },
                                                    onRemoveItem = {
                                                        selectedImages = selectedImages.filterNot { it.uri == item.uri }
                                                        exportResults.remove(item.uri)
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // ====== 底部：右下角液态玻璃双层按钮组 + 悬浮果冻胶囊导航栏 ======
                    if (!isImmersiveReader) {
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            horizontalAlignment = Alignment.End,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (currentMode != ProcessMode.ARCHIVE_READER) {
                                FlClashLiquidGlassFloatingBarActions(
                                    selectedCount = selectedImages.size,
                                    isBusy = isSavingBatch || isExtractingArchive,
                                    isExtracting = isExtractingArchive,
                                    completedCount = if (isExtractingArchive) extractDoneCount else completedCount,
                                    totalTaskCount = if (isExtractingArchive) extractTotalCount else totalTaskCount,
                                    isQuickHubExpanded = activeLayer2Menu == LiquidGlassLayer2Menu.FAB_QUICK_HUB,
                                    onToggleQuickHub = {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        activeLayer2Menu = if (activeLayer2Menu == LiquidGlassLayer2Menu.FAB_QUICK_HUB) {
                                            LiquidGlassLayer2Menu.NONE
                                        } else {
                                            LiquidGlassLayer2Menu.FAB_QUICK_HUB
                                        }
                                    },
                                    onPickArchives = {
                                        openArchiveInReaderFlag = false
                                        pickArchiveLauncher.launch(arrayOf("*/*"))
                                    },
                                    onSaveAllToGallery = triggerBatchSaveToGallery,
                                    onShareAll = shareAllExtractedImages,
                                    onCancelClick = cancelRunningTask
                                )
                            }

                            if (!isWideScreen) {
                                FlClashFloatingLiquidDockBar(
                                    continuousPagePositionProvider = continuousPagePositionProvider,
                                    onSelectMode = animateToMode
                                )
                            }
                        }
                    }
                }
            }

            // ====== Apple 液态玻璃第二层弹出面板（按源按钮象限弹出，点击空白处自动缩回按钮） ======
            LiquidGlassLayer2PopoverHost(
                activeMenu = activeLayer2Menu,
                onDismiss = {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    activeLayer2Menu = LiquidGlassLayer2Menu.NONE
                },
                archivePassword = archivePassword,
                onArchivePasswordChange = { archivePassword = it },
                savedArchivePasswords = savedArchivePasswords,
                onSaveCurrentArchivePassword = {
                    if (archivePassword.isNotBlank()) {
                        savedArchivePasswords = ImageCompressor.saveArchivePasswordToHistory(context, archivePassword)
                        Toast.makeText(context, "已存入常用密码", Toast.LENGTH_SHORT).show()
                    }
                },
                onRemoveArchivePassword = { pwdToRemove ->
                    savedArchivePasswords = ImageCompressor.removeArchivePasswordFromHistory(context, pwdToRemove)
                },
                selectedRenameTemplate = selectedRenameTemplate,
                onSelectRenameTemplate = { selectedRenameTemplate = it },
                customRenamePrefix = customRenamePrefix,
                onCustomRenamePrefixChange = { customRenamePrefix = it },
                queueSortOrder = queueSortOrder,
                onSelectQueueSortOrder = { newOrder ->
                    queueSortOrder = newOrder
                    selectedImages = ImageCompressor.sortImageQueue(selectedImages, newOrder)
                },
                showOnlyUnsaved = showOnlyUnsaved,
                onToggleShowOnlyUnsaved = { showOnlyUnsaved = it },
                readerLayoutMode = readerLayoutMode,
                onSelectReaderLayoutMode = { readerLayoutMode = it },
                readerVolumeKeyPaging = readerVolumeKeyPaging,
                onToggleReaderVolumeKeyPaging = { readerVolumeKeyPaging = it },
                hasExtractedImages = selectedImages.isNotEmpty(),
                onQuickImportArchive = {
                    activeLayer2Menu = LiquidGlassLayer2Menu.NONE
                    openArchiveInReaderFlag = false
                    pickArchiveLauncher.launch(arrayOf("*/*"))
                },
                onQuickOpenArchiveInReader = {
                    activeLayer2Menu = LiquidGlassLayer2Menu.NONE
                    if (selectedImages.isNotEmpty()) {
                        animateToMode(ProcessMode.ARCHIVE_READER)
                    } else {
                        openArchiveInReaderFlag = true
                        pickArchiveLauncher.launch(arrayOf("*/*"))
                    }
                },
                onQuickSaveAllToGallery = {
                    activeLayer2Menu = LiquidGlassLayer2Menu.NONE
                    triggerBatchSaveToGallery()
                },
                onQuickShareAll = {
                    activeLayer2Menu = LiquidGlassLayer2Menu.NONE
                    shareAllExtractedImages()
                },
                onQuickPickDirectory = {
                    activeLayer2Menu = LiquidGlassLayer2Menu.NONE
                    pickOutputDirectoryLauncher.launch(customTreeUri)
                },
                onQuickClearQueue = {
                    activeLayer2Menu = LiquidGlassLayer2Menu.NONE
                    selectedImages = emptyList()
                    exportResults.clear()
                    lastExportReport = null
                    lastImportedArchiveBanner = null
                }
            )

            // ====== 加密压缩包密码解锁液态玻璃弹窗（内置常用密码一键点选填入） ======
            AnimatedVisibility(
                visible = pendingPasswordArchiveUris.isNotEmpty(),
                enter = fadeIn(spring(stiffness = JELLY_STIFFNESS)) +
                    scaleIn(initialScale = 0.76f, animationSpec = spring(dampingRatio = JELLY_DAMPING, stiffness = JELLY_STIFFNESS)),
                exit = fadeOut(spring(stiffness = JELLY_STIFFNESS)) +
                    scaleOut(targetScale = 0.78f, animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = 420f))
            ) {
                ArchivePasswordUnlockModal(
                    archiveNames = pendingPasswordArchiveNames,
                    passwordInput = unlockPasswordInput,
                    errorText = unlockPasswordError,
                    savedPasswords = savedArchivePasswords,
                    onRemoveSavedPassword = { pwd ->
                        savedArchivePasswords = ImageCompressor.removeArchivePasswordFromHistory(context, pwd)
                    },
                    onPasswordChange = {
                        unlockPasswordInput = it
                        unlockPasswordError = null
                    },
                    onDismiss = {
                        pendingPasswordArchiveUris = emptyList()
                        unlockPasswordError = null
                    },
                    onConfirmUnlock = {
                        if (unlockPasswordInput.isBlank()) {
                            unlockPasswordError = "请输入压缩包密码"
                        } else {
                            archivePassword = unlockPasswordInput
                            savedArchivePasswords = ImageCompressor.saveArchivePasswordToHistory(context, unlockPasswordInput)
                            handleArchiveImport(
                                pendingPasswordArchiveUris,
                                unlockPasswordInput,
                                jumpToReaderAfterUnlock
                            )
                        }
                    }
                )
            }

            // ====== Container Transform 卡片展开大图详情预览弹窗（支持一键存相册与一键分享） ======
            AnimatedVisibility(
                visible = inspectedItem != null,
                enter = fadeIn(animationSpec = spring(stiffness = JELLY_STIFFNESS)) +
                    scaleIn(
                        initialScale = 0.78f,
                        animationSpec = spring(
                            dampingRatio = JELLY_DAMPING,
                            stiffness = JELLY_STIFFNESS
                        )
                    ),
                exit = fadeOut(animationSpec = spring(stiffness = JELLY_STIFFNESS)) +
                    scaleOut(
                        targetScale = 0.80f,
                        animationSpec = spring(
                            dampingRatio = PAGE_SPRING_DAMPING,
                            stiffness = 450f
                        )
                    )
            ) {
                val activeItem = inspectedItem
                if (activeItem != null) {
                    ImageDetailPreviewModal(
                        item = activeItem,
                        exportResult = exportResults[activeItem.uri],
                        onDismiss = { inspectedItem = null },
                        onSaveToGallery = { saveSingleImageItemToGallery(activeItem) },
                        onShare = {
                            val targetUri = exportResults[activeItem.uri]?.savedUri ?: activeItem.uri
                            ImageCompressor.shareOutputUris(
                                context = context,
                                uris = listOf(targetUri),
                                mimeType = activeItem.mimeType,
                                chooserTitle = activeItem.displayName
                            )
                        },
                        onOpenInReader = {
                            inspectedItem = null
                            animateToMode(ProcessMode.ARCHIVE_READER)
                        },
                        onRemove = {
                            selectedImages = selectedImages.filterNot { it.uri == activeItem.uri }
                            exportResults.remove(activeItem.uri)
                            inspectedItem = null
                        }
                    )
                }
            }
        }
    }
}

/**
 * 一级液态玻璃 2x2 参数按钮矩阵：
 * 点击任意按钮从对应象限弹出二级玻璃菜单，点击空白处自动缩回按钮
 */
@Composable
private fun FlClashExtractorLiquidGlassMatrix(
    activeMenu: LiquidGlassLayer2Menu,
    archivePassword: String,
    savedPasswordCount: Int,
    selectedRenameTemplate: RenameTemplate,
    queueSortOrder: QueueSortOrder,
    readerLayoutMode: ReaderLayoutMode,
    readerVolumeKeyPaging: Boolean,
    onOpenMenu: (LiquidGlassLayer2Menu) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            LiquidGlassTriggerTile(
                icon = Icons.Default.Password,
                title = "常用密码本",
                valueText = when {
                    archivePassword.isNotBlank() -> "已预设密码"
                    savedPasswordCount > 0 -> "已存 $savedPasswordCount 条密码"
                    else -> "点击管理密码"
                },
                isActive = activeMenu == LiquidGlassLayer2Menu.PASSWORD_BOOK_PANEL,
                modifier = Modifier.weight(1f),
                onClick = { onOpenMenu(LiquidGlassLayer2Menu.PASSWORD_BOOK_PANEL) }
            )
            LiquidGlassTriggerTile(
                icon = Icons.Default.DriveFileRenameOutline,
                title = "存相册命名",
                valueText = selectedRenameTemplate.shortLabel,
                isActive = activeMenu == LiquidGlassLayer2Menu.RENAME_TEMPLATE_PANEL,
                modifier = Modifier.weight(1f),
                onClick = { onOpenMenu(LiquidGlassLayer2Menu.RENAME_TEMPLATE_PANEL) }
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            LiquidGlassTriggerTile(
                icon = Icons.Default.Sort,
                title = "列表排序",
                valueText = queueSortOrder.label,
                isActive = activeMenu == LiquidGlassLayer2Menu.QUEUE_SORT_PANEL,
                modifier = Modifier.weight(1f),
                onClick = { onOpenMenu(LiquidGlassLayer2Menu.QUEUE_SORT_PANEL) }
            )
            LiquidGlassTriggerTile(
                icon = Icons.Default.AutoStories,
                title = "阅读器预设",
                valueText = "${readerLayoutMode.label}${if (readerVolumeKeyPaging) " · 音量翻页" else ""}",
                isActive = activeMenu == LiquidGlassLayer2Menu.READER_PRESET_PANEL,
                modifier = Modifier.weight(1f),
                onClick = { onOpenMenu(LiquidGlassLayer2Menu.READER_PRESET_PANEL) }
            )
        }
    }
}

/**
 * Apple 液态玻璃第二层弹出菜单宿主：
 * - 按一级按钮所在的屏幕象限绑定精准形变锚点（左上 / 右上 / 左下 / 右下 / 阅读器右上 / FAB右下）
 * - 点击面板外部的任意空白区域，面板按原路径缩回按钮本身
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun LiquidGlassLayer2PopoverHost(
    activeMenu: LiquidGlassLayer2Menu,
    onDismiss: () -> Unit,
    archivePassword: String,
    onArchivePasswordChange: (String) -> Unit,
    savedArchivePasswords: List<String>,
    onSaveCurrentArchivePassword: () -> Unit,
    onRemoveArchivePassword: (String) -> Unit,
    selectedRenameTemplate: RenameTemplate,
    onSelectRenameTemplate: (RenameTemplate) -> Unit,
    customRenamePrefix: String,
    onCustomRenamePrefixChange: (String) -> Unit,
    queueSortOrder: QueueSortOrder,
    onSelectQueueSortOrder: (QueueSortOrder) -> Unit,
    showOnlyUnsaved: Boolean,
    onToggleShowOnlyUnsaved: (Boolean) -> Unit,
    readerLayoutMode: ReaderLayoutMode,
    onSelectReaderLayoutMode: (ReaderLayoutMode) -> Unit,
    readerVolumeKeyPaging: Boolean,
    onToggleReaderVolumeKeyPaging: (Boolean) -> Unit,
    hasExtractedImages: Boolean,
    onQuickImportArchive: () -> Unit,
    onQuickOpenArchiveInReader: () -> Unit,
    onQuickSaveAllToGallery: () -> Unit,
    onQuickShareAll: () -> Unit,
    onQuickPickDirectory: () -> Unit,
    onQuickClearQueue: () -> Unit
) {
    var rememberedMenu by remember { mutableStateOf(LiquidGlassLayer2Menu.PASSWORD_BOOK_PANEL) }
    if (activeMenu != LiquidGlassLayer2Menu.NONE) {
        rememberedMenu = activeMenu
    }

    val isFabMenu = rememberedMenu == LiquidGlassLayer2Menu.FAB_QUICK_HUB
    val isReaderMenu = rememberedMenu == LiquidGlassLayer2Menu.READER_CONTROL_PANEL

    val origin = when (rememberedMenu) {
        LiquidGlassLayer2Menu.PASSWORD_BOOK_PANEL -> TransformOrigin(0.24f, 0.28f)
        LiquidGlassLayer2Menu.RENAME_TEMPLATE_PANEL -> TransformOrigin(0.76f, 0.28f)
        LiquidGlassLayer2Menu.QUEUE_SORT_PANEL -> TransformOrigin(0.24f, 0.44f)
        LiquidGlassLayer2Menu.READER_PRESET_PANEL -> TransformOrigin(0.76f, 0.44f)
        LiquidGlassLayer2Menu.READER_CONTROL_PANEL -> TransformOrigin(0.86f, 0.12f)
        LiquidGlassLayer2Menu.FAB_QUICK_HUB -> TransformOrigin(0.92f, 0.90f)
        LiquidGlassLayer2Menu.NONE -> TransformOrigin(0.5f, 0.35f)
    }

    AnimatedVisibility(
        visible = activeMenu != LiquidGlassLayer2Menu.NONE,
        enter = fadeIn(animationSpec = spring(stiffness = JELLY_STIFFNESS)) +
            scaleIn(
                initialScale = 0.62f,
                transformOrigin = origin,
                animationSpec = spring(dampingRatio = JELLY_DAMPING, stiffness = JELLY_STIFFNESS)
            ),
        exit = fadeOut(animationSpec = spring(stiffness = 460f)) +
            scaleOut(
                targetScale = 0.62f,
                transformOrigin = origin,
                animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = 460f)
            )
    ) {
        BackHandler(onBack = onDismiss)

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.28f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss
                )
                .padding(horizontal = 20.dp, vertical = if (isReaderMenu) 64.dp else 88.dp),
            contentAlignment = when {
                isFabMenu -> Alignment.BottomEnd
                isReaderMenu -> Alignment.TopEnd
                else -> Alignment.Center
            }
        ) {
            LiquidGlassSurfaceCard(
                cornerRadius = 26.dp,
                isHighlighted = true,
                containerColor = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.96f),
                modifier = Modifier
                    .widthIn(max = if (isFabMenu) 290.dp else 480.dp)
                    .fillMaxWidth()
                    .shadow(
                        elevation = 16.dp,
                        shape = RoundedCornerShape(26.dp),
                        ambientColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.25f),
                        spotColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.30f)
                    )
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = {}
                    )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateContentSize(
                            animationSpec = spring(
                                dampingRatio = 0.56f,
                                stiffness = JELLY_STIFFNESS
                            )
                        )
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    when (rememberedMenu) {
                        LiquidGlassLayer2Menu.PASSWORD_BOOK_PANEL -> {
                            Layer2Header("解压密码与常用密码本", "支持 ZIP / CBZ / 7Z / RAR 解锁", onDismiss)
                            OutlinedTextField(
                                value = archivePassword,
                                onValueChange = onArchivePasswordChange,
                                label = { Text("默认解压密码（选填）") },
                                placeholder = { Text("导入加密包时优先使用此密码自动解锁") },
                                leadingIcon = { Icon(Icons.Default.Password, contentDescription = null) },
                                trailingIcon = {
                                    if (archivePassword.isNotEmpty()) {
                                        IconButton(onClick = { onArchivePasswordChange("") }) {
                                            Icon(Icons.Default.Clear, contentDescription = "清除")
                                        }
                                    }
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                            SavedSecretHistoryChipsRow(
                                label = "常用解压密码",
                                currentInput = archivePassword,
                                savedItems = savedArchivePasswords,
                                onSelect = onArchivePasswordChange,
                                onSaveCurrent = onSaveCurrentArchivePassword,
                                onRemove = onRemoveArchivePassword
                            )
                            if (hasExtractedImages) {
                                HorizontalDivider(thickness = 1.dp, color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    FilledTonalButton(
                                        onClick = onQuickShareAll,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("一键分享全部")
                                    }
                                    Button(
                                        onClick = onQuickSaveAllToGallery,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("一键存相册")
                                    }
                                }
                            }
                        }

                        LiquidGlassLayer2Menu.RENAME_TEMPLATE_PANEL -> {
                            Layer2Header("一键存相册重命名规则", "点击空白处自动收起", onDismiss)
                            FlClashSegmentedRow(
                                items = RenameTemplate.entries,
                                selectedItem = selectedRenameTemplate,
                                itemLabel = { it.shortLabel },
                                onItemSelected = onSelectRenameTemplate
                            )
                            if (selectedRenameTemplate == RenameTemplate.PREFIX_INDEX) {
                                OutlinedTextField(
                                    value = customRenamePrefix,
                                    onValueChange = onCustomRenamePrefixChange,
                                    label = { Text("自定义前缀") },
                                    placeholder = { Text("例如：Manga") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }

                        LiquidGlassLayer2Menu.QUEUE_SORT_PANEL -> {
                            Layer2Header("解压列表排序与筛选", "同步决定阅读器页码顺序", onDismiss)
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                QueueSortOrder.entries.forEach { order ->
                                    val selected = queueSortOrder == order
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = if (selected) {
                                            MaterialTheme.colorScheme.primaryContainer
                                        } else {
                                            MaterialTheme.colorScheme.surfaceContainerHigh
                                        },
                                        border = BorderStroke(
                                            1.dp,
                                            if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                                        ),
                                        modifier = Modifier.flClashJellyClick(
                                            pressScale = 0.90f,
                                            shape = RoundedCornerShape(12.dp),
                                            onClick = {
                                                onSelectQueueSortOrder(order)
                                                onDismiss()
                                            }
                                        )
                                    ) {
                                        Text(
                                            text = order.label,
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (selected) {
                                                MaterialTheme.colorScheme.onPrimaryContainer
                                            } else {
                                                MaterialTheme.colorScheme.onSurface
                                            },
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                        )
                                    }
                                }
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onToggleShowOnlyUnsaved(!showOnlyUnsaved) }
                                    .padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("仅显示尚未存入相册的图片", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                    Text("方便筛选未导出的剩余图片", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(checked = showOnlyUnsaved, onCheckedChange = onToggleShowOnlyUnsaved)
                            }
                        }

                        LiquidGlassLayer2Menu.READER_PRESET_PANEL,
                        LiquidGlassLayer2Menu.READER_CONTROL_PANEL -> {
                            Layer2Header("阅读器液态玻璃控制", "支持条漫、单页、双页跨页与音量键翻页", onDismiss)
                            Text("翻页阅读模式", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            FlClashSegmentedRow(
                                items = ReaderLayoutMode.entries,
                                selectedItem = readerLayoutMode,
                                itemLabel = { it.label },
                                onItemSelected = onSelectReaderLayoutMode
                            )

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onToggleReaderVolumeKeyPaging(!readerVolumeKeyPaging) }
                                    .padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("音量上下键翻页", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                    Text("音量下键下一页 · 音量上键上一页", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(checked = readerVolumeKeyPaging, onCheckedChange = onToggleReaderVolumeKeyPaging)
                            }

                            OutlinedTextField(
                                value = archivePassword,
                                onValueChange = onArchivePasswordChange,
                                label = { Text("加密压缩包解锁密码") },
                                placeholder = { Text("若压缩包有密码请在此输入") },
                                leadingIcon = { Icon(Icons.Default.Password, contentDescription = null) },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                            SavedSecretHistoryChipsRow(
                                label = "常用解压密码",
                                currentInput = archivePassword,
                                savedItems = savedArchivePasswords,
                                onSelect = onArchivePasswordChange,
                                onSaveCurrent = onSaveCurrentArchivePassword,
                                onRemove = onRemoveArchivePassword
                            )
                        }

                        LiquidGlassLayer2Menu.FAB_QUICK_HUB -> {
                            Layer2Header("快捷操作中心", "点击空白处自动缩回按钮", onDismiss)
                            LiquidGlassMenuActionRow(
                                icon = Icons.Default.FolderZip,
                                title = "导入压缩包解压 (支持密码)",
                                onClick = onQuickImportArchive
                            )
                            LiquidGlassMenuActionRow(
                                icon = Icons.Default.AutoStories,
                                title = if (hasExtractedImages) "切换到阅读器看图" else "选择压缩包直接阅读",
                                onClick = onQuickOpenArchiveInReader
                            )
                            if (hasExtractedImages) {
                                LiquidGlassMenuActionRow(
                                    icon = Icons.Default.Download,
                                    title = "一键保存全部到相册",
                                    onClick = onQuickSaveAllToGallery
                                )
                                LiquidGlassMenuActionRow(
                                    icon = Icons.Default.Share,
                                    title = "一键分享全部图片",
                                    onClick = onQuickShareAll
                                )
                            }
                            LiquidGlassMenuActionRow(
                                icon = Icons.Outlined.FolderOpen,
                                title = "更改存相册目录",
                                onClick = onQuickPickDirectory
                            )
                            if (hasExtractedImages) {
                                LiquidGlassMenuActionRow(
                                    icon = Icons.Outlined.DeleteSweep,
                                    title = "清空当前解压列表",
                                    onClick = onQuickClearQueue
                                )
                            }
                        }

                        LiquidGlassLayer2Menu.NONE -> Unit
                    }
                }
            }
        }
    }
}

@Composable
private fun Layer2Header(
    title: String,
    subtitle: String,
    onClose: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
        }
        IconButton(onClick = onClose, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Close, contentDescription = "收起", modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun LiquidGlassMenuActionRow(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .flClashJellyClick(
                pressScale = 0.92f,
                shape = RoundedCornerShape(14.dp),
                onClick = onClick
            )
            .background(MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.85f))
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp)
        )
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold
        )
    }
}

/**
 * 常用密码本胶囊条（支持一键填入、存入当前密码与单条删除）
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SavedSecretHistoryChipsRow(
    label: String,
    currentInput: String,
    savedItems: List<String>,
    onSelect: (String) -> Unit,
    onSaveCurrent: (() -> Unit)? = null,
    onRemove: (String) -> Unit
) {
    if (savedItems.isEmpty() && (onSaveCurrent == null || currentInput.isBlank())) return

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "$label (点选一键填入)",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (onSaveCurrent != null && currentInput.isNotBlank() && currentInput.trim() !in savedItems) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.flClashJellyClick(
                        pressScale = 0.88f,
                        shape = RoundedCornerShape(8.dp),
                        onClick = onSaveCurrent
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.BookmarkAdd,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = "存入常用",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }
        }

        if (savedItems.isNotEmpty()) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                savedItems.forEach { secret ->
                    val isSelected = secret == currentInput
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) {
                            MaterialTheme.colorScheme.primaryContainer
                        } else {
                            MaterialTheme.colorScheme.surfaceContainerHigh
                        },
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                        ),
                        modifier = Modifier.flClashJellyClick(
                            pressScale = 0.90f,
                            shape = RoundedCornerShape(10.dp),
                            onClick = { onSelect(secret) }
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(start = 10.dp, end = 6.dp, top = 5.dp, bottom = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = secret,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) {
                                    MaterialTheme.colorScheme.onPrimaryContainer
                                } else {
                                    MaterialTheme.colorScheme.onSurface
                                },
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "删除此条密码",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier
                                    .size(14.dp)
                                    .clip(CircleShape)
                                    .clickable { onRemove(secret) }
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * 独立压缩包图片阅读器视图（支持加密压缩包密码解锁、解压进度条、条漫 / 单页 / 双页跨页、手势双指缩放弹簧回弹、音量键翻页、页码书签记忆、单页直存相册与分享）
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FlClashArchiveImageReaderView(
    images: List<SelectedImageItem>,
    readerLayoutMode: ReaderLayoutMode,
    isImmersive: Boolean,
    archiveBanner: String?,
    hasArchivePassword: Boolean,
    isExtracting: Boolean,
    extractDoneCount: Int,
    extractTotalCount: Int,
    extractCurrentFile: String,
    volumePageStepSignal: Int = 0,
    volumePageDirection: Int = 0,
    onCancelExtract: () -> Unit,
    onToggleImmersive: () -> Unit,
    onToggleLayoutMode: () -> Unit,
    onOpenReaderLayer2Menu: () -> Unit,
    onPickArchiveToRead: () -> Unit,
    onPickImagesToRead: () -> Unit,
    onSaveSingleImage: (SelectedImageItem) -> Unit,
    onShareSingleImage: (SelectedImageItem) -> Unit
) {
    val context = LocalContext.current
    val extractProgressTarget = if (extractTotalCount > 0) {
        (extractDoneCount.toFloat() / extractTotalCount.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }
    val animatedExtractProgress by animateFloatAsState(
        targetValue = extractProgressTarget,
        animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = JELLY_STIFFNESS),
        label = "ReaderExtractProgress"
    )

    if (images.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            LiquidGlassSurfaceCard(
                cornerRadius = 24.dp,
                isHighlighted = isExtracting,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(64.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (isExtracting) Icons.Default.Unarchive else Icons.Default.AutoStories,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(30.dp)
                            )
                        }
                    }
                    Text(
                        text = if (isExtracting) "正在解压压缩包..." else "压缩包图片阅读器",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    if (isExtracting) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = when {
                                        extractTotalCount > 0 -> "已解压 $extractDoneCount / $extractTotalCount 张"
                                        extractDoneCount > 0 -> "已解压 $extractDoneCount 张"
                                        else -> "正在读取压缩包索引..."
                                    },
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                if (extractTotalCount > 0) {
                                    Text(
                                        text = "${(animatedExtractProgress * 100).roundToInt()}%",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                            if (extractTotalCount > 0) {
                                LinearProgressIndicator(
                                    progress = { animatedExtractProgress },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp)),
                                    color = MaterialTheme.colorScheme.primary,
                                    trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                                )
                            } else {
                                LinearProgressIndicator(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp)),
                                    color = MaterialTheme.colorScheme.primary,
                                    trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                                )
                            }
                            if (extractCurrentFile.isNotBlank()) {
                                Text(
                                    text = extractCurrentFile,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            FilledTonalButton(
                                onClick = onCancelExtract,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("取消解压")
                            }
                        }
                    } else {
                        Text(
                            text = "直接阅读 .zip · .cbz · .7z · .rar · .tar.gz 内的图片，支持常用密码解锁、条漫/双页跨页与单页存相册",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = onPickArchiveToRead,
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Default.FolderZip, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("打开压缩包")
                            }
                            FilledTonalButton(
                                onClick = onPickImagesToRead,
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("选择图片")
                            }
                        }
                    }
                }
            }
        }
        return
    }

    val listState = rememberLazyListState()
    val readerPagerState = rememberPagerState(
        initialPage = 0,
        pageCount = { images.size }
    )
    val doubleSpreadPairs = remember(images) { images.chunked(2) }
    val spreadPagerState = rememberPagerState(
        initialPage = 0,
        pageCount = { doubleSpreadPairs.size.coerceAtLeast(1) }
    )
    val coroutineScope = rememberCoroutineScope()

    val archiveBookmarkKey = remember(archiveBanner, images.firstOrNull()?.uri) {
        archiveBanner?.substringBefore(" · ")?.trim()?.takeIf { it.isNotBlank() }
            ?: images.firstOrNull()?.fromArchiveName
            ?: images.firstOrNull()?.displayName
            ?: ""
    }

    val currentPageIndex = when (readerLayoutMode) {
        ReaderLayoutMode.VERTICAL_STRIP ->
            listState.firstVisibleItemIndex.coerceIn(0, (images.size - 1).coerceAtLeast(0))
        ReaderLayoutMode.HORIZONTAL_PAGER ->
            readerPagerState.currentPage.coerceIn(0, (images.size - 1).coerceAtLeast(0))
        ReaderLayoutMode.DOUBLE_PAGE_LTR, ReaderLayoutMode.DOUBLE_PAGE_RTL ->
            (spreadPagerState.currentPage * 2).coerceIn(0, (images.size - 1).coerceAtLeast(0))
    }

    // 响应手机音量上下键翻页
    LaunchedEffect(volumePageStepSignal) {
        if (volumePageStepSignal > 0 && volumePageDirection != 0 && images.isNotEmpty()) {
            when (readerLayoutMode) {
                ReaderLayoutMode.VERTICAL_STRIP -> {
                    val target = (listState.firstVisibleItemIndex + volumePageDirection)
                        .coerceIn(0, images.size - 1)
                    listState.animateScrollToItem(target)
                }
                ReaderLayoutMode.HORIZONTAL_PAGER -> {
                    val target = (readerPagerState.currentPage + volumePageDirection)
                        .coerceIn(0, images.size - 1)
                    readerPagerState.animateScrollToPage(
                        page = target,
                        animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = JELLY_STIFFNESS)
                    )
                }
                ReaderLayoutMode.DOUBLE_PAGE_LTR, ReaderLayoutMode.DOUBLE_PAGE_RTL -> {
                    val targetSpread = (spreadPagerState.currentPage + volumePageDirection)
                        .coerceIn(0, (doubleSpreadPairs.size - 1).coerceAtLeast(0))
                    spreadPagerState.animateScrollToPage(
                        page = targetSpread,
                        animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = JELLY_STIFFNESS)
                    )
                }
            }
        }
    }

    // 打开压缩包时自动恢复到上次阅读页码
    var hasRestoredBookmarkForKey by remember(archiveBookmarkKey, images.size) { mutableStateOf(false) }
    LaunchedEffect(archiveBookmarkKey, images.size) {
        if (!hasRestoredBookmarkForKey && archiveBookmarkKey.isNotBlank() && images.size > 1) {
            hasRestoredBookmarkForKey = true
            val savedPage = ImageCompressor.getReaderBookmark(context, archiveBookmarkKey)
            if (savedPage in 1 until images.size) {
                listState.scrollToItem(savedPage)
                readerPagerState.scrollToPage(savedPage)
                spreadPagerState.scrollToPage((savedPage / 2).coerceIn(0, (doubleSpreadPairs.size - 1).coerceAtLeast(0)))
                Toast.makeText(
                    context,
                    "已恢复至上次阅读位置：第 ${savedPage + 1} / ${images.size} 页",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    // 翻页/滑动时自动保存当前阅读页码书签
    LaunchedEffect(currentPageIndex, archiveBookmarkKey) {
        if (hasRestoredBookmarkForKey && archiveBookmarkKey.isNotBlank() && images.size > 1) {
            ImageCompressor.saveReaderBookmark(context, archiveBookmarkKey, currentPageIndex)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        when (readerLayoutMode) {
            ReaderLayoutMode.VERTICAL_STRIP -> {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(
                        top = if (isImmersive) 0.dp else 64.dp,
                        bottom = if (isImmersive) 64.dp else 148.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    itemsIndexed(
                        items = images,
                        key = { _, item -> item.uri.toString() }
                    ) { idx, item ->
                        ReaderZoomablePageItem(
                            uri = item.uri,
                            pageLabel = "${idx + 1} / ${images.size} · ${item.displayName}",
                            isVerticalMode = true,
                            onTapPage = onToggleImmersive,
                            onSavePage = { onSaveSingleImage(item) },
                            onSharePage = { onShareSingleImage(item) }
                        )
                    }
                }
            }

            ReaderLayoutMode.HORIZONTAL_PAGER -> {
                HorizontalPager(
                    state = readerPagerState,
                    beyondBoundsPageCount = 1,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(
                            top = if (isImmersive) 0.dp else 58.dp,
                            bottom = if (isImmersive) 0.dp else 90.dp
                        )
                ) { idx ->
                    val item = images[idx]
                    ReaderZoomablePageItem(
                        uri = item.uri,
                        pageLabel = "${idx + 1} / ${images.size} · ${item.displayName}",
                        isVerticalMode = false,
                        onTapPage = onToggleImmersive,
                        onSavePage = { onSaveSingleImage(item) },
                        onSharePage = { onShareSingleImage(item) }
                    )
                }
            }

            ReaderLayoutMode.DOUBLE_PAGE_LTR, ReaderLayoutMode.DOUBLE_PAGE_RTL -> {
                val isRtlManga = readerLayoutMode == ReaderLayoutMode.DOUBLE_PAGE_RTL
                HorizontalPager(
                    state = spreadPagerState,
                    beyondBoundsPageCount = 1,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(
                            top = if (isImmersive) 0.dp else 58.dp,
                            bottom = if (isImmersive) 0.dp else 90.dp
                        )
                ) { spreadIdx ->
                    val pair = doubleSpreadPairs.getOrNull(spreadIdx) ?: emptyList()
                    val orderedPair = if (isRtlManga && pair.size == 2) {
                        listOf(pair[1], pair[0])
                    } else {
                        pair
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        orderedPair.forEach { item ->
                            val realPageIdx = images.indexOf(item).coerceAtLeast(0)
                            Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                                ReaderZoomablePageItem(
                                    uri = item.uri,
                                    pageLabel = "P.${realPageIdx + 1}",
                                    isVerticalMode = false,
                                    onTapPage = onToggleImmersive,
                                    onSavePage = { onSaveSingleImage(item) },
                                    onSharePage = { onShareSingleImage(item) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // 顶部液态玻璃阅读器悬浮控制条
        LiquidGlassSurfaceCard(
            cornerRadius = 20.dp,
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.90f),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = "${currentPageIndex + 1} / ${images.size}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        Text(
                            text = archiveBanner ?: images[currentPageIndex].displayName,
                            style = MaterialTheme.typography.labelMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            modifier = Modifier.flClashJellyClick(
                                pressScale = 0.88f,
                                shape = RoundedCornerShape(10.dp),
                                onClick = onToggleLayoutMode
                            )
                        ) {
                            Text(
                                text = readerLayoutMode.label,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                            )
                        }

                        IconButton(onClick = onPickArchiveToRead, modifier = Modifier.size(32.dp)) {
                            Icon(
                                imageVector = Icons.Default.FolderZip,
                                contentDescription = "打开其他压缩包",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        IconButton(onClick = onOpenReaderLayer2Menu, modifier = Modifier.size(32.dp)) {
                            Icon(
                                imageVector = if (hasArchivePassword) Icons.Default.Key else Icons.Default.Tune,
                                contentDescription = "阅读设置与常用密码",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        IconButton(onClick = onToggleImmersive, modifier = Modifier.size(32.dp)) {
                            Icon(
                                imageVector = if (isImmersive) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                                contentDescription = "全屏阅读",
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                AnimatedVisibility(visible = isExtracting) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 12.dp, end = 12.dp, bottom = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = when {
                                    extractTotalCount > 0 -> "正在解压 ($extractDoneCount/$extractTotalCount) · $extractCurrentFile"
                                    extractDoneCount > 0 -> "正在解压 ($extractDoneCount 张) · $extractCurrentFile"
                                    else -> "正在解析压缩包条目..."
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            if (extractTotalCount > 0) {
                                Text(
                                    text = "${(animatedExtractProgress * 100).roundToInt()}%",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                        if (extractTotalCount > 0) {
                            LinearProgressIndicator(
                                progress = { animatedExtractProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = MaterialTheme.colorScheme.primary,
                                trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                            )
                        } else {
                            LinearProgressIndicator(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = MaterialTheme.colorScheme.primary,
                                trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                            )
                        }
                    }
                }
            }
        }

        if (isImmersive && images.size > 1) {
            LiquidGlassSurfaceCard(
                cornerRadius = 20.dp,
                containerColor = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.90f),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("${currentPageIndex + 1}", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Slider(
                        value = currentPageIndex.toFloat(),
                        onValueChange = { target ->
                            val targetIdx = target.roundToInt().coerceIn(0, images.size - 1)
                            coroutineScope.launch {
                                when (readerLayoutMode) {
                                    ReaderLayoutMode.VERTICAL_STRIP -> listState.scrollToItem(targetIdx)
                                    ReaderLayoutMode.HORIZONTAL_PAGER -> readerPagerState.scrollToPage(targetIdx)
                                    ReaderLayoutMode.DOUBLE_PAGE_LTR, ReaderLayoutMode.DOUBLE_PAGE_RTL ->
                                        spreadPagerState.scrollToPage((targetIdx / 2).coerceIn(0, (doubleSpreadPairs.size - 1).coerceAtLeast(0)))
                                }
                            }
                        },
                        valueRange = 0f..(images.size - 1).toFloat(),
                        modifier = Modifier.weight(1f)
                    )
                    Text("${images.size}", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

@Composable
private fun ReaderZoomablePageItem(
    uri: Uri,
    pageLabel: String,
    isVerticalMode: Boolean,
    onTapPage: () -> Unit,
    onSavePage: () -> Unit,
    onSharePage: () -> Unit
) {
    var scale by remember(uri) { mutableFloatStateOf(1f) }
    var offsetX by remember(uri) { mutableFloatStateOf(0f) }
    var offsetY by remember(uri) { mutableFloatStateOf(0f) }
    var boxWidthPx by remember { mutableIntStateOf(0) }
    var boxHeightPx by remember { mutableIntStateOf(0) }

    val animatedScale by animateFloatAsState(
        targetValue = scale,
        animationSpec = spring(dampingRatio = JELLY_DAMPING, stiffness = JELLY_STIFFNESS),
        label = "ReaderPageZoom"
    )
    val animatedOffsetX by animateFloatAsState(
        targetValue = offsetX,
        animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = 420f),
        label = "ReaderPagePanX"
    )
    val animatedOffsetY by animateFloatAsState(
        targetValue = offsetY,
        animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = 420f),
        label = "ReaderPagePanY"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (isVerticalMode) Modifier else Modifier.fillMaxHeight())
            .clip(RoundedCornerShape(if (isVerticalMode) 8.dp else 14.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerLow)
            .onSizeChanged {
                boxWidthPx = it.width
                boxHeightPx = it.height
            }
            .pointerInput(uri) {
                detectTapGestures(
                    onDoubleTap = { tapOffset ->
                        if (scale > 1.05f) {
                            scale = 1f
                            offsetX = 0f
                            offsetY = 0f
                        } else {
                            val targetZoom = 2.25f
                            scale = targetZoom
                            if (boxWidthPx > 0 && boxHeightPx > 0) {
                                val centerX = boxWidthPx / 2f
                                val centerY = boxHeightPx / 2f
                                val maxDx = (boxWidthPx * (targetZoom - 1f)) / 2f
                                val maxDy = (boxHeightPx * (targetZoom - 1f)) / 2f
                                offsetX = ((centerX - tapOffset.x) * 1.1f).coerceIn(-maxDx, maxDx)
                                offsetY = ((centerY - tapOffset.y) * 1.1f).coerceIn(-maxDy, maxDy)
                            }
                        }
                    },
                    onTap = { onTapPage() }
                )
            }
            .then(
                if (!isVerticalMode || scale > 1.01f) {
                    Modifier.pointerInput(uri, boxWidthPx, boxHeightPx) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            val newScale = (scale * zoom).coerceIn(1f, 3.5f)
                            scale = newScale
                            if (newScale > 1.02f) {
                                val maxDx = if (boxWidthPx > 0) (boxWidthPx * (newScale - 1f)) / 2f else 1200f
                                val maxDy = if (boxHeightPx > 0) (boxHeightPx * (newScale - 1f)) / 2f else 1600f
                                offsetX = (offsetX + pan.x).coerceIn(-maxDx, maxDx)
                                offsetY = (offsetY + pan.y).coerceIn(-maxDy, maxDy)
                            } else {
                                scale = 1f
                                offsetX = 0f
                                offsetY = 0f
                            }
                        }
                    }
                } else {
                    Modifier
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = uri,
            contentDescription = pageLabel,
            contentScale = if (isVerticalMode) ContentScale.FillWidth else ContentScale.Fit,
            modifier = Modifier
                .fillMaxWidth()
                .graphicsLayer {
                    scaleX = animatedScale
                    scaleY = animatedScale
                    translationX = animatedOffsetX
                    translationY = animatedOffsetY
                }
        )

        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color.Black.copy(alpha = 0.52f)
            ) {
                Text(
                    text = pageLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
            Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.52f),
                modifier = Modifier
                    .size(28.dp)
                    .clickable { onSavePage() }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = "一键存相册",
                        tint = Color.White,
                        modifier = Modifier.size(15.dp)
                    )
                }
            }
            Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.52f),
                modifier = Modifier
                    .size(28.dp)
                    .clickable { onSharePage() }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "一键分享此页",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

/**
 * 加密压缩包密码解锁液态玻璃弹窗（内置常用密码一键点选填入）
 */
@Composable
private fun ArchivePasswordUnlockModal(
    archiveNames: String,
    passwordInput: String,
    errorText: String?,
    savedPasswords: List<String> = emptyList(),
    onRemoveSavedPassword: (String) -> Unit = {},
    onPasswordChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onConfirmUnlock: () -> Unit
) {
    var passwordVisible by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismiss
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        LiquidGlassSurfaceCard(
            cornerRadius = 26.dp,
            isHighlighted = true,
            modifier = Modifier
                .widthIn(max = 420.dp)
                .fillMaxWidth()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {}
                )
        ) {
            Column(
                modifier = Modifier.padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "压缩包受密码保护",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = archiveNames,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                OutlinedTextField(
                    value = passwordInput,
                    onValueChange = onPasswordChange,
                    label = { Text("输入压缩包密码") },
                    singleLine = true,
                    isError = errorText != null,
                    visualTransformation = if (passwordVisible) {
                        VisualTransformation.None
                    } else {
                        PasswordVisualTransformation()
                    },
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = "切换密码可见"
                            )
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                if (savedPasswords.isNotEmpty()) {
                    SavedSecretHistoryChipsRow(
                        label = "常用解锁密码",
                        currentInput = passwordInput,
                        savedItems = savedPasswords,
                        onSelect = onPasswordChange,
                        onSaveCurrent = null,
                        onRemove = onRemoveSavedPassword
                    )
                }

                if (errorText != null) {
                    Text(
                        text = errorText,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FilledTonalButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("取消")
                    }
                    Button(
                        onClick = onConfirmUnlock,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("解锁并打开")
                    }
                }
            }
        }
    }
}

/**
 * 右下角液态玻璃双层启动按钮组：
 * 左侧为圆形液态玻璃二级快捷菜单钮，右侧为 FlClash 主胶囊（空闲时「导入压缩包」/「一键存相册」，运行时「X / Y · 点击取消」）
 */
@OptIn(ExperimentalAnimationApi::class)
@Composable
private fun FlClashLiquidGlassFloatingBarActions(
    selectedCount: Int,
    isBusy: Boolean,
    isExtracting: Boolean,
    completedCount: Int,
    totalTaskCount: Int,
    isQuickHubExpanded: Boolean,
    onToggleQuickHub: () -> Unit,
    onPickArchives: () -> Unit,
    onSaveAllToGallery: () -> Unit,
    onShareAll: () -> Unit,
    onCancelClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        val hubRotation by animateFloatAsState(
            targetValue = if (isQuickHubExpanded) 45f else 0f,
            animationSpec = spring(dampingRatio = JELLY_DAMPING, stiffness = JELLY_STIFFNESS),
            label = "QuickHubRotate"
        )
        LiquidGlassSurfaceCard(
            cornerRadius = 22.dp,
            isHighlighted = isQuickHubExpanded,
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.94f),
            modifier = Modifier
                .size(46.dp)
                .shadow(
                    elevation = 8.dp,
                    shape = CircleShape,
                    ambientColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                    spotColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)
                )
                .flClashJellyClick(
                    enabled = true,
                    pressScale = 0.85f,
                    shape = CircleShape,
                    onClick = onToggleQuickHub
                )
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "展开二级快捷菜单",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier
                        .size(22.dp)
                        .graphicsLayer { rotationZ = hubRotation }
                )
            }
        }

        // 当已解压出图片且未在执行后台任务时，并排提供「一键分享」液态玻璃胶囊按钮
        AnimatedVisibility(visible = selectedCount > 0 && !isBusy) {
            LiquidGlassSurfaceCard(
                cornerRadius = 22.dp,
                containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.94f),
                modifier = Modifier
                    .shadow(
                        elevation = 6.dp,
                        shape = RoundedCornerShape(22.dp),
                        ambientColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                        spotColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
                    )
                    .flClashJellyClick(
                        enabled = true,
                        pressScale = 0.88f,
                        shape = RoundedCornerShape(22.dp),
                        onClick = onShareAll
                    )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "一键分享",
                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "一键分享",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
            }
        }

        val containerColor by animateColorAsState(
            targetValue = when {
                isBusy -> MaterialTheme.colorScheme.tertiaryContainer
                selectedCount == 0 -> MaterialTheme.colorScheme.primary
                else -> MaterialTheme.colorScheme.primary
            },
            animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = JELLY_STIFFNESS),
            label = "RunFabColor"
        )

        val contentColor = when {
            isBusy -> MaterialTheme.colorScheme.onTertiaryContainer
            else -> MaterialTheme.colorScheme.onPrimary
        }

        Box(
            modifier = Modifier
                .shadow(
                    elevation = 8.dp,
                    shape = RoundedCornerShape(22.dp),
                    ambientColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.25f),
                    spotColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.30f)
                )
                .flClashJellyClick(
                    enabled = true,
                    pressScale = 0.88f,
                    shape = RoundedCornerShape(22.dp),
                    onClick = {
                        when {
                            isBusy -> onCancelClick()
                            selectedCount == 0 -> onPickArchives()
                            else -> onSaveAllToGallery()
                        }
                    }
                )
                .background(containerColor)
                .border(
                    width = 1.dp,
                    color = Color.White.copy(alpha = 0.35f),
                    shape = RoundedCornerShape(22.dp)
                )
                .padding(horizontal = 18.dp, vertical = 12.dp)
        ) {
            AnimatedContent(
                targetState = Triple(selectedCount, isBusy, isExtracting),
                transitionSpec = {
                    (scaleIn(
                        initialScale = 0.85f,
                        animationSpec = spring(dampingRatio = JELLY_DAMPING, stiffness = JELLY_STIFFNESS)
                    ) + fadeIn()).togetherWith(
                        scaleOut(targetScale = 0.85f) + fadeOut()
                    )
                },
                label = "FlClashFabTextMorph"
            ) { (count, busy, extracting) ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val icon = when {
                        busy -> Icons.Default.Close
                        count == 0 -> Icons.Default.FolderZip
                        else -> Icons.Default.Download
                    }
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = contentColor,
                        modifier = Modifier.size(19.dp)
                    )

                    val text = when {
                        busy && extracting ->
                            if (totalTaskCount > 0) "解压 $completedCount/$totalTaskCount · 取消" else "解压中 · 取消"
                        busy ->
                            if (totalTaskCount > 0) "存相册 $completedCount/$totalTaskCount · 取消" else "保存中 · 取消"
                        count == 0 -> "导入压缩包"
                        else -> "一键存相册 ($count)"
                    }

                    Text(
                        text = text,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = contentColor
                    )
                }
            }
        }
    }
}

/**
 * 底部悬浮果冻胶囊导航栏 (2个核心页签：解压 · 阅读)
 */
@Composable
private fun FlClashFloatingLiquidDockBar(
    continuousPagePositionProvider: () -> Float,
    onSelectMode: (ProcessMode) -> Unit
) {
    val tabCount = ProcessMode.entries.size
    val continuousPagePosition = continuousPagePositionProvider()
    var barWidthPx by remember { mutableIntStateOf(0) }
    var isDraggingBar by remember { mutableStateOf(false) }
    var dragFractionPosition by remember { mutableFloatStateOf(continuousPagePosition) }
    var pressedTabIndex by remember { mutableIntStateOf(-1) }

    val targetFraction = if (isDraggingBar) {
        dragFractionPosition.coerceIn(0f, (tabCount - 1).toFloat())
    } else {
        continuousPagePosition.coerceIn(0f, (tabCount - 1).toFloat())
    }

    val animatedTabPosition by animateFloatAsState(
        targetValue = targetFraction,
        animationSpec = spring(
            dampingRatio = if (isDraggingBar) 0.72f else JELLY_DAMPING,
            stiffness = if (isDraggingBar) 650f else 330f
        ),
        label = "FloatingDockJellyPosition"
    )

    val dockScale by animateFloatAsState(
        targetValue = if (isDraggingBar || pressedTabIndex != -1) 1.025f else 1f,
        animationSpec = spring(dampingRatio = 0.42f, stiffness = 360f),
        label = "FloatingDockOuterScale"
    )

    val motionDelta = abs(targetFraction - animatedTabPosition).coerceIn(0f, 1f)
    val pillStretchX = 1f + (motionDelta * 0.34f)
    val pillSquishY = 1f - (motionDelta * 0.14f)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .graphicsLayer {
                scaleX = dockScale
                scaleY = dockScale
            }
            .shadow(
                elevation = 10.dp,
                shape = RoundedCornerShape(28.dp),
                ambientColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                spotColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
            )
            .clip(RoundedCornerShape(28.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.94f))
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.40f),
                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)
                    )
                ),
                shape = RoundedCornerShape(28.dp)
            )
            .onSizeChanged { barWidthPx = it.width }
            .pointerInput(barWidthPx) {
                if (barWidthPx <= 0) return@pointerInput
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val startFrac = ((down.position.x / barWidthPx.toFloat()) * tabCount - 0.5f)
                        .coerceIn(0f, (tabCount - 1).toFloat())
                    var currentFrac = startFrac
                    var hasDragged = false
                    var lastTriggeredIdx = ((down.position.x / barWidthPx.toFloat()) * tabCount)
                        .toInt()
                        .coerceIn(0, tabCount - 1)
                    pressedTabIndex = lastTriggeredIdx

                    do {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull() ?: break
                        if (change.pressed) {
                            val dx = abs(change.position.x - down.position.x)
                            if (dx > 5f) {
                                hasDragged = true
                                isDraggingBar = true
                            }
                            if (hasDragged) {
                                change.consume()
                                currentFrac = ((change.position.x / barWidthPx.toFloat()) * tabCount - 0.5f)
                                    .coerceIn(0f, (tabCount - 1).toFloat())
                                dragFractionPosition = currentFrac
                                val hoveredIdx = ((change.position.x / barWidthPx.toFloat()) * tabCount)
                                    .toInt()
                                    .coerceIn(0, tabCount - 1)
                                pressedTabIndex = hoveredIdx
                                if (hoveredIdx != lastTriggeredIdx) {
                                    lastTriggeredIdx = hoveredIdx
                                    onSelectMode(ProcessMode.entries[hoveredIdx])
                                }
                            }
                        }
                    } while (event.changes.any { it.pressed })

                    pressedTabIndex = -1
                    if (hasDragged) {
                        isDraggingBar = false
                        val finalIdx = currentFrac.roundToInt().coerceIn(0, tabCount - 1)
                        onSelectMode(ProcessMode.entries[finalIdx])
                    } else {
                        val tappedIdx = ((down.position.x / barWidthPx.toFloat()) * tabCount)
                            .toInt()
                            .coerceIn(0, tabCount - 1)
                        onSelectMode(ProcessMode.entries[tappedIdx])
                    }
                }
            }
    ) {
        val tabWidthPx = if (barWidthPx > 0) barWidthPx / tabCount else 0
        val tabWidthDp = with(LocalDensity.current) { tabWidthPx.toDp() }

        if (tabWidthPx > 0) {
            val offsetXPx = (animatedTabPosition * tabWidthPx).roundToInt()
            Box(
                modifier = Modifier
                    .offset { IntOffset(x = offsetXPx, y = 0) }
                    .width(tabWidthDp)
                    .fillMaxHeight()
                    .padding(horizontal = 6.dp, vertical = 6.dp)
                    .graphicsLayer {
                        scaleX = pillStretchX
                        scaleY = pillSquishY
                    }
                    .clip(RoundedCornerShape(22.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .border(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.45f),
                        shape = RoundedCornerShape(22.dp)
                    )
            )
        }

        Row(modifier = Modifier.fillMaxSize()) {
            ProcessMode.entries.forEachIndexed { index, mode ->
                val distance = abs(animatedTabPosition - index).coerceIn(0f, 1f)
                val isSelected = distance < 0.45f
                val isFingerPressing = pressedTabIndex == index

                val iconScale by animateFloatAsState(
                    targetValue = when {
                        isFingerPressing -> 0.84f
                        isSelected -> 1.16f
                        else -> 0.94f
                    },
                    animationSpec = spring(dampingRatio = 0.40f, stiffness = 380f),
                    label = "DockIconBounceScale"
                )

                val iconLiftY by animateFloatAsState(
                    targetValue = if (isSelected) -3.5f else 0f,
                    animationSpec = spring(dampingRatio = 0.42f, stiffness = 360f),
                    label = "DockIconBounceLift"
                )

                val icon = when (mode) {
                    ProcessMode.ARCHIVE_EXTRACT -> if (isSelected) Icons.Default.FolderZip else Icons.Outlined.FolderZip
                    ProcessMode.ARCHIVE_READER -> if (isSelected) Icons.Default.AutoStories else Icons.Outlined.AutoStories
                }

                val contentColor = if (isSelected) {
                    MaterialTheme.colorScheme.onPrimaryContainer
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = mode.shortTitle,
                        tint = contentColor,
                        modifier = Modifier
                            .size(21.dp)
                            .graphicsLayer {
                                scaleX = iconScale
                                scaleY = iconScale
                                translationY = iconLiftY
                            }
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = mode.shortTitle,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = contentColor
                    )
                }
            }
        }
    }
}

/**
 * FlClash 解压工作台 2x2 Bento 仪表盘卡片组
 */
@Composable
private fun FlClashExtractorBentoDashboardGrid(
    selectedImages: List<SelectedImageItem>,
    exportResultsMap: Map<Uri, ExportSaveResult>,
    readerLayoutMode: ReaderLayoutMode,
    customDirName: String?,
    lastImportedArchiveBanner: String?,
    onPickArchives: () -> Unit,
    onOpenReader: () -> Unit,
    onSaveAllToGallery: () -> Unit,
    onShareAll: () -> Unit,
    onPickDirectory: () -> Unit,
    onResetDirectory: () -> Unit
) {
    val totalOrigBytes = selectedImages.sumOf { it.originalSize }
    val savedCount = selectedImages.count { exportResultsMap[it.uri]?.isSuccess == true }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            LiquidGlassSurfaceCard(
                cornerRadius = 18.dp,
                modifier = Modifier
                    .weight(1f)
                    .flClashJellyClick(onClick = onPickArchives)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (selectedImages.isNotEmpty()) Color(0xFF22C55E) else MaterialTheme.colorScheme.outline
                                    )
                            )
                            Text("解压压缩包", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(
                            imageVector = Icons.Default.FolderZip,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = if (selectedImages.isEmpty()) "导入压缩包" else "${selectedImages.size} 张图片",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = lastImportedArchiveBanner
                            ?: if (selectedImages.isEmpty()) "ZIP / 7Z / RAR / CBZ" else ImageCompressor.formatFileSize(totalOrigBytes),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            LiquidGlassSurfaceCard(
                cornerRadius = 18.dp,
                modifier = Modifier
                    .weight(1f)
                    .flClashJellyClick(onClick = onOpenReader)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("归档阅读器", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Icon(
                            imageVector = Icons.Default.AutoStories,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = if (selectedImages.isNotEmpty()) "阅读 (${selectedImages.size}页)" else "进入阅读器",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "${readerLayoutMode.label} · 自动记忆页码",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            LiquidGlassSurfaceCard(
                cornerRadius = 18.dp,
                modifier = Modifier
                    .weight(1f)
                    .flClashJellyClick(
                        enabled = selectedImages.isNotEmpty(),
                        onClick = {
                            if (savedCount == selectedImages.size && savedCount > 0) {
                                onShareAll()
                            } else {
                                onSaveAllToGallery()
                            }
                        }
                    )
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("存相册与分享", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Icon(
                            imageVector = if (savedCount > 0) Icons.Default.Share else Icons.Default.Download,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = when {
                            selectedImages.isEmpty() -> "待导入"
                            savedCount > 0 -> "已存 $savedCount/${selectedImages.size}"
                            else -> "一键存相册"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (selectedImages.isEmpty()) "解压后可批量保存或分享" else "点击批量保存或向外分享",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            LiquidGlassSurfaceCard(
                cornerRadius = 18.dp,
                modifier = Modifier
                    .weight(1f)
                    .flClashJellyClick(onClick = onPickDirectory)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("保存位置", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (customDirName != null) {
                            Icon(
                                imageVector = Icons.Default.Restore,
                                contentDescription = "重置",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .size(16.dp)
                                    .clickable { onResetDirectory() }
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Outlined.FolderOpen,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Text(
                        text = customDirName ?: "系统相册",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = if (customDirName != null) "自定义目录" else "Pictures/Extracted",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

/**
 * 实时解压进度条横幅卡片（工作台非空时解压新包显示）
 */
@Composable
private fun ExtractionProgressCard(
    extractDoneCount: Int,
    extractTotalCount: Int,
    extractCurrentFile: String,
    onCancelExtract: () -> Unit
) {
    val extractProgressTarget = if (extractTotalCount > 0) {
        (extractDoneCount.toFloat() / extractTotalCount.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }
    val animatedExtractProgress by animateFloatAsState(
        targetValue = extractProgressTarget,
        animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = JELLY_STIFFNESS),
        label = "BannerExtractProgress"
    )

    LiquidGlassSurfaceCard(
        cornerRadius = 18.dp,
        isHighlighted = true,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = when {
                        extractTotalCount > 0 -> "正在解压 ($extractDoneCount / $extractTotalCount 张)"
                        extractDoneCount > 0 -> "正在解压 ($extractDoneCount 张)"
                        else -> "正在读取压缩包索引..."
                    },
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (extractTotalCount > 0) {
                        Text(
                            text = "${(animatedExtractProgress * 100).roundToInt()}%",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.errorContainer,
                        modifier = Modifier.clickable { onCancelExtract() }
                    ) {
                        Text(
                            text = "取消",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }
            if (extractTotalCount > 0) {
                LinearProgressIndicator(
                    progress = { animatedExtractProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                )
            } else {
                LinearProgressIndicator(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                )
            }
            if (extractCurrentFile.isNotBlank()) {
                Text(
                    text = extractCurrentFile,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

/**
 * Q 弹果冻分段选择器
 */
@Composable
private fun <T> FlClashSegmentedRow(
    items: List<T>,
    selectedItem: T,
    itemLabel: (T) -> String,
    enabled: Boolean = true,
    onItemSelected: (T) -> Unit
) {
    val selectedIndex = items.indexOf(selectedItem).coerceAtLeast(0)
    var rowWidthPx by remember { mutableIntStateOf(0) }

    val animatedIndex by animateFloatAsState(
        targetValue = selectedIndex.toFloat(),
        animationSpec = spring(
            dampingRatio = JELLY_DAMPING,
            stiffness = 380f
        ),
        label = "SegmentJellyOffset"
    )

    val stretchDelta = abs(selectedIndex.toFloat() - animatedIndex).coerceIn(0f, 1f)
    val pillScaleX = 1f + (stretchDelta * 0.25f)
    val pillScaleY = 1f - (stretchDelta * 0.12f)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(42.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceContainer)
            .border(
                1.dp,
                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f),
                RoundedCornerShape(14.dp)
            )
            .onSizeChanged { rowWidthPx = it.width }
    ) {
        val itemWidthPx = if (rowWidthPx > 0 && items.isNotEmpty()) rowWidthPx / items.size else 0
        val itemWidthDp = with(LocalDensity.current) { itemWidthPx.toDp() }

        if (itemWidthPx > 0) {
            val offsetXPx = (animatedIndex * itemWidthPx).roundToInt()
            Box(
                modifier = Modifier
                    .offset { IntOffset(x = offsetXPx, y = 0) }
                    .width(itemWidthDp)
                    .fillMaxHeight()
                    .padding(3.dp)
                    .graphicsLayer {
                        scaleX = pillScaleX
                        scaleY = pillScaleY
                    }
                    .clip(RoundedCornerShape(11.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.35f),
                        RoundedCornerShape(11.dp)
                    )
            )
        }

        Row(modifier = Modifier.fillMaxSize()) {
            items.forEach { item ->
                val isSelected = item == selectedItem
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .flClashJellyClick(
                            enabled = enabled,
                            pressScale = 0.88f,
                            shape = RoundedCornerShape(11.dp),
                            onClick = { onItemSelected(item) }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = itemLabel(item),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) {
                            MaterialTheme.colorScheme.onPrimaryContainer
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                }
            }
        }
    }
}

/**
 * 桌面/平板端左侧 M3 NavigationRail
 */
@Composable
private fun FlClashNavigationRail(
    currentMode: ProcessMode,
    selectedCount: Int,
    onSelectMode: (ProcessMode) -> Unit
) {
    NavigationRail(
        containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
        header = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 12.dp, bottom = 8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(44.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Dashboard,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
                if (selectedCount > 0) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Badge(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ) {
                        Text("$selectedCount", modifier = Modifier.padding(horizontal = 4.dp))
                    }
                }
            }
        },
        modifier = Modifier.fillMaxHeight()
    ) {
        Spacer(modifier = Modifier.height(8.dp))
        ProcessMode.entries.forEach { mode ->
            val isSelected = currentMode == mode
            val icon = when (mode) {
                ProcessMode.ARCHIVE_EXTRACT -> if (isSelected) Icons.Default.FolderZip else Icons.Outlined.FolderZip
                ProcessMode.ARCHIVE_READER -> if (isSelected) Icons.Default.AutoStories else Icons.Outlined.AutoStories
            }
            NavigationRailItem(
                selected = isSelected,
                onClick = { onSelectMode(mode) },
                icon = { Icon(imageVector = icon, contentDescription = mode.shortTitle) },
                label = {
                    Text(
                        text = mode.shortTitle,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    selectedTextColor = MaterialTheme.colorScheme.primary,
                    indicatorColor = MaterialTheme.colorScheme.primaryContainer
                ),
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }
    }
}

/**
 * 极简顶栏（含动态取色、保存目录选择、一键分享全部与清空列表）
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FlClashTopBar(
    currentMode: ProcessMode,
    selectedCount: Int,
    customTreeUri: Uri?,
    useDynamicColor: Boolean,
    isBusy: Boolean,
    onToggleDynamicColor: () -> Unit,
    onPickDirectory: () -> Unit,
    onShareAll: () -> Unit,
    onClearQueue: () -> Unit
) {
    Column {
        TopAppBar(
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = currentMode.fullTitle,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                    ) {
                        Text(
                            text = currentMode.shortTitle,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                        )
                    }
                }
            },
            actions = {
                if (selectedCount > 0) {
                    IconButton(onClick = onShareAll) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "一键分享全部",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                IconButton(onClick = onToggleDynamicColor) {
                    Icon(
                        imageVector = if (useDynamicColor) Icons.Default.AutoAwesome else Icons.Outlined.Palette,
                        contentDescription = "动态取色",
                        tint = if (useDynamicColor) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                }

                IconButton(
                    onClick = onPickDirectory,
                    enabled = !isBusy
                ) {
                    Icon(
                        imageVector = Icons.Outlined.FolderOpen,
                        contentDescription = "存相册目录",
                        tint = if (customTreeUri != null) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                }

                if (selectedCount > 0 && !isBusy) {
                    IconButton(onClick = onClearQueue) {
                        Icon(
                            imageVector = Icons.Outlined.DeleteSweep,
                            contentDescription = "清空列表",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.background
            )
        )
        HorizontalDivider(
            thickness = 1.dp,
            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
        )
    }
}

/**
 * 批量存相册完成统计与一键分享接力横幅
 */
@Composable
private fun BatchExportSummaryBanner(
    selectedImages: List<SelectedImageItem>,
    resultsMap: Map<Uri, ExportSaveResult>,
    exportReport: BatchExportReport?,
    onShareClick: () -> Unit
) {
    val successfulResults = selectedImages.mapNotNull { resultsMap[it.uri] }.filter { it.isSuccess }
    if (successfulResults.isEmpty()) return

    val totalSavedBytes = successfulResults.sumOf { it.savedSize }

    LiquidGlassSurfaceCard(
        cornerRadius = 18.dp,
        isHighlighted = true,
        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "已存入相册 (${successfulResults.size}/${selectedImages.size} 张)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                    text = "共 ${ImageCompressor.formatFileSize(totalSavedBytes)} · ${exportReport?.targetFolderLabel ?: "Pictures/Extracted"}",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Button(
                onClick = onShareClick,
                shape = RoundedCornerShape(14.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Icon(Icons.Default.Share, contentDescription = "一键分享", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("一键分享", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

/**
 * 18dp 液态玻璃解压图片列表卡片（内置单张存相册按钮、单张分享按钮与移除按钮）
 */
@Composable
private fun ExtractedImageItemCard(
    item: SelectedImageItem,
    exportResult: ExportSaveResult?,
    modifier: Modifier = Modifier,
    onCardClick: () -> Unit,
    onSaveSingleClick: () -> Unit,
    onShareSingleClick: () -> Unit,
    onRemoveItem: () -> Unit
) {
    val context = LocalContext.current
    val thumbRequest = remember(item.uri) {
        ImageRequest.Builder(context)
            .data(item.uri)
            .size(180, 180)
            .crossfade(false)
            .build()
    }

    LiquidGlassSurfaceCard(
        cornerRadius = 18.dp,
        modifier = modifier
            .fillMaxWidth()
            .flClashJellyClick(
                enabled = true,
                pressScale = 0.93f,
                shape = RoundedCornerShape(18.dp),
                onClick = onCardClick
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainer)
            ) {
                AsyncImage(
                    model = thumbRequest,
                    contentDescription = item.displayName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text(
                    text = item.displayName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                val srcFormatShort = item.mimeType.substringAfterLast('/').uppercase(Locale.ROOT)
                Text(
                    text = "$srcFormatShort · ${item.width}×${item.height} · ${ImageCompressor.formatFileSize(item.originalSize)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (exportResult != null) {
                    if (exportResult.isSuccess) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "已存相册 · ${exportResult.savedPathLabel}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.tertiary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.ErrorOutline,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = exportResult.errorMessage ?: "保存失败",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }

            IconButton(
                onClick = onSaveSingleClick,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Download,
                    contentDescription = "存相册",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
            }

            IconButton(
                onClick = onShareSingleClick,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = "分享",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(17.dp)
                )
            }

            IconButton(
                onClick = onRemoveItem,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "移除",
                    tint = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

/**
 * 大图详情预览液态玻璃弹窗（支持一键存相册、一键分享、在阅读器中打开）
 */
@Composable
private fun ImageDetailPreviewModal(
    item: SelectedImageItem,
    exportResult: ExportSaveResult?,
    onDismiss: () -> Unit,
    onSaveToGallery: () -> Unit,
    onShare: () -> Unit,
    onOpenInReader: () -> Unit,
    onRemove: () -> Unit
) {
    BackHandler(onBack = onDismiss)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.50f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDismiss
            )
            .padding(18.dp),
        contentAlignment = Alignment.Center
    ) {
        LiquidGlassSurfaceCard(
            cornerRadius = 24.dp,
            isHighlighted = true,
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.96f),
            modifier = Modifier
                .widthIn(max = 560.dp)
                .fillMaxWidth()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {}
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.displayName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = exportResult?.savedPathLabel
                                ?: "${item.width}×${item.height} · ${ImageCompressor.formatFileSize(item.originalSize)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(onClick = onSaveToGallery) {
                        Icon(imageVector = Icons.Default.Download, contentDescription = "存相册", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = onShare) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = "分享", tint = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "关闭")
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainer)
                        .border(
                            1.dp,
                            MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                            RoundedCornerShape(16.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = item.uri,
                        contentDescription = item.displayName,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(
                        onClick = onRemove,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("移除")
                    }
                    FilledTonalButton(
                        onClick = onOpenInReader,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("阅读器打开")
                    }
                    Button(
                        onClick = onSaveToGallery,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("存相册")
                    }
                }
            }
        }
    }
}

/**
 * 解压工作台空状态引导与实时解压进度卡片
 */
@Composable
private fun EmptyExtractorWorkbenchCard(
    isExtracting: Boolean = false,
    extractDoneCount: Int = 0,
    extractTotalCount: Int = 0,
    extractCurrentFile: String = "",
    onCancelExtract: () -> Unit = {},
    onPickArchives: () -> Unit,
    onPickArchivesAndRead: () -> Unit
) {
    val extractProgressTarget = if (extractTotalCount > 0) {
        (extractDoneCount.toFloat() / extractTotalCount.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }
    val animatedExtractProgress by animateFloatAsState(
        targetValue = extractProgressTarget,
        animationSpec = spring(dampingRatio = PAGE_SPRING_DAMPING, stiffness = JELLY_STIFFNESS),
        label = "WorkbenchExtractProgress"
    )

    LiquidGlassSurfaceCard(
        cornerRadius = 20.dp,
        isHighlighted = isExtracting,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                modifier = Modifier.size(56.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (isExtracting) Icons.Default.Unarchive else Icons.Outlined.FolderZip,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            Text(
                text = if (isExtracting) "正在解压压缩包..." else "导入压缩包提取图片",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            if (isExtracting) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = when {
                                extractTotalCount > 0 -> "已解压 $extractDoneCount / $extractTotalCount 张"
                                extractDoneCount > 0 -> "已解压 $extractDoneCount 张"
                                else -> "正在读取压缩包索引..."
                            },
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        if (extractTotalCount > 0) {
                            Text(
                                text = "${(animatedExtractProgress * 100).roundToInt()}%",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    if (extractTotalCount > 0) {
                        LinearProgressIndicator(
                            progress = { animatedExtractProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                        )
                    } else {
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = MaterialTheme.colorScheme.surfaceContainerHigh
                        )
                    }
                    if (extractCurrentFile.isNotBlank()) {
                        Text(
                            text = extractCurrentFile,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    FilledTonalButton(
                        onClick = onCancelExtract,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("取消解压")
                    }
                }
            } else {
                Text(
                    text = "支持加密 .zip · .cbz · .7z · .rar · .tar.gz 解压，支持常用密码本、一键存相册与一键分享",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(
                        onClick = onPickArchives,
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FolderZip,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("导入压缩包")
                    }
                    FilledTonalButton(
                        onClick = onPickArchivesAndRead,
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoStories,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("解压并阅读")
                    }
                }
            }
        }
    }
}