package com.example.imagecompressor

import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.compose.runtime.Immutable
import androidx.documentfile.provider.DocumentFile
import com.github.junrar.Archive
import com.github.junrar.rarfile.FileHeader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.apache.commons.compress.PasswordRequiredException
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry
import org.apache.commons.compress.archivers.zip.ZipFile
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import java.io.BufferedInputStream
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.nio.charset.Charset
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.CRC32
import java.util.zip.Inflater
import java.util.zip.InflaterInputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

/**
 * 底部导航栏两大核心工作空间（独立纯净解压与阅读版）：
 * 1. ARCHIVE_EXTRACT：解压工作台（多格式带密码解压、实时解压进度条、列表排序、一键存相册、一键分享）
 * 2. ARCHIVE_READER：归档阅读器（条漫连读 / 单页翻页 / 双页左→右 / 日漫右→左、双指缩放、音量键翻页、页码书签记忆、单页直存相册与分享）
 */
enum class ProcessMode(
    val shortTitle: String,
    val fullTitle: String,
    val subtitle: String
) {
    ARCHIVE_EXTRACT(
        shortTitle = "解压",
        fullTitle = "压缩包解压",
        subtitle = "带密码提取 · 存相册与分享"
    ),
    ARCHIVE_READER(
        shortTitle = "阅读",
        fullTitle = "归档阅读器",
        subtitle = "条漫 · 单页 · 双页跨页看图"
    )
}

/**
 * 阅读器翻页与跨页模式
 */
enum class ReaderLayoutMode(val label: String) {
    VERTICAL_STRIP("条漫连读"),
    HORIZONTAL_PAGER("单页翻页"),
    DOUBLE_PAGE_LTR("双页左→右"),
    DOUBLE_PAGE_RTL("日漫右→左")
}

/**
 * 队列图片排序方式
 */
enum class QueueSortOrder(val label: String) {
    NAME_ASC("名称 A→Z"),
    NAME_DESC("名称 Z→A"),
    SIZE_DESC("体积大→小"),
    SIZE_ASC("体积小→大"),
    RESOLUTION_DESC("分辨率高→低")
}

/**
 * 存相册时的批量重命名模板
 */
enum class RenameTemplate(val label: String, val shortLabel: String) {
    KEEP_ORIGINAL("保留原名", "原文件名"),
    PREFIX_INDEX("前缀 + 序号 (001)", "前缀+序号"),
    DATE_INDEX("日期 + 序号 (001)", "日期+序号")
}

/**
 * 批量存相册配置参数
 */
@Immutable
data class GalleryExportConfig(
    val renameTemplate: RenameTemplate = RenameTemplate.KEEP_ORIGINAL,
    val customRenamePrefix: String = "IMG",
    val customTreeUri: Uri? = null
)

/**
 * 解压或导入的单张图片元数据
 */
@Immutable
data class SelectedImageItem(
    val uri: Uri,
    val displayName: String,
    val originalSize: Long,
    val mimeType: String,
    val width: Int,
    val height: Int,
    val fromArchiveName: String? = null
)

/**
 * 单张图片存相册结果
 */
@Immutable
data class ExportSaveResult(
    val source: SelectedImageItem,
    val isSuccess: Boolean,
    val savedUri: Uri? = null,
    val savedName: String = "",
    val savedSize: Long = 0L,
    val savedPathLabel: String = "",
    val errorMessage: String? = null
)

/**
 * 批量存相册汇总报告
 */
@Immutable
data class BatchExportReport(
    val itemResults: List<ExportSaveResult>,
    val targetFolderLabel: String = "Pictures/Extracted"
)

/**
 * 多格式压缩包解压导入结果汇总（含加密密码检测状态）
 */
@Immutable
data class ArchiveImportSummary(
    val archiveCount: Int,
    val extractedImages: List<SelectedImageItem>,
    val archiveNames: List<String>,
    val needsPassword: Boolean = false,
    val wrongPassword: Boolean = false,
    val pendingUris: List<Uri> = emptyList(),
    val errorNote: String? = null
)

/**
 * 纯 Kotlin 标准 PKWARE ZipCrypto 解密引擎（零外部依赖，兼容全平台加密 ZIP / CBZ）
 */
private class PkwareZipCryptoCipher(passwordBytes: ByteArray) {
    private var k0: Int = 0x12345678
    private var k1: Int = 0x23456789
    private var k2: Int = 0x34567890

    init {
        for (b in passwordBytes) {
            updateKeys(b.toInt() and 0xFF)
        }
    }

    private fun updateKeys(byteVal: Int) {
        k0 = crc32Step(k0, byteVal)
        k1 = (k1 + (k0 and 0xFF)) * 134775813 + 1
        k2 = crc32Step(k2, (k1 ushr 24) and 0xFF)
    }

    private fun magicByte(): Int {
        val t = (k2 and 0xFFFF) or 2
        return ((t * (t xor 1)) ushr 8) and 0xFF
    }

    fun decryptByte(cipherByte: Int): Byte {
        val c = cipherByte and 0xFF
        val plain = c xor magicByte()
        updateKeys(plain)
        return plain.toByte()
    }

    companion object {
        private val CRC_TABLE = IntArray(256).apply {
            for (i in 0 until 256) {
                var r = i
                repeat(8) {
                    r = if ((r and 1) != 0) {
                        (r ushr 1) xor -0x12477ce0 // 0xEDB88320
                    } else {
                        r ushr 1
                    }
                }
                this[i] = r
            }
        }

        private fun crc32Step(oldCrc: Int, byteVal: Int): Int {
            return (oldCrc ushr 8) xor CRC_TABLE[(oldCrc xor byteVal) and 0xFF]
        }
    }
}

object ImageCompressor {

    private val SUPPORTED_IMAGE_EXTENSIONS = setOf(
        "jpg", "jpeg", "png", "webp", "bmp", "heic", "heif"
    )

    private val SUPPORTED_ARCHIVE_EXTENSIONS = setOf(
        "zip", "cbz", "7z", "rar", "cbr", "tar", "gz", "tgz", "bz2", "tbz2", "xz", "txz", "jar", "apk"
    )

    private const val PREFS_READER_BOOKMARKS = "flclash_reader_bookmarks"
    private const val PREFS_SAVED_SECRETS = "flclash_saved_secrets"
    private const val KEY_HISTORY_ARCHIVE_PWD = "history_archive_passwords"

    /**
     * 对解压出的图片列表按指定维度排序（自然文件名顺逆序、文件体积、分辨率像素数）
     */
    fun sortImageQueue(items: List<SelectedImageItem>, order: QueueSortOrder): List<SelectedImageItem> {
        return when (order) {
            QueueSortOrder.NAME_ASC -> items.sortedWith { a, b -> compareNaturalStrings(a.displayName, b.displayName) }
            QueueSortOrder.NAME_DESC -> items.sortedWith { a, b -> compareNaturalStrings(b.displayName, a.displayName) }
            QueueSortOrder.SIZE_DESC -> items.sortedByDescending { it.originalSize }
            QueueSortOrder.SIZE_ASC -> items.sortedBy { it.originalSize }
            QueueSortOrder.RESOLUTION_DESC -> items.sortedByDescending { it.width.toLong() * it.height.toLong() }
        }
    }

    /**
     * 保存阅读器当前压缩包/图集的阅读页码书签
     */
    fun saveReaderBookmark(context: Context, archiveKey: String, pageIndex: Int) {
        if (archiveKey.isBlank() || pageIndex < 0) return
        runCatching {
            context.getSharedPreferences(PREFS_READER_BOOKMARKS, Context.MODE_PRIVATE)
                .edit()
                .putInt(archiveKey, pageIndex)
                .apply()
        }
    }

    /**
     * 读取阅读器上次记录的页码书签（未找到返回 0）
     */
    fun getReaderBookmark(context: Context, archiveKey: String): Int {
        if (archiveKey.isBlank()) return 0
        return runCatching {
            context.getSharedPreferences(PREFS_READER_BOOKMARKS, Context.MODE_PRIVATE)
                .getInt(archiveKey, 0)
                .coerceAtLeast(0)
        }.getOrDefault(0)
    }

    /**
     * 读取保存的常用压缩包密码列表
     */
    fun getSavedArchivePasswords(context: Context): List<String> {
        return runCatching {
            val raw = context.getSharedPreferences(PREFS_SAVED_SECRETS, Context.MODE_PRIVATE)
                .getString(KEY_HISTORY_ARCHIVE_PWD, "") ?: ""
            if (raw.isBlank()) emptyList()
            else raw.split("\u001F").map { it.trim() }.filter { it.isNotEmpty() }
        }.getOrDefault(emptyList())
    }

    /**
     * 保存一条压缩包密码到常用密码本（自动去重并置顶，最多保留 12 条）
     */
    fun saveArchivePasswordToHistory(context: Context, password: String): List<String> {
        val trimmed = password.trim()
        if (trimmed.isEmpty()) return getSavedArchivePasswords(context)
        val updated = (listOf(trimmed) + getSavedArchivePasswords(context).filterNot { it == trimmed }).take(12)
        runCatching {
            context.getSharedPreferences(PREFS_SAVED_SECRETS, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_HISTORY_ARCHIVE_PWD, updated.joinToString("\u001F"))
                .apply()
        }
        return updated
    }

    /**
     * 从常用密码本移除一条压缩包密码
     */
    fun removeArchivePasswordFromHistory(context: Context, password: String): List<String> {
        val updated = getSavedArchivePasswords(context).filterNot { it == password }
        runCatching {
            context.getSharedPreferences(PREFS_SAVED_SECRETS, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_HISTORY_ARCHIVE_PWD, updated.joinToString("\u001F"))
                .apply()
        }
        return updated
    }

    /**
     * 单张图片一键保存到系统相册或自定义目录（供阅读器单页保存与列表卡片单张保存调用）
     */
    suspend fun saveSingleImageToGallery(
        context: Context,
        sourceUri: Uri,
        originalDisplayName: String,
        customTreeUri: Uri? = null
    ): Pair<Uri, String>? = withContext(Dispatchers.IO) {
        runCatching {
            val bytes = when (sourceUri.scheme) {
                "file" -> File(sourceUri.path ?: return@runCatching null).readBytes()
                else -> context.contentResolver.openInputStream(sourceUri)?.use { it.readBytes() }
                    ?: return@runCatching null
            }
            val cleanStem = sanitizeFileName(originalDisplayName.substringBeforeLast('.').ifBlank { "image" })
            val ext = originalDisplayName.substringAfterLast('.', "jpg").lowercase(Locale.ROOT)
            val outName = "${cleanStem}_${System.currentTimeMillis() % 10000}.$ext"
            val mime = guessMimeTypeFromName(outName)
            if (customTreeUri != null) {
                saveToCustomDocumentTree(context, customTreeUri, outName, mime, bytes)
            } else {
                saveToSystemGallery(context, outName, mime, bytes)
            }
        }.getOrNull()
    }

    /**
     * 批量将解压出的图片一键保存到系统相册（Pictures/Extracted）或用户指定的自定义目录
     */
    suspend fun saveBatchToGallery(
        context: Context,
        items: List<SelectedImageItem>,
        config: GalleryExportConfig,
        onProgress: (completedCount: Int, totalCount: Int, latestResult: ExportSaveResult) -> Unit
    ): BatchExportReport = withContext(Dispatchers.IO) {
        val total = items.size
        val results = ArrayList<ExportSaveResult>(total)
        var lastEmitMs = 0L
        var folderLabel = "Pictures/Extracted"

        items.forEachIndexed { index, item ->
            ensureActive()
            val result = exportSingleExtractedImage(context, item, config, index)
            if (result.isSuccess && result.savedPathLabel.isNotBlank()) {
                folderLabel = result.savedPathLabel.substringBeforeLast('/', folderLabel)
            }
            results.add(result)
            val now = System.currentTimeMillis()
            val done = index + 1
            if (done <= 1 || done == total || !result.isSuccess || (now - lastEmitMs) >= 50L) {
                lastEmitMs = now
                onProgress(done, total, result)
            }
        }
        BatchExportReport(
            itemResults = results,
            targetFolderLabel = folderLabel
        )
    }

    private fun exportSingleExtractedImage(
        context: Context,
        item: SelectedImageItem,
        config: GalleryExportConfig,
        sequenceIndex: Int
    ): ExportSaveResult {
        return try {
            val rawBytes = when (item.uri.scheme) {
                "file" -> File(item.uri.path ?: "").readBytes()
                else -> context.contentResolver.openInputStream(item.uri)?.use { it.readBytes() }
                    ?: return ExportSaveResult(
                        source = item,
                        isSuccess = false,
                        errorMessage = "无法读取源文件"
                    )
            }

            val ext = item.displayName.substringAfterLast('.', "jpg").lowercase(Locale.ROOT)
            val outputFileName = buildExportFileName(item, config, sequenceIndex, ext)
            val mimeType = item.mimeType.ifBlank { guessMimeTypeFromName(outputFileName) }

            val (savedUri, locationDesc) = if (config.customTreeUri != null) {
                saveToCustomDocumentTree(
                    context = context,
                    treeUri = config.customTreeUri,
                    fileName = outputFileName,
                    mimeType = mimeType,
                    bytes = rawBytes
                )
            } else {
                saveToSystemGallery(
                    context = context,
                    fileName = outputFileName,
                    mimeType = mimeType,
                    bytes = rawBytes
                )
            }

            ExportSaveResult(
                source = item,
                isSuccess = true,
                savedUri = savedUri,
                savedName = outputFileName,
                savedSize = rawBytes.size.toLong(),
                savedPathLabel = locationDesc
            )
        } catch (e: Exception) {
            ExportSaveResult(
                source = item,
                isSuccess = false,
                errorMessage = e.localizedMessage ?: "保存失败"
            )
        }
    }

    private fun buildExportFileName(
        item: SelectedImageItem,
        config: GalleryExportConfig,
        sequenceIndex: Int,
        effectiveExtension: String
    ): String {
        val rawStem = item.displayName
            .substringBeforeLast('.')
            .ifBlank { "image_${sequenceIndex + 1}" }

        val indexStr = String.format(Locale.US, "%03d", sequenceIndex + 1)
        val dateStr = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val customPrefix = sanitizeFileName(config.customRenamePrefix.trim().ifBlank { "IMG" })

        val coreBase = when (config.renameTemplate) {
            RenameTemplate.KEEP_ORIGINAL -> sanitizeFileName(rawStem)
            RenameTemplate.PREFIX_INDEX -> "${customPrefix}_$indexStr"
            RenameTemplate.DATE_INDEX -> "${dateStr}_$indexStr"
        }

        return "${coreBase}.$effectiveExtension"
    }

    /**
     * 一键向外分享解压出的图片（自动将本地缓存文件转为 MediaStore content:// Uri，无需额外 FileProvider 配置）
     */
    fun shareOutputUris(
        context: Context,
        uris: List<Uri>,
        mimeType: String = "image/*",
        chooserTitle: String = "分享图片"
    ) {
        if (uris.isEmpty()) {
            Toast.makeText(context, "暂无可分享的图片", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val safeUris = ArrayList<Uri>()
            for (u in uris) {
                if (u.scheme == "content") {
                    safeUris.add(u)
                } else if (u.scheme == "file") {
                    val f = File(u.path ?: continue)
                    if (f.exists()) {
                        val exported = runCatching {
                            val bytes = f.readBytes()
                            val mime = guessMimeTypeFromName(f.name)
                            saveToSystemGallery(context, "SHARE_${f.name}", mime, bytes).first
                        }.getOrNull()
                        if (exported != null) {
                            safeUris.add(exported)
                        }
                    }
                }
            }
            if (safeUris.isEmpty()) {
                Toast.makeText(context, "未找到可分享的文件路径", Toast.LENGTH_SHORT).show()
                return
            }

            val intent = if (safeUris.size == 1) {
                Intent(Intent.ACTION_SEND).apply {
                    type = mimeType
                    putExtra(Intent.EXTRA_STREAM, safeUris[0])
                    clipData = ClipData.newRawUri("", safeUris[0])
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                    type = mimeType
                    putParcelableArrayListExtra(Intent.EXTRA_STREAM, safeUris)
                    val clip = ClipData.newRawUri("", safeUris[0])
                    for (i in 1 until safeUris.size) {
                        clip.addItem(ClipData.Item(safeUris[i]))
                    }
                    clipData = clip
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            }
            val chooser = Intent.createChooser(intent, chooserTitle).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            Toast.makeText(context, "调起分享失败: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * 判断某个 Uri 是否为受支持的压缩包格式
     */
    fun isArchiveUri(context: Context, uri: Uri): Boolean {
        val mime = context.contentResolver.getType(uri)?.lowercase(Locale.ROOT) ?: ""
        if (mime.contains("zip") ||
            mime.contains("7z") ||
            mime.contains("rar") ||
            mime.contains("tar") ||
            mime.contains("gzip") ||
            mime.contains("bzip2") ||
            mime.contains("xz") ||
            mime.contains("cbz") ||
            mime.contains("cbr") ||
            mime.contains("compressed")
        ) {
            return true
        }
        val displayName = queryDisplayName(context, uri).lowercase(Locale.ROOT)
        val ext = displayName.substringAfterLast('.', "")
        if (ext in SUPPORTED_ARCHIVE_EXTENSIONS) return true

        val pathSeg = uri.lastPathSegment?.lowercase(Locale.ROOT) ?: ""
        val pathExt = pathSeg.substringAfterLast('.', "")
        return pathExt in SUPPORTED_ARCHIVE_EXTENSIONS
    }

    /**
     * 从一个或多个多格式压缩包（支持加密 .zip / .cbz / .7z / .rar 及 .tar.gz / .xz）中提取所有图片，并实时回调解压进度
     */
    suspend fun extractImagesFromArchiveUris(
        context: Context,
        archiveUris: List<Uri>,
        password: String = "",
        onExtractProgress: ((extractedCount: Int, totalEntries: Int, currentFileName: String) -> Unit)? = null
    ): ArchiveImportSummary = withContext(Dispatchers.IO) {
        val cacheRoot = File(context.cacheDir, "archive_imports").apply {
            if (!exists()) mkdirs()
        }
        val extractedItems = mutableListOf<SelectedImageItem>()
        val archiveNames = mutableListOf<String>()
        val pendingEncryptedUris = mutableListOf<Uri>()
        var needsPassword = false
        var wrongPassword = false
        var lastError: String? = null
        var lastProgressEmitMs = 0L
        val throttledProgress: (Int, Int, String) -> Unit = { done, total, currentName ->
            val now = System.currentTimeMillis()
            if (done <= 1 || done == total || total in 1..80 || (now - lastProgressEmitMs) >= 16L) {
                lastProgressEmitMs = now
                onExtractProgress?.invoke(done, total, currentName)
            }
        }

        archiveUris.forEachIndexed { idx, archiveUri ->
            ensureActive()
            val displayName = queryDisplayName(context, archiveUri).ifBlank {
                "archive_${idx + 1}.zip"
            }
            archiveNames.add(displayName)
            onExtractProgress?.invoke(0, 0, "正在解析: $displayName")

            val batchFolder = File(cacheRoot, "arc_${System.currentTimeMillis()}_$idx").apply {
                mkdirs()
            }

            val lowerName = displayName.lowercase(Locale.ROOT)
            val mime = context.contentResolver.getType(archiveUri)?.lowercase(Locale.ROOT) ?: ""

            try {
                val outcome = when {
                    lowerName.endsWith(".7z") || mime.contains("7z") -> {
                        extractSevenZArchive(context, archiveUri, displayName, batchFolder, password, throttledProgress)
                    }
                    lowerName.endsWith(".rar") || lowerName.endsWith(".cbr") || mime.contains("rar") -> {
                        extractRarArchive(context, archiveUri, displayName, batchFolder, password, throttledProgress)
                    }
                    lowerName.endsWith(".tar.gz") || lowerName.endsWith(".tgz") ||
                        (lowerName.endsWith(".gz") && !lowerName.endsWith(".svgz")) || mime.contains("gzip") -> {
                        SingleArchiveOutcome(
                            items = extractTarStreamArchive(context, archiveUri, displayName, batchFolder, "gz", throttledProgress)
                        )
                    }
                    lowerName.endsWith(".tar.bz2") || lowerName.endsWith(".tbz2") ||
                        lowerName.endsWith(".bz2") || mime.contains("bzip2") -> {
                        SingleArchiveOutcome(
                            items = extractTarStreamArchive(context, archiveUri, displayName, batchFolder, "bz2", throttledProgress)
                        )
                    }
                    lowerName.endsWith(".tar.xz") || lowerName.endsWith(".txz") ||
                        lowerName.endsWith(".xz") || mime.contains("xz") -> {
                        SingleArchiveOutcome(
                            items = extractTarStreamArchive(context, archiveUri, displayName, batchFolder, "xz", throttledProgress)
                        )
                    }
                    lowerName.endsWith(".tar") || mime.contains("tar") -> {
                        SingleArchiveOutcome(
                            items = extractTarStreamArchive(context, archiveUri, displayName, batchFolder, "plain", throttledProgress)
                        )
                    }
                    else -> {
                        extractZipArchiveWithPasswordSupport(context, archiveUri, displayName, batchFolder, password, throttledProgress)
                    }
                }

                if (outcome.needsPassword) {
                    needsPassword = true
                    if (outcome.wrongPassword) wrongPassword = true
                    pendingEncryptedUris.add(archiveUri)
                }
                if (outcome.errorNote != null) {
                    lastError = outcome.errorNote
                }
                extractedItems.addAll(outcome.items)
            } catch (e: Exception) {
                lastError = e.localizedMessage ?: "压缩包解析失败"
            }
        }

        val sortedItems = extractedItems.sortedWith { a, b ->
            compareNaturalStrings(a.displayName, b.displayName)
        }

        ArchiveImportSummary(
            archiveCount = archiveUris.size,
            extractedImages = sortedItems,
            archiveNames = archiveNames,
            needsPassword = needsPassword,
            wrongPassword = wrongPassword,
            pendingUris = if (pendingEncryptedUris.isNotEmpty()) pendingEncryptedUris else archiveUris,
            errorNote = lastError
        )
    }

    private data class SingleArchiveOutcome(
        val items: List<SelectedImageItem> = emptyList(),
        val needsPassword: Boolean = false,
        val wrongPassword: Boolean = false,
        val errorNote: String? = null
    )

    /**
     * 使用 Apache Commons Compress ZipFile + 内置 ZipCrypto 解密引擎解析普通或加密 ZIP / CBZ 压缩包
     */
    @Suppress("DEPRECATION")
    private fun extractZipArchiveWithPasswordSupport(
        context: Context,
        archiveUri: Uri,
        archiveDisplayName: String,
        destFolder: File,
        password: String,
        onExtractProgress: ((extractedCount: Int, totalEntries: Int, currentFileName: String) -> Unit)? = null
    ): SingleArchiveOutcome {
        val tempZip = File(destFolder, "temp_source.zip")
        try {
            context.contentResolver.openInputStream(archiveUri)?.use { input ->
                FileOutputStream(tempZip).use { output ->
                    input.copyTo(output)
                }
            } ?: return SingleArchiveOutcome(errorNote = "无法读取压缩包文件流")

            val outcomeUtf8 = tryExtractCommonsZipFile(tempZip, archiveDisplayName, destFolder, "UTF-8", password, onExtractProgress)
            if (outcomeUtf8.needsPassword || outcomeUtf8.items.isNotEmpty()) {
                return outcomeUtf8
            }

            val outcomeGbk = tryExtractCommonsZipFile(tempZip, archiveDisplayName, destFolder, "GBK", password, onExtractProgress)
            if (outcomeGbk.needsPassword || outcomeGbk.items.isNotEmpty()) {
                return outcomeGbk
            }
        } finally {
            tempZip.delete()
        }

        val fallbackItems = tryExtractZipWithCharset(context, archiveUri, archiveDisplayName, destFolder, Charsets.UTF_8, onExtractProgress)
            ?: tryExtractZipWithCharset(context, archiveUri, archiveDisplayName, destFolder, Charset.forName("GBK"), onExtractProgress)
            ?: emptyList()
        return SingleArchiveOutcome(items = fallbackItems)
    }

    @Suppress("DEPRECATION")
    private fun tryExtractCommonsZipFile(
        tempZip: File,
        archiveDisplayName: String,
        destFolder: File,
        encoding: String,
        password: String,
        onExtractProgress: ((extractedCount: Int, totalEntries: Int, currentFileName: String) -> Unit)? = null
    ): SingleArchiveOutcome {
        val items = mutableListOf<SelectedImageItem>()
        return try {
            ZipFile(tempZip, encoding).use { zipFile ->
                val validEntries = mutableListOf<Triple<ZipArchiveEntry, String, String>>()
                val entriesEnum = zipFile.entries
                while (entriesEnum.hasMoreElements()) {
                    val entry: ZipArchiveEntry = entriesEnum.nextElement()
                    if (entry.isDirectory) continue
                    val rawName = entry.name.replace('\\', '/')
                    val simpleName = rawName.substringAfterLast('/')
                    val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                    if (isValidImageEntry(rawName, simpleName, ext)) {
                        validEntries.add(Triple(entry, rawName, simpleName))
                    }
                }
                val totalEntries = validEntries.size.coerceAtLeast(1)
                var counter = 0

                for ((entry, _, simpleName) in validEntries) {
                    val isEncryptedEntry = entry.generalPurposeBit.usesEncryption() || !zipFile.canReadEntryData(entry)
                    if (isEncryptedEntry) {
                        if (password.isBlank()) {
                            return SingleArchiveOutcome(
                                needsPassword = true,
                                wrongPassword = false,
                                errorNote = "压缩包「$archiveDisplayName」受密码保护"
                            )
                        }
                        val rawEncrypted = zipFile.getRawInputStream(entry)?.use { it.readBytes() }
                            ?: continue
                        val decryptedBytes = decryptPkwareZipEntry(rawEncrypted, entry, password)
                            ?: return SingleArchiveOutcome(
                                needsPassword = true,
                                wrongPassword = true,
                                errorNote = "压缩包密码错误，请重新输入"
                            )
                        counter++
                        val outFile = File(destFolder, "${counter}_${sanitizeFileName(simpleName)}")
                        FileOutputStream(outFile).use { it.write(decryptedBytes) }
                        buildSelectedImageIfValid(outFile, simpleName, archiveDisplayName)?.let {
                            items.add(it)
                            onExtractProgress?.invoke(items.size, totalEntries, simpleName)
                        }
                    } else {
                        counter++
                        val outFile = File(destFolder, "${counter}_${sanitizeFileName(simpleName)}")
                        zipFile.getInputStream(entry)?.use { input ->
                            FileOutputStream(outFile).use { fos ->
                                input.copyTo(fos)
                            }
                        }
                        buildSelectedImageIfValid(outFile, simpleName, archiveDisplayName)?.let {
                            items.add(it)
                            onExtractProgress?.invoke(items.size, totalEntries, simpleName)
                        }
                    }
                }
            }
            SingleArchiveOutcome(items = items)
        } catch (e: Exception) {
            val msg = (e.message ?: "").lowercase(Locale.ROOT)
            if (msg.contains("password") || msg.contains("encrypted")) {
                SingleArchiveOutcome(
                    needsPassword = true,
                    wrongPassword = password.isNotBlank(),
                    errorNote = "压缩包受密码保护"
                )
            } else {
                SingleArchiveOutcome(items = items)
            }
        }
    }

    /**
     * 解密标准 PKWARE ZipCrypto 条目（支持 STORED 与 DEFLATED）
     */
    private fun decryptPkwareZipEntry(
        rawEncryptedBytes: ByteArray,
        entry: ZipArchiveEntry,
        password: String
    ): ByteArray? {
        if (rawEncryptedBytes.size < 12) return null
        val cipher = PkwareZipCryptoCipher(password.toByteArray(Charsets.UTF_8))
        val header = ByteArray(12)
        for (i in 0 until 12) {
            header[i] = cipher.decryptByte(rawEncryptedBytes[i].toInt())
        }

        val payloadLen = rawEncryptedBytes.size - 12
        val decryptedPayload = ByteArray(payloadLen)
        for (i in 0 until payloadLen) {
            decryptedPayload[i] = cipher.decryptByte(rawEncryptedBytes[12 + i].toInt())
        }

        val plainBytes = when (entry.method) {
            ZipEntry.STORED -> decryptedPayload
            ZipEntry.DEFLATED -> {
                runCatching {
                    InflaterInputStream(
                        ByteArrayInputStream(decryptedPayload),
                        Inflater(true)
                    ).use { it.readBytes() }
                }.getOrNull() ?: return null
            }
            else -> return null
        }

        if (entry.crc > 0L) {
            val crc = CRC32()
            crc.update(plainBytes)
            if (crc.value != entry.crc) {
                return null
            }
        }
        return plainBytes
    }

    /**
     * 解析 7z 格式压缩包（支持 AES-256 密码解锁）
     */
    @Suppress("DEPRECATION")
    private fun extractSevenZArchive(
        context: Context,
        archiveUri: Uri,
        archiveDisplayName: String,
        destFolder: File,
        password: String,
        onExtractProgress: ((extractedCount: Int, totalEntries: Int, currentFileName: String) -> Unit)? = null
    ): SingleArchiveOutcome {
        val items = mutableListOf<SelectedImageItem>()
        val tempFile = File(destFolder, "temp_source.7z")
        try {
            context.contentResolver.openInputStream(archiveUri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return SingleArchiveOutcome()

            val sevenZ = if (password.isNotBlank()) {
                SevenZFile(tempFile, password.toCharArray())
            } else {
                SevenZFile(tempFile)
            }

            sevenZ.use { archive ->
                val totalEntries = archive.entries.count { entry ->
                    if (entry.isDirectory) false
                    else {
                        val rawName = entry.name.replace('\\', '/')
                        val simpleName = rawName.substringAfterLast('/')
                        val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                        isValidImageEntry(rawName, simpleName, ext)
                    }
                }.coerceAtLeast(1)

                var entry = archive.nextEntry
                var counter = 0
                val buffer = ByteArray(16 * 1024)
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val rawName = entry.name.replace('\\', '/')
                        val simpleName = rawName.substringAfterLast('/')
                        val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                        if (isValidImageEntry(rawName, simpleName, ext)) {
                            counter++
                            val outFile = File(destFolder, "${counter}_${sanitizeFileName(simpleName)}")
                            if (outFile.canonicalPath.startsWith(destFolder.canonicalPath)) {
                                FileOutputStream(outFile).use { fos ->
                                    var len: Int
                                    while (archive.read(buffer).also { len = it } > 0) {
                                        fos.write(buffer, 0, len)
                                    }
                                    fos.flush()
                                }
                                buildSelectedImageIfValid(outFile, simpleName, archiveDisplayName)?.let {
                                    items.add(it)
                                    onExtractProgress?.invoke(items.size, totalEntries, simpleName)
                                }
                            }
                        }
                    }
                    entry = archive.nextEntry
                }
            }
        } catch (e: PasswordRequiredException) {
            return SingleArchiveOutcome(
                needsPassword = true,
                wrongPassword = password.isNotBlank(),
                errorNote = "7Z 压缩包需要密码解锁"
            )
        } catch (e: Exception) {
            val msg = (e.message ?: "").lowercase(Locale.ROOT)
            if (msg.contains("password") || msg.contains("encrypted") || msg.contains("aes")) {
                return SingleArchiveOutcome(
                    needsPassword = true,
                    wrongPassword = password.isNotBlank(),
                    errorNote = if (password.isNotBlank()) "7Z 密码错误，请重试" else "7Z 压缩包受密码保护"
                )
            }
            return SingleArchiveOutcome(items = items, errorNote = e.localizedMessage)
        } finally {
            tempFile.delete()
        }
        return SingleArchiveOutcome(items = items)
    }

    /**
     * 解析 RAR / CBR 格式压缩包 (兼容 junrar 7.5.5 单参数 Archive(File) 构造器)
     */
    private fun extractRarArchive(
        context: Context,
        archiveUri: Uri,
        archiveDisplayName: String,
        destFolder: File,
        password: String,
        onExtractProgress: ((extractedCount: Int, totalEntries: Int, currentFileName: String) -> Unit)? = null
    ): SingleArchiveOutcome {
        val items = mutableListOf<SelectedImageItem>()
        val tempFile = File(destFolder, "temp_source.rar")
        try {
            context.contentResolver.openInputStream(archiveUri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            } ?: return SingleArchiveOutcome()

            Archive(tempFile).use { archive ->
                val totalEntries = archive.fileHeaders.count { hdr ->
                    if (hdr.isDirectory) false
                    else {
                        val rawName = hdr.fileName.replace('\\', '/')
                        val simpleName = rawName.substringAfterLast('/')
                        val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                        isValidImageEntry(rawName, simpleName, ext)
                    }
                }.coerceAtLeast(1)

                var header: FileHeader? = archive.nextFileHeader()
                var counter = 0
                while (header != null) {
                    val currentHeader = header
                    if (currentHeader.isEncrypted) {
                        return SingleArchiveOutcome(
                            needsPassword = true,
                            wrongPassword = password.isNotBlank(),
                            errorNote = "RAR 压缩包受密码保护（建议使用加密 ZIP 或 7Z 格式）"
                        )
                    }
                    if (!currentHeader.isDirectory) {
                        val rawName = currentHeader.fileName.replace('\\', '/')
                        val simpleName = rawName.substringAfterLast('/')
                        val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                        if (isValidImageEntry(rawName, simpleName, ext)) {
                            counter++
                            val outFile = File(destFolder, "${counter}_${sanitizeFileName(simpleName)}")
                            if (outFile.canonicalPath.startsWith(destFolder.canonicalPath)) {
                                FileOutputStream(outFile).use { fos ->
                                    archive.extractFile(currentHeader, fos)
                                    fos.flush()
                                }
                                buildSelectedImageIfValid(outFile, simpleName, archiveDisplayName)?.let {
                                    items.add(it)
                                    onExtractProgress?.invoke(items.size, totalEntries, simpleName)
                                }
                            }
                        }
                    }
                    header = archive.nextFileHeader()
                }
            }
        } catch (e: Exception) {
            return SingleArchiveOutcome(items = items, errorNote = e.localizedMessage)
        } finally {
            tempFile.delete()
        }
        return SingleArchiveOutcome(items = items)
    }

    /**
     * 解析 TAR / TAR.GZ / TAR.BZ2 / TAR.XZ 流式归档包
     */
    private fun extractTarStreamArchive(
        context: Context,
        archiveUri: Uri,
        archiveDisplayName: String,
        destFolder: File,
        compressionType: String,
        onExtractProgress: ((extractedCount: Int, totalEntries: Int, currentFileName: String) -> Unit)? = null
    ): List<SelectedImageItem> {
        val items = mutableListOf<SelectedImageItem>()
        context.contentResolver.openInputStream(archiveUri)?.use { rawInput ->
            val buffered = BufferedInputStream(rawInput)
            val decompressedStream: InputStream = when (compressionType) {
                "gz" -> GzipCompressorInputStream(buffered)
                "bz2" -> BZip2CompressorInputStream(buffered)
                "xz" -> XZCompressorInputStream(buffered)
                else -> buffered
            }
            TarArchiveInputStream(decompressedStream).use { tarIn ->
                var entry = tarIn.nextEntry
                var counter = 0
                val buffer = ByteArray(16 * 1024)
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val rawName = entry.name.replace('\\', '/')
                        val simpleName = rawName.substringAfterLast('/')
                        val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                        if (isValidImageEntry(rawName, simpleName, ext)) {
                            counter++
                            val outFile = File(destFolder, "${counter}_${sanitizeFileName(simpleName)}")
                            if (outFile.canonicalPath.startsWith(destFolder.canonicalPath)) {
                                FileOutputStream(outFile).use { fos ->
                                    var len: Int
                                    while (tarIn.read(buffer).also { len = it } > 0) {
                                        fos.write(buffer, 0, len)
                                    }
                                    fos.flush()
                                }
                                buildSelectedImageIfValid(outFile, simpleName, archiveDisplayName)?.let {
                                    items.add(it)
                                    onExtractProgress?.invoke(items.size, 0, simpleName)
                                }
                            }
                        }
                    }
                    entry = tarIn.nextEntry
                }
            }
        }
        return items
    }

    private fun tryExtractZipWithCharset(
        context: Context,
        zipUri: Uri,
        zipDisplayName: String,
        destFolder: File,
        charset: Charset,
        onExtractProgress: ((extractedCount: Int, totalEntries: Int, currentFileName: String) -> Unit)? = null
    ): List<SelectedImageItem>? {
        val items = mutableListOf<SelectedImageItem>()
        return try {
            context.contentResolver.openInputStream(zipUri)?.use { rawInput ->
                val zis = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    ZipInputStream(BufferedInputStream(rawInput), charset)
                } else {
                    ZipInputStream(BufferedInputStream(rawInput))
                }

                var entry: ZipEntry? = zis.nextEntry
                var fileCounter = 0
                val buffer = ByteArray(16 * 1024)
                while (entry != null) {
                    val currentEntry = entry
                    if (!currentEntry.isDirectory) {
                        val rawName = currentEntry.name.replace('\\', '/')
                        val simpleName = rawName.substringAfterLast('/')
                        val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)

                        if (isValidImageEntry(rawName, simpleName, ext)) {
                            fileCounter++
                            val outFile = File(destFolder, "${fileCounter}_${sanitizeFileName(simpleName)}")

                            if (outFile.canonicalPath.startsWith(destFolder.canonicalPath)) {
                                FileOutputStream(outFile).use { fos ->
                                    var len: Int
                                    while (zis.read(buffer).also { len = it } > 0) {
                                        fos.write(buffer, 0, len)
                                    }
                                    fos.flush()
                                }
                                buildSelectedImageIfValid(outFile, simpleName, zipDisplayName)?.let {
                                    items.add(it)
                                    onExtractProgress?.invoke(items.size, 0, simpleName)
                                }
                            }
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
            items
        } catch (e: IllegalArgumentException) {
            null
        } catch (e: Exception) {
            items
        }
    }

    private fun isValidImageEntry(rawName: String, simpleName: String, ext: String): Boolean {
        return !simpleName.startsWith("._") &&
            !rawName.contains("__MACOSX/") &&
            ext in SUPPORTED_IMAGE_EXTENSIONS
    }

    private fun sanitizeFileName(simpleName: String): String {
        return buildString {
            for (ch in simpleName) {
                if (ch.isLetterOrDigit() || ch == '.' || ch == '_' || ch == '-') {
                    append(ch)
                } else {
                    append('_')
                }
            }
        }
    }

    private fun compareNaturalStrings(a: String, b: String): Int {
        val reg = Regex("(\\d+)|(\\D+)")
        val partsA = reg.findAll(a.lowercase(Locale.ROOT)).map { it.value }.toList()
        val partsB = reg.findAll(b.lowercase(Locale.ROOT)).map { it.value }.toList()
        val len = minOf(partsA.size, partsB.size)
        for (i in 0 until len) {
            val pa = partsA[i]
            val pb = partsB[i]
            val na = pa.toBigIntegerOrNull()
            val nb = pb.toBigIntegerOrNull()
            val cmp = if (na != null && nb != null) {
                na.compareTo(nb)
            } else {
                pa.compareTo(pb)
            }
            if (cmp != 0) return cmp
        }
        return partsA.size.compareTo(partsB.size)
    }

    private fun buildSelectedImageIfValid(
        outFile: File,
        simpleName: String,
        archiveDisplayName: String
    ): SelectedImageItem? {
        val boundsOptions = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }
        BitmapFactory.decodeFile(outFile.absolutePath, boundsOptions)
        return if (boundsOptions.outWidth > 0 && boundsOptions.outHeight > 0) {
            SelectedImageItem(
                uri = Uri.fromFile(outFile),
                displayName = simpleName,
                originalSize = outFile.length(),
                mimeType = guessMimeTypeFromName(simpleName),
                width = boundsOptions.outWidth,
                height = boundsOptions.outHeight,
                fromArchiveName = archiveDisplayName
            )
        } else {
            outFile.delete()
            null
        }
    }

    /**
     * 读取直接导入的普通图片元数据
     */
    suspend fun inspectImages(context: Context, uris: List<Uri>): List<SelectedImageItem> =
        withContext(Dispatchers.IO) {
            uris.mapNotNull { uri ->
                runCatching {
                    val resolver = context.contentResolver
                    val name = queryDisplayName(context, uri).ifBlank {
                        "image_${System.currentTimeMillis()}.jpg"
                    }
                    var size = 0L

                    resolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                        if (cursor.moveToFirst()) {
                            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                            if (sizeIndex != -1 && !cursor.isNull(sizeIndex)) {
                                size = cursor.getLong(sizeIndex)
                            }
                        }
                    }

                    if (size <= 0L) {
                        resolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                            size = afd.length.coerceAtLeast(0L)
                        }
                    }

                    val mimeType = resolver.getType(uri) ?: guessMimeTypeFromName(name)

                    val boundsOptions = BitmapFactory.Options().apply {
                        inJustDecodeBounds = true
                    }
                    resolver.openInputStream(uri)?.use { input ->
                        BitmapFactory.decodeStream(input, null, boundsOptions)
                    }

                    SelectedImageItem(
                        uri = uri,
                        displayName = name,
                        originalSize = size,
                        mimeType = mimeType,
                        width = boundsOptions.outWidth.coerceAtLeast(0),
                        height = boundsOptions.outHeight.coerceAtLeast(0)
                    )
                }.getOrNull()
            }
        }

    private fun queryDisplayName(context: Context, uri: Uri): String {
        if (uri.scheme == "file") {
            return uri.lastPathSegment ?: ""
        }
        runCatching {
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx != -1 && !cursor.isNull(idx)) {
                        return cursor.getString(idx)
                    }
                }
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: ""
    }

    private fun saveToCustomDocumentTree(
        context: Context,
        treeUri: Uri,
        fileName: String,
        mimeType: String,
        bytes: ByteArray
    ): Pair<Uri, String> {
        val treeDir = DocumentFile.fromTreeUri(context, treeUri)
            ?: throw IllegalStateException("无法访问自定义目录")

        val finalName = if (treeDir.findFile(fileName) != null) {
            val stem = fileName.substringBeforeLast('.')
            val ext = fileName.substringAfterLast('.')
            "${stem}_${System.currentTimeMillis() % 100000}.$ext"
        } else {
            fileName
        }

        val targetFile = treeDir.createFile(mimeType, finalName)
            ?: throw IllegalStateException("无法创建文件: $finalName")

        context.contentResolver.openOutputStream(targetFile.uri, "wt")?.use { output ->
            output.write(bytes)
            output.flush()
        } ?: throw IllegalStateException("无法写入文件")

        val dirName = treeDir.name ?: "自定义目录"
        return targetFile.uri to "$dirName/$finalName"
    }

    private fun saveToSystemGallery(
        context: Context,
        fileName: String,
        mimeType: String,
        bytes: ByteArray
    ): Pair<Uri, String> {
        val resolver = context.contentResolver
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativePath = "${Environment.DIRECTORY_PICTURES}/Extracted"
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, mimeType)
                put(MediaStore.Images.Media.RELATIVE_PATH, relativePath)
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("无法创建相册记录")

            resolver.openOutputStream(uri)?.use { out ->
                out.write(bytes)
                out.flush()
            } ?: throw IllegalStateException("无法写入相册")

            val completeValues = ContentValues().apply {
                put(MediaStore.Images.Media.IS_PENDING, 0)
            }
            resolver.update(uri, completeValues, null, null)
            return uri to "Pictures/Extracted/$fileName"
        } else {
            @Suppress("DEPRECATION")
            val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
            val extractedDir = File(picturesDir, "Extracted").apply {
                if (!exists()) mkdirs()
            }
            val outFile = File(extractedDir, fileName)
            FileOutputStream(outFile).use { out ->
                out.write(bytes)
                out.flush()
            }
            @Suppress("DEPRECATION")
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DATA, outFile.absolutePath)
                put(MediaStore.Images.Media.MIME_TYPE, mimeType)
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: Uri.fromFile(outFile)
            return uri to "Pictures/Extracted/${outFile.name}"
        }
    }

    private fun guessMimeTypeFromName(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        return when (ext) {
            "png" -> "image/png"
            "webp" -> "image/webp"
            "heic", "heif" -> "image/heic"
            "bmp" -> "image/bmp"
            else -> "image/jpeg"
        }
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0L) return "0 KB"
        val kb = bytes / 1024.0
        return if (kb < 1024.0) {
            String.format(Locale.US, "%.1f KB", kb)
        } else {
            val mb = kb / 1024.0
            String.format(Locale.US, "%.2f MB", mb)
        }
    }
}