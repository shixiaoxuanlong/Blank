# Android 批量图片压缩与解码转码应用（含 GitHub Actions 自动编译 APK）

本压缩包已内置 **GitHub Actions 云端自动打包脚本**（`.github/workflows/build.yml`）以及完整的应用图标与源码结构，无需电脑安装 Android Studio，即可在手机上通过 GitHub 在线编译生成可安装的 `.apk` 文件。

## 手机端免电脑编译 APK 步骤（3 分钟搞定）

1. **用 MT 管理器解压本压缩包**：
   - 将本压缩包解压到手机任意文件夹。
2. **新建 GitHub 仓库并上传文件**：
   - 在手机浏览器登录 GitHub，点击右上角 `+` -> **New repository**（名称随意，如 `image-compressor`，勾选 **Add a README file** 后点击 **Create repository**）。
   - 将解压出来的所有文件和文件夹上传到该仓库。
   - *提示*：如果手机浏览器网页端上传时漏掉了隐藏文件夹 `.github`，只需点击仓库顶部的 **Actions** 标签页 -> 点击 **set up a workflow yourself**，把压缩包里的 `.github/workflows/build.yml`（或单独提供的 `build.yml`）内容复制粘贴进去并点击右上角 **Commit changes** 即可。
3. **等待自动编译并下载 APK**：
   - 点击仓库顶部的 **Actions** 标签页，你会看到 `Build Android APK` 正在运行（也可以手动点击 **Run workflow** 触发）。
   - 等待约 2～3 分钟变成绿色对勾后，点进该次运行记录，滑到页面最底部的 **Artifacts** 区域，点击 **`ImageCompressor-Debug-APK`** 即可下载编译好的安装包。
   - 下载下来的 Artifact 压缩包在 MT 管理器里点开，里面就是可直接点击安装的 **`app-debug.apk`**！
