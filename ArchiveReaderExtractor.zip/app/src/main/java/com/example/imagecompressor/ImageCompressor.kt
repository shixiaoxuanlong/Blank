package com.example.imagecompressor

import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.compose.runtime.Immutable
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.CancellationException
import androidx.exifinterface.media.ExifInterface
import com.github.junrar.Archive
import com.github.junrar.rarfile.FileHeader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.apache.commons.compress.PasswordRequiredException
import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry
import org.apache.commons.compress.archivers.zip.ZipFile
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorOutputStream
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.Charset
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.Inflater
import java.util.zip.InflaterInputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * 底部导航栏五大工作空间：
 * 1. COMPRESS_TRANSCODE：画质压缩、尺寸缩放与格式转码
 * 2. OBFUSCATE_ENCRYPT：口令色块加密（自动写入粒度标记）
 * 3. DEOBFUSCATE_RESTORE：口令无损还原（自动识别文件名中的粒度标记）
 * 4. ARCHIVE_HUB：多格式压缩包解压与加密打包
 * 5. ARCHIVE_READER：独立压缩包图片阅读器（支持密码解锁、条漫连读、翻页缩放、口令实时解密预览）
 */
enum class ProcessMode(
    val shortTitle: String,
    val fullTitle: String,
    val subtitle: String
) {
    COMPRESS_TRANSCODE(
        shortTitle = "压缩",
        fullTitle = "画质压缩",
        subtitle = "转码与尺寸缩放"
    ),
    OBFUSCATE_ENCRYPT(
        shortTitle = "混淆",
        fullTitle = "色块混淆",
        subtitle = "口令像素加密"
    ),
    DEOBFUSCATE_RESTORE(
        shortTitle = "还原",
        fullTitle = "无损还原",
        subtitle = "口令逆向还原"
    ),
    ARCHIVE_HUB(
        shortTitle = "解压",
        fullTitle = "文件解压",
        subtitle = "极速解压与批量导出"
    ),
    ARCHIVE_READER(
        shortTitle = "阅读",
        fullTitle = "图集阅读",
        subtitle = "直看加密包与图集"
    );

    companion object {
        val standaloneModes: List<ProcessMode> = listOf(ARCHIVE_HUB, ARCHIVE_READER)
    }
}

/**
 * 归档中心子模式
 */
enum class ArchiveSubMode(val label: String, val desc: String) {
    PACK_TO_ARCHIVE(
        label = "打包归档",
        desc = "封装为压缩包（支持密码）"
    ),
    EXTRACT_FROM_ARCHIVE(
        label = "解压提取",
        desc = "提取并导出图片（支持密码）"
    )
}

/**
 * 阅读器翻页模式
 */
enum class ReaderLayoutMode(val label: String) {
    VERTICAL_STRIP("条漫连读"),
    HORIZONTAL_PAGER("单页翻页"),
    DOUBLE_PAGE_LTR("双页左→右"),
    DOUBLE_PAGE_RTL("日漫右→左")
}

/**
 * 队列图片排序方式
 */
enum class QueueSortOrder(val label: String) {
    NAME_ASC("名称 A→Z"),
    NAME_DESC("名称 Z→A"),
    SIZE_DESC("体积大→小"),
    SIZE_ASC("体积小→大"),
    RESOLUTION_DESC("分辨率高→低")
}

/**
 * 1:1 复刻 FlClash-0.9.1 (lib/views/theme.dart & lib/models/config.dart) 主题设定枚举与数据模型
 */
enum class FlClashThemeMode(val label: String) {
    SYSTEM("自动"),
    LIGHT("浅色"),
    DARK("深色")
}

enum class FlClashColorStyle(val label: String, val desc: String) {
    VIVID("鲜艳 (Vivid)", "保持种子主色，表面呈纯净中性灰"),
    TINTED("浸染 (Tinted)", "保持种子主色，表面带有主色相微染"),
    SOFT("柔和 (Soft)", "柔和低饱和主色与中性灰表面"),
    MONOCHROME("单色 (Mono)", "极简黑白主色与纯灰阶表面")
}

enum class FlClashLiquidGlassMode(val label: String) {
    NONE("关闭"),
    STANDARD("标准"),
    ULTRA("极致")
}

enum class FlClashTabAnimation(val label: String) {
    SLIDE("滑动"),
    FADE("渐隐")
}

@Immutable
data class FlClashThemeProps(
    val themeMode: FlClashThemeMode = FlClashThemeMode.SYSTEM,
    val pureBlack: Boolean = false,
    val primaryColor: Int? = DEFAULT_PRIMARY_COLOR,
    val primaryColors: List<Int> = DEFAULT_PRIMARY_COLORS,
    val colorStyle: FlClashColorStyle = FlClashColorStyle.VIVID,
    val floatingNavigationBar: Boolean = true,
    val tabAnimation: FlClashTabAnimation = FlClashTabAnimation.SLIDE,
    val liquidGlass: FlClashLiquidGlassMode = FlClashLiquidGlassMode.ULTRA
) {
    val isDefault: Boolean
        get() = primaryColor == DEFAULT_PRIMARY_COLOR &&
            primaryColors == DEFAULT_PRIMARY_COLORS &&
            colorStyle == FlClashColorStyle.VIVID &&
            themeMode == FlClashThemeMode.SYSTEM &&
            !pureBlack &&
            floatingNavigationBar &&
            tabAnimation == FlClashTabAnimation.SLIDE &&
            liquidGlass == FlClashLiquidGlassMode.ULTRA

    companion object {
        // FlClash-0.9.1 lib/common/constant.dart: defaultPrimaryColor & Apple macOS accent colors
        const val DEFAULT_PRIMARY_COLOR: Int = 0xFF007AFF.toInt()
        val DEFAULT_PRIMARY_COLORS: List<Int> = listOf(
            0xFF007AFF.toInt(), // iOS Blue
            0xFFAF52DE.toInt(), // Purple
            0xFFFF2D55.toInt(), // Rose Pink
            0xFFFF3B30.toInt(), // Coral Red
            0xFFFF9500.toInt(), // Orange
            0xFFFFCC00.toInt(), // Yellow
            0xFF34C759.toInt(), // Green
            0xFF8E8E93.toInt()  // Graphite Gray
        )
    }
}

/**
 * 批量重命名与序号模板
 */
enum class RenameTemplate(val label: String, val shortLabel: String) {
    KEEP_ORIGINAL("保留原名", "原文件名"),
    PREFIX_INDEX("前缀 + 序号 (001)", "前缀+序号"),
    DATE_INDEX("日期 + 序号 (001)", "日期+序号")
}

/**
 * 目标压缩包格式
 */
enum class ArchiveOutputFormat(
    val label: String,
    val shortLabel: String,
    val extension: String,
    val mimeType: String,
    val description: String,
    val supportsPassword: Boolean
) {
    ZIP(
        label = "ZIP (.zip)",
        shortLabel = "ZIP",
        extension = "zip",
        mimeType = "application/zip",
        description = "通用格式，支持设置密码加密",
        supportsPassword = true
    ),
    SEVEN_Z(
        label = "7Z (.7z)",
        shortLabel = "7Z",
        extension = "7z",
        mimeType = "application/x-7z-compressed",
        description = "LZMA2 高压缩比归档",
        supportsPassword = false
    ),
    CBZ(
        label = "CBZ 漫画 (.cbz)",
        shortLabel = "CBZ",
        extension = "cbz",
        mimeType = "application/x-cbz",
        description = "漫画图集格式，支持设置密码",
        supportsPassword = true
    ),
    TAR_GZ(
        label = "TAR.GZ (.tar.gz)",
        shortLabel = "TAR.GZ",
        extension = "tar.gz",
        mimeType = "application/gzip",
        description = "GZIP 压缩流归档",
        supportsPassword = false
    ),
    TAR_XZ(
        label = "TAR.XZ (.tar.xz)",
        shortLabel = "TAR.XZ",
        extension = "tar.xz",
        mimeType = "application/x-xz",
        description = "XZ 紧凑流归档",
        supportsPassword = false
    ),
    TAR(
        label = "TAR (.tar)",
        shortLabel = "TAR",
        extension = "tar",
        mimeType = "application/x-tar",
        description = "无损极速合并归档",
        supportsPassword = false
    )
}

/**
 * 压缩包压缩率等级
 */
enum class ArchiveCompressionLevel(val label: String, val zipLevel: Int) {
    STORE_ONLY("仅存储", Deflater.NO_COMPRESSION),
    STANDARD("标准", Deflater.DEFAULT_COMPRESSION),
    ULTRA("极限", Deflater.BEST_COMPRESSION)
}

/**
 * 色块混淆粒度选项
 */
enum class BlockGridSize(val label: String, val shortLabel: String, val blockPx: Int, val fileTag: String) {
    BLOCK_8("8×8 细密", "8×8", 8, "B8"),
    BLOCK_16("16×16 标准", "16×16", 16, "B16"),
    BLOCK_32("32×32 大块", "32×32", 32, "B32"),
    BLOCK_64("64×64 超大", "64×64", 64, "B64")
}

/**
 * 目标编码格式
 */
enum class OutputFormat(
    val label: String,
    val shortLabel: String,
    val extension: String,
    val mimeType: String,
    val supportsQualitySlider: Boolean,
    val description: String
) {
    JPEG(
        label = "JPEG",
        shortLabel = "JPEG",
        extension = "jpg",
        mimeType = "image/jpeg",
        supportsQualitySlider = true,
        description = "适合照片瘦身"
    ),
    WEBP_LOSSY(
        label = "WebP 有损",
        shortLabel = "WebP",
        extension = "webp",
        mimeType = "image/webp",
        supportsQualitySlider = true,
        description = "高压缩率，支持透明"
    ),
    WEBP_LOSSLESS(
        label = "WebP 无损",
        shortLabel = "WebP无损",
        extension = "webp",
        mimeType = "image/webp",
        supportsQualitySlider = false,
        description = "无损像素，比 PNG 更小"
    ),
    PNG(
        label = "PNG 无损",
        shortLabel = "PNG",
        extension = "png",
        mimeType = "image/png",
        supportsQualitySlider = false,
        description = "100% 像素精度无损保存"
    )
}

/**
 * 尺寸限制选项
 */
enum class ResolutionOption(val label: String, val maxDimensionPx: Int?) {
    ORIGINAL("原图", null),
    MAX_2560("2K", 2560),
    MAX_1920("1080P", 1920),
    MAX_1080("1080px", 1080),
    MAX_720("720P", 720)
}

/**
 * 批量处理与打包配置参数
 */
@Immutable
data class CompressionConfig(
    val mode: ProcessMode = ProcessMode.COMPRESS_TRANSCODE,
    val archiveSubMode: ArchiveSubMode = ArchiveSubMode.PACK_TO_ARCHIVE,
    val format: OutputFormat = OutputFormat.JPEG,
    val quality: Int = 80,
    val resolutionOption: ResolutionOption = ResolutionOption.ORIGINAL,
    val stripExifMetadata: Boolean = true,
    val renameTemplate: RenameTemplate = RenameTemplate.KEEP_ORIGINAL,
    val customRenamePrefix: String = "IMG",
    val customTreeUri: Uri? = null,
    val obfuscationKey: String = "",
    val blockGridSize: BlockGridSize = BlockGridSize.BLOCK_16,
    val autoTagBlockSizeInName: Boolean = true,
    val packResultIntoArchive: Boolean = false,
    val archiveOutputFormat: ArchiveOutputFormat = ArchiveOutputFormat.ZIP,
    val archiveCompressionLevel: ArchiveCompressionLevel = ArchiveCompressionLevel.STANDARD,
    val archivePassword: String = "",
    val customArchiveBaseName: String = ""
)

/**
 * 待处理的单张原图元数据
 */
@Immutable
data class SelectedImageItem(
    val uri: Uri,
    val displayName: String,
    val originalSize: Long,
    val mimeType: String,
    val width: Int,
    val height: Int,
    val fromArchiveName: String? = null
)

/**
 * 单张图片处理结果
 */
@Immutable
data class CompressionResult(
    val source: SelectedImageItem,
    val isSuccess: Boolean,
    val mode: ProcessMode = ProcessMode.COMPRESS_TRANSCODE,
    val outputUri: Uri? = null,
    val outputName: String = "",
    val compressedSize: Long = 0L,
    val outputWidth: Int = 0,
    val outputHeight: Int = 0,
    val outputFormat: OutputFormat = OutputFormat.JPEG,
    val savedPathLabel: String = "",
    val packedIntoArchiveName: String? = null,
    val errorMessage: String? = null
)

/**
 * 批量执行完成后的汇总报告
 */
@Immutable
data class BatchExecutionReport(
    val itemResults: List<CompressionResult>,
    val archiveSavedUri: Uri? = null,
    val archiveFileName: String? = null,
    val archiveSavedPathLabel: String? = null,
    val archiveTotalBytes: Long = 0L,
    val isArchiveEncrypted: Boolean = false
)

/**
 * 多格式压缩包导入结果汇总（含加密密码检测状态）
 */
@Immutable
data class ArchiveImportSummary(
    val archiveCount: Int,
    val extractedImages: List<SelectedImageItem>,
    val archiveNames: List<String>,
    val needsPassword: Boolean = false,
    val wrongPassword: Boolean = false,
    val pendingUris: List<Uri> = emptyList(),
    val errorNote: String? = null
)

/**
 * 基于文字口令 (SHA-256 + SplitMix64) 的确定性伪随机数生成器
 */
private class KeySeededRandom(secretText: String, saltTag: String) {
    private var state: Long

    init {
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(secretText.toByteArray(Charsets.UTF_8))
        digest.update(0.toByte())
        digest.update(saltTag.toByteArray(Charsets.UTF_8))
        val hashBytes = digest.digest()
        val buf = ByteBuffer.wrap(hashBytes)
        var acc = 0L
        repeat(4) {
            acc = acc xor buf.long
        }
        state = if (acc == 0L) -0x61c8864680b583ebL else acc
    }

    fun nextLong(): Long {
        var z = (state + -0x61c8864680b583ebL).also { state = it }
        z = (z xor (z ushr 30)) * -0x40a7b892e31b1a47L
        z = (z xor (z ushr 27)) * -0x6b2fb644ecceee15L
        return z xor (z ushr 31)
    }

    fun nextInt(bound: Int): Int {
        if (bound <= 1) return 0
        return ((nextLong() ushr 1) % bound.toLong()).toInt()
    }

    fun nextByteMask(): Int = (nextLong() and 0xFFL).toInt()
}

/**
 * 纯 Kotlin 标准 PKWARE ZipCrypto 加密/解密引擎（零外部依赖，兼容全平台 ZIP 工具）
 */
private class PkwareZipCryptoCipher(passwordBytes: ByteArray) {
    private var k0: Int = 0x12345678
    private var k1: Int = 0x23456789
    private var k2: Int = 0x34567890

    init {
        for (b in passwordBytes) {
            updateKeys(b.toInt() and 0xFF)
        }
    }

    private fun updateKeys(byteVal: Int) {
        k0 = crc32Step(k0, byteVal)
        k1 = (k1 + (k0 and 0xFF)) * 134775813 + 1
        k2 = crc32Step(k2, (k1 ushr 24) and 0xFF)
    }

    private fun magicByte(): Int {
        val t = (k2 and 0xFFFF) or 2
        return ((t * (t xor 1)) ushr 8) and 0xFF
    }

    fun encryptByte(plainByte: Int): Byte {
        val p = plainByte and 0xFF
        val cipher = p xor magicByte()
        updateKeys(p)
        return cipher.toByte()
    }

    fun decryptByte(cipherByte: Int): Byte {
        val c = cipherByte and 0xFF
        val plain = c xor magicByte()
        updateKeys(plain)
        return plain.toByte()
    }

    companion object {
        private val CRC_TABLE = IntArray(256).apply {
            for (i in 0 until 256) {
                var r = i
                repeat(8) {
                    r = if ((r and 1) != 0) {
                        (r ushr 1) xor -0x12477ce0 // 0xEDB88320
                    } else {
                        r ushr 1
                    }
                }
                this[i] = r
            }
        }

        private fun crc32Step(oldCrc: Int, byteVal: Int): Int {
            return (oldCrc ushr 8) xor CRC_TABLE[(oldCrc xor byteVal) and 0xFF]
        }
    }
}

object ImageCompressor {

    private val SUPPORTED_IMAGE_EXTENSIONS = setOf(
        "jpg", "jpeg", "png", "webp", "bmp", "heic", "heif"
    )

    private val SUPPORTED_ARCHIVE_EXTENSIONS = setOf(
        "zip", "cbz", "7z", "rar", "cbr", "tar", "gz", "tgz", "bz2", "tbz2", "xz", "txz", "jar", "apk"
    )

                private const val PREFS_READER_BOOKMARKS = "flclash_reader_bookmarks"
    private const val PREFS_SAVED_SECRETS = "flclash_saved_secrets"
    private const val PREFS_FLCLASH_THEME = "flclash_091_theme_settings"

    fun loadFlClashThemeProps(context: Context): FlClashThemeProps {
        return runCatching {
            val sp = context.getSharedPreferences(PREFS_FLCLASH_THEME, Context.MODE_PRIVATE)
            val modeName = sp.getString("themeMode", FlClashThemeMode.SYSTEM.name) ?: FlClashThemeMode.SYSTEM.name
            val styleName = sp.getString("colorStyle", FlClashColorStyle.VIVID.name) ?: FlClashColorStyle.VIVID.name
            val glassName = sp.getString("liquidGlass", FlClashLiquidGlassMode.ULTRA.name) ?: FlClashLiquidGlassMode.ULTRA.name
            val tabAnimName = sp.getString("tabAnimation", FlClashTabAnimation.SLIDE.name) ?: FlClashTabAnimation.SLIDE.name
            val hasPrimary = sp.getBoolean("hasPrimaryColor", true)
            val primaryVal = sp.getInt("primaryColor", FlClashThemeProps.DEFAULT_PRIMARY_COLOR)
            val colorsRaw = sp.getString("primaryColors", "") ?: ""
            val parsedColors = if (colorsRaw.isBlank()) {
                FlClashThemeProps.DEFAULT_PRIMARY_COLORS
            } else {
                colorsRaw.split(",").mapNotNull { it.toIntOrNull() }.ifEmpty { FlClashThemeProps.DEFAULT_PRIMARY_COLORS }
            }
            FlClashThemeProps(
                themeMode = runCatching { FlClashThemeMode.valueOf(modeName) }.getOrDefault(FlClashThemeMode.SYSTEM),
                pureBlack = sp.getBoolean("pureBlack", false),
                primaryColor = if (hasPrimary) primaryVal else null,
                primaryColors = parsedColors,
                colorStyle = runCatching { FlClashColorStyle.valueOf(styleName) }.getOrDefault(FlClashColorStyle.VIVID),
                floatingNavigationBar = sp.getBoolean("floatingNavigationBar", true),
                tabAnimation = runCatching { FlClashTabAnimation.valueOf(tabAnimName) }.getOrDefault(FlClashTabAnimation.SLIDE),
                liquidGlass = runCatching { FlClashLiquidGlassMode.valueOf(glassName) }.getOrDefault(FlClashLiquidGlassMode.ULTRA)
            )
        }.getOrDefault(FlClashThemeProps())
    }

    fun saveFlClashThemeProps(context: Context, props: FlClashThemeProps) {
        runCatching {
            context.getSharedPreferences(PREFS_FLCLASH_THEME, Context.MODE_PRIVATE)
                .edit()
                .putString("themeMode", props.themeMode.name)
                .putBoolean("pureBlack", props.pureBlack)
                .putBoolean("hasPrimaryColor", props.primaryColor != null)
                .putInt("primaryColor", props.primaryColor ?: FlClashThemeProps.DEFAULT_PRIMARY_COLOR)
                .putString("primaryColors", props.primaryColors.joinToString(","))
                .putString("colorStyle", props.colorStyle.name)
                .putBoolean("floatingNavigationBar", props.floatingNavigationBar)
                .putString("tabAnimation", props.tabAnimation.name)
                .putString("liquidGlass", props.liquidGlass.name)
                .apply()
        }
    }
    private const val KEY_HISTORY_OBFUSCATION = "history_obfuscation_keys"
    private const val KEY_HISTORY_ARCHIVE_PWD = "history_archive_passwords"

    /**
     * 超大文件极速 I/O 常量：256KB 块缓冲区（相比默认 8KB 减少 96% 系统调用次数）
     * 以及线程局部 64KB BitmapFactory Header 解码复用缓冲，避免打开数百张大图时频繁触发 GC
     */
    private const val IO_BUFFER_SIZE = 256 * 1024
    private val DECODE_TEMP_STORAGE = object : ThreadLocal<ByteArray>() {
        override fun initialValue(): ByteArray = ByteArray(64 * 1024)
    }

    /**
     * 针对超大压缩包的零拷贝/内核通道快速定位：
     * - 若 Uri 为 file:// 本地文件则直接映射原文件（0 字节拷贝）；
     * - 若为 content:// 则优先走 FileChannel.transferFrom 内核态零拷贝传输，回退采用 256KB 大块缓冲流。
     */
    private fun resolveOrCopyUriToTempFileFast(
        context: Context,
        sourceUri: Uri,
        tempFile: File
    ): Pair<File, Boolean> {
        if (sourceUri.scheme == "file") {
            val localPath = sourceUri.path
            if (!localPath.isNullOrBlank()) {
                val directFile = File(localPath)
                if (directFile.exists() && directFile.canRead() && directFile.length() > 0L) {
                    return directFile to false
                }
            }
        }
        val transferredViaChannel = runCatching {
            context.contentResolver.openFileDescriptor(sourceUri, "r")?.use { pfd ->
                val statLen = pfd.statSize
                FileInputStream(pfd.fileDescriptor).channel.use { inChannel ->
                    FileOutputStream(tempFile).channel.use { outChannel ->
                        if (statLen > 0L) {
                            var pos = 0L
                            while (pos < statLen) {
                                val copied = outChannel.transferFrom(inChannel, pos, (statLen - pos).coerceAtMost(16L * 1024L * 1024L))
                                if (copied <= 0L) break
                                pos += copied
                            }
                            pos > 0L
                        } else {
                            false
                        }
                    }
                }
            } ?: false
        }.getOrDefault(false)

        if (!transferredViaChannel || !tempFile.exists() || tempFile.length() == 0L) {
            val buf = ByteArray(IO_BUFFER_SIZE)
            context.contentResolver.openInputStream(sourceUri)?.use { rawIn ->
                BufferedOutputStream(FileOutputStream(tempFile), IO_BUFFER_SIZE).use { out ->
                    var read: Int
                    while (rawIn.read(buf).also { read = it } > 0) {
                        out.write(buf, 0, read)
                    }
                    out.flush()
                }
            } ?: throw IllegalStateException("无法读取压缩包文件流")
        }
        return tempFile to true
    }

    /**
     * 对图片队列按指定维度排序（自然文件名顺逆序、文件体积、分辨率像素数）
     */
    fun sortImageQueue(items: List<SelectedImageItem>, order: QueueSortOrder): List<SelectedImageItem> {
        return when (order) {
            QueueSortOrder.NAME_ASC -> items.sortedWith { a, b -> compareNaturalStrings(a.displayName, b.displayName) }
            QueueSortOrder.NAME_DESC -> items.sortedWith { a, b -> compareNaturalStrings(b.displayName, a.displayName) }
            QueueSortOrder.SIZE_DESC -> items.sortedByDescending { it.originalSize }
            QueueSortOrder.SIZE_ASC -> items.sortedBy { it.originalSize }
            QueueSortOrder.RESOLUTION_DESC -> items.sortedByDescending { it.width.toLong() * it.height.toLong() }
        }
    }

    /**
     * 读取保存的常用文字混淆口令列表
     */
    fun getSavedObfuscationKeys(context: Context): List<String> =
        readSecretList(context, KEY_HISTORY_OBFUSCATION)

    /**
     * 保存一条文字混淆口令到历史密码本（自动去重并置顶，最多保留 10 条）
     */
    fun saveObfuscationKeyToHistory(context: Context, key: String): List<String> =
        addSecretToList(context, KEY_HISTORY_OBFUSCATION, key)

    /**
     * 从历史密码本移除一条文字混淆口令
     */
    fun removeObfuscationKeyFromHistory(context: Context, key: String): List<String> =
        removeSecretFromList(context, KEY_HISTORY_OBFUSCATION, key)

    /**
     * 读取保存的常用压缩包密码列表
     */
    fun getSavedArchivePasswords(context: Context): List<String> =
        readSecretList(context, KEY_HISTORY_ARCHIVE_PWD)

    /**
     * 保存一条压缩包密码到历史密码本（自动去重并置顶，最多保留 10 条）
     */
    fun saveArchivePasswordToHistory(context: Context, password: String): List<String> =
        addSecretToList(context, KEY_HISTORY_ARCHIVE_PWD, password)

    /**
     * 从历史密码本移除一条压缩包密码
     */
    fun removeArchivePasswordFromHistory(context: Context, password: String): List<String> =
        removeSecretFromList(context, KEY_HISTORY_ARCHIVE_PWD, password)

    private fun readSecretList(context: Context, prefKey: String): List<String> {
        return runCatching {
            val raw = context.getSharedPreferences(PREFS_SAVED_SECRETS, Context.MODE_PRIVATE)
                .getString(prefKey, "") ?: ""
            if (raw.isBlank()) emptyList()
            else raw.split("").map { it.trim() }.filter { it.isNotEmpty() }
        }.getOrDefault(emptyList())
    }

    private fun addSecretToList(context: Context, prefKey: String, newValue: String): List<String> {
        val trimmed = newValue.trim()
        if (trimmed.isEmpty()) return readSecretList(context, prefKey)
        val updated = (listOf(trimmed) + readSecretList(context, prefKey).filterNot { it == trimmed }).take(10)
        runCatching {
            context.getSharedPreferences(PREFS_SAVED_SECRETS, Context.MODE_PRIVATE)
                .edit()
                .putString(prefKey, updated.joinToString(""))
                .apply()
        }
        return updated
    }

    private fun removeSecretFromList(context: Context, prefKey: String, targetValue: String): List<String> {
        val updated = readSecretList(context, prefKey).filterNot { it == targetValue }
        runCatching {
            context.getSharedPreferences(PREFS_SAVED_SECRETS, Context.MODE_PRIVATE)
                .edit()
                .putString(prefKey, updated.joinToString(""))
                .apply()
        }
        return updated
    }
    private val BLOCK_TAG_REGEX = Regex("(?:^|_)(B8|B16|B32|B64)(?:_|\\.)", RegexOption.IGNORE_CASE)

    /**
     * 保存阅读器当前压缩包/图集的阅读页码书签
     */
    fun saveReaderBookmark(context: Context, archiveKey: String, pageIndex: Int) {
        if (archiveKey.isBlank() || pageIndex < 0) return
        runCatching {
            context.getSharedPreferences(PREFS_READER_BOOKMARKS, Context.MODE_PRIVATE)
                .edit()
                .putInt(archiveKey, pageIndex)
                .apply()
        }
    }

    /**
     * 读取阅读器上次记录的页码书签（未找到返回 0）
     */
    fun getReaderBookmark(context: Context, archiveKey: String): Int {
        if (archiveKey.isBlank()) return 0
        return runCatching {
            context.getSharedPreferences(PREFS_READER_BOOKMARKS, Context.MODE_PRIVATE)
                .getInt(archiveKey, 0)
                .coerceAtLeast(0)
        }.getOrDefault(0)
    }

    /**
     * 阅读器单页一键落盘保存到系统相册或自定义目录（支持直接保存实时解混淆后的图片）
     */
    suspend fun saveReaderPageToGallery(
        context: Context,
        sourceUri: Uri,
        originalDisplayName: String,
        isDecryptedPreview: Boolean,
        customTreeUri: Uri? = null
    ): Pair<Uri, String>? = withContext(Dispatchers.IO) {
        runCatching {
            val bytes = when (sourceUri.scheme) {
                "file" -> File(sourceUri.path ?: return@runCatching null).readBytes()
                else -> context.contentResolver.openInputStream(sourceUri)?.use { it.readBytes() }
                    ?: return@runCatching null
            }
            val cleanStem = sanitizeFileName(originalDisplayName.substringBeforeLast('.').ifBlank { "page" })
            val ext = if (isDecryptedPreview) {
                "png"
            } else {
                originalDisplayName.substringAfterLast('.', "jpg").lowercase(Locale.ROOT)
            }
            val prefix = if (isDecryptedPreview) "READER_DEC_" else "READER_"
            val outName = "${prefix}${cleanStem}_${System.currentTimeMillis() % 10000}.$ext"
            val mime = guessMimeTypeFromName(outName)
            if (customTreeUri != null) {
                saveToCustomDocumentTree(context, customTreeUri, outName, mime, bytes)
            } else {
                saveToSystemGallery(context, outName, mime, bytes)
            }
        }.getOrNull()
    }

    /**
     * 自动从图片文件名识别加密时写入的色块粒度标记（如 OBF_B16_xxx.png -> BLOCK_16）
     */
    fun detectBlockGridFromItems(items: List<SelectedImageItem>): BlockGridSize? {
        for (item in items) {
            val match = BLOCK_TAG_REGEX.find(item.displayName) ?: continue
            val tag = match.groupValues.getOrNull(1)?.uppercase(Locale.ROOT) ?: continue
            val found = BlockGridSize.entries.firstOrNull { it.fileTag == tag }
            if (found != null) return found
        }
        return null
    }

    /**
     * 一键向外分享处理完的图片或压缩包（自动将本地缓存文件转为 MediaStore content:// Uri，无需额外 FileProvider 配置）
     */
    fun shareOutputUris(
        context: Context,
        uris: List<Uri>,
        mimeType: String = "*/*",
        chooserTitle: String = "分享文件"
    ) {
        if (uris.isEmpty()) {
            Toast.makeText(context, "暂无可分享的文件", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val safeUris = ArrayList<Uri>()
            for (u in uris) {
                if (u.scheme == "content") {
                    safeUris.add(u)
                } else if (u.scheme == "file") {
                    val f = File(u.path ?: continue)
                    if (f.exists()) {
                        val exported = runCatching {
                            val bytes = f.readBytes()
                            val mime = guessMimeTypeFromName(f.name)
                            saveToSystemGallery(context, "SHARE_${f.name}", mime, bytes).first
                        }.getOrNull()
                        if (exported != null) {
                            safeUris.add(exported)
                        }
                    }
                }
            }
            if (safeUris.isEmpty()) {
                Toast.makeText(context, "未找到可分享的文件路径", Toast.LENGTH_SHORT).show()
                return
            }

            val intent = if (safeUris.size == 1) {
                Intent(Intent.ACTION_SEND).apply {
                    type = mimeType
                    putExtra(Intent.EXTRA_STREAM, safeUris[0])
                    clipData = ClipData.newRawUri("", safeUris[0])
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                    type = mimeType
                    putParcelableArrayListExtra(Intent.EXTRA_STREAM, safeUris)
                    val clip = ClipData.newRawUri("", safeUris[0])
                    for (i in 1 until safeUris.size) {
                        clip.addItem(ClipData.Item(safeUris[i]))
                    }
                    clipData = clip
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            }
            val chooser = Intent.createChooser(intent, chooserTitle).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            Toast.makeText(context, "调起分享失败: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * 判断某个 Uri 是否为受支持的压缩包格式
     */
    fun isArchiveUri(context: Context, uri: Uri): Boolean {
        val mime = context.contentResolver.getType(uri)?.lowercase(Locale.ROOT) ?: ""
        if (mime.contains("zip") ||
            mime.contains("7z") ||
            mime.contains("rar") ||
            mime.contains("tar") ||
            mime.contains("gzip") ||
            mime.contains("bzip2") ||
            mime.contains("xz") ||
            mime.contains("cbz") ||
            mime.contains("cbr") ||
            mime.contains("compressed")
        ) {
            return true
        }
        val displayName = queryDisplayName(context, uri).lowercase(Locale.ROOT)
        val ext = displayName.substringAfterLast('.', "")
        if (ext in SUPPORTED_ARCHIVE_EXTENSIONS) return true

        val pathSeg = uri.lastPathSegment?.lowercase(Locale.ROOT) ?: ""
        val pathExt = pathSeg.substringAfterLast('.', "")
        return pathExt in SUPPORTED_ARCHIVE_EXTENSIONS
    }

    /**
     * 从一个或多个多格式压缩包（支持加密 .zip / .cbz / .7z / .rar 及 .tar.gz / .xz）中提取所有图片，并实时回调解压进度
     */
    suspend fun extractImagesFromArchiveUris(
        context: Context,
        archiveUris: List<Uri>,
        password: String = "",
        onProgressiveBatch: ((List<SelectedImageItem>) -> Unit)? = null,
        onExtractProgress: ((extractedCount: Int, totalEntries: Int, currentFileName: String) -> Unit)? = null
    ): ArchiveImportSummary = withContext(Dispatchers.IO) {
        val cacheRoot = File(context.cacheDir, "archive_imports").apply {
            if (!exists()) mkdirs()
        }
        val extractedItems = mutableListOf<SelectedImageItem>()
        val archiveNames = mutableListOf<String>()
        val pendingEncryptedUris = mutableListOf<Uri>()
        var needsPassword = false
        var wrongPassword = false
        var lastError: String? = null
        var lastProgressEmitMs = 0L
        val throttledProgress: (Int, Int, String) -> Unit = { done, total, currentName ->
            val now = System.currentTimeMillis()
            if (done <= 1 || done == total || (now - lastProgressEmitMs) >= 55L) {
                lastProgressEmitMs = now
                onExtractProgress?.invoke(done, total, currentName)
            }
        }
        var lastProgressiveEmitCount = 0
        val emitProgressiveIfNeeded: (List<SelectedImageItem>) -> Unit = { currentSubList ->
            if (onProgressiveBatch != null) {
                val combinedSize = extractedItems.size + currentSubList.size
                if ((lastProgressiveEmitCount == 0 && combinedSize >= 4) ||
                    (combinedSize - lastProgressiveEmitCount >= 16)
                ) {
                    lastProgressiveEmitCount = combinedSize
                    val snapshot = ArrayList<SelectedImageItem>(combinedSize).apply {
                        addAll(extractedItems)
                        addAll(currentSubList)
                    }
                    onProgressiveBatch(snapshot)
                }
            }
        }

        archiveUris.forEachIndexed { idx, archiveUri ->
            ensureActive()
            val displayName = queryDisplayName(context, archiveUri).ifBlank {
                "archive_${idx + 1}.zip"
            }
            archiveNames.add(displayName)

            val batchFolder = File(cacheRoot, "arc_${System.currentTimeMillis()}_$idx").apply {
                mkdirs()
            }

            val lowerName = displayName.lowercase(Locale.ROOT)
            val mime = context.contentResolver.getType(archiveUri)?.lowercase(Locale.ROOT) ?: ""

            try {
                val outcome = when {
                    lowerName.endsWith(".7z") || mime.contains("7z") -> {
                        extractSevenZArchive(context, archiveUri, displayName, batchFolder, password, throttledProgress, emitProgressiveIfNeeded)
                    }
                    lowerName.endsWith(".rar") || lowerName.endsWith(".cbr") || mime.contains("rar") -> {
                        extractRarArchive(context, archiveUri, displayName, batchFolder, password, throttledProgress, emitProgressiveIfNeeded)
                    }
                    lowerName.endsWith(".tar.gz") || lowerName.endsWith(".tgz") ||
                        (lowerName.endsWith(".gz") && !lowerName.endsWith(".svgz")) || mime.contains("gzip") -> {
                        SingleArchiveOutcome(
                            items = extractTarStreamArchive(context, archiveUri, displayName, batchFolder, "gz", throttledProgress, emitProgressiveIfNeeded)
                        )
                    }
                    lowerName.endsWith(".tar.bz2") || lowerName.endsWith(".tbz2") ||
                        lowerName.endsWith(".bz2") || mime.contains("bzip2") -> {
                        SingleArchiveOutcome(
                            items = extractTarStreamArchive(context, archiveUri, displayName, batchFolder, "bz2", throttledProgress, emitProgressiveIfNeeded)
                        )
                    }
                    lowerName.endsWith(".tar.xz") || lowerName.endsWith(".txz") ||
                        lowerName.endsWith(".xz") || mime.contains("xz") -> {
                        SingleArchiveOutcome(
                            items = extractTarStreamArchive(context, archiveUri, displayName, batchFolder, "xz", throttledProgress, emitProgressiveIfNeeded)
                        )
                    }
                    lowerName.endsWith(".tar") || mime.contains("tar") -> {
                        SingleArchiveOutcome(
                            items = extractTarStreamArchive(context, archiveUri, displayName, batchFolder, "plain", throttledProgress, emitProgressiveIfNeeded)
                        )
                    }
                    else -> {
                        extractZipArchiveWithPasswordSupport(context, archiveUri, displayName, batchFolder, password, throttledProgress, emitProgressiveIfNeeded)
                    }
                }

                if (outcome.needsPassword) {
                    needsPassword = true
                    if (outcome.wrongPassword) wrongPassword = true
                    pendingEncryptedUris.add(archiveUri)
                }
                if (outcome.errorNote != null) {
                    lastError = outcome.errorNote
                }
                extractedItems.addAll(outcome.items)
            } catch (e: Exception) {
                lastError = e.localizedMessage ?: "压缩包解析失败"
            }
        }

        val sortedItems = extractedItems.sortedWith { a, b ->
            compareNaturalStrings(a.displayName, b.displayName)
        }

        ArchiveImportSummary(
            archiveCount = archiveUris.size,
            extractedImages = sortedItems,
            archiveNames = archiveNames,
            needsPassword = needsPassword,
            wrongPassword = wrongPassword,
            pendingUris = if (pendingEncryptedUris.isNotEmpty()) pendingEncryptedUris else archiveUris,
            errorNote = lastError
        )
    }

    private data class SingleArchiveOutcome(
        val items: List<SelectedImageItem> = emptyList(),
        val needsPassword: Boolean = false,
        val wrongPassword: Boolean = false,
        val errorNote: String? = null
    )

    /**
     * 使用 Apache Commons Compress ZipFile + 内置 ZipCrypto 解密引擎解析普通或加密 ZIP / CBZ 压缩包
     */
    @Suppress("DEPRECATION")
    private fun extractZipArchiveWithPasswordSupport(
        context: Context,
        archiveUri: Uri,
        archiveDisplayName: String,
        destFolder: File,
        password: String,
        onExtractProgress: ((extractedCount: Int, totalEntries: Int, currentFileName: String) -> Unit)? = null,
        onProgressiveSubBatch: ((List<SelectedImageItem>) -> Unit)? = null
    ): SingleArchiveOutcome {
        val fallbackTempZip = File(destFolder, "temp_source.zip")
        var shouldDeleteTemp = false
        try {
            val (zipSourceFile, isTemp) = runCatching {
                resolveOrCopyUriToTempFileFast(context, archiveUri, fallbackTempZip)
            }.getOrElse {
                return SingleArchiveOutcome(errorNote = "无法读取压缩包文件流")
            }
            shouldDeleteTemp = isTemp

            val outcomeUtf8 = tryExtractCommonsZipFile(
                zipSourceFile,
                archiveDisplayName,
                destFolder,
                "UTF-8",
                password,
                onExtractProgress,
                onProgressiveSubBatch
            )
            if (outcomeUtf8.needsPassword || outcomeUtf8.items.isNotEmpty()) {
                return outcomeUtf8
            }

            val outcomeGbk = tryExtractCommonsZipFile(
                zipSourceFile,
                archiveDisplayName,
                destFolder,
                "GBK",
                password,
                onExtractProgress,
                onProgressiveSubBatch
            )
            if (outcomeGbk.needsPassword || outcomeGbk.items.isNotEmpty()) {
                return outcomeGbk
            }
        } finally {
            if (shouldDeleteTemp && fallbackTempZip.exists()) {
                fallbackTempZip.delete()
            }
        }

        val fallbackItems = tryExtractZipWithCharset(context, archiveUri, archiveDisplayName, destFolder, Charsets.UTF_8, onExtractProgress, onProgressiveSubBatch)
            ?: tryExtractZipWithCharset(context, archiveUri, archiveDisplayName, destFolder, Charset.forName("GBK"), onExtractProgress, onProgressiveSubBatch)
            ?: emptyList()
        return SingleArchiveOutcome(items = fallbackItems)
    }

    @Suppress("DEPRECATION")
    private fun tryExtractCommonsZipFile(
        tempZip: File,
        archiveDisplayName: String,
        destFolder: File,
        encoding: String,
        password: String,
        onExtractProgress: ((extractedCount: Int, totalEntries: Int, currentFileName: String) -> Unit)? = null,
        onProgressiveSubBatch: ((List<SelectedImageItem>) -> Unit)? = null
    ): SingleArchiveOutcome {
        val items = mutableListOf<SelectedImageItem>()
        return try {
            ZipFile(tempZip, encoding).use { zipFile ->
                val validEntries = ArrayList<Triple<ZipArchiveEntry, String, String>>()
                val entriesEnum = zipFile.entries
                while (entriesEnum.hasMoreElements()) {
                    val entry: ZipArchiveEntry = entriesEnum.nextElement()
                    if (entry.isDirectory) continue
                    val rawName = entry.name.replace('\', '/')
                    val simpleName = rawName.substringAfterLast('/')
                    val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                    if (isValidImageEntry(rawName, simpleName, ext)) {
                        validEntries.add(Triple(entry, rawName, simpleName))
                    }
                }
                // 预先按自然页码顺序排列中央目录条目，使第 1 页最先被解压出来，配合流式回调实现超大文件秒开阅读
                validEntries.sortWith { a, b -> compareNaturalStrings(a.third, b.third) }

                val totalEntries = validEntries.size.coerceAtLeast(1)
                var counter = 0
                val copyBuffer = ByteArray(IO_BUFFER_SIZE)

                for ((entry, _, simpleName) in validEntries) {
                    val isEncryptedEntry = entry.generalPurposeBit.usesEncryption() || !zipFile.canReadEntryData(entry)
                    if (isEncryptedEntry) {
                        if (password.isBlank()) {
                            return SingleArchiveOutcome(
                                needsPassword = true,
                                wrongPassword = false,
                                errorNote = "压缩包「$archiveDisplayName」受密码保护"
                            )
                        }
                        val rawEncrypted = zipFile.getRawInputStream(entry)?.use { it.readBytes() }
                            ?: continue
                        val decryptedBytes = decryptPkwareZipEntry(rawEncrypted, entry, password)
                            ?: return SingleArchiveOutcome(
                                needsPassword = true,
                                wrongPassword = true,
                                errorNote = "压缩包密码错误，请重新输入"
                            )
                        counter++
                        val outFile = File(destFolder, "${counter}_${sanitizeFileName(simpleName)}")
                        BufferedOutputStream(FileOutputStream(outFile), IO_BUFFER_SIZE).use { it.write(decryptedBytes) }
                        buildSelectedImageIfValid(outFile, simpleName, archiveDisplayName)?.let {
                            items.add(it)
                            onExtractProgress?.invoke(items.size, totalEntries, simpleName)
                            onProgressiveSubBatch?.invoke(items)
                        }
                    } else {
                        counter++
                        val outFile = File(destFolder, "${counter}_${sanitizeFileName(simpleName)}")
                        zipFile.getInputStream(entry)?.use { input ->
                            BufferedOutputStream(FileOutputStream(outFile), IO_BUFFER_SIZE).use { fos ->
                                var len: Int
                                while (input.read(copyBuffer).also { len = it } > 0) {
                                    fos.write(copyBuffer, 0, len)
                                }
                                fos.flush()
                            }
                        }
                        buildSelectedImageIfValid(outFile, simpleName, archiveDisplayName)?.let {
                            items.add(it)
                            onExtractProgress?.invoke(items.size, totalEntries, simpleName)
                            onProgressiveSubBatch?.invoke(items)
                        }
                    }
                }
            }
            SingleArchiveOutcome(items = items)
        } catch (e: Exception) {
            val msg = (e.message ?: "").lowercase(Locale.ROOT)
            if (msg.contains("password") || msg.contains("encrypted")) {
                SingleArchiveOutcome(
                    needsPassword = true,
                    wrongPassword = password.isNotBlank(),
                    errorNote = "压缩包受密码保护"
                )
            } else {
                SingleArchiveOutcome(items = items)
            }
        }
    }

    /**
     * 解密标准 PKWARE ZipCrypto 条目（支持 STORED 与 DEFLATED）
     */
    private fun decryptPkwareZipEntry(
        rawEncryptedBytes: ByteArray,
        entry: ZipArchiveEntry,
        password: String
    ): ByteArray? {
        if (rawEncryptedBytes.size < 12) return null
        val cipher = PkwareZipCryptoCipher(password.toByteArray(Charsets.UTF_8))
        val header = ByteArray(12)
        for (i in 0 until 12) {
            header[i] = cipher.decryptByte(rawEncryptedBytes[i].toInt())
        }

        val payloadLen = rawEncryptedBytes.size - 12
        val decryptedPayload = ByteArray(payloadLen)
        for (i in 0 until payloadLen) {
            decryptedPayload[i] = cipher.decryptByte(rawEncryptedBytes[12 + i].toInt())
        }

        val plainBytes = when (entry.method) {
            ZipEntry.STORED -> decryptedPayload
            ZipEntry.DEFLATED -> {
                runCatching {
                    InflaterInputStream(
                        ByteArrayInputStream(decryptedPayload),
                        Inflater(true),
                        IO_BUFFER_SIZE
                    ).use { it.readBytes() }
                }.getOrNull() ?: return null
            }
            else -> return null
        }

        if (entry.crc > 0L) {
            val crc = CRC32()
            crc.update(plainBytes)
            if (crc.value != entry.crc) {
                return null
            }
        }
        return plainBytes
    }

    /**
     * 解析 7z 格式压缩包（支持 AES-256 密码解锁 + 256KB 大块流式读取）
     */
    @Suppress("DEPRECATION")
    private fun extractSevenZArchive(
        context: Context,
        archiveUri: Uri,
        archiveDisplayName: String,
        destFolder: File,
        password: String,
        onExtractProgress: ((extractedCount: Int, totalEntries: Int, currentFileName: String) -> Unit)? = null,
        onProgressiveSubBatch: ((List<SelectedImageItem>) -> Unit)? = null
    ): SingleArchiveOutcome {
        val items = mutableListOf<SelectedImageItem>()
        val fallbackTempFile = File(destFolder, "temp_source.7z")
        var shouldDeleteTemp = false
        try {
            val (sevenZSourceFile, isTemp) = runCatching {
                resolveOrCopyUriToTempFileFast(context, archiveUri, fallbackTempFile)
            }.getOrElse {
                return SingleArchiveOutcome()
            }
            shouldDeleteTemp = isTemp

            val sevenZ = if (password.isNotBlank()) {
                SevenZFile(sevenZSourceFile, password.toCharArray())
            } else {
                SevenZFile(sevenZSourceFile)
            }

            sevenZ.use { archive ->
                val totalEntries = archive.entries.count { entry ->
                    if (entry.isDirectory) false
                    else {
                        val rawName = entry.name.replace('\', '/')
                        val simpleName = rawName.substringAfterLast('/')
                        val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                        isValidImageEntry(rawName, simpleName, ext)
                    }
                }.coerceAtLeast(1)

                var entry = archive.nextEntry
                var counter = 0
                val buffer = ByteArray(IO_BUFFER_SIZE)
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val rawName = entry.name.replace('\', '/')
                        val simpleName = rawName.substringAfterLast('/')
                        val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                        if (isValidImageEntry(rawName, simpleName, ext)) {
                            counter++
                            val outFile = File(destFolder, "${counter}_${sanitizeFileName(simpleName)}")
                            if (outFile.canonicalPath.startsWith(destFolder.canonicalPath)) {
                                BufferedOutputStream(FileOutputStream(outFile), IO_BUFFER_SIZE).use { fos ->
                                    var len: Int
                                    while (archive.read(buffer).also { len = it } > 0) {
                                        fos.write(buffer, 0, len)
                                    }
                                    fos.flush()
                                }
                                buildSelectedImageIfValid(outFile, simpleName, archiveDisplayName)?.let {
                                    items.add(it)
                                    onExtractProgress?.invoke(items.size, totalEntries, simpleName)
                                    onProgressiveSubBatch?.invoke(items)
                                }
                            }
                        }
                    }
                    entry = archive.nextEntry
                }
            }
        } catch (e: PasswordRequiredException) {
            return SingleArchiveOutcome(
                needsPassword = true,
                wrongPassword = password.isNotBlank(),
                errorNote = "7Z 压缩包需要密码解锁"
            )
        } catch (e: Exception) {
            val msg = (e.message ?: "").lowercase(Locale.ROOT)
            if (msg.contains("password") || msg.contains("encrypted") || msg.contains("aes")) {
                return SingleArchiveOutcome(
                    needsPassword = true,
                    wrongPassword = password.isNotBlank(),
                    errorNote = if (password.isNotBlank()) "7Z 密码错误，请重试" else "7Z 压缩包受密码保护"
                )
            }
            return SingleArchiveOutcome(items = items, errorNote = e.localizedMessage)
        } finally {
            if (shouldDeleteTemp && fallbackTempFile.exists()) {
                fallbackTempFile.delete()
            }
        }
        return SingleArchiveOutcome(items = items)
    }

    /**
     * 解析 RAR / CBR 格式压缩包 (兼容 junrar 7.5.5 单参数 Archive(File) 构造器 + 零拷贝直读优化)
     */
    private fun extractRarArchive(
        context: Context,
        archiveUri: Uri,
        archiveDisplayName: String,
        destFolder: File,
        password: String,
        onExtractProgress: ((extractedCount: Int, totalEntries: Int, currentFileName: String) -> Unit)? = null,
        onProgressiveSubBatch: ((List<SelectedImageItem>) -> Unit)? = null
    ): SingleArchiveOutcome {
        val items = mutableListOf<SelectedImageItem>()
        val fallbackTempFile = File(destFolder, "temp_source.rar")
        var shouldDeleteTemp = false
        try {
            val (rarSourceFile, isTemp) = runCatching {
                resolveOrCopyUriToTempFileFast(context, archiveUri, fallbackTempFile)
            }.getOrElse {
                return SingleArchiveOutcome()
            }
            shouldDeleteTemp = isTemp

            Archive(rarSourceFile).use { archive ->
                val totalEntries = archive.fileHeaders.count { hdr ->
                    if (hdr.isDirectory) false
                    else {
                        val rawName = hdr.fileName.replace('\', '/')
                        val simpleName = rawName.substringAfterLast('/')
                        val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                        isValidImageEntry(rawName, simpleName, ext)
                    }
                }.coerceAtLeast(1)

                var header: FileHeader? = archive.nextFileHeader()
                var counter = 0
                while (header != null) {
                    val currentHeader = header
                    if (currentHeader.isEncrypted) {
                        return SingleArchiveOutcome(
                            needsPassword = true,
                            wrongPassword = password.isNotBlank(),
                            errorNote = "RAR 压缩包受密码保护（建议使用加密 ZIP 或 7Z 格式）"
                        )
                    }
                    if (!currentHeader.isDirectory) {
                        val rawName = currentHeader.fileName.replace('\', '/')
                        val simpleName = rawName.substringAfterLast('/')
                        val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                        if (isValidImageEntry(rawName, simpleName, ext)) {
                            counter++
                            val outFile = File(destFolder, "${counter}_${sanitizeFileName(simpleName)}")
                            if (outFile.canonicalPath.startsWith(destFolder.canonicalPath)) {
                                BufferedOutputStream(FileOutputStream(outFile), IO_BUFFER_SIZE).use { fos ->
                                    archive.extractFile(currentHeader, fos)
                                    fos.flush()
                                }
                                buildSelectedImageIfValid(outFile, simpleName, archiveDisplayName)?.let {
                                    items.add(it)
                                    onExtractProgress?.invoke(items.size, totalEntries, simpleName)
                                    onProgressiveSubBatch?.invoke(items)
                                }
                            }
                        }
                    }
                    header = archive.nextFileHeader()
                }
            }
        } catch (e: Exception) {
            return SingleArchiveOutcome(items = items, errorNote = e.localizedMessage)
        } finally {
            if (shouldDeleteTemp && fallbackTempFile.exists()) {
                fallbackTempFile.delete()
            }
        }
        return SingleArchiveOutcome(items = items)
    }

    /**
     * 解析 TAR / TAR.GZ / TAR.BZ2 / TAR.XZ 流式归档包（256KB 大块缓冲加速）
     */
    private fun extractTarStreamArchive(
        context: Context,
        archiveUri: Uri,
        archiveDisplayName: String,
        destFolder: File,
        compressionType: String,
        onExtractProgress: ((extractedCount: Int, totalEntries: Int, currentFileName: String) -> Unit)? = null,
        onProgressiveSubBatch: ((List<SelectedImageItem>) -> Unit)? = null
    ): List<SelectedImageItem> {
        val items = mutableListOf<SelectedImageItem>()
        context.contentResolver.openInputStream(archiveUri)?.use { rawInput ->
            val buffered = BufferedInputStream(rawInput, IO_BUFFER_SIZE)
            val decompressedStream: InputStream = when (compressionType) {
                "gz" -> GzipCompressorInputStream(buffered)
                "bz2" -> BZip2CompressorInputStream(buffered)
                "xz" -> XZCompressorInputStream(buffered)
                else -> buffered
            }
            TarArchiveInputStream(decompressedStream).use { tarIn ->
                var entry = tarIn.nextEntry
                var counter = 0
                val buffer = ByteArray(IO_BUFFER_SIZE)
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val rawName = entry.name.replace('\', '/')
                        val simpleName = rawName.substringAfterLast('/')
                        val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)
                        if (isValidImageEntry(rawName, simpleName, ext)) {
                            counter++
                            val outFile = File(destFolder, "${counter}_${sanitizeFileName(simpleName)}")
                            if (outFile.canonicalPath.startsWith(destFolder.canonicalPath)) {
                                BufferedOutputStream(FileOutputStream(outFile), IO_BUFFER_SIZE).use { fos ->
                                    var len: Int
                                    while (tarIn.read(buffer).also { len = it } > 0) {
                                        fos.write(buffer, 0, len)
                                    }
                                    fos.flush()
                                }
                                buildSelectedImageIfValid(outFile, simpleName, archiveDisplayName)?.let {
                                    items.add(it)
                                    onExtractProgress?.invoke(items.size, 0, simpleName)
                                    onProgressiveSubBatch?.invoke(items)
                                }
                            }
                        }
                    }
                    entry = tarIn.nextEntry
                }
            }
        }
        return items
    }

    private fun tryExtractZipWithCharset(
        context: Context,
        zipUri: Uri,
        zipDisplayName: String,
        destFolder: File,
        charset: Charset,
        onExtractProgress: ((extractedCount: Int, totalEntries: Int, currentFileName: String) -> Unit)? = null,
        onProgressiveSubBatch: ((List<SelectedImageItem>) -> Unit)? = null
    ): List<SelectedImageItem>? {
        val items = mutableListOf<SelectedImageItem>()
        return try {
            context.contentResolver.openInputStream(zipUri)?.use { rawInput ->
                val bufferedIn = BufferedInputStream(rawInput, IO_BUFFER_SIZE)
                val zis = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    ZipInputStream(bufferedIn, charset)
                } else {
                    ZipInputStream(bufferedIn)
                }

                var entry: ZipEntry? = zis.nextEntry
                var fileCounter = 0
                val buffer = ByteArray(IO_BUFFER_SIZE)
                while (entry != null) {
                    val currentEntry = entry
                    if (!currentEntry.isDirectory) {
                        val rawName = currentEntry.name.replace('\', '/')
                        val simpleName = rawName.substringAfterLast('/')
                        val ext = simpleName.substringAfterLast('.', "").lowercase(Locale.ROOT)

                        if (isValidImageEntry(rawName, simpleName, ext)) {
                            fileCounter++
                            val outFile = File(destFolder, "${fileCounter}_${sanitizeFileName(simpleName)}")

                            if (outFile.canonicalPath.startsWith(destFolder.canonicalPath)) {
                                BufferedOutputStream(FileOutputStream(outFile), IO_BUFFER_SIZE).use { fos ->
                                    var len: Int
                                    while (zis.read(buffer).also { len = it } > 0) {
                                        fos.write(buffer, 0, len)
                                    }
                                    fos.flush()
                                }
                                buildSelectedImageIfValid(outFile, simpleName, zipDisplayName)?.let {
                                    items.add(it)
                                    onExtractProgress?.invoke(items.size, 0, simpleName)
                                    onProgressiveSubBatch?.invoke(items)
                                }
                            }
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
            items
        } catch (e: IllegalArgumentException) {
            null
        } catch (e: Exception) {
            items
        }
    }

    /**
     * 供「归档阅读器」实时口令解混淆预览使用：将色块图在缓存中解混淆并返回预览 Uri
     */
    suspend fun decryptImageForReaderPreview(
        context: Context,
        item: SelectedImageItem,
        secretKey: String,
        fallbackGridSize: BlockGridSize
    ): Uri? = withContext(Dispatchers.IO) {
        if (secretKey.isBlank()) return@withContext null
        runCatching {
            val detectedGrid = detectBlockGridFromItems(listOf(item)) ?: fallbackGridSize
            val previewDir = File(context.cacheDir, "reader_decrypted").apply {
                if (!exists()) mkdirs()
            }
            val keyHash = secretKey.hashCode().toUInt().toString(16)
            val cacheFile = File(
                previewDir,
                "dec_${keyHash}_${detectedGrid.fileTag}_${sanitizeFileName(item.displayName)}.png"
            )
            if (cacheFile.exists() && cacheFile.length() > 0L) {
                return@withContext Uri.fromFile(cacheFile)
            }

            val opts = BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.ARGB_8888
                inScaled = false
            }
            val rawBitmap = context.contentResolver.openInputStream(item.uri)?.use { input ->
                BitmapFactory.decodeStream(input, null, opts)
            } ?: return@withContext null

            val restored = transformImageBlocks(
                source = rawBitmap,
                secretKey = secretKey,
                blockSize = detectedGrid.blockPx,
                isEncrypt = false
            )
            if (restored !== rawBitmap) rawBitmap.recycle()

            FileOutputStream(cacheFile).use { fos ->
                restored.compress(Bitmap.CompressFormat.PNG, 100, fos)
                fos.flush()
            }
            restored.recycle()
            Uri.fromFile(cacheFile)
        }.getOrNull()
    }

    private fun isValidImageEntry(rawName: String, simpleName: String, ext: String): Boolean {
        return !simpleName.startsWith("._") &&
            !rawName.contains("__MACOSX/") &&
            ext in SUPPORTED_IMAGE_EXTENSIONS
    }

    private fun sanitizeFileName(simpleName: String): String {
        return buildString {
            for (ch in simpleName) {
                if (ch.isLetterOrDigit() || ch == '.' || ch == '_' || ch == '-') {
                    append(ch)
                } else {
                    append('_')
                }
            }
        }
    }

    /**
     * 零对象分配的自然文件名排序比较器（避免在数千条目归档排序时重复编译 Regex 与分配 BigInteger）
     */
    private fun compareNaturalStrings(a: String, b: String): Int {
        var ia = 0
        var ib = 0
        val na = a.length
        val nb = b.length
        while (ia < na && ib < nb) {
            val ca = a[ia]
            val cb = b[ib]
            if (ca.isDigit() && cb.isDigit()) {
                var za = ia
                while (za < na && a[za] == '0') za++
                var zb = ib
                while (zb < nb && b[zb] == '0') zb++
                var ea = za
                while (ea < na && a[ea].isDigit()) ea++
                var eb = zb
                while (eb < nb && b[eb].isDigit()) eb++
                val lenA = ea - za
                val lenB = eb - zb
                if (lenA != lenB) return lenA.compareTo(lenB)
                for (k in 0 until lenA) {
                    val dCmp = a[za + k].compareTo(b[zb + k])
                    if (dCmp != 0) return dCmp
                }
                val rawLenA = ea - ia
                val rawLenB = eb - ib
                if (rawLenA != rawLenB) return rawLenA.compareTo(rawLenB)
                ia = ea
                ib = eb
            } else {
                val uca = ca.lowercaseChar()
                val ucb = cb.lowercaseChar()
                if (uca != ucb) return uca.compareTo(ucb)
                ia++
                ib++
            }
        }
        return (na - ia).compareTo(nb - ib)
    }

    private fun buildSelectedImageIfValid(
        outFile: File,
        simpleName: String,
        archiveDisplayName: String
    ): SelectedImageItem? {
        val len = outFile.length()
        if (len <= 0L) {
            outFile.delete()
            return null
        }
        val boundsOptions = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
            inTempStorage = DECODE_TEMP_STORAGE.get()
        }
        BitmapFactory.decodeFile(outFile.absolutePath, boundsOptions)
        return if (boundsOptions.outWidth > 0 && boundsOptions.outHeight > 0) {
            SelectedImageItem(
                uri = Uri.fromFile(outFile),
                displayName = simpleName,
                originalSize = len,
                mimeType = guessMimeTypeFromName(simpleName),
                width = boundsOptions.outWidth,
                height = boundsOptions.outHeight,
                fromArchiveName = archiveDisplayName
            )
        } else {
            outFile.delete()
            null
        }
    }

    /**
     * 并行快速读取选中图片的元数据（支持百张级超大图片瞬间解析，复用 64KB 线程局部解码缓存）
     */
    suspend fun inspectImages(context: Context, uris: List<Uri>): List<SelectedImageItem> =
        withContext(Dispatchers.IO) {
            coroutineScope {
                uris.chunked(12).flatMap { chunk ->
                    chunk.map { uri ->
                        async {
                            runCatching {
                                val resolver = context.contentResolver
                                var name = ""
                                var size = 0L

                                if (uri.scheme == "file") {
                                    val f = File(uri.path ?: "")
                                    name = f.name
                                    size = f.length()
                                } else {
                                    resolver.query(
                                        uri,
                                        arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                                        null,
                                        null,
                                        null
                                    )?.use { cursor ->
                                        if (cursor.moveToFirst()) {
                                            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                                            if (nameIdx != -1 && !cursor.isNull(nameIdx)) {
                                                name = cursor.getString(nameIdx)
                                            }
                                            val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                                            if (sizeIdx != -1 && !cursor.isNull(sizeIdx)) {
                                                size = cursor.getLong(sizeIdx)
                                            }
                                        }
                                    }
                                }

                                if (name.isBlank()) {
                                    name = uri.lastPathSegment?.substringAfterLast('/')
                                        ?: "image_${System.currentTimeMillis()}.jpg"
                                }

                                if (size <= 0L) {
                                    resolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                                        size = afd.length.coerceAtLeast(0L)
                                    }
                                }

                                val mimeType = resolver.getType(uri) ?: guessMimeTypeFromName(name)

                                val boundsOptions = BitmapFactory.Options().apply {
                                    inJustDecodeBounds = true
                                    inTempStorage = DECODE_TEMP_STORAGE.get()
                                }
                                if (uri.scheme == "file" && !uri.path.isNullOrBlank()) {
                                    BitmapFactory.decodeFile(uri.path, boundsOptions)
                                } else {
                                    resolver.openInputStream(uri)?.use { input ->
                                        BitmapFactory.decodeStream(input, null, boundsOptions)
                                    }
                                }

                                SelectedImageItem(
                                    uri = uri,
                                    displayName = name,
                                    originalSize = size,
                                    mimeType = mimeType,
                                    width = boundsOptions.outWidth.coerceAtLeast(0),
                                    height = boundsOptions.outHeight.coerceAtLeast(0)
                                )
                            }.getOrNull()
                        }
                    }.awaitAll().filterNotNull()
                }
            }
        }

    private fun queryDisplayName(context: Context, uri: Uri): String {
        if (uri.scheme == "file") {
            return uri.lastPathSegment ?: ""
        }
        runCatching {
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx != -1 && !cursor.isNull(idx)) {
                        return cursor.getString(idx)
                    }
                }
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: ""
    }

    /**
     * 批量执行图片处理或直接打包压入压缩包（内置零外部依赖的密码加密 ZIP/CBZ 写入器）
     */
    suspend fun processBatch(
        context: Context,
        items: List<SelectedImageItem>,
        config: CompressionConfig,
        onProgress: (completedCount: Int, totalCount: Int, latestResult: CompressionResult) -> Unit
    ): BatchExecutionReport = withContext(Dispatchers.IO) {
        val total = items.size
        val results = ArrayList<CompressionResult>(total)
        var lastEmitMs = 0L
        val throttledBatchProgress: (Int, Int, CompressionResult) -> Unit = { done, totalCnt, res ->
            val now = System.currentTimeMillis()
            if (done <= 1 || done == totalCnt || !res.isSuccess || (now - lastEmitMs) >= 50L) {
                lastEmitMs = now
                onProgress(done, totalCnt, res)
            }
        }

        val shouldPackIntoArchive = (config.mode == ProcessMode.ARCHIVE_HUB &&
            config.archiveSubMode == ArchiveSubMode.PACK_TO_ARCHIVE) ||
            (config.mode != ProcessMode.ARCHIVE_HUB && config.packResultIntoArchive)

        if (!shouldPackIntoArchive) {
            items.forEachIndexed { index, item ->
                ensureActive()
                val result = if (config.mode == ProcessMode.ARCHIVE_HUB) {
                    exportRawImageDirectly(context, item, config, index)
                } else {
                    processSingleImageToSavedFile(context, item, config, index)
                }
                results.add(result)
                throttledBatchProgress(index + 1, total, result)
            }
            return@withContext BatchExecutionReport(itemResults = results)
        }

        val timestamp = SimpleDateFormat("MMdd_HHmmss", Locale.US).format(Date())
        val baseArchiveName = config.customArchiveBaseName.trim().ifBlank {
            when (config.mode) {
                ProcessMode.COMPRESS_TRANSCODE -> "Compressed_$timestamp"
                ProcessMode.OBFUSCATE_ENCRYPT -> "Obfuscated_$timestamp"
                ProcessMode.DEOBFUSCATE_RESTORE -> "Restored_$timestamp"
                ProcessMode.ARCHIVE_HUB, ProcessMode.ARCHIVE_READER -> "Photos_$timestamp"
            }
        }
        val archiveFileName = "${sanitizeFileName(baseArchiveName)}.${config.archiveOutputFormat.extension}"
        val tempArchiveFile = File(context.cacheDir, "pack_tmp_${System.currentTimeMillis()}.${config.archiveOutputFormat.extension}")
        if (tempArchiveFile.exists()) tempArchiveFile.delete()

        val usedEntryNames = HashSet<String>()
        val isEncryptedZip = (config.archiveOutputFormat == ArchiveOutputFormat.ZIP ||
            config.archiveOutputFormat == ArchiveOutputFormat.CBZ) &&
            config.archivePassword.isNotBlank()

        try {
            when {
                isEncryptedZip -> {
                    val encryptedEntries = ArrayList<Pair<String, ByteArray>>()
                    items.forEachIndexed { index, item ->
                        ensureActive()
                        val prepared = prepareImageBytesForArchive(context, item, config, index)
                        if (prepared.result.isSuccess && prepared.bytes != null) {
                            val uniqueName = allocateUniqueEntryName(prepared.result.outputName, usedEntryNames)
                            encryptedEntries.add(uniqueName to prepared.bytes)
                            val updatedRes = prepared.result.copy(
                                savedPathLabel = "加密归档: $archiveFileName/$uniqueName",
                                packedIntoArchiveName = archiveFileName
                            )
                            results.add(updatedRes)
                            throttledBatchProgress(index + 1, total, updatedRes)
                        } else {
                            results.add(prepared.result)
                            throttledBatchProgress(index + 1, total, prepared.result)
                        }
                    }
                    writePasswordProtectedZipFile(
                        targetFile = tempArchiveFile,
                        entries = encryptedEntries,
                        password = config.archivePassword
                    )
                }

                config.archiveOutputFormat == ArchiveOutputFormat.ZIP ||
                    config.archiveOutputFormat == ArchiveOutputFormat.CBZ -> {
                    FileOutputStream(tempArchiveFile).use { rawFos ->
                        ZipOutputStream(BufferedOutputStream(rawFos)).use { zos ->
                            zos.setLevel(config.archiveCompressionLevel.zipLevel)
                            items.forEachIndexed { index, item ->
                                ensureActive()
                                val prepared = prepareImageBytesForArchive(context, item, config, index)
                                if (prepared.result.isSuccess && prepared.bytes != null) {
                                    val uniqueName = allocateUniqueEntryName(prepared.result.outputName, usedEntryNames)
                                    val entry = ZipEntry(uniqueName).apply {
                                        time = System.currentTimeMillis()
                                    }
                                    zos.putNextEntry(entry)
                                    zos.write(prepared.bytes)
                                    zos.closeEntry()
                                    val updatedRes = prepared.result.copy(
                                        savedPathLabel = "已打入: $archiveFileName/$uniqueName",
                                        packedIntoArchiveName = archiveFileName
                                    )
                                    results.add(updatedRes)
                                    throttledBatchProgress(index + 1, total, updatedRes)
                                } else {
                                    results.add(prepared.result)
                                    throttledBatchProgress(index + 1, total, prepared.result)
                                }
                            }
                            zos.finish()
                        }
                    }
                }

                config.archiveOutputFormat == ArchiveOutputFormat.SEVEN_Z -> {
                    SevenZOutputFile(tempArchiveFile).use { sevenZOut ->
                        items.forEachIndexed { index, item ->
                            ensureActive()
                            val prepared = prepareImageBytesForArchive(context, item, config, index)
                            if (prepared.result.isSuccess && prepared.bytes != null) {
                                val uniqueName = allocateUniqueEntryName(prepared.result.outputName, usedEntryNames)
                                val entry = SevenZArchiveEntry().apply {
                                    setName(uniqueName)
                                    setDirectory(false)
                                    setLastModifiedDate(Date())
                                    setSize(prepared.bytes.size.toLong())
                                }
                                sevenZOut.putArchiveEntry(entry)
                                sevenZOut.write(prepared.bytes)
                                sevenZOut.closeArchiveEntry()
                                val updatedRes = prepared.result.copy(
                                    savedPathLabel = "已打入 7Z: $archiveFileName/$uniqueName",
                                    packedIntoArchiveName = archiveFileName
                                )
                                results.add(updatedRes)
                                throttledBatchProgress(index + 1, total, updatedRes)
                            } else {
                                results.add(prepared.result)
                                throttledBatchProgress(index + 1, total, prepared.result)
                            }
                        }
                        sevenZOut.finish()
                    }
                }

                else -> {
                    FileOutputStream(tempArchiveFile).use { rawFos ->
                        val bufferedOut = BufferedOutputStream(rawFos)
                        val tarStream = when (config.archiveOutputFormat) {
                            ArchiveOutputFormat.TAR_GZ -> TarArchiveOutputStream(GzipCompressorOutputStream(bufferedOut))
                            ArchiveOutputFormat.TAR_XZ -> TarArchiveOutputStream(XZCompressorOutputStream(bufferedOut))
                            else -> TarArchiveOutputStream(bufferedOut)
                        }
                        tarStream.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX)
                        tarStream.use { tos ->
                            items.forEachIndexed { index, item ->
                                ensureActive()
                                val prepared = prepareImageBytesForArchive(context, item, config, index)
                                if (prepared.result.isSuccess && prepared.bytes != null) {
                                    val uniqueName = allocateUniqueEntryName(prepared.result.outputName, usedEntryNames)
                                    val tarEntry = TarArchiveEntry(uniqueName).apply {
                                        setSize(prepared.bytes.size.toLong())
                                        setModTime(Date())
                                    }
                                    tos.putArchiveEntry(tarEntry)
                                    tos.write(prepared.bytes)
                                    tos.closeArchiveEntry()
                                    val updatedRes = prepared.result.copy(
                                        savedPathLabel = "已打入归档: $archiveFileName/$uniqueName",
                                        packedIntoArchiveName = archiveFileName
                                    )
                                    results.add(updatedRes)
                                    throttledBatchProgress(index + 1, total, updatedRes)
                                } else {
                                    results.add(prepared.result)
                                    throttledBatchProgress(index + 1, total, prepared.result)
                                }
                            }
                            tos.finish()
                        }
                    }
                }
            }

            val archiveSize = tempArchiveFile.length()
            val (savedArchiveUri, archivePathLabel) = saveArchiveFileToTarget(
                context = context,
                sourceFile = tempArchiveFile,
                fileName = archiveFileName,
                mimeType = config.archiveOutputFormat.mimeType,
                customTreeUri = config.customTreeUri
            )

            val finalResults = results.map { res ->
                if (res.isSuccess) {
                    res.copy(savedPathLabel = "$archivePathLabel (${res.outputName})")
                } else {
                    res
                }
            }

            BatchExecutionReport(
                itemResults = finalResults,
                archiveSavedUri = savedArchiveUri,
                archiveFileName = archiveFileName,
                archiveSavedPathLabel = archivePathLabel,
                archiveTotalBytes = archiveSize,
                isArchiveEncrypted = isEncryptedZip
            )
        } finally {
            tempArchiveFile.delete()
        }
    }

    /**
     * 生成标准 PKWARE ZipCrypto 加密的 .zip / .cbz 压缩包（全平台通用，零第三方依赖）
     */
    private fun writePasswordProtectedZipFile(
        targetFile: File,
        entries: List<Pair<String, ByteArray>>,
        password: String
    ) {
        val pwdBytes = password.toByteArray(Charsets.UTF_8)
        val secureRandom = SecureRandom()

        data class CentralRecord(
            val nameBytes: ByteArray,
            val crc: Int,
            val compSize: Int,
            val uncompSize: Int,
            val localHeaderOffset: Int
        )

        val centralRecords = ArrayList<CentralRecord>(entries.size)
        var currentOffset = 0

        FileOutputStream(targetFile).use { rawFos ->
            BufferedOutputStream(rawFos).use { out ->
                for ((entryName, plainBytes) in entries) {
                    val nameBytes = entryName.toByteArray(Charsets.UTF_8)
                    val crcCalc = CRC32()
                    crcCalc.update(plainBytes)
                    val crcVal = crcCalc.value.toInt()

                    val cipher = PkwareZipCryptoCipher(pwdBytes)
                    val randomHeader = ByteArray(12)
                    secureRandom.nextBytes(randomHeader)
                    randomHeader[11] = ((crcVal ushr 24) and 0xFF).toByte()

                    val encHeader = ByteArray(12)
                    for (i in 0 until 12) {
                        encHeader[i] = cipher.encryptByte(randomHeader[i].toInt())
                    }
                    val encPayload = ByteArray(plainBytes.size)
                    for (i in plainBytes.indices) {
                        encPayload[i] = cipher.encryptByte(plainBytes[i].toInt())
                    }

                    val compSize = 12 + encPayload.size
                    val uncompSize = plainBytes.size
                    val localOffset = currentOffset

                    val lfh = ByteBuffer.allocate(30).order(ByteOrder.LITTLE_ENDIAN).apply {
                        putInt(0x04034B50)
                        putShort(20.toShort())
                        putShort(0x0801.toShort()) // Bit 0 (Encrypted) + Bit 11 (UTF-8)
                        putShort(0.toShort())      // STORED
                        putShort(0.toShort())
                        putShort(0x0021.toShort())
                        putInt(crcVal)
                        putInt(compSize)
                        putInt(uncompSize)
                        putShort(nameBytes.size.toShort())
                        putShort(0.toShort())
                    }.array()

                    out.write(lfh)
                    out.write(nameBytes)
                    out.write(encHeader)
                    out.write(encPayload)

                    currentOffset += 30 + nameBytes.size + compSize
                    centralRecords.add(
                        CentralRecord(
                            nameBytes = nameBytes,
                            crc = crcVal,
                            compSize = compSize,
                            uncompSize = uncompSize,
                            localHeaderOffset = localOffset
                        )
                    )
                }

                val cdStartOffset = currentOffset
                var cdSize = 0
                for (rec in centralRecords) {
                    val cdh = ByteBuffer.allocate(46).order(ByteOrder.LITTLE_ENDIAN).apply {
                        putInt(0x02014B50)
                        putShort(20.toShort())
                        putShort(20.toShort())
                        putShort(0x0801.toShort())
                        putShort(0.toShort())
                        putShort(0.toShort())
                        putShort(0x0021.toShort())
                        putInt(rec.crc)
                        putInt(rec.compSize)
                        putInt(rec.uncompSize)
                        putShort(rec.nameBytes.size.toShort())
                        putShort(0.toShort())
                        putShort(0.toShort())
                        putShort(0.toShort())
                        putShort(0.toShort())
                        putInt(0)
                        putInt(rec.localHeaderOffset)
                    }.array()
                    out.write(cdh)
                    out.write(rec.nameBytes)
                    cdSize += 46 + rec.nameBytes.size
                }

                val eocd = ByteBuffer.allocate(22).order(ByteOrder.LITTLE_ENDIAN).apply {
                    putInt(0x06054B50)
                    putShort(0.toShort())
                    putShort(0.toShort())
                    putShort(centralRecords.size.toShort())
                    putShort(centralRecords.size.toShort())
                    putInt(cdSize)
                    putInt(cdStartOffset)
                    putShort(0.toShort())
                }.array()
                out.write(eocd)
                out.flush()
            }
        }
    }

    private data class PreparedArchiveEntry(
        val result: CompressionResult,
        val bytes: ByteArray?
    )

    private fun allocateUniqueEntryName(desiredName: String, used: MutableSet<String>): String {
        if (used.add(desiredName)) return desiredName
        val stem = desiredName.substringBeforeLast('.')
        val ext = desiredName.substringAfterLast('.', "jpg")
        var counter = 2
        while (true) {
            val candidate = "${stem}_$counter.$ext"
            if (used.add(candidate)) return candidate
            counter++
        }
    }

    private fun buildFormattedFileName(
        item: SelectedImageItem,
        config: CompressionConfig,
        sequenceIndex: Int,
        effectiveExtension: String
    ): String {
        val rawStem = item.displayName
            .substringBeforeLast('.')
            .replace(Regex("^(COMP_|OBF_B\\d+_|OBF_|RESTORED_|ARC_)"), "")
            .ifBlank { "image_${sequenceIndex + 1}" }

        val indexStr = String.format(Locale.US, "%03d", sequenceIndex + 1)
        val dateStr = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val customPrefix = sanitizeFileName(config.customRenamePrefix.trim().ifBlank { "IMG" })

        val coreBase = when (config.renameTemplate) {
            RenameTemplate.KEEP_ORIGINAL -> sanitizeFileName(rawStem)
            RenameTemplate.PREFIX_INDEX -> "${customPrefix}_$indexStr"
            RenameTemplate.DATE_INDEX -> "${dateStr}_$indexStr"
        }

        val modePrefix = when (config.mode) {
            ProcessMode.COMPRESS_TRANSCODE -> if (config.renameTemplate == RenameTemplate.KEEP_ORIGINAL) "COMP_" else ""
            ProcessMode.OBFUSCATE_ENCRYPT -> {
                if (config.autoTagBlockSizeInName) {
                    "OBF_${config.blockGridSize.fileTag}_"
                } else {
                    "OBF_"
                }
            }
            ProcessMode.DEOBFUSCATE_RESTORE -> if (config.renameTemplate == RenameTemplate.KEEP_ORIGINAL) "RESTORED_" else ""
            ProcessMode.ARCHIVE_HUB, ProcessMode.ARCHIVE_READER -> ""
        }

        return "${modePrefix}${coreBase}.$effectiveExtension"
    }

    private fun prepareImageBytesForArchive(
        context: Context,
        item: SelectedImageItem,
        config: CompressionConfig,
        sequenceIndex: Int
    ): PreparedArchiveEntry {
        if (config.mode == ProcessMode.ARCHIVE_HUB) {
            return try {
                val rawBytes = context.contentResolver.openInputStream(item.uri)?.use { it.readBytes() }
                    ?: return PreparedArchiveEntry(
                        result = CompressionResult(
                            source = item,
                            isSuccess = false,
                            mode = config.mode,
                            errorMessage = "无法读取原图字节流"
                        ),
                        bytes = null
                    )
                val ext = item.displayName.substringAfterLast('.', "jpg").lowercase(Locale.ROOT)
                val outName = buildFormattedFileName(item, config, sequenceIndex, ext)
                PreparedArchiveEntry(
                    result = CompressionResult(
                        source = item,
                        isSuccess = true,
                        mode = config.mode,
                        outputUri = item.uri,
                        outputName = outName,
                        compressedSize = rawBytes.size.toLong(),
                        outputWidth = item.width,
                        outputHeight = item.height,
                        outputFormat = OutputFormat.PNG
                    ),
                    bytes = rawBytes
                )
            } catch (e: Exception) {
                PreparedArchiveEntry(
                    result = CompressionResult(
                        source = item,
                        isSuccess = false,
                        mode = config.mode,
                        errorMessage = e.localizedMessage ?: "读取图片失败"
                    ),
                    bytes = null
                )
            }
        }

        return encodeSingleImageInMemory(context, item, config, sequenceIndex, cachePreview = true)
    }

    private fun saveArchiveFileToTarget(
        context: Context,
        sourceFile: File,
        fileName: String,
        mimeType: String,
        customTreeUri: Uri?
    ): Pair<Uri, String> {
        if (customTreeUri != null) {
            val treeDir = DocumentFile.fromTreeUri(context, customTreeUri)
                ?: throw IllegalStateException("无法访问自定义目录")
            val finalName = if (treeDir.findFile(fileName) != null) {
                val stem = fileName.substringBefore('.')
                val ext = fileName.substringAfter('.')
                "${stem}_${System.currentTimeMillis() % 10000}.$ext"
            } else {
                fileName
            }
            val targetFile = treeDir.createFile(mimeType, finalName)
                ?: throw IllegalStateException("无法创建压缩包: $finalName")
            context.contentResolver.openOutputStream(targetFile.uri, "wt")?.use { out ->
                FileInputStream(sourceFile).use { input ->
                    input.copyTo(out)
                }
                out.flush()
            } ?: throw IllegalStateException("无法打开输出流")
            val dirName = treeDir.name ?: "自定义目录"
            return targetFile.uri to "$dirName/$finalName"
        }

        val resolver = context.contentResolver
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativePath = "${Environment.DIRECTORY_DOWNLOADS}/CompressedArchives"
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.RELATIVE_PATH, relativePath)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("无法在下载目录创建压缩包")

            resolver.openOutputStream(uri)?.use { out ->
                FileInputStream(sourceFile).use { input ->
                    input.copyTo(out)
                }
                out.flush()
            } ?: throw IllegalStateException("无法写入下载目录")

            val completeValues = ContentValues().apply {
                put(MediaStore.Downloads.IS_PENDING, 0)
            }
            resolver.update(uri, completeValues, null, null)
            return uri to "Download/CompressedArchives/$fileName"
        } else {
            @Suppress("DEPRECATION")
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val archiveDir = File(downloadsDir, "CompressedArchives").apply {
                if (!exists()) mkdirs()
            }
            val outFile = File(archiveDir, fileName)
            FileInputStream(sourceFile).use { input ->
                FileOutputStream(outFile).use { out ->
                    input.copyTo(out)
                    out.flush()
                }
            }
            return Uri.fromFile(outFile) to "Download/CompressedArchives/${outFile.name}"
        }
    }

    private fun exportRawImageDirectly(
        context: Context,
        item: SelectedImageItem,
        config: CompressionConfig,
        sequenceIndex: Int
    ): CompressionResult {
        return try {
            val rawBytes = context.contentResolver.openInputStream(item.uri)?.use { it.readBytes() }
                ?: return CompressionResult(
                    source = item,
                    isSuccess = false,
                    mode = ProcessMode.ARCHIVE_HUB,
                    errorMessage = "无法读取源文件"
                )

            val ext = item.displayName.substringAfterLast('.', "jpg").lowercase(Locale.ROOT)
            val outputFileName = buildFormattedFileName(item, config, sequenceIndex, ext)
            val mimeType = item.mimeType.ifBlank { guessMimeTypeFromName(outputFileName) }

            val (savedUri, locationDesc) = if (config.customTreeUri != null) {
                saveToCustomDocumentTree(
                    context = context,
                    treeUri = config.customTreeUri,
                    fileName = outputFileName,
                    mimeType = mimeType,
                    bytes = rawBytes
                )
            } else {
                saveToSystemGallery(
                    context = context,
                    fileName = outputFileName,
                    mimeType = mimeType,
                    bytes = rawBytes
                )
            }

            CompressionResult(
                source = item,
                isSuccess = true,
                mode = ProcessMode.ARCHIVE_HUB,
                outputUri = savedUri,
                outputName = outputFileName,
                compressedSize = rawBytes.size.toLong(),
                outputWidth = item.width,
                outputHeight = item.height,
                outputFormat = OutputFormat.PNG,
                savedPathLabel = locationDesc
            )
        } catch (e: Exception) {
            CompressionResult(
                source = item,
                isSuccess = false,
                mode = ProcessMode.ARCHIVE_HUB,
                errorMessage = e.localizedMessage ?: "导出失败"
            )
        }
    }

    private fun processSingleImageToSavedFile(
        context: Context,
        item: SelectedImageItem,
        config: CompressionConfig,
        sequenceIndex: Int
    ): CompressionResult {
        val prepared = encodeSingleImageInMemory(context, item, config, sequenceIndex, cachePreview = false)
        if (!prepared.result.isSuccess || prepared.bytes == null) {
            return prepared.result
        }

        return try {
            val effectiveFormat = prepared.result.outputFormat
            val outputFileName = prepared.result.outputName
            val (savedUri, locationDesc) = if (config.customTreeUri != null) {
                saveToCustomDocumentTree(
                    context = context,
                    treeUri = config.customTreeUri,
                    fileName = outputFileName,
                    mimeType = effectiveFormat.mimeType,
                    bytes = prepared.bytes
                )
            } else {
                saveToSystemGallery(
                    context = context,
                    fileName = outputFileName,
                    mimeType = effectiveFormat.mimeType,
                    bytes = prepared.bytes
                )
            }
            prepared.result.copy(
                outputUri = savedUri,
                savedPathLabel = locationDesc
            )
        } catch (e: Exception) {
            prepared.result.copy(
                isSuccess = false,
                errorMessage = e.localizedMessage ?: "写入失败"
            )
        }
    }

    private fun encodeSingleImageInMemory(
        context: Context,
        item: SelectedImageItem,
        config: CompressionConfig,
        sequenceIndex: Int,
        cachePreview: Boolean
    ): PreparedArchiveEntry {
        return try {
            val resolver = context.contentResolver
            val isObfuscationFlow = config.mode == ProcessMode.OBFUSCATE_ENCRYPT ||
                config.mode == ProcessMode.DEOBFUSCATE_RESTORE

            if (isObfuscationFlow && config.obfuscationKey.isBlank()) {
                return PreparedArchiveEntry(
                    result = CompressionResult(
                        source = item,
                        isSuccess = false,
                        mode = config.mode,
                        errorMessage = "请输入文字口令"
                    ),
                    bytes = null
                )
            }

            val maxTargetDim = if (config.mode == ProcessMode.DEOBFUSCATE_RESTORE) {
                null
            } else {
                config.resolutionOption.maxDimensionPx
            }

            val sampleSize = if (config.mode == ProcessMode.DEOBFUSCATE_RESTORE) {
                1
            } else {
                calculateInSampleSize(
                    srcWidth = item.width,
                    srcHeight = item.height,
                    maxDimension = maxTargetDim
                )
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
                inScaled = false
            }

            val rawBitmap = resolver.openInputStream(item.uri)?.use { input ->
                BitmapFactory.decodeStream(input, null, decodeOptions)
            } ?: return PreparedArchiveEntry(
                result = CompressionResult(
                    source = item,
                    isSuccess = false,
                    mode = config.mode,
                    errorMessage = "无法解码源图"
                ),
                bytes = null
            )

            val orientedBitmap = if (config.mode == ProcessMode.DEOBFUSCATE_RESTORE) {
                rawBitmap
            } else {
                val exifOrientation = resolver.openInputStream(item.uri)?.use { exifStream ->
                    runCatching {
                        val exif = ExifInterface(exifStream)
                        exif.getAttributeInt(
                            ExifInterface.TAG_ORIENTATION,
                            ExifInterface.ORIENTATION_NORMAL
                        )
                    }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
                } ?: ExifInterface.ORIENTATION_NORMAL

                applyExifOrientation(rawBitmap, exifOrientation).also {
                    if (it !== rawBitmap) rawBitmap.recycle()
                }
            }

            val scaledBitmap = if (config.mode == ProcessMode.DEOBFUSCATE_RESTORE) {
                orientedBitmap
            } else {
                scaleDownIfNeeded(orientedBitmap, maxTargetDim).also {
                    if (it !== orientedBitmap) orientedBitmap.recycle()
                }
            }

            val effectiveOutputFormat = when (config.mode) {
                ProcessMode.OBFUSCATE_ENCRYPT -> OutputFormat.PNG
                ProcessMode.DEOBFUSCATE_RESTORE -> config.format
                ProcessMode.COMPRESS_TRANSCODE -> config.format
                ProcessMode.ARCHIVE_HUB, ProcessMode.ARCHIVE_READER -> OutputFormat.PNG
            }

            val effectiveGridSize = if (config.mode == ProcessMode.DEOBFUSCATE_RESTORE) {
                detectBlockGridFromItems(listOf(item)) ?: config.blockGridSize
            } else {
                config.blockGridSize
            }

            val processedBitmap = when (config.mode) {
                ProcessMode.OBFUSCATE_ENCRYPT -> {
                    transformImageBlocks(
                        source = scaledBitmap,
                        secretKey = config.obfuscationKey,
                        blockSize = effectiveGridSize.blockPx,
                        isEncrypt = true
                    ).also {
                        if (it !== scaledBitmap) scaledBitmap.recycle()
                    }
                }
                ProcessMode.DEOBFUSCATE_RESTORE -> {
                    transformImageBlocks(
                        source = scaledBitmap,
                        secretKey = config.obfuscationKey,
                        blockSize = effectiveGridSize.blockPx,
                        isEncrypt = false
                    ).also {
                        if (it !== scaledBitmap) scaledBitmap.recycle()
                    }
                }
                else -> scaledBitmap
            }

            val finalBitmap = if (effectiveOutputFormat == OutputFormat.JPEG && processedBitmap.hasAlpha()) {
                flattenAlphaOnWhite(processedBitmap).also {
                    if (it !== processedBitmap) processedBitmap.recycle()
                }
            } else {
                processedBitmap
            }

            val outWidth = finalBitmap.width
            val outHeight = finalBitmap.height

            var encodedBytes = ByteArrayOutputStream().use { buffer ->
                val compressFormat = resolveBitmapCompressFormat(effectiveOutputFormat)
                val effectiveQuality = when (effectiveOutputFormat) {
                    OutputFormat.JPEG, OutputFormat.WEBP_LOSSY -> config.quality.coerceIn(10, 100)
                    OutputFormat.WEBP_LOSSLESS, OutputFormat.PNG -> 100
                }
                val ok = finalBitmap.compress(compressFormat, effectiveQuality, buffer)
                finalBitmap.recycle()
                if (!ok) {
                    return PreparedArchiveEntry(
                        result = CompressionResult(
                            source = item,
                            isSuccess = false,
                            mode = config.mode,
                            errorMessage = "编码失败"
                        ),
                        bytes = null
                    )
                }
                buffer.toByteArray()
            }

            if (!config.stripExifMetadata && effectiveOutputFormat == OutputFormat.JPEG) {
                encodedBytes = preserveSafeExifInJpegBytes(context, item.uri, encodedBytes)
            }

            val outputFileName = buildFormattedFileName(
                item = item,
                config = config,
                sequenceIndex = sequenceIndex,
                effectiveExtension = effectiveOutputFormat.extension
            )

            val previewUri = runCatching {
                val previewDir = File(context.cacheDir, "packed_previews").apply {
                    if (!exists()) mkdirs()
                }
                val previewFile = File(previewDir, "${System.currentTimeMillis()}_${sequenceIndex}_$outputFileName")
                FileOutputStream(previewFile).use { it.write(encodedBytes) }
                Uri.fromFile(previewFile)
            }.getOrNull()

            PreparedArchiveEntry(
                result = CompressionResult(
                    source = item,
                    isSuccess = true,
                    mode = config.mode,
                    outputUri = previewUri,
                    outputName = outputFileName,
                    compressedSize = encodedBytes.size.toLong(),
                    outputWidth = outWidth,
                    outputHeight = outHeight,
                    outputFormat = effectiveOutputFormat
                ),
                bytes = encodedBytes
            )
        } catch (e: Exception) {
            PreparedArchiveEntry(
                result = CompressionResult(
                    source = item,
                    isSuccess = false,
                    mode = config.mode,
                    errorMessage = e.localizedMessage ?: "处理出错"
                ),
                bytes = null
            )
        }
    }

    private fun preserveSafeExifInJpegBytes(
        context: Context,
        sourceUri: Uri,
        jpegBytes: ByteArray
    ): ByteArray {
        return runCatching {
            val tempFile = File(context.cacheDir, "exif_tmp_${System.currentTimeMillis()}.jpg")
            try {
                FileOutputStream(tempFile).use { it.write(jpegBytes) }
                val srcExif = context.contentResolver.openInputStream(sourceUri)?.use { ExifInterface(it) }
                    ?: return jpegBytes
                val dstExif = ExifInterface(tempFile)
                val safeTags = listOf(
                    ExifInterface.TAG_MAKE,
                    ExifInterface.TAG_MODEL,
                    ExifInterface.TAG_DATETIME,
                    ExifInterface.TAG_DATETIME_ORIGINAL,
                    ExifInterface.TAG_EXPOSURE_TIME,
                    ExifInterface.TAG_F_NUMBER,
                    ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY,
                    ExifInterface.TAG_FOCAL_LENGTH,
                    ExifInterface.TAG_WHITE_BALANCE
                )
                for (tag in safeTags) {
                    val v = srcExif.getAttribute(tag)
                    if (!v.isNullOrBlank()) {
                        dstExif.setAttribute(tag, v)
                    }
                }
                dstExif.saveAttributes()
                tempFile.readBytes()
            } finally {
                tempFile.delete()
            }
        }.getOrDefault(jpegBytes)
    }

    /**
     * 核心可逆色块混淆与无损还原算法（性能优化版：零 Pair 对象分配 + 复用小块缓冲区，大幅降低内存峰值与 GC 停顿）
     */
    private fun transformImageBlocks(
        source: Bitmap,
        secretKey: String,
        blockSize: Int,
        isEncrypt: Boolean
    ): Bitmap {
        val width = source.width
        val height = source.height
        val outBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

        val bSize = blockSize.coerceIn(4, 128)
        val fullCols = width / bSize
        val fullRows = height / bSize
        val remW = width % bSize
        val remH = height % bSize
        val last = bSize - 1

        // 仅分配两个轻量级色块缓冲区（例如 16x16 仅占 1KB），避免分配两个全尺寸 4K IntArray 及上千万个 Pair 对象
        val srcBlock = IntArray(bSize * bSize)
        val dstBlock = IntArray(bSize * bSize)

        val mainBlockCount = fullCols * fullRows
        if (mainBlockCount > 0) {
            val prng = KeySeededRandom(secretKey, "MAIN_${width}x${height}_$bSize")
            val perm = generatePermutation(mainBlockCount, prng)
            val orientations = IntArray(mainBlockCount) { prng.nextInt(8) }
            val dR = IntArray(mainBlockCount) { prng.nextByteMask() }
            val dG = IntArray(mainBlockCount) { prng.nextByteMask() }
            val dB = IntArray(mainBlockCount) { prng.nextByteMask() }

            for (srcIdx in 0 until mainBlockCount) {
                val dstIdx = perm[srcIdx]
                val orient = orientations[srcIdx] and 7
                val rShift = dR[srcIdx]
                val gShift = dG[srcIdx]
                val bShift = dB[srcIdx]

                val srcStartX = (srcIdx % fullCols) * bSize
                val srcStartY = (srcIdx / fullCols) * bSize
                val dstStartX = (dstIdx % fullCols) * bSize
                val dstStartY = (dstIdx / fullCols) * bSize

                if (isEncrypt) {
                    source.getPixels(srcBlock, 0, bSize, srcStartX, srcStartY, bSize, bSize)
                    for (localY in 0 until bSize) {
                        val rowOffset = localY * bSize
                        for (localX in 0 until bSize) {
                            val tx: Int
                            val ty: Int
                            when (orient) {
                                0 -> { tx = localX; ty = localY }
                                1 -> { tx = last - localY; ty = localX }
                                2 -> { tx = last - localX; ty = last - localY }
                                3 -> { tx = localY; ty = last - localX }
                                4 -> { tx = last - localX; ty = localY }
                                5 -> { tx = localX; ty = last - localY }
                                6 -> { tx = localY; ty = localX }
                                else -> { tx = last - localY; ty = last - localX }
                            }
                            dstBlock[ty * bSize + tx] = shiftPixelColor(
                                srcBlock[rowOffset + localX],
                                rShift,
                                gShift,
                                bShift,
                                true
                            )
                        }
                    }
                    outBitmap.setPixels(dstBlock, 0, bSize, dstStartX, dstStartY, bSize, bSize)
                } else {
                    source.getPixels(srcBlock, 0, bSize, dstStartX, dstStartY, bSize, bSize)
                    for (localY in 0 until bSize) {
                        val rowOffset = localY * bSize
                        for (localX in 0 until bSize) {
                            val tx: Int
                            val ty: Int
                            when (orient) {
                                0 -> { tx = localX; ty = localY }
                                1 -> { tx = last - localY; ty = localX }
                                2 -> { tx = last - localX; ty = last - localY }
                                3 -> { tx = localY; ty = last - localX }
                                4 -> { tx = last - localX; ty = localY }
                                5 -> { tx = localX; ty = last - localY }
                                6 -> { tx = localY; ty = localX }
                                else -> { tx = last - localY; ty = last - localX }
                            }
                            dstBlock[rowOffset + localX] = shiftPixelColor(
                                srcBlock[ty * bSize + tx],
                                rShift,
                                gShift,
                                bShift,
                                false
                            )
                        }
                    }
                    outBitmap.setPixels(dstBlock, 0, bSize, srcStartX, srcStartY, bSize, bSize)
                }
            }
        }

        if (remW > 0 && fullRows > 0) {
            val prng = KeySeededRandom(secretKey, "RIGHT_${width}x${height}_$bSize")
            val perm = generatePermutation(fullRows, prng)
            val flipFlags = IntArray(fullRows) { prng.nextInt(4) }
            val dR = IntArray(fullRows) { prng.nextByteMask() }
            val dG = IntArray(fullRows) { prng.nextByteMask() }
            val dB = IntArray(fullRows) { prng.nextByteMask() }
            val startX = fullCols * bSize
            val rightSrc = IntArray(remW * bSize)
            val rightDst = IntArray(remW * bSize)

            for (srcRow in 0 until fullRows) {
                val dstRow = perm[srcRow]
                val flip = flipFlags[srcRow]
                val rShift = dR[srcRow]
                val gShift = dG[srcRow]
                val bShift = dB[srcRow]

                val srcStartY = srcRow * bSize
                val dstStartY = dstRow * bSize

                if (isEncrypt) {
                    source.getPixels(rightSrc, 0, remW, startX, srcStartY, remW, bSize)
                    for (localY in 0 until bSize) {
                        val ty = if ((flip and 2) != 0) (bSize - 1 - localY) else localY
                        for (localX in 0 until remW) {
                            val tx = if ((flip and 1) != 0) (remW - 1 - localX) else localX
                            rightDst[ty * remW + tx] = shiftPixelColor(
                                rightSrc[localY * remW + localX],
                                rShift,
                                gShift,
                                bShift,
                                true
                            )
                        }
                    }
                    outBitmap.setPixels(rightDst, 0, remW, startX, dstStartY, remW, bSize)
                } else {
                    source.getPixels(rightSrc, 0, remW, startX, dstStartY, remW, bSize)
                    for (localY in 0 until bSize) {
                        val ty = if ((flip and 2) != 0) (bSize - 1 - localY) else localY
                        for (localX in 0 until remW) {
                            val tx = if ((flip and 1) != 0) (remW - 1 - localX) else localX
                            rightDst[localY * remW + localX] = shiftPixelColor(
                                rightSrc[ty * remW + tx],
                                rShift,
                                gShift,
                                bShift,
                                false
                            )
                        }
                    }
                    outBitmap.setPixels(rightDst, 0, remW, startX, srcStartY, remW, bSize)
                }
            }
        }

        if (remH > 0 && fullCols > 0) {
            val prng = KeySeededRandom(secretKey, "BOTTOM_${width}x${height}_$bSize")
            val perm = generatePermutation(fullCols, prng)
            val flipFlags = IntArray(fullCols) { prng.nextInt(4) }
            val dR = IntArray(fullCols) { prng.nextByteMask() }
            val dG = IntArray(fullCols) { prng.nextByteMask() }
            val dB = IntArray(fullCols) { prng.nextByteMask() }
            val startY = fullRows * bSize
            val botSrc = IntArray(bSize * remH)
            val botDst = IntArray(bSize * remH)

            for (srcCol in 0 until fullCols) {
                val dstCol = perm[srcCol]
                val flip = flipFlags[srcCol]
                val rShift = dR[srcCol]
                val gShift = dG[srcCol]
                val bShift = dB[srcCol]

                val srcStartX = srcCol * bSize
                val dstStartX = dstCol * bSize

                if (isEncrypt) {
                    source.getPixels(botSrc, 0, bSize, srcStartX, startY, bSize, remH)
                    for (localY in 0 until remH) {
                        val ty = if ((flip and 2) != 0) (remH - 1 - localY) else localY
                        for (localX in 0 until bSize) {
                            val tx = if ((flip and 1) != 0) (bSize - 1 - localX) else localX
                            botDst[ty * bSize + tx] = shiftPixelColor(
                                botSrc[localY * bSize + localX],
                                rShift,
                                gShift,
                                bShift,
                                true
                            )
                        }
                    }
                    outBitmap.setPixels(botDst, 0, bSize, dstStartX, startY, bSize, remH)
                } else {
                    source.getPixels(botSrc, 0, bSize, dstStartX, startY, bSize, remH)
                    for (localY in 0 until remH) {
                        val ty = if ((flip and 2) != 0) (remH - 1 - localY) else localY
                        for (localX in 0 until bSize) {
                            val tx = if ((flip and 1) != 0) (bSize - 1 - localX) else localX
                            botDst[localY * bSize + localX] = shiftPixelColor(
                                botSrc[ty * bSize + tx],
                                rShift,
                                gShift,
                                bShift,
                                false
                            )
                        }
                    }
                    outBitmap.setPixels(botDst, 0, bSize, srcStartX, startY, bSize, remH)
                }
            }
        }

        if (remW > 0 && remH > 0) {
            val cornerCount = remW * remH
            val prng = KeySeededRandom(secretKey, "CORNER_${width}x${height}_$bSize")
            val perm = generatePermutation(cornerCount, prng)
            val rShift = prng.nextByteMask()
            val gShift = prng.nextByteMask()
            val bShift = prng.nextByteMask()
            val startX = fullCols * bSize
            val startY = fullRows * bSize
            val corSrc = IntArray(cornerCount)
            val corDst = IntArray(cornerCount)
            source.getPixels(corSrc, 0, remW, startX, startY, remW, remH)

            for (idx in 0 until cornerCount) {
                val dstIdx = perm[idx]
                if (isEncrypt) {
                    corDst[dstIdx] = shiftPixelColor(corSrc[idx], rShift, gShift, bShift, true)
                } else {
                    corDst[idx] = shiftPixelColor(corSrc[dstIdx], rShift, gShift, bShift, false)
                }
            }
            outBitmap.setPixels(corDst, 0, remW, startX, startY, remW, remH)
        }

        return outBitmap
    }

    private fun generatePermutation(count: Int, prng: KeySeededRandom): IntArray {
        val arr = IntArray(count) { it }
        for (i in count - 1 downTo 1) {
            val j = prng.nextInt(i + 1)
            val tmp = arr[i]
            arr[i] = arr[j]
            arr[j] = tmp
        }
        return arr
    }

    private fun shiftPixelColor(pixel: Int, dR: Int, dG: Int, dB: Int, isEncrypt: Boolean): Int {
        val r = (pixel shr 16) and 0xFF
        val g = (pixel shr 8) and 0xFF
        val b = pixel and 0xFF

        val nr: Int
        val ng: Int
        val nb: Int
        if (isEncrypt) {
            nr = (r + dR) and 0xFF
            ng = (g + dG) and 0xFF
            nb = (b + dB) and 0xFF
        } else {
            nr = (r - dR) and 0xFF
            ng = (g - dG) and 0xFF
            nb = (b - dB) and 0xFF
        }
        return (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
    }

    @Suppress("DEPRECATION")
    private fun resolveBitmapCompressFormat(format: OutputFormat): Bitmap.CompressFormat {
        return when (format) {
            OutputFormat.JPEG -> Bitmap.CompressFormat.JPEG
            OutputFormat.PNG -> Bitmap.CompressFormat.PNG
            OutputFormat.WEBP_LOSSY -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Bitmap.CompressFormat.WEBP_LOSSY
                } else {
                    Bitmap.CompressFormat.WEBP
                }
            }
            OutputFormat.WEBP_LOSSLESS -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Bitmap.CompressFormat.WEBP_LOSSLESS
                } else {
                    Bitmap.CompressFormat.WEBP
                }
            }
        }
    }

    private fun saveToCustomDocumentTree(
        context: Context,
        treeUri: Uri,
        fileName: String,
        mimeType: String,
        bytes: ByteArray
    ): Pair<Uri, String> {
        val treeDir = DocumentFile.fromTreeUri(context, treeUri)
            ?: throw IllegalStateException("无法访问自定义目录")

        val finalName = if (treeDir.findFile(fileName) != null) {
            val stem = fileName.substringBeforeLast('.')
            val ext = fileName.substringAfterLast('.')
            "${stem}_${System.currentTimeMillis() % 100000}.$ext"
        } else {
            fileName
        }

        val targetFile = treeDir.createFile(mimeType, finalName)
            ?: throw IllegalStateException("无法创建文件: $finalName")

        context.contentResolver.openOutputStream(targetFile.uri, "wt")?.use { output ->
            output.write(bytes)
            output.flush()
        } ?: throw IllegalStateException("无法写入文件")

        val dirName = treeDir.name ?: "自定义目录"
        return targetFile.uri to "$dirName/$finalName"
    }

    private fun saveToSystemGallery(
        context: Context,
        fileName: String,
        mimeType: String,
        bytes: ByteArray
    ): Pair<Uri, String> {
        val resolver = context.contentResolver
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativePath = "${Environment.DIRECTORY_PICTURES}/Compressed"
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, mimeType)
                put(MediaStore.Images.Media.RELATIVE_PATH, relativePath)
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("无法创建相册记录")

            resolver.openOutputStream(uri)?.use { out ->
                out.write(bytes)
                out.flush()
            } ?: throw IllegalStateException("无法写入相册")

            val completeValues = ContentValues().apply {
                put(MediaStore.Images.Media.IS_PENDING, 0)
            }
            resolver.update(uri, completeValues, null, null)
            return uri to "Pictures/Compressed/$fileName"
        } else {
            @Suppress("DEPRECATION")
            val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
            val compressedDir = File(picturesDir, "Compressed").apply {
                if (!exists()) mkdirs()
            }
            val outFile = File(compressedDir, fileName)
            FileOutputStream(outFile).use { out ->
                out.write(bytes)
                out.flush()
            }
            @Suppress("DEPRECATION")
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DATA, outFile.absolutePath)
                put(MediaStore.Images.Media.MIME_TYPE, mimeType)
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: Uri.fromFile(outFile)
            return uri to "Pictures/Compressed/${outFile.name}"
        }
    }

    private fun calculateInSampleSize(srcWidth: Int, srcHeight: Int, maxDimension: Int?): Int {
        if (srcWidth <= 0 || srcHeight <= 0) return 1
        val targetMax = maxDimension ?: 4096
        var inSampleSize = 1
        val longestSide = max(srcWidth, srcHeight)
        if (longestSide > targetMax) {
            val halfLongest = longestSide / 2
            while ((halfLongest / inSampleSize) >= targetMax) {
                inSampleSize *= 2
            }
        }
        return inSampleSize.coerceAtLeast(1)
    }

    private fun applyExifOrientation(bitmap: Bitmap, orientation: Int): Bitmap {
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.preScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.preScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> {
                matrix.postRotate(90f)
                matrix.preScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_TRANSVERSE -> {
                matrix.postRotate(270f)
                matrix.preScale(-1f, 1f)
            }
            else -> return bitmap
        }
        return runCatching {
            Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        }.getOrDefault(bitmap)
    }

    private fun scaleDownIfNeeded(bitmap: Bitmap, maxDimension: Int?): Bitmap {
        if (maxDimension == null || maxDimension <= 0) return bitmap
        val width = bitmap.width
        val height = bitmap.height
        val longest = max(width, height)
        if (longest <= maxDimension) return bitmap

        val ratio = maxDimension.toFloat() / longest.toFloat()
        val targetWidth = (width * ratio).roundToInt().coerceAtLeast(1)
        val targetHeight = (height * ratio).roundToInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, targetWidth, targetHeight, true)
    }

    private fun flattenAlphaOnWhite(source: Bitmap): Bitmap {
        val result = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.drawColor(Color.WHITE)
        canvas.drawBitmap(source, 0f, 0f, null)
        return result
    }

    private fun guessMimeTypeFromName(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        return when (ext) {
            "png" -> "image/png"
            "webp" -> "image/webp"
            "heic", "heif" -> "image/heic"
            "bmp" -> "image/bmp"
            else -> "image/jpeg"
        }
    }

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0L) return "0 KB"
        val kb = bytes / 1024.0
        return if (kb < 1024.0) {
            String.format(Locale.US, "%.1f KB", kb)
        } else {
            val mb = kb / 1024.0
            String.format(Locale.US, "%.2f MB", mb)
        }
    }
}